export interface Article {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  image: string;
  slug: string;
  colorClass: string;
  author: {
    name: string;
    avatar: string;
  };
  readTime: string;
  content?: string;
}

export const articles: Article[] = [
  {
    id: "1",
    title: "THE POWER OF SELF-CARE RITUALS",
    excerpt: "Discover transformative self-care routines that nurture your mind, body, and soul — because every woman deserves to feel radiant from the inside out.",
    date: "March 19, 2025",
    image: "https://images.unsplash.com/photo-1596178060671-7a80dc8059ea?w=800&h=800&fit=crop",
    slug: "self-care-rituals",
    colorClass: "bg-vibrant-purple",
    author: {
      name: "Amara Chen",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
    },
    readTime: "5 min",
    content: `
      <p>Self-care isn't selfish — it's essential. In a world that constantly demands more from women, carving out time for yourself is a radical act of self-love.</p>
      
      <h2>MORNING RITUALS THAT SET THE TONE</h2>
      <p>Start your day with intention. Whether it's a warm cup of tea, journaling, or a gentle skincare routine, morning rituals ground you before the world rushes in.</p>
      
      <h2>SKINCARE AS SELF-LOVE</h2>
      <p>Your skin tells your story. A consistent skincare routine isn't vanity — it's a daily reminder that you're worth the time and attention.</p>
      
      <h2>MOVEMENT THAT FEELS GOOD</h2>
      <p>Forget punishing workouts. Find movement that brings you joy — dance, yoga, walks in nature. Your body is meant to be celebrated, not punished.</p>
      
      <h2>DIGITAL DETOX</h2>
      <p>Unplug regularly. Social media comparison steals your peace. Replace scrolling with reading, creating, or simply being present.</p>
      
      <p>Self-care looks different for every woman. The key is finding what replenishes your energy and making it non-negotiable.</p>
    `
  },
  {
    id: "2",
    title: "WOMEN LEADING IN BUSINESS",
    excerpt: "Meet the bold women shattering glass ceilings and redefining leadership with empathy, vision, and unstoppable determination.",
    date: "March 15, 2025",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&h=800&fit=crop",
    slug: "women-leading-business",
    colorClass: "bg-vibrant-yellow",
    author: {
      name: "Lena Blackwell",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop"
    },
    readTime: "7 min"
  },
  {
    id: "3",
    title: "GLOWING SKIN SECRETS",
    excerpt: "Unlock the science-backed skincare tips that dermatologists swear by for naturally radiant, healthy-looking skin at every age.",
    date: "March 10, 2025",
    image: "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=800&h=800&fit=crop",
    slug: "glowing-skin-secrets",
    colorClass: "bg-vibrant-mint",
    author: {
      name: "Priya Sharma",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
    },
    readTime: "6 min"
  },
  {
    id: "4",
    title: "CONFIDENCE FROM WITHIN",
    excerpt: "True confidence isn't about perfection — it's about embracing your authentic self and owning every room you walk into.",
    date: "February 28, 2025",
    image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&h=800&fit=crop",
    slug: "confidence-from-within",
    colorClass: "bg-vibrant-coral",
    author: {
      name: "Amara Chen",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
    },
    readTime: "5 min"
  },
  {
    id: "5",
    title: "FASHION THAT EMPOWERS",
    excerpt: "How dressing intentionally can boost your mood, sharpen your mindset, and become a powerful form of self-expression.",
    date: "February 20, 2025",
    image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800&h=800&fit=crop",
    slug: "fashion-that-empowers",
    colorClass: "bg-vibrant-blue",
    author: {
      name: "Lena Blackwell",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop"
    },
    readTime: "4 min"
  },
  {
    id: "6",
    title: "WELLNESS & MENTAL HEALTH",
    excerpt: "Breaking the stigma around women's mental health and discovering practical tools for emotional resilience and inner peace.",
    date: "February 15, 2025",
    image: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800&h=800&fit=crop",
    slug: "wellness-mental-health",
    colorClass: "bg-vibrant-magenta",
    author: {
      name: "Priya Sharma",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
    },
    readTime: "6 min"
  },
  {
    id: "7",
    title: "BALANCING CAREER & LIFE",
    excerpt: "Practical strategies for ambitious women navigating the beautiful chaos of career goals, relationships, and personal fulfillment.",
    date: "February 10, 2025",
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&h=800&fit=crop",
    slug: "balancing-career-life",
    colorClass: "bg-vibrant-orange",
    author: {
      name: "Amara Chen",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
    },
    readTime: "8 min"
  },
  {
    id: "8",
    title: "WOMEN IN CREATIVE ARTS",
    excerpt: "Celebrating female artists, writers, and creators who are reshaping culture and inspiring the next generation of women.",
    date: "February 5, 2025",
    image: "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=800&h=800&fit=crop",
    slug: "women-creative-arts",
    colorClass: "bg-vibrant-lavender",
    author: {
      name: "Lena Blackwell",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop"
    },
    readTime: "5 min"
  },
  {
    id: "9",
    title: "NUTRITION FOR HER",
    excerpt: "A guide to nourishing your body with the right foods at every stage of life — from hormonal balance to peak energy.",
    date: "January 28, 2025",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800&h=800&fit=crop",
    slug: "nutrition-for-her",
    colorClass: "bg-vibrant-yellow",
    author: {
      name: "Priya Sharma",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
    },
    readTime: "7 min"
  }
];
