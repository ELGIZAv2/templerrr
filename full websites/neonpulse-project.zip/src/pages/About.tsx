import Header from "@/components/Header";
import { Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

const About = () => {
  return (
    <div className="min-h-screen bg-background animate-fade-in">
      <Header />
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-16 text-center space-y-6">
          <h1 className="text-4xl md:text-5xl lg:text-6xl leading-tight animate-slide-down">About NeonPulse</h1>
          <p className="text-lg text-muted-foreground leading-relaxed animate-slide-up stagger-1">
            Cutting through the hype to deliver sharp, honest tech analysis.
          </p>
        </div>
        <section className="mb-16 space-y-6 text-muted-foreground animate-slide-up stagger-2">
          <h2 className="text-3xl text-foreground mb-6">Our Story</h2>
          <p>NeonPulse was born from frustration with tech media that prioritizes clicks over clarity. We wanted a publication that respects readers' intelligence — one that explains the "why" behind breakthroughs, not just the "what."</p>
          <p>Our team of engineers, researchers, and journalists covers AI, robotics, cybersecurity, and emerging tech with depth and nuance. No sponsored content, no affiliate links, no hype — just signal.</p>
        </section>
        <section className="mb-16 rounded-2xl bg-card p-8 md:p-12">
          <h2 className="text-3xl mb-6">Our Mission</h2>
          <div className="space-y-4 text-muted-foreground">
            <p>We believe understanding technology is essential for navigating the future. NeonPulse is dedicated to:</p>
            <ul className="space-y-3 ml-6">
              <li className="flex items-start"><span className="mr-3 mt-1">•</span><span>Making complex tech accessible without dumbing it down</span></li>
              <li className="flex items-start"><span className="mr-3 mt-1">•</span><span>Highlighting both the promise and risks of emerging technology</span></li>
              <li className="flex items-start"><span className="mr-3 mt-1">•</span><span>Amplifying underrepresented voices in tech</span></li>
              <li className="flex items-start"><span className="mr-3 mt-1">•</span><span>Holding powerful tech companies accountable</span></li>
            </ul>
          </div>
        </section>
        <section className="text-center py-12 rounded-2xl bg-card">
          <h2 className="text-3xl mb-4">Join the Signal</h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">Subscribe for weekly deep dives into the tech that matters.</p>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8">
            <Mail className="mr-2 h-4 w-4" />Subscribe
          </Button>
        </section>
      </main>
    </div>
  );
};

export default About;
