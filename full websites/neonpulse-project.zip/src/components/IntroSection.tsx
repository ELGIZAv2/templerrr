const IntroSection = () => {
  return (
    <section className="max-w-4xl mx-auto py-12 md:py-16 px-4 animate-fade-in">
      <div className="text-center space-y-6">
        <h2 className="text-3xl md:text-4xl leading-tight animate-slide-up">
          NeonPulse cuts through the noise — delivering sharp analysis on AI, robotics, cybersecurity, and the tech shaping tomorrow.
        </h2>
        <p className="text-lg text-muted-foreground leading-relaxed max-w-3xl mx-auto animate-slide-up stagger-1">
          From deep learning breakthroughs to startup disruptions, we cover the stories that matter 
          to builders, thinkers, and anyone curious about what's next in technology.
        </p>
      </div>
    </section>
  );
};

export default IntroSection;
