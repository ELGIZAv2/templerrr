export interface Article {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  date: string;
  readTime: string;
  image: string;
  author: {
    name: string;
    avatar: string;
    bio: string;
  };
  content: {
    introduction: string;
    sections: {
      heading: string;
      content: string;
    }[];
    conclusion: string;
  };
  tags: string[];
}

export const articles: Article[] = [
  {
    id: "001",
    title: "GPT-5 and the Age of Reasoning AI",
    subtitle: "How next-gen language models are learning to think, not just predict",
    category: "AI",
    date: "Apr 28, 2026",
    readTime: "7 min",
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1920&q=80",
    author: {
      name: "Alex Voss",
      avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=800&q=80",
      bio: "AI researcher and machine learning engineer",
    },
    content: {
      introduction: "The jump from pattern matching to genuine reasoning has been AI's holy grail. With GPT-5 on the horizon, we're closer than ever to models that don't just predict the next token — they actually think through problems.",
      sections: [
        { heading: "From Prediction to Reasoning", content: "Earlier models excelled at statistical pattern matching. GPT-5 introduces chain-of-thought reasoning at a fundamental architecture level, allowing multi-step logical deduction that previous models could only approximate through prompting tricks." },
        { heading: "Benchmark Breakers", content: "On ARC-AGI, MATH, and GPQA benchmarks, GPT-5 class models show 40-60% improvement over their predecessors. More importantly, they demonstrate transfer reasoning — solving novel problem types they were never explicitly trained on." },
        { heading: "Real-World Impact", content: "From drug discovery to theorem proving, reasoning AI is already transforming industries. Companies are deploying these models for complex supply chain optimization, legal analysis, and scientific research at unprecedented speed." },
        { heading: "The Alignment Question", content: "More capable reasoning also means more capable deception. The AI safety community is racing to develop interpretability tools that can verify whether a model's reasoning chain is genuine or merely performative." },
      ],
      conclusion: "Reasoning AI isn't just an incremental improvement — it's a paradigm shift. The question isn't whether machines will think, but how we'll ensure they think in ways aligned with human values.",
    },
    tags: ["AI", "GPT-5", "reasoning", "machine learning"],
  },
  {
    id: "002",
    title: "Inside Tesla's Optimus Factory",
    subtitle: "A first look at mass-produced humanoid robots",
    category: "Robotics",
    date: "Apr 20, 2026",
    readTime: "8 min",
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=1920&q=80",
    author: {
      name: "Mira Patel",
      avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&q=80",
      bio: "Robotics journalist and hardware analyst",
    },
    content: {
      introduction: "Tesla's Fremont facility has been quietly retooled for something unprecedented: the mass production of humanoid robots. We got an exclusive tour of the Optimus Gen-3 assembly line.",
      sections: [
        { heading: "The Assembly Line", content: "Unlike traditional auto manufacturing, the Optimus line resembles a surgical theater. Clean rooms, precision actuator calibration stations, and AI-driven quality control systems inspect every joint with sub-millimeter accuracy." },
        { heading: "What Optimus Can Do", content: "Gen-3 units can navigate unstructured environments, handle fragile objects, and perform over 200 distinct manipulation tasks. Their learning system allows new skills to be uploaded fleet-wide overnight." },
        { heading: "The Economics", content: "At a projected $20,000 per unit, Tesla aims to make Optimus cheaper than a year's minimum wage salary. The economic implications for manufacturing, eldercare, and logistics are staggering." },
        { heading: "Ethical Considerations", content: "Labor unions and ethicists are raising valid concerns about workforce displacement. Tesla's response: robots will handle dangerous and tedious tasks, freeing humans for creative and supervisory roles." },
      ],
      conclusion: "Mass-produced humanoid robots are no longer science fiction. The real question is how society adapts to their presence — and whether we do so thoughtfully or reactively.",
    },
    tags: ["robotics", "Tesla", "Optimus", "manufacturing"],
  },
  {
    id: "003",
    title: "Zero-Day Markets: The Dark Economy of Exploits",
    subtitle: "How vulnerability brokers operate in the shadows",
    category: "Cybersecurity",
    date: "Apr 12, 2026",
    readTime: "6 min",
    image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1920&q=80",
    author: {
      name: "Jordan Blake",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80",
      bio: "Cybersecurity analyst and ethical hacker",
    },
    content: {
      introduction: "A single zero-day exploit for iOS can fetch $2.5 million on the open market. Welcome to the shadowy world of vulnerability brokers, where software bugs are worth more than gold.",
      sections: [
        { heading: "The Marketplace", content: "Companies like Zerodium and Crowdfense publicly advertise bounties for exploits. But beneath the surface, a darker market exists where nation-states and criminal organizations bid for exclusive access to unpatched vulnerabilities." },
        { heading: "Pricing the Unpatchable", content: "An iOS full-chain exploit with persistence commands up to $2.5M. Android equivalents fetch $2M. Browser zero-days range from $500K to $1.5M. The pricing reflects both the difficulty of discovery and the target's market share." },
        { heading: "Defense Strategies", content: "Bug bounty programs by major tech companies are one countermeasure. Apple, Google, and Microsoft now offer up to $1M for critical vulnerabilities — still a fraction of what the dark market pays, but enough to attract ethical researchers." },
        { heading: "The Arms Race", content: "As defensive AI improves at finding bugs automatically, the window between discovery and exploitation shrinks. The future of cybersecurity is a speed game — and both sides are accelerating." },
      ],
      conclusion: "The zero-day market reveals an uncomfortable truth: our digital infrastructure's security is partly determined by economic incentives. Until defensive rewards match offensive ones, the exploit economy will thrive.",
    },
    tags: ["cybersecurity", "zero-day", "exploits", "security"],
  },
  {
    id: "W001",
    title: "How AI Agents Are Replacing SaaS",
    subtitle: "The shift from software tools to autonomous digital workers",
    category: "AI",
    date: "Apr 5, 2026",
    readTime: "7 min",
    image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=1920&q=80",
    author: {
      name: "Alex Voss",
      avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=800&q=80",
      bio: "AI researcher and machine learning engineer",
    },
    content: {
      introduction: "The SaaS model — pay monthly for software you operate yourself — is being disrupted by AI agents that don't just provide tools, they do the work. Welcome to the agentic era.",
      sections: [
        { heading: "From Tools to Workers", content: "Traditional SaaS gives you a dashboard and expects you to use it. AI agents take your goal, break it into tasks, execute them autonomously, and report back. The interface isn't a UI — it's a conversation." },
        { heading: "Early Winners", content: "Companies like Devin (coding), Harvey (legal), and Glean (enterprise search) are proving the model works. Their agents don't just assist — they complete entire workflows end-to-end." },
        { heading: "The Trust Problem", content: "Giving an AI agent access to your email, calendar, and financial tools requires enormous trust. The companies solving verification, audit trails, and graceful failure modes will win." },
        { heading: "What This Means for Developers", content: "If AI agents replace SaaS UIs, developers need to think in workflows, not features. The new product surface is the agent's capability, not the pixel-perfect dashboard." },
      ],
      conclusion: "SaaS isn't dying — it's evolving. The next generation of software won't ask you to click buttons. It'll ask what you want done, then go do it.",
    },
    tags: ["AI agents", "SaaS", "automation", "startups"],
  },
  {
    id: "T001",
    title: "Quantum Computing Finally Gets Real",
    subtitle: "IBM and Google race toward practical quantum advantage",
    category: "Robotics",
    date: "Mar 28, 2026",
    readTime: "8 min",
    image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=1920&q=80",
    author: {
      name: "Mira Patel",
      avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&q=80",
      bio: "Quantum computing correspondent",
    },
    content: {
      introduction: "After decades of 'five years away,' quantum computing is delivering real results. IBM's 1,121-qubit Condor processor and Google's Willow chip are solving problems classical computers simply cannot.",
      sections: [
        { heading: "Beyond Supremacy", content: "Quantum supremacy was a milestone, but quantum advantage — solving useful problems faster than classical machines — is the real prize. Recent breakthroughs in error correction have made this practically achievable." },
        { heading: "Drug Discovery", content: "Pharmaceutical companies are using quantum simulations to model molecular interactions with unprecedented accuracy. What took months of classical computation now takes hours on quantum systems." },
        { heading: "Cryptography Implications", content: "Post-quantum cryptography standards are now essential, not theoretical. NIST has finalized new encryption standards, and organizations worldwide are racing to implement them before quantum machines can break current encryption." },
        { heading: "The Access Question", content: "Quantum computing as a service (QCaaS) is democratizing access. AWS Braket, Azure Quantum, and IBM Quantum Network let startups experiment without billion-dollar hardware investments." },
      ],
      conclusion: "Quantum computing's transition from lab curiosity to practical tool is happening now. The organizations that understand and prepare for this shift will have an enormous advantage in the next decade.",
    },
    tags: ["quantum computing", "IBM", "Google", "cryptography"],
  },
  {
    id: "G001",
    title: "The Open Source AI Revolution",
    subtitle: "How Llama, Mistral, and community models are challenging Big Tech",
    category: "AI",
    date: "Mar 20, 2026",
    readTime: "6 min",
    image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=1920&q=80",
    author: {
      name: "Jordan Blake",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80",
      bio: "Open source advocate and developer",
    },
    content: {
      introduction: "The assumption that only trillion-dollar companies can build frontier AI is being shattered. Open source models are closing the gap — and in some domains, they're winning.",
      sections: [
        { heading: "The Llama Effect", content: "Meta's decision to open-source Llama changed the game. Within months, the community fine-tuned variants that rivaled GPT-4 on specific tasks, at a fraction of the cost." },
        { heading: "Mistral and the European Push", content: "French startup Mistral proved you don't need Silicon Valley resources. Their Mixtral model demonstrated that clever architecture matters more than raw compute, inspiring a wave of efficient model designs." },
        { heading: "The Fine-Tuning Ecosystem", content: "Tools like LoRA, QLoRA, and PEFT have made it possible to customize large models on consumer hardware. A researcher with a single GPU can now create specialized AI that outperforms general-purpose giants." },
        { heading: "Challenges Ahead", content: "Open source AI faces real challenges: safety guardrails are harder to enforce, liability is unclear, and training data transparency remains an issue. But the momentum is undeniable." },
      ],
      conclusion: "Open source AI isn't just an alternative to proprietary models — it's the foundation of a more democratic, innovative, and transparent AI ecosystem. The future of AI is open.",
    },
    tags: ["open source", "Llama", "Mistral", "AI democratization"],
  },
];

export const getArticleById = (id: string): Article | undefined => {
  return articles.find(article => article.id === id);
};

export const getRelatedArticles = (currentId: string, count = 3): Article[] => {
  const current = getArticleById(currentId);
  if (!current) return articles.slice(0, count);
  return articles
    .filter(a => a.id !== currentId)
    .sort((a, b) => (a.category === current.category ? -1 : 1))
    .slice(0, count);
};
