# NeuralPulse

Cutting-edge insights on AI, machine learning, and the future of technology.

## Tech stack

- Vite
- React + TypeScript
- Tailwind CSS
- shadcn/ui

## Local development

```sh
npm install
npm run dev
```
