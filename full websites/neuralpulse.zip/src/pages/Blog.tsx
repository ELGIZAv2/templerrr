import { Link } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Section from "@/components/Section";
import ArticlePreview from "@/components/ArticlePreview";
import BlogHighlight from "@/components/BlogHighlight";
import blog1 from "@/assets/blog-1.avif";
import blog2 from "@/assets/blog-2.avif";
import blog3 from "@/assets/blog-3.avif";
import blog4 from "@/assets/blog-4.avif";
import blog5 from "@/assets/blog-5.avif";
import blog6 from "@/assets/blog-6.avif";
import blog7 from "@/assets/blog-7.avif";
import blog8 from "@/assets/blog-8.avif";
import blog9 from "@/assets/blog-9.avif";
import blog10 from "@/assets/blog-10.avif";
import malmoHero from "@/assets/malmo/malmo-hero.jpg";

const Blog = () => {
  const articlesRef = useRef<(HTMLElement | null)[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fadeInUp");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }, // Changed from 0.5 to 0.1 - triggers earlier
    );

    articlesRef.current.forEach((article) => {
      if (article) observer.observe(article);
    });

    return () => observer.disconnect();
  }, [selectedCategory]);

  const featuredArticle = {
    title: "GPT-5 and the Dawn of Reasoning Machines",
    description:
      "Inside the next leap in artificial intelligence—how multi-step reasoning models are reshaping research, engineering, and everyday work.",
    image: malmoHero,
    tag: "AI",
    slug: "mlmo-architectural-renaissance",
  };

  const articles = [
    {
      title: "Inside the Transformer Revolution",
      description: "How attention mechanisms quietly rewired modern machine learning.",
      image: blog2,
      tag: "AI",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "Humanoid Robots Hit the Factory Floor",
      description: "Boston Dynamics, Figure, and Tesla race to deploy general-purpose machines.",
      image: blog3,
      tag: "Robotics",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "The New GPU Wars",
      description: "Nvidia, AMD, and a wave of startups battle for AI silicon supremacy.",
      image: blog4,
      tag: "Hardware",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "Open Source vs. Closed Models",
      description: "Why Llama, Mistral, and DeepSeek are reshaping the AI landscape.",
      image: blog7,
      tag: "Research",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "AI-Native Startups to Watch",
      description: "The founders rebuilding entire industries on top of foundation models.",
      image: blog8,
      tag: "Startups",
      slug: "mlmo-architectural-renaissance",
    },
  ];

  const opinions = [
    {
      title: "Why Alignment Still Matters",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
      author: "Emma Thompson",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "The End of the Prompt Era",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
      author: "Marcus Chen",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "Building Trustworthy Agents",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80",
      author: "Sofia Rodriguez",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "Scaling Laws Are Not Dead",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80",
      author: "James Wilson",
      slug: "mlmo-architectural-renaissance",
    },
  ];

  const allArticles = [
    { title: "Diffusion Models for Video", description: "How Sora and Veo are turning text into cinema.", image: blog5, tag: "AI", slug: "mlmo-architectural-renaissance" },
    { title: "Neuromorphic Chips Explained", description: "Brain-inspired silicon promises massive efficiency gains.", image: blog6, tag: "Hardware", slug: "mlmo-architectural-renaissance" },
    { title: "Reinforcement Learning at Scale", description: "Training agents that master open-ended environments.", image: blog7, tag: "Research", slug: "mlmo-architectural-renaissance" },
    { title: "The Quiet Rise of Edge AI", description: "Running powerful models on phones, watches, and sensors.", image: blog8, tag: "Hardware", slug: "mlmo-architectural-renaissance" },
    { title: "Autonomous Drones in Logistics", description: "Last-mile delivery is finally taking flight.", image: blog9, tag: "Robotics", slug: "mlmo-architectural-renaissance" },
    { title: "Synthetic Data Goes Mainstream", description: "Why model trainers are turning to AI-generated datasets.", image: blog10, tag: "Research", slug: "mlmo-architectural-renaissance" },
    { title: "AI Copilots for Every Job", description: "From accountants to surgeons, agents are joining the team.", image: blog1, tag: "Startups", slug: "mlmo-architectural-renaissance" },
    { title: "The Ethics of Deepfakes", description: "Generative media is outpacing the laws meant to govern it.", image: blog2, tag: "Ethics", slug: "mlmo-architectural-renaissance" },
    { title: "Quantum + Classical Hybrids", description: "How quantum coprocessors might accelerate AI workloads.", image: blog3, tag: "Hardware", slug: "mlmo-architectural-renaissance" },
    { title: "Foundation Models for Biology", description: "Protein folding, drug design, and the new wet lab.", image: blog4, tag: "Research", slug: "mlmo-architectural-renaissance" },
    { title: "Self-Driving's Second Wind", description: "Waymo expands as Tesla bets the company on FSD.", image: blog5, tag: "Robotics", slug: "mlmo-architectural-renaissance" },
    { title: "Agentic Workflows in the Enterprise", description: "Multi-agent systems are quietly replacing SaaS dashboards.", image: blog6, tag: "AI", slug: "mlmo-architectural-renaissance" },
    { title: "The Data Center Power Crisis", description: "AI's electricity appetite is reshaping the grid.", image: blog7, tag: "Hardware", slug: "mlmo-architectural-renaissance" },
    { title: "Vision-Language Models Get Real", description: "Multimodal systems that can see, read, and reason.", image: blog8, tag: "AI", slug: "mlmo-architectural-renaissance" },
    { title: "Regulating Frontier AI", description: "EU AI Act, US executive orders, and a fragmented future.", image: blog9, tag: "Ethics", slug: "mlmo-architectural-renaissance" },
    { title: "The Robotics Foundation Model", description: "Generalist policies trained on millions of hours of motion.", image: blog10, tag: "Robotics", slug: "mlmo-architectural-renaissance" },
    { title: "Tiny Teams, Billion-Dollar AI", description: "Lean startups are punching far above their weight.", image: blog1, tag: "Startups", slug: "mlmo-architectural-renaissance" },
    { title: "Bias in Foundation Models", description: "Mitigating harmful patterns in trillion-parameter networks.", image: blog2, tag: "Ethics", slug: "mlmo-architectural-renaissance" },
    { title: "Brain-Computer Interfaces in 2026", description: "Neuralink, Synchron, and the race to read minds.", image: blog3, tag: "Hardware", slug: "mlmo-architectural-renaissance" },
    { title: "Open Weights, Closed Datasets", description: "The new transparency frontier for AI labs.", image: blog4, tag: "Research", slug: "mlmo-architectural-renaissance" },
  ];
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <Section>
        <BlogHighlight
          title={featuredArticle.title}
          description={featuredArticle.description}
          href={`/article/${featuredArticle.slug}`}
          imageSrc={featuredArticle.image}
          imageAlt={featuredArticle.title}
        />
      </Section>

      {/* Articles Grid */}
      <Section
        className="relative overflow-x-scroll scroll-smooth snap-x snap-mandatory pb-28 [-ms-overflow-style:none] [-webkit-overflow-scrolling:touch] [scrollbar-width:none] 
  [&::-webkit-scrollbar]:hidden"
      >
        <div className="m-0 flex w-full list-none items-start overflow-x-visible after:ml-[-6.25%] after:block after:flex-[0_0_calc(50vw-50%)] after:content-[''] lg:after:ml-[-4.347826087%]">
          {articles.map((article, index) => (
            <div
              key={index}
              ref={(el) => (articlesRef.current[index] = el)}
              className="m-0 mr-[6.25%] inline-flex max-w-[42rem] flex-[0_0_80%] scroll-snap-align-center sm:flex-[0_0_43.75%] lg:mr-[4.347826087%] lg:flex-[0_0_30.434783%]"
            >
              <ArticlePreview
                title={article.title}
                slug={article.slug}
                image={article.image}
                imageAlt={article.title}
                category={article.tag}
                categorySlug={article.tag.toLowerCase()}
                teaser={article.description}
              />
            </div>
          ))}
        </div>
      </Section>

      {/* Opinions Section */}
      <Section>
        <h2
          className="text-[hsl(var(--editorial-text))]"
          style={{
            width: "100%",
            marginBottom: "3rem",
            padding: "1rem 0",
            textAlign: "left",
            letterSpacing: "0.2rem",
            textTransform: "uppercase",
            borderBottom: "1px solid rgba(0, 0, 0, 0.2)",
            fontSize: "1.6rem",
            fontWeight: 600,
            lineHeight: 1.5,
          }}
        >
          Opinions
        </h2>
        <div className="m-0 grid w-full list-none gap-12 p-0 text-left sm:grid-cols-2 lg:grid-cols-[repeat(auto-fit,minmax(20rem,1fr))] 2xl:gap-24">
          {opinions.map((opinion, index) => (
            <Link
              key={index}
              to={`/article/${opinion.slug}`}
              ref={(el) => (articlesRef.current[articles.length + index] = el)}
              className="group blog-feed__item"
              style={{
                flex: "0 0 calc(25% - 2.25rem)",
                animationDelay: `${index * 150}ms`,
              }}
            >
              <article className="h-full">
                <div className="relative w-[60px] h-[60px] rounded-full overflow-hidden bg-muted mb-4">
                  <img
                    src={opinion.avatar}
                    alt={opinion.author}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <h2 className="font-sans font-semibold text-[2.2rem] md:text-[2.7rem] leading-[1.4] text-[hsl(var(--editorial-text))] text-left">
                  <span className="inline-block mb-[-0.3em] pb-[0.3em] [transition:background-position_600ms_cubic-bezier(0.45,0,0.55,1)] bg-current [background-image:linear-gradient(90deg,rgba(203,48,223,0.5)_0%,rgba(254,44,85,0.5)_46%,hsl(var(--foreground))_54%,hsl(var(--foreground))_100%)] bg-[length:220%_100%] bg-[position:100%_0] bg-clip-text text-transparent group-hover:bg-[position:0%_0]">
                    {opinion.title}
                  </span>
                </h2>
              </article>
            </Link>
          ))}
        </div>
      </Section>

      {/* More Articles Section */}
      <Section>
        <h2
          className="text-[hsl(var(--editorial-text))]"
          style={{
            width: "100%",
            marginBottom: "3rem",
            padding: "1rem 0",
            textAlign: "left",
            letterSpacing: "0.2rem",
            textTransform: "uppercase",
            borderBottom: "1px solid rgba(0, 0, 0, 0.2)",
            fontSize: "1.6rem",
            fontWeight: 600,
            lineHeight: 1.5,
          }}
        >
          More Articles
        </h2>

        {/* Category Filter Bar */}
        <div
          className="flex gap-4 mb-8 flex-wrap bg-background py-4 justify-center w-screen relative left-1/2 right-1/2 ml-0 mr-0"
          style={{
            position: "sticky",
            top: "72px",
            zIndex: 10,
            marginLeft: "calc(-50vw + 50%)",
            marginRight: "calc(-50vw + 50%)",
          }}
        >
          {["All", "AI", "Robotics", "Hardware", "Research", "Startups", "Ethics"].map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`uppercase tracking-wide text-[1.6rem] leading-[2rem] font-normal px-4 py-2 rounded-[0.6rem] transition-all duration-300 ${
                selectedCategory === category
                  ? "bg-[rgba(254,44,85,0.15)] text-[#FE2C55]"
                  : "text-[hsl(var(--foreground))] hover:text-[#FE2C55]"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid list-none gap-x-16 gap-y-24 py-8 text-left sm:grid-cols-2 lg:grid-cols-3">
          {allArticles
            .filter((article) => selectedCategory === "All" || article.tag === selectedCategory)
            .map((article, index) => (
              <div
                key={index}
                ref={(el) => (articlesRef.current[articles.length + opinions.length + index] = el)}
                className="blog-feed__item"
                style={{
                  animationDelay: `${(index % 3) * 150}ms`,
                }}
              >
                <ArticlePreview
                  title={article.title}
                  slug={article.slug}
                  image={article.image}
                  imageAlt={article.title}
                  category={article.tag}
                  categorySlug={article.tag.toLowerCase()}
                  teaser={article.description}
                />
              </div>
            ))}
        </div>
      </Section>

      <Footer />
    </div>
  );
};

export default Blog;
