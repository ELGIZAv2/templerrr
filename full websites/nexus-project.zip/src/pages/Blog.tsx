import { Link } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Section from "@/components/Section";
import ArticlePreview from "@/components/ArticlePreview";
import BlogHighlight from "@/components/BlogHighlight";
import blog1 from "@/assets/blog-1.avif";
import blog2 from "@/assets/blog-2.avif";
import blog3 from "@/assets/blog-3.avif";
import blog4 from "@/assets/blog-4.avif";
import blog5 from "@/assets/blog-5.avif";
import blog6 from "@/assets/blog-6.avif";
import blog7 from "@/assets/blog-7.avif";
import blog8 from "@/assets/blog-8.avif";
import blog9 from "@/assets/blog-9.avif";
import blog10 from "@/assets/blog-10.avif";
import malmoHero from "@/assets/malmo/malmo-hero.jpg";

const Blog = () => {
  const articlesRef = useRef<(HTMLElement | null)[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fadeInUp");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }, // Changed from 0.5 to 0.1 - triggers earlier
    );

    articlesRef.current.forEach((article) => {
      if (article) observer.observe(article);
    });

    return () => observer.disconnect();
  }, [selectedCategory]);

  const featuredArticle = {
    title: "NEXUS: Inside the AI Models Reshaping Our Reality",
    description:
      "From silicon labs to global infrastructure—an investigation into how frontier AI systems are quietly rewriting the rules of work, creativity, and power.",
    image: malmoHero,
    tag: "Artificial Intelligence",
    slug: "mlmo-architectural-renaissance",
  };

  const articles = [
    {
      title: "The Quantum Computing Race",
      description: "Inside the labs building machines that defy classical physics.",
      image: blog2,
      tag: "Quantum",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "Neural Interfaces Go Mainstream",
      description: "Brain-computer links move from science fiction to consumer reality.",
      image: blog3,
      tag: "Biotech",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "Autonomous Robotics in 2026",
      description: "How humanoid robots are entering factories, homes, and cities.",
      image: blog4,
      tag: "Robotics",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "The New Cybersecurity Frontier",
      description: "Defending critical infrastructure in an age of AI-powered attacks.",
      image: blog7,
      tag: "Security",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "Edge AI and the Smart Device Boom",
      description: "Powerful models now run entirely on your phone—and that changes everything.",
      image: blog8,
      tag: "AI",
      slug: "mlmo-architectural-renaissance",
    },
  ];

  const opinions = [
    {
      title: "Why Open Source AI Will Win",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
      author: "Emma Thompson",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "The End of the Smartphone Era",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
      author: "Marcus Chen",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "Regulating Superintelligence",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80",
      author: "Sofia Rodriguez",
      slug: "mlmo-architectural-renaissance",
    },
    {
      title: "Web3 After the Hype",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80",
      author: "James Wilson",
      slug: "mlmo-architectural-renaissance",
    },
  ];

  const allArticles = [
    { title: "Generative Video Goes Pro", description: "Hollywood-grade tools land on your laptop.", image: blog5, tag: "AI", slug: "mlmo-architectural-renaissance" },
    { title: "Inside the Chip Wars", description: "How geopolitics is rewiring the semiconductor map.", image: blog6, tag: "Hardware", slug: "mlmo-architectural-renaissance" },
    { title: "Post-Quantum Cryptography", description: "Preparing the internet for a quantum future.", image: blog7, tag: "Security", slug: "mlmo-architectural-renaissance" },
    { title: "Humanoid Robots at Work", description: "The companies deploying bipedal labor at scale.", image: blog8, tag: "Robotics", slug: "mlmo-architectural-renaissance" },
    { title: "Spatial Computing Arrives", description: "Mixed reality headsets find their killer app.", image: blog9, tag: "AR/VR", slug: "mlmo-architectural-renaissance" },
    { title: "AI Agents That Actually Work", description: "Beyond chatbots: autonomous software employees.", image: blog10, tag: "AI", slug: "mlmo-architectural-renaissance" },
    { title: "The Fusion Energy Breakthrough", description: "Startups racing to commercialize clean power.", image: blog1, tag: "Energy", slug: "mlmo-architectural-renaissance" },
    { title: "Decentralized Identity", description: "Owning your data in the post-platform internet.", image: blog2, tag: "Web3", slug: "mlmo-architectural-renaissance" },
    { title: "Satellite Internet Wars", description: "Low-orbit constellations reshape connectivity.", image: blog3, tag: "Space", slug: "mlmo-architectural-renaissance" },
    { title: "Synthetic Biology Boom", description: "Programming cells like software.", image: blog4, tag: "Biotech", slug: "mlmo-architectural-renaissance" },
    { title: "The Coding Copilot Revolution", description: "How AI is rewriting software engineering.", image: blog5, tag: "AI", slug: "mlmo-architectural-renaissance" },
    { title: "Sustainable Data Centers", description: "Cooling the carbon footprint of the cloud.", image: blog6, tag: "Energy", slug: "mlmo-architectural-renaissance" },
    { title: "Drones Beyond Delivery", description: "Autonomous aerial systems take flight.", image: blog7, tag: "Robotics", slug: "mlmo-architectural-renaissance" },
    { title: "Privacy in the Age of AI", description: "Tools to reclaim control of your digital life.", image: blog8, tag: "Security", slug: "mlmo-architectural-renaissance" },
    { title: "Mars-Bound Startups", description: "The new private space race heats up.", image: blog9, tag: "Space", slug: "mlmo-architectural-renaissance" },
    { title: "Foundation Models Explained", description: "What powers ChatGPT, Claude, and Gemini.", image: blog10, tag: "AI", slug: "mlmo-architectural-renaissance" },
    { title: "Wearable Health Tech", description: "Continuous biometrics enter mainstream medicine.", image: blog1, tag: "Biotech", slug: "mlmo-architectural-renaissance" },
    { title: "The Rise of Neuromorphic Chips", description: "Silicon designed like the human brain.", image: blog2, tag: "Hardware", slug: "mlmo-architectural-renaissance" },
    { title: "AI in Scientific Discovery", description: "Models accelerating drug and materials research.", image: blog3, tag: "AI", slug: "mlmo-architectural-renaissance" },
    { title: "Smart City Infrastructure", description: "Sensors, edge AI, and the urban OS.", image: blog4, tag: "Hardware", slug: "mlmo-architectural-renaissance" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <Section>
        <BlogHighlight
          title={featuredArticle.title}
          description={featuredArticle.description}
          href={`/article/${featuredArticle.slug}`}
          imageSrc={featuredArticle.image}
          imageAlt={featuredArticle.title}
        />
      </Section>

      {/* Articles Grid */}
      <Section
        className="relative overflow-x-scroll scroll-smooth snap-x snap-mandatory pb-28 [-ms-overflow-style:none] [-webkit-overflow-scrolling:touch] [scrollbar-width:none] 
  [&::-webkit-scrollbar]:hidden"
      >
        <div className="m-0 flex w-full list-none items-start overflow-x-visible after:ml-[-6.25%] after:block after:flex-[0_0_calc(50vw-50%)] after:content-[''] lg:after:ml-[-4.347826087%]">
          {articles.map((article, index) => (
            <div
              key={index}
              ref={(el) => (articlesRef.current[index] = el)}
              className="m-0 mr-[6.25%] inline-flex max-w-[42rem] flex-[0_0_80%] scroll-snap-align-center sm:flex-[0_0_43.75%] lg:mr-[4.347826087%] lg:flex-[0_0_30.434783%]"
            >
              <ArticlePreview
                title={article.title}
                slug={article.slug}
                image={article.image}
                imageAlt={article.title}
                category={article.tag}
                categorySlug={article.tag.toLowerCase()}
                teaser={article.description}
              />
            </div>
          ))}
        </div>
      </Section>

      {/* Opinions Section */}
      <Section>
        <h2
          className="text-[hsl(var(--editorial-text))]"
          style={{
            width: "100%",
            marginBottom: "3rem",
            padding: "1rem 0",
            textAlign: "left",
            letterSpacing: "0.2rem",
            textTransform: "uppercase",
            borderBottom: "1px solid rgba(0, 0, 0, 0.2)",
            fontSize: "1.6rem",
            fontWeight: 600,
            lineHeight: 1.5,
          }}
        >
          Opinions
        </h2>
        <div className="m-0 grid w-full list-none gap-12 p-0 text-left sm:grid-cols-2 lg:grid-cols-[repeat(auto-fit,minmax(20rem,1fr))] 2xl:gap-24">
          {opinions.map((opinion, index) => (
            <Link
              key={index}
              to={`/article/${opinion.slug}`}
              ref={(el) => (articlesRef.current[articles.length + index] = el)}
              className="group blog-feed__item"
              style={{
                flex: "0 0 calc(25% - 2.25rem)",
                animationDelay: `${index * 150}ms`,
              }}
            >
              <article className="h-full">
                <div className="relative w-[60px] h-[60px] rounded-full overflow-hidden bg-muted mb-4">
                  <img
                    src={opinion.avatar}
                    alt={opinion.author}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <h2 className="font-sans font-semibold text-[2.2rem] md:text-[2.7rem] leading-[1.4] text-[hsl(var(--editorial-text))] text-left">
                  <span className="inline-block mb-[-0.3em] pb-[0.3em] [transition:background-position_600ms_cubic-bezier(0.45,0,0.55,1)] bg-current [background-image:linear-gradient(90deg,rgba(203,48,223,0.5)_0%,rgba(254,44,85,0.5)_46%,hsl(var(--foreground))_54%,hsl(var(--foreground))_100%)] bg-[length:220%_100%] bg-[position:100%_0] bg-clip-text text-transparent group-hover:bg-[position:0%_0]">
                    {opinion.title}
                  </span>
                </h2>
              </article>
            </Link>
          ))}
        </div>
      </Section>

      {/* More Articles Section */}
      <Section>
        <h2
          className="text-[hsl(var(--editorial-text))]"
          style={{
            width: "100%",
            marginBottom: "3rem",
            padding: "1rem 0",
            textAlign: "left",
            letterSpacing: "0.2rem",
            textTransform: "uppercase",
            borderBottom: "1px solid rgba(0, 0, 0, 0.2)",
            fontSize: "1.6rem",
            fontWeight: 600,
            lineHeight: 1.5,
          }}
        >
          More Articles
        </h2>

        {/* Category Filter Bar */}
        <div
          className="flex gap-4 mb-8 flex-wrap bg-background py-4 justify-center w-screen relative left-1/2 right-1/2 ml-0 mr-0"
          style={{
            position: "sticky",
            top: "72px",
            zIndex: 10,
            marginLeft: "calc(-50vw + 50%)",
            marginRight: "calc(-50vw + 50%)",
          }}
        >
          {["All", "AI", "Robotics", "Quantum", "Biotech", "Security", "Hardware", "Space", "Energy", "AR/VR", "Web3"].map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`uppercase tracking-wide text-[1.6rem] leading-[2rem] font-normal px-4 py-2 rounded-[0.6rem] transition-all duration-300 ${
                selectedCategory === category
                  ? "bg-[rgba(254,44,85,0.15)] text-[#FE2C55]"
                  : "text-[hsl(var(--foreground))] hover:text-[#FE2C55]"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid list-none gap-x-16 gap-y-24 py-8 text-left sm:grid-cols-2 lg:grid-cols-3">
          {allArticles
            .filter((article) => selectedCategory === "All" || article.tag === selectedCategory)
            .map((article, index) => (
              <div
                key={index}
                ref={(el) => (articlesRef.current[articles.length + opinions.length + index] = el)}
                className="blog-feed__item"
                style={{
                  animationDelay: `${(index % 3) * 150}ms`,
                }}
              >
                <ArticlePreview
                  title={article.title}
                  slug={article.slug}
                  image={article.image}
                  imageAlt={article.title}
                  category={article.tag}
                  categorySlug={article.tag.toLowerCase()}
                  teaser={article.description}
                />
              </div>
            ))}
        </div>
      </Section>

      <Footer />
    </div>
  );
};

export default Blog;
