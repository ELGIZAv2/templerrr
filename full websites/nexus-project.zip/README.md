# NEXUS

A bold tech publication exploring artificial intelligence, robotics, quantum computing, and the frontier of innovation.

## Stack

- Vite + React + TypeScript
- Tailwind CSS
- shadcn/ui

## Local Development

```sh
npm install
npm run dev
```

Build for production:

```sh
npm run build
```

© NEXUS 2026
