import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface Item {
  product_id: string;
  size?: string;
  quantity: number;
}

interface Payload {
  email: string;
  first_name: string;
  last_name: string;
  phone?: string;
  shipping_address: string;
  shipping_city: string;
  shipping_postal_code: string;
  shipping_country: string;
  shipping_method?: "standard" | "express" | "overnight";
  items: Item[];
}

const SHIPPING_COSTS: Record<string, number> = { standard: 0, express: 15, overnight: 35 };

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const authHeader = req.headers.get("Authorization");
    let userId: string | null = null;
    if (authHeader) {
      const userClient = createClient(supabaseUrl, anonKey, {
        global: { headers: { Authorization: authHeader } },
      });
      const { data } = await userClient.auth.getUser();
      userId = data.user?.id ?? null;
    }

    const body = (await req.json()) as Payload;
    if (!body?.items?.length) {
      return new Response(JSON.stringify({ error: "No items" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    for (const f of ["email", "first_name", "last_name", "shipping_address", "shipping_city", "shipping_postal_code", "shipping_country"] as const) {
      if (!body[f]) {
        return new Response(JSON.stringify({ error: `Missing ${f}` }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
    }

    const admin = createClient(supabaseUrl, serviceKey);
    const ids = body.items.map((i) => i.product_id);
    const { data: products, error: prodErr } = await admin
      .from("products")
      .select("id, name, price, image_url, stock, is_active")
      .in("id", ids);
    if (prodErr) throw prodErr;

    let subtotal = 0;
    const itemRows: any[] = [];
    for (const item of body.items) {
      const p = products?.find((x) => x.id === item.product_id);
      if (!p || !p.is_active) {
        return new Response(JSON.stringify({ error: `Product unavailable: ${item.product_id}` }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      if (item.quantity < 1 || item.quantity > 10) {
        return new Response(JSON.stringify({ error: "Invalid quantity" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const unit = Number(p.price);
      subtotal += unit * item.quantity;
      itemRows.push({
        product_id: p.id,
        product_name: p.name,
        product_image: p.image_url,
        size: item.size ?? null,
        unit_price: unit,
        quantity: item.quantity,
      });
    }

    const shippingMethod = body.shipping_method ?? "standard";
    const shippingCost = SHIPPING_COSTS[shippingMethod] ?? 0;
    const total = subtotal + shippingCost;

    const { data: order, error: orderErr } = await admin
      .from("orders")
      .insert({
        user_id: userId,
        email: body.email,
        first_name: body.first_name,
        last_name: body.last_name,
        phone: body.phone ?? null,
        shipping_address: body.shipping_address,
        shipping_city: body.shipping_city,
        shipping_postal_code: body.shipping_postal_code,
        shipping_country: body.shipping_country,
        shipping_method: shippingMethod,
        shipping_cost: shippingCost,
        subtotal,
        total,
      })
      .select()
      .single();
    if (orderErr) throw orderErr;

    const { error: itemsErr } = await admin
      .from("order_items")
      .insert(itemRows.map((r) => ({ ...r, order_id: order.id })));
    if (itemsErr) throw itemsErr;

    return new Response(JSON.stringify({ order_id: order.id, total }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    console.error(e);
    return new Response(JSON.stringify({ error: e.message ?? "Server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
