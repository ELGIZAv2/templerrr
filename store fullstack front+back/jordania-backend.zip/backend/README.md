# JORDANIA — Backend

This folder mirrors the live backend that powers the storefront. The actual
runtime is **Lovable Cloud** (managed Postgres + Auth + Edge Functions); the
files here are kept as a readable reference and an easy export path.

## Structure

```
backend/
├── README.md
├── schema.sql              # Database schema (tables, RLS, triggers)
├── seed.sql                # Initial product catalog
└── functions/
    └── create-order/
        └── index.ts        # Server-side order creation (also at supabase/functions/create-order)
```

## Tables

- `profiles` — per-user info, auto-created on signup
- `user_roles` — admin/user role assignments (separate table for security)
- `products` — sneaker catalog
- `favorites` — wishlist (one row per user × product)
- `orders` + `order_items` — placed orders with snapshot of items

## Auth

- Email/password (signup + login)
- Profile and a default `user` role are created automatically on signup
- Use `has_role(user_id, 'admin')` from RLS policies to gate admin actions

## Edge functions

- `create-order` — validates the cart against live product data, computes the
  authoritative subtotal/shipping/total, and writes `orders` + `order_items`
  using the service role. Called from the checkout page via
  `supabase.functions.invoke('create-order', { body })`.

## Promoting a user to admin

Run once against the database:

```sql
insert into public.user_roles (user_id, role)
values ('<auth-user-uuid>', 'admin');
```

## Environment variables (auto-provided)

Edge functions receive `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and
`SUPABASE_SERVICE_ROLE_KEY` automatically — no setup needed.
