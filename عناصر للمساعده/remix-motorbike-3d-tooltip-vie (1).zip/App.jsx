import React, { useRef, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Canvas, useThree } from '@react-three/fiber';
import { OrbitControls, Environment, Html, ContactShadows } from '@react-three/drei';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js';

const MotorbikeModel = ({ onLoaded, onLoadStart }) => {
  const groupRef = useRef();
  const [model, setModel] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const modelData = window.UPLOADED_3D_MODELS?.find(
      (m) => m.name === '70040001-7d33-4a4c-b04e-0d52b64e0ccc.glb'
    );
    if (!modelData) {
      setError('Model not found');
      setLoading(false);
      return;
    }

    const dracoLoader = new DRACOLoader();
    dracoLoader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.7/');
    const loader = new GLTFLoader();
    loader.setDRACOLoader(dracoLoader);

    loader.load(
      modelData.dataUrl,
      (gltf) => {
        const scene = gltf.scene;

        // Center and scale
        const box = new THREE.Box3().setFromObject(scene);
        const size = box.getSize(new THREE.Vector3());
        const center = box.getCenter(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z);
        if (maxDim > 0) scene.scale.multiplyScalar(3.5 / maxDim);

        box.setFromObject(scene);
        box.getCenter(center);
        scene.position.sub(center);

        // Lift so it sits on ground
        const box2 = new THREE.Box3().setFromObject(scene);
        scene.position.y -= box2.min.y;

        // Enhance materials
        scene.traverse((child) => {
          if (child.isMesh) {
            child.castShadow = !isMobile;
            child.receiveShadow = !isMobile;
            if (child.material) {
              child.material.envMapIntensity = isMobile ? 1.2 : 2.5;
            }
          }
        });

        setModel(scene);
        if (onLoaded) onLoaded();
      },
      undefined,
      (err) => {
        console.error('Model load error:', err);
        setError('Failed to load model');
        if (onLoaded) onLoaded();
      }
    );
  }, []);

  if (error || !model) return null;

  return (
    <group ref={groupRef}>
      <primitive object={model} />
    </group>
  );
};

// Spotlight beam effect
const SpotlightBeam = ({ position, target, color }) => {
  return (
    <spotLight
      position={position}
      target-position={target}
      intensity={3}
      angle={0.35}
      penumbra={0.5}
      color={color}
      castShadow
      shadow-mapSize={[1024, 1024]}
      shadow-bias={-0.001}
    />
  );
};

const isMobile = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent) || window.innerWidth < 768;

const Ground = ({ color, roughness, metalness }) => (
  <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.005, 0]} receiveShadow>
    <planeGeometry args={[30, 30]} />
    <meshStandardMaterial color={color} roughness={roughness} metalness={metalness} envMapIntensity={0} />
  </mesh>
);

// Camera edit mode state — stored at App level, passed down
// editingCameraForId: the tooltip ID currently being camera-edited, or null

// ─── Scene Settings Store ────────────────────────────────────────────────────
const DEFAULT_SCENE = {
  ambientIntensity: 0.3,
  sunIntensity: 1.8,
  sunColor: '#fff5e0',
  bounceIntensity: 0.7,
  envPreset: 'sunset',
  bgColor: '#c7c7c7',
  fogColor: '#c7c7c7',
  fogNear: 7.5,
  fogFar: 18,
  floorColor: '#808080',
  floorRoughness: 0.7,
  floorMetalness: 0.0,
  tonemapping: 0.8,
  autoRotateSpeed: 0.6,
};

// ─── Design tokens — minimal premium dark ────────────────────────────────────
const UI = {
  bg: '#0a0a0a',
  bgPanel: '#0f0f0f',
  bgRow: '#141414',
  bgHover: '#161616',
  border: '#2a2a2a',
  borderAccent: '#c9a84c33',
  gold: '#c9a84c',
  goldDim: '#c9a84c77',
  goldFaint: '#c9a84c12',
  text: '#e8e8e8',
  textMid: '#999',
  textDim: '#555',
  red: '#c0392b',
  font: "'Inter', sans-serif",
  mono: "'Inter', monospace",
  // Bar-specific tokens — solid dark so they read against any bg
  barBg: '#0d0d0d',
  barBorder: '#222222',
  barText: '#c0c0c0',
  barTextDim: '#555',
};

// Pending click marker (before tooltip is saved)
const ClickMarker = ({ point }) => {
  if (!point) return null;
  return (
    <Html position={[point.x, point.y, point.z]} zIndexRange={[20, 0]} style={{ pointerEvents: 'none' }}>
      <div style={{
        width: '22px', height: '22px', borderRadius: '50%',
        background: '#c0392b',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transform: 'translate(-50%, -50%)',
        boxShadow: '0 2px 12px rgba(192,57,43,0.45), 0 0 0 2.5px #ffffff',
        flexShrink: 0,
      }}>
        <svg width="10" height="10" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
          <line x1="6" y1="1" x2="6" y2="11" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round"/>
          <line x1="1" y1="6" x2="11" y2="6" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      </div>
    </Html>
  );
};

const AXIS_COLORS = { x: '#e05a5a', y: '#6abf7b', z: '#5b8fe8' };

// Saved tooltip pins rendered in 3D
const TooltipPins = ({ tooltips, onRemove, selectedId, onSelect, editMode, onFlyTo, expandedId, onSetExpanded }) => {
  return tooltips.map((t) => {
    const isSelected = selectedId === t.id;
    const hasCam = !!t.hasCamera;
    const isExpanded = expandedId === t.id;
    const hasDesc = !!t.description;
    const hasDetails = t.details?.length > 0;
    const hasContent = hasDesc || hasDetails;

    return (
      <Html key={t.id} position={[t.x, t.y, t.z]} zIndexRange={[15, 0]} style={{ overflow: 'visible' }}>
        <div style={{ position: 'relative', pointerEvents: 'auto' }}>
          {/* Circle marker */}
          <div
            onPointerDown={(e) => {
              e.stopPropagation();
              if (editMode) {
                onSelect(t.id);
              } else {
                if (isExpanded) {
                  // Collapse: close card and fly back out
                  onSetExpanded(null);
                  onFlyTo(t); // toggles back since activeFlyId === t.id
                } else {
                  // Expand: fly in then show card
                  if (hasCam) onFlyTo(t);
                  if (hasContent) onSetExpanded(t.id);
                }
              }
            }}
            style={{
              width: '22px', height: '22px', borderRadius: '50%',
              background: isSelected ? '#c0392b' : '#ffffffee',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transform: 'translate(-50%, -50%)',
              cursor: editMode ? 'pointer' : ((hasCam || hasContent) ? 'pointer' : 'default'),
              boxShadow: isSelected
                ? '0 2px 12px rgba(192,57,43,0.45), 0 0 0 2.5px #ffffff'
                : hasCam && !editMode
                  ? `0 2px 12px rgba(0,0,0,0.4), 0 0 0 2px ${UI.gold}`
                  : '0 2px 12px rgba(0,0,0,0.4)',
              transition: 'all 0.15s ease',
              flexShrink: 0,
              position: 'relative',
              zIndex: 2,
            }}
          >
            <svg width="10" height="10" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="6" y1="1" x2="6" y2="11" stroke={isSelected ? '#ffffff' : '#111111'} strokeWidth="1.5" strokeLinecap="round"/>
              <line x1="1" y1="6" x2="11" y2="6" stroke={isSelected ? '#ffffff' : '#111111'} strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </div>

          {/* Tooltip bubble — label + optional expanded content */}
          {!isSelected && (
            <div
              style={{
                position: 'absolute',
                left: '18px',
                top: '-22px',
                background: '#0f0f0ff5',
                border: `1px solid ${isExpanded ? UI.gold + '55' : '#2e2e2e'}`,
                fontFamily: UI.font,
                userSelect: 'none',
                transition: 'border-color 0.2s, width 0.22s ease',
                width: isExpanded && hasContent ? '220px' : 'max-content',
                maxWidth: '220px',
                pointerEvents: 'none',
                overflow: 'hidden',
              }}
            >
              {/* Label row */}
              <div style={{
                padding: '5px 10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '8px',
                whiteSpace: 'nowrap',
              }}>
                <span style={{
                  fontSize: '15px',
                  color: '#e0e0e0',
                  letterSpacing: '0.08em',
                }}>
                  {t.label}
                </span>
              </div>

              {/* Expanded content */}
              {isExpanded && hasContent && (
                <div style={{
                  borderTop: `1px solid #2e2e2e`,
                  padding: '8px 10px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '6px',
                  animation: 'tooltipExpand 0.18s ease',
                }}>
                  <style>{`
                    @keyframes tooltipExpand {
                      from { opacity: 0; transform: translateY(-4px); }
                      to   { opacity: 1; transform: translateY(0); }
                    }
                  `}</style>

                  {hasDesc && (
                    <p style={{
                      margin: 0,
                      fontSize: '13px',
                      color: UI.textMid,
                      lineHeight: '1.65',
                      letterSpacing: '0.03em',
                      whiteSpace: 'normal',
                    }}>
                      {t.description}
                    </p>
                  )}

                  {hasDetails && (
                    <div style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '0',
                      marginTop: hasDesc ? '4px' : '0',
                    }}>
                      {t.details.map((d, i) => (
                        <div key={i} style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'baseline',
                          gap: '10px',
                          padding: '4px 0',
                          borderBottom: i < t.details.length - 1 ? `1px solid #1e1e1e` : 'none',
                        }}>
                          <span style={{
                            fontSize: '10px',
                            letterSpacing: '0.15em',
                            color: UI.textDim,
                            textTransform: 'uppercase',
                            flexShrink: 0,
                          }}>
                            {d.key}
                          </span>
                          <span style={{
                            fontSize: '13px',
                            color: UI.text,
                            letterSpacing: '0.04em',
                            textAlign: 'right',
                          }}>
                            {d.value}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </Html>
    );
  });
};

// Invisible mesh overlay that absorbs raycasts
const RaycastPlane = ({ onPick, draggingId }) => {
  const { gl, camera, scene } = useThree();

  useEffect(() => {
    const canvas = gl.domElement;

    const handleClick = (e) => {
      if (e.detail !== 1) return;
      // Suppress new picks when a tooltip is selected for gizmo editing
      if (draggingId) return;
      const rect = canvas.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera({ x, y }, camera);

      const objects = [];
      scene.traverse((obj) => {
        if (obj.isMesh && !(obj.geometry.type === 'PlaneGeometry')) objects.push(obj);
      });

      const hits = raycaster.intersectObjects(objects, true);
      if (hits.length > 0) {
        const p = hits[0].point;
        onPick({ x: parseFloat(p.x.toFixed(3)), y: parseFloat(p.y.toFixed(3)), z: parseFloat(p.z.toFixed(3)) });
      }
    };

    let downX = 0, downY = 0;
    const DRAG_THRESHOLD = 5;

    const handleMouseDown = (e) => { downX = e.clientX; downY = e.clientY; };
    const guardedClick = (e) => {
      const dx = e.clientX - downX;
      const dy = e.clientY - downY;
      if (Math.sqrt(dx * dx + dy * dy) > DRAG_THRESHOLD) return;
      handleClick(e);
    };

    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('click', guardedClick);
    return () => {
      canvas.removeEventListener('mousedown', handleMouseDown);
      canvas.removeEventListener('click', guardedClick);
    };
  }, [gl, camera, scene, onPick, draggingId]);

  return null;
};

// Add-tooltip panel — shows when there's a pending click point
const AddTooltipPanel = ({ point, onAdd, onClear, onUpdatePoint }) => {
  const [label, setLabel] = useState('');
  const [description, setDescription] = useState('');
  const [details, setDetails] = useState([{ key: '', value: '' }]);
  const [hasCamera, setHasCamera] = useState(false);

  useEffect(() => { setLabel(''); setDescription(''); setDetails([{ key: '', value: '' }]); setHasCamera(false); }, [point]);

  if (!point) return null;

  const handleAdd = () => {
    const trimmed = label.trim();
    if (!trimmed) return;
    const cleanDetails = details.filter(d => d.key.trim() || d.value.trim());
    onAdd({ ...point, label, description, details: cleanDetails, hasCamera, id: Date.now() });
    setLabel('');
    setDescription('');
    setDetails([{ key: '', value: '' }]);
    setHasCamera(false);
  };

  return (
    <div style={{
      position: 'fixed',
      bottom: '80px',
      left: '50%',
      transform: 'translateX(-50%)',
      background: '#0d0d0d',
      border: `1px solid ${UI.border}`,
      padding: '0',
      fontFamily: UI.font,
      zIndex: 20,
      width: '280px',
      boxSizing: 'border-box',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '10px 14px',
        borderBottom: `1px solid ${UI.border}`,
      }}>
        <div style={{ fontSize: '8px', letterSpacing: '0.2em', color: UI.textMid, textTransform: 'uppercase' }}>
          New Tooltip
        </div>
        <button onClick={onClear} style={{
          background: 'none', border: 'none', color: UI.textDim,
          cursor: 'pointer', fontSize: '11px', lineHeight: 1, padding: '0 2px',
        }}>✕</button>
      </div>

      <div style={{ padding: '12px 14px' }}>
        {/* Position scrubbers */}
        <div style={{ fontSize: '8px', letterSpacing: '0.18em', color: UI.textDim, textTransform: 'uppercase', marginBottom: '8px' }}>
          Position
        </div>
        <div style={{ display: 'flex', gap: '6px', marginBottom: '14px' }}>
          {['x', 'y', 'z'].map((axis) => (
            <ScrubInput
              key={axis}
              axis={axis}
              value={point[axis]}
              onChange={(val) => onUpdatePoint({ ...point, [axis]: val })}
            />
          ))}
        </div>

        {/* Label input */}
        <div style={{ fontSize: '8px', letterSpacing: '0.18em', color: UI.textDim, textTransform: 'uppercase', marginBottom: '8px' }}>
          Label
        </div>
        <input
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
          placeholder="Engine, Headlight…"
          style={{
            width: '100%',
            background: 'transparent',
            border: 'none',
            borderBottom: `1px solid ${UI.border}`,
            color: UI.text,
            fontFamily: UI.font,
            fontSize: '12px',
            padding: '6px 0',
            marginBottom: '14px',
            boxSizing: 'border-box',
            outline: 'none',
            letterSpacing: '0.04em',
          }}
          autoFocus
        />

        {/* Description */}
        <div style={{ fontSize: '8px', letterSpacing: '0.18em', color: UI.textDim, textTransform: 'uppercase', marginBottom: '8px' }}>
          Description
        </div>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Optional description…"
          rows={2}
          style={{
            width: '100%',
            background: 'transparent',
            border: 'none',
            borderBottom: `1px solid ${UI.border}`,
            color: UI.text,
            fontFamily: UI.font,
            fontSize: '11px',
            padding: '6px 0',
            marginBottom: '14px',
            boxSizing: 'border-box',
            outline: 'none',
            resize: 'none',
            letterSpacing: '0.03em',
            lineHeight: '1.6',
          }}
        />

        {/* Details rows */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
          <div style={{ fontSize: '8px', letterSpacing: '0.18em', color: UI.textDim, textTransform: 'uppercase' }}>
            Details
          </div>
          <button
            onClick={() => setDetails(d => [...d, { key: '', value: '' }])}
            style={{ background: 'none', border: 'none', color: UI.textDim, cursor: 'pointer', fontSize: '14px', lineHeight: 1, padding: 0 }}
            onMouseEnter={e => e.currentTarget.style.color = UI.gold}
            onMouseLeave={e => e.currentTarget.style.color = UI.textDim}
          >+</button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '14px' }}>
          {details.map((d, i) => (
            <div key={i} style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
              <input
                value={d.key}
                onChange={e => setDetails(prev => prev.map((r, j) => j === i ? { ...r, key: e.target.value } : r))}
                placeholder="Label"
                style={{ flex: 1, background: 'transparent', border: 'none', borderBottom: `1px solid ${UI.border}`, color: UI.textMid, fontFamily: UI.font, fontSize: '10px', padding: '4px 0', outline: 'none', minWidth: 0 }}
              />
              <input
                value={d.value}
                onChange={e => setDetails(prev => prev.map((r, j) => j === i ? { ...r, value: e.target.value } : r))}
                placeholder="Value"
                style={{ flex: 1, background: 'transparent', border: 'none', borderBottom: `1px solid ${UI.border}`, color: UI.text, fontFamily: UI.font, fontSize: '10px', padding: '4px 0', outline: 'none', minWidth: 0 }}
              />
              {details.length > 1 && (
                <button
                  onClick={() => setDetails(prev => prev.filter((_, j) => j !== i))}
                  style={{ background: 'none', border: 'none', color: UI.textDim, cursor: 'pointer', fontSize: '11px', padding: '0 2px', lineHeight: 1, flexShrink: 0 }}
                  onMouseEnter={e => e.currentTarget.style.color = UI.red}
                  onMouseLeave={e => e.currentTarget.style.color = UI.textDim}
                >✕</button>
              )}
            </div>
          ))}
        </div>

        {/* Camera keyframe checkbox */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
          <label
            htmlFor="new-tooltip-cam"
            style={{
              fontSize: '7px', letterSpacing: '0.2em', color: UI.textDim,
              textTransform: 'uppercase', cursor: 'pointer', userSelect: 'none',
            }}
          >
            Camera Keyframe
          </label>
          <input
            id="new-tooltip-cam"
            type="checkbox"
            checked={hasCamera}
            onChange={(e) => setHasCamera(e.target.checked)}
            style={{ accentColor: UI.gold, width: '13px', height: '13px', cursor: 'pointer' }}
          />
        </div>

        {/* Add button */}
        <button onClick={handleAdd} disabled={!label.trim()} style={{
          width: '100%',
          background: label.trim() ? UI.gold : 'transparent',
          border: `1px solid ${label.trim() ? UI.gold : UI.border}`,
          color: label.trim() ? '#0a0a0a' : UI.textDim,
          fontFamily: UI.font,
          fontSize: '9px',
          fontWeight: '700',
          letterSpacing: '0.2em',
          textTransform: 'uppercase',
          padding: '9px 0',
          cursor: label.trim() ? 'pointer' : 'default',
          transition: 'all 0.15s ease',
        }}>
          Add Tooltip
        </button>
      </div>
    </div>
  );
};

// Scrubber input: click+drag horizontally to change value, or click to type
const ScrubInput = ({ axis, value, onChange }) => {
  const [editing, setEditing] = useState(false);
  const [raw, setRaw] = useState('');
  const inputRef = useRef();

  const handlePointerDown = (e) => {
    if (editing) return;
    e.preventDefault();
    const startX = e.clientX;
    const startVal = value;
    let moved = false;

    const onMove = (me) => {
      const dx = me.clientX - startX;
      if (Math.abs(dx) > 2) moved = true;
      if (moved) onChange(parseFloat((startVal + dx * 0.005).toFixed(3)));
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      if (!moved) {
        setRaw(value.toFixed(3));
        setEditing(true);
        setTimeout(() => inputRef.current?.select(), 0);
      }
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const commitEdit = () => {
    const parsed = parseFloat(raw);
    if (!isNaN(parsed)) onChange(parseFloat(parsed.toFixed(3)));
    setEditing(false);
  };

  const col = AXIS_COLORS[axis];

  return (
    <div style={{ flex: 1 }}>
      <div style={{
        fontSize: '7px', color: col, letterSpacing: '0.2em',
        marginBottom: '5px', textAlign: 'center',
        textTransform: 'uppercase', opacity: 0.8,
      }}>
        {axis.toUpperCase()}
      </div>
      {editing ? (
        <input
          ref={inputRef}
          value={raw}
          onChange={(e) => setRaw(e.target.value)}
          onBlur={commitEdit}
          onKeyDown={(e) => { if (e.key === 'Enter') commitEdit(); if (e.key === 'Escape') setEditing(false); }}
          style={{
            width: '100%',
            background: 'transparent',
            border: 'none',
            borderBottom: `1px solid ${col}`,
            color: UI.text,
            fontFamily: UI.mono,
            fontSize: '11px',
            padding: '3px 0',
            textAlign: 'center',
            outline: 'none',
            boxSizing: 'border-box',
            letterSpacing: '0.05em',
          }}
        />
      ) : (
        <div
          onPointerDown={handlePointerDown}
          style={{
            background: 'transparent',
            borderBottom: `1px solid ${UI.border}`,
            color: UI.textMid,
            fontFamily: UI.mono,
            fontSize: '11px',
            padding: '3px 0',
            textAlign: 'center',
            cursor: 'ew-resize',
            userSelect: 'none',
            fontVariantNumeric: 'tabular-nums',
            letterSpacing: '0.03em',
            transition: 'color 0.15s, border-color 0.15s',
          }}
          onMouseEnter={(e) => { e.currentTarget.style.color = UI.text; e.currentTarget.style.borderColor = col; }}
          onMouseLeave={(e) => { e.currentTarget.style.color = UI.textMid; e.currentTarget.style.borderColor = UI.border; }}
        >
          {value.toFixed(3)}
        </div>
      )}
    </div>
  );
};

// Saved tooltips panel — slide-in side drawer
const ExpandedEditor = ({ t, onMove, onRename, onSetCamera, onClearCamera, onUpdateTooltip }) => {
  const [labelVal, setLabelVal] = useState(t.label);
  const [labelEditing, setLabelEditing] = useState(false);
  const [descVal, setDescVal] = useState(t.description || '');
  const [details, setDetails] = useState(t.details?.length ? t.details : [{ key: '', value: '' }]);
  const labelInputRef = useRef();
  const hasCam = !!t.hasCamera;

  useEffect(() => { setLabelVal(t.label); }, [t.label]);
  useEffect(() => { setDescVal(t.description || ''); }, [t.description]);
  useEffect(() => { setDetails(t.details?.length ? t.details : [{ key: '', value: '' }]); }, [t.id]);

  const commitDesc = () => {
    onUpdateTooltip(t.id, { description: descVal });
  };

  const commitDetails = (newDetails) => {
    const clean = newDetails.filter(d => d.key.trim() || d.value.trim());
    onUpdateTooltip(t.id, { details: clean });
  };

  const commitLabel = () => {
    const trimmed = labelVal.trim();
    if (trimmed && trimmed !== t.label) onRename(t.id, trimmed);
    else setLabelVal(t.label);
    setLabelEditing(false);
  };

  return (
    <div style={{
      background: UI.bg,
      borderBottom: `1px solid ${UI.border}`,
      padding: '10px 16px 14px',
    }}>
      {/* Label rename */}
      <div style={{ fontSize: '7px', letterSpacing: '0.2em', color: UI.textDim, textTransform: 'uppercase', marginBottom: '6px' }}>
        Label
      </div>
      <div style={{ marginBottom: '14px' }}>
        {labelEditing ? (
          <input
            ref={labelInputRef}
            value={labelVal}
            onChange={(e) => setLabelVal(e.target.value)}
            onBlur={commitLabel}
            onKeyDown={(e) => { if (e.key === 'Enter') commitLabel(); if (e.key === 'Escape') { setLabelVal(t.label); setLabelEditing(false); } }}
            style={{
              width: '100%',
              background: 'transparent',
              border: 'none',
              borderBottom: `1px solid ${UI.gold}`,
              color: UI.text,
              fontFamily: UI.font,
              fontSize: '12px',
              padding: '5px 0',
              outline: 'none',
              boxSizing: 'border-box',
              letterSpacing: '0.05em',
            }}
          />
        ) : (
          <div
            onClick={() => { setLabelEditing(true); setTimeout(() => labelInputRef.current?.select(), 0); }}
            style={{
              borderBottom: `1px solid ${UI.border}`,
              color: UI.text,
              fontFamily: UI.font,
              fontSize: '12px',
              padding: '5px 0',
              cursor: 'text',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              letterSpacing: '0.05em',
            }}
          >
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.label}</span>
            <span style={{ fontSize: '9px', color: UI.textDim, marginLeft: '6px', flexShrink: 0 }}>✎</span>
          </div>
        )}
      </div>

      {/* Description */}
      <div style={{ fontSize: '7px', letterSpacing: '0.2em', color: UI.textDim, textTransform: 'uppercase', marginBottom: '6px' }}>
        Description
      </div>
      <textarea
        value={descVal}
        onChange={e => setDescVal(e.target.value)}
        onBlur={commitDesc}
        placeholder="Optional description…"
        rows={2}
        style={{
          width: '100%',
          background: 'transparent',
          border: 'none',
          borderBottom: `1px solid ${UI.border}`,
          color: UI.text,
          fontFamily: UI.font,
          fontSize: '11px',
          padding: '5px 0',
          marginBottom: '14px',
          boxSizing: 'border-box',
          outline: 'none',
          resize: 'none',
          letterSpacing: '0.03em',
          lineHeight: '1.6',
        }}
      />

      {/* Details rows */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
        <div style={{ fontSize: '7px', letterSpacing: '0.2em', color: UI.textDim, textTransform: 'uppercase' }}>Details</div>
        <button
          onClick={() => setDetails(d => [...d, { key: '', value: '' }])}
          style={{ background: 'none', border: 'none', color: UI.textDim, cursor: 'pointer', fontSize: '14px', lineHeight: 1, padding: 0 }}
          onMouseEnter={e => e.currentTarget.style.color = UI.gold}
          onMouseLeave={e => e.currentTarget.style.color = UI.textDim}
        >+</button>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '16px' }}>
        {details.map((d, i) => (
          <div key={i} style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
            <input
              value={d.key}
              onChange={e => { const next = details.map((r, j) => j === i ? { ...r, key: e.target.value } : r); setDetails(next); }}
              onBlur={() => commitDetails(details)}
              placeholder="Label"
              style={{ flex: 1, background: 'transparent', border: 'none', borderBottom: `1px solid ${UI.border}`, color: UI.textMid, fontFamily: UI.font, fontSize: '10px', padding: '4px 0', outline: 'none', minWidth: 0 }}
            />
            <input
              value={d.value}
              onChange={e => { const next = details.map((r, j) => j === i ? { ...r, value: e.target.value } : r); setDetails(next); }}
              onBlur={() => commitDetails(details)}
              placeholder="Value"
              style={{ flex: 1, background: 'transparent', border: 'none', borderBottom: `1px solid ${UI.border}`, color: UI.text, fontFamily: UI.font, fontSize: '10px', padding: '4px 0', outline: 'none', minWidth: 0 }}
            />
            {details.length > 1 && (
              <button
                onClick={() => { const next = details.filter((_, j) => j !== i); setDetails(next); commitDetails(next); }}
                style={{ background: 'none', border: 'none', color: UI.textDim, cursor: 'pointer', fontSize: '11px', padding: '0 2px', lineHeight: 1, flexShrink: 0 }}
                onMouseEnter={e => e.currentTarget.style.color = UI.red}
                onMouseLeave={e => e.currentTarget.style.color = UI.textDim}
              >✕</button>
            )}
          </div>
        ))}
      </div>

      {/* Position scrubbers */}
      <div style={{ fontSize: '7px', letterSpacing: '0.2em', color: UI.textDim, textTransform: 'uppercase', marginBottom: '8px' }}>
        Position
      </div>
      <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
        {['x', 'y', 'z'].map((axis) => (
          <ScrubInput
            key={axis}
            axis={axis}
            value={t[axis]}
            onChange={(val) => onMove(t.id, { ...t, [axis]: val })}
          />
        ))}
      </div>

      {/* Camera keyframe */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <label
          htmlFor={`cam-toggle-${t.id}`}
          style={{
            fontSize: '7px', letterSpacing: '0.2em', color: UI.textDim,
            textTransform: 'uppercase', cursor: 'pointer', userSelect: 'none',
          }}
        >
          Camera Keyframe
        </label>
        <input
          id={`cam-toggle-${t.id}`}
          type="checkbox"
          checked={hasCam}
          onChange={(e) => {
            if (e.target.checked) onSetCamera(t.id);
            else onClearCamera(t.id);
          }}
          style={{ accentColor: UI.gold, width: '13px', height: '13px', cursor: 'pointer' }}
        />
      </div>
    </div>
  );
};

const CopySingleButton = ({ tooltip }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e) => {
    e.stopPropagation();
    const data = {
      label: tooltip.label,
      position: { x: tooltip.x, y: tooltip.y, z: tooltip.z },
      hasCamera: tooltip.hasCamera ?? false,
      description: tooltip.description || '',
      details: tooltip.details || [],
    };
    const prefix = `Use these settings for the tooltip "${tooltip.label}"\n`;
    navigator.clipboard.writeText(prefix + JSON.stringify(data, null, 2)).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  };

  return (
    <button
      onClick={handleCopy}
      title="Copy JSON"
      style={{
        background: 'none', border: 'none', padding: '2px 4px',
        cursor: 'pointer', color: copied ? UI.gold : UI.textDim,
        transition: 'color 0.15s', lineHeight: 1, display: 'flex', alignItems: 'center',
      }}
      onMouseEnter={(e) => { if (!copied) e.currentTarget.style.color = UI.text; }}
      onMouseLeave={(e) => { if (!copied) e.currentTarget.style.color = UI.textDim; }}
    >
      {copied
        ? <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><polyline points="1,6 4.5,9.5 11,2.5" stroke={UI.gold} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
        : <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><rect x="4" y="1" width="7" height="8" rx="1" stroke="currentColor" strokeWidth="1.2"/><rect x="1" y="3" width="7" height="8" rx="1" stroke="currentColor" strokeWidth="1.2" fill="#0f0f0f"/></svg>
      }
    </button>
  );
};

const TooltipInfoCard = ({ tooltip, onClose }) => {
  const hasDetails = tooltip.details?.length > 0;
  const hasDesc = !!tooltip.description;

  return (
    <div style={{
      position: 'fixed',
      bottom: '80px',
      left: '50%',
      transform: 'translateX(-50%)',
      background: '#0d0d0d',
      border: `1px solid ${UI.border}`,
      fontFamily: UI.font,
      zIndex: 20,
      width: '300px',
      boxSizing: 'border-box',
      animation: 'fadeSlideUp 0.2s ease',
    }}>
      <style>{`
        @keyframes fadeSlideUp {
          from { opacity: 0; transform: translateX(-50%) translateY(8px); }
          to   { opacity: 1; transform: translateX(-50%) translateY(0); }
        }
      `}</style>
      {/* Header */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '10px 14px',
        borderBottom: `1px solid ${UI.border}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <svg width="9" height="9" viewBox="0 0 12 12" fill="none">
            <circle cx="6" cy="6" r="2" fill={UI.gold}/>
            <path d="M6 1v2M6 9v2M1 6h2M9 6h2" stroke={UI.gold} strokeWidth="1.2" strokeLinecap="round"/>
          </svg>
          <span style={{ fontSize: '10px', fontWeight: '600', letterSpacing: '0.1em', color: UI.text, textTransform: 'uppercase' }}>
            {tooltip.label}
          </span>
        </div>
        <button onClick={onClose} style={{
          background: 'none', border: 'none', color: UI.textDim,
          cursor: 'pointer', fontSize: '11px', lineHeight: 1, padding: '0 2px',
        }}>✕</button>
      </div>

      <div style={{ padding: '12px 14px' }}>
        {/* Description */}
        {hasDesc && (
          <p style={{
            fontSize: '11px', color: UI.textMid, lineHeight: '1.7',
            letterSpacing: '0.03em', margin: 0,
            marginBottom: hasDetails ? '14px' : 0,
          }}>
            {tooltip.description}
          </p>
        )}

        {/* Details table */}
        {hasDetails && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
            {tooltip.details.map((d, i) => (
              <div key={i} style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '7px 0',
                borderBottom: i < tooltip.details.length - 1 ? `1px solid ${UI.border}` : 'none',
                gap: '12px',
              }}>
                <span style={{ fontSize: '9px', letterSpacing: '0.15em', color: UI.textDim, textTransform: 'uppercase', flexShrink: 0 }}>
                  {d.key}
                </span>
                <span style={{ fontSize: '11px', color: UI.text, letterSpacing: '0.04em', textAlign: 'right' }}>
                  {d.value}
                </span>
              </div>
            ))}
          </div>
        )}

        {!hasDesc && !hasDetails && (
          <div style={{ fontSize: '11px', color: UI.textDim, letterSpacing: '0.05em' }}>
            No details available.
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Scene Settings Panel ─────────────────────────────────────────────────────

const SettingsRow = ({ label, children }) => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px', padding: '7px 0', borderBottom: `1px solid ${UI.border}` }}>
    <span style={{ fontSize: '9px', letterSpacing: '0.15em', color: UI.textDim, textTransform: 'uppercase', flexShrink: 0 }}>{label}</span>
    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>{children}</div>
  </div>
);

const SliderInput = ({ value, min, max, step = 0.01, onChange }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
    <input
      type="range" min={min} max={max} step={step} value={value}
      onChange={e => onChange(parseFloat(e.target.value))}
      style={{ width: '90px', accentColor: UI.gold, cursor: 'pointer' }}
    />
    <span style={{ fontFamily: UI.mono, fontSize: '10px', color: UI.textMid, minWidth: '34px', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
      {value.toFixed(2)}
    </span>
  </div>
);

const ColorInput = ({ value, onChange }) => (
  <input
    type="color" value={value}
    onChange={e => onChange(e.target.value)}
    style={{ width: '28px', height: '20px', border: `1px solid ${UI.border}`, cursor: 'pointer', background: 'none', padding: '1px', borderRadius: '2px' }}
  />
);

const SelectInput = ({ value, options, onChange }) => (
  <select
    value={value} onChange={e => onChange(e.target.value)}
    style={{
      background: UI.bgRow, border: `1px solid ${UI.border}`, color: UI.text,
      fontFamily: UI.font, fontSize: '9px', letterSpacing: '0.1em',
      padding: '3px 6px', cursor: 'pointer', outline: 'none',
    }}
  >
    {options.map(o => <option key={o} value={o}>{o}</option>)}
  </select>
);

const SceneSettingsPanel = ({ scene, onUpdate, settingsOpen, setSettingsOpen }) => {
  const [copied, setCopied] = useState(false);

  const handleExport = () => {
    const prefix = 'Use these scene settings to restore the scene configuration.\n';
    navigator.clipboard.writeText(prefix + JSON.stringify(scene, null, 2)).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  };

  const handleReset = () => onUpdate(DEFAULT_SCENE);

  const s = (key) => (val) => onUpdate({ ...scene, [key]: val });

  const ENV_PRESETS = ['dawn', 'sunset', 'night', 'warehouse', 'forest', 'apartment', 'studio', 'city', 'park', 'lobby'];

  return (
    <>
      {/* Toggle tab — left side */}
      <div
        onClick={() => setSettingsOpen(v => !v)}
        style={{
          position: 'fixed',
          top: '50%',
          left: settingsOpen ? '280px' : '0px',
          transform: 'translateY(-50%)',
          transition: 'left 0.3s cubic-bezier(0.4,0,0.2,1)',
          background: '#111111',
          borderTop: `1px solid ${UI.border}`,
          borderBottom: `1px solid ${UI.border}`,
          borderRight: `1px solid ${UI.border}`,
          width: '36px',
          cursor: 'pointer',
          zIndex: 30,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          userSelect: 'none',
          overflow: 'hidden',
        }}
      >
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '20px 0' }}>
          <div style={{
            writingMode: 'vertical-rl', textOrientation: 'mixed', transform: 'rotate(180deg)',
            fontFamily: UI.font, fontSize: '7.5px', letterSpacing: '0.22em',
            color: UI.gold, textTransform: 'uppercase', fontWeight: '500',
          }}>
            Scene
          </div>
        </div>
      </div>

      {/* Drawer */}
      <div style={{
        position: 'fixed', top: 0, left: settingsOpen ? '0px' : '-280px',
        width: '280px', height: '100%',
        background: UI.bgPanel, borderRight: `1px solid ${UI.border}`,
        transition: 'left 0.3s cubic-bezier(0.4,0,0.2,1)',
        zIndex: 25, display: 'flex', flexDirection: 'column',
        fontFamily: UI.font, boxSizing: 'border-box',
      }}>
        {/* Header */}
        <div style={{ padding: '18px 16px 14px', borderBottom: `1px solid ${UI.border}`, flexShrink: 0 }}>
          <div style={{ fontSize: '8px', letterSpacing: '0.25em', color: UI.textDim, textTransform: 'uppercase', marginBottom: '8px' }}>
            Configuration
          </div>
          <div style={{ fontSize: '16px', fontFamily: "'Instrument Serif', serif", fontWeight: '400', color: UI.text, letterSpacing: '0.04em' }}>
            Scene Settings
          </div>
        </div>

        {/* Scrollable content */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 16px' }}>

          {/* Lighting */}
          <div style={{ padding: '12px 0 4px', fontSize: '7px', letterSpacing: '0.25em', color: UI.gold, textTransform: 'uppercase', marginTop: '4px' }}>
            Lighting
          </div>
          <SettingsRow label="Ambient">
            <SliderInput value={scene.ambientIntensity} min={0} max={5} step={0.05} onChange={s('ambientIntensity')} />
          </SettingsRow>
          <SettingsRow label="Sun Intensity">
            <SliderInput value={scene.sunIntensity} min={0} max={10} step={0.1} onChange={s('sunIntensity')} />
          </SettingsRow>
          <SettingsRow label="Sun Color">
            <ColorInput value={scene.sunColor} onChange={s('sunColor')} />
          </SettingsRow>
          <SettingsRow label="Bounce Light">
            <SliderInput value={scene.bounceIntensity} min={0} max={3} step={0.05} onChange={s('bounceIntensity')} />
          </SettingsRow>
          <SettingsRow label="Exposure">
            <SliderInput value={scene.tonemapping} min={0.3} max={2.0} step={0.01} onChange={s('tonemapping')} />
          </SettingsRow>
          <SettingsRow label="Environment">
            <SelectInput value={scene.envPreset} options={ENV_PRESETS} onChange={s('envPreset')} />
          </SettingsRow>

          {/* Background & Fog */}
          <div style={{ padding: '16px 0 4px', fontSize: '7px', letterSpacing: '0.25em', color: UI.gold, textTransform: 'uppercase' }}>
            Background
          </div>
          <SettingsRow label="BG Color">
            <ColorInput value={scene.bgColor} onChange={s('bgColor')} />
          </SettingsRow>
          <SettingsRow label="Fog Color">
            <ColorInput value={scene.fogColor} onChange={s('fogColor')} />
          </SettingsRow>
          <SettingsRow label="Fog Near">
            <SliderInput value={scene.fogNear} min={2} max={30} step={0.5} onChange={s('fogNear')} />
          </SettingsRow>
          <SettingsRow label="Fog Far">
            <SliderInput value={scene.fogFar} min={10} max={80} step={1} onChange={s('fogFar')} />
          </SettingsRow>

          {/* Floor */}
          <div style={{ padding: '16px 0 4px', fontSize: '7px', letterSpacing: '0.25em', color: UI.gold, textTransform: 'uppercase' }}>
            Floor
          </div>
          <SettingsRow label="Color">
            <ColorInput value={scene.floorColor} onChange={s('floorColor')} />
          </SettingsRow>
          <SettingsRow label="Roughness">
            <SliderInput value={scene.floorRoughness} min={0} max={1} step={0.01} onChange={s('floorRoughness')} />
          </SettingsRow>
          <SettingsRow label="Metalness">
            <SliderInput value={scene.floorMetalness} min={0} max={1} step={0.01} onChange={s('floorMetalness')} />
          </SettingsRow>

          {/* Camera */}
          <div style={{ padding: '16px 0 4px', fontSize: '7px', letterSpacing: '0.25em', color: UI.gold, textTransform: 'uppercase' }}>
            Camera
          </div>
          <SettingsRow label="Rotate Speed">
            <SliderInput value={scene.autoRotateSpeed} min={0.1} max={5} step={0.05} onChange={s('autoRotateSpeed')} />
          </SettingsRow>

          {/* Reset */}
          <button
            onClick={handleReset}
            style={{
              marginTop: '18px', width: '100%', background: 'transparent',
              border: `1px solid ${UI.border}`, color: UI.textDim,
              fontFamily: UI.font, fontSize: '9px', fontWeight: '600',
              letterSpacing: '0.18em', textTransform: 'uppercase',
              padding: '8px 0', cursor: 'pointer', transition: 'all 0.15s',
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = UI.textMid; e.currentTarget.style.color = UI.text; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = UI.border; e.currentTarget.style.color = UI.textDim; }}
          >
            Reset Defaults
          </button>
        </div>

        {/* Footer — export */}
        <div style={{ padding: '12px 16px', borderTop: `1px solid ${UI.border}`, flexShrink: 0 }}>
          <button
            onClick={handleExport}
            onMouseEnter={e => { if (!copied) { e.currentTarget.style.background = '#d4b05a'; e.currentTarget.style.borderColor = '#d4b05a'; }}}
            onMouseLeave={e => { if (!copied) { e.currentTarget.style.background = UI.gold; e.currentTarget.style.borderColor = UI.gold; }}}
            style={{
              width: '100%', background: copied ? 'transparent' : UI.gold,
              border: `1px solid ${copied ? UI.gold : UI.gold}`,
              color: copied ? UI.gold : '#0a0a0a',
              fontFamily: UI.font, fontSize: '9px', fontWeight: '700',
              letterSpacing: '0.18em', textTransform: 'uppercase',
              padding: '9px 0', cursor: 'pointer', transition: 'all 0.2s ease',
            }}
          >
            {copied ? '✓ Copied' : 'Export JSON'}
          </button>
        </div>
      </div>
    </>
  );
};

// ─── Saved Tooltips Panel ─────────────────────────────────────────────────────
const SavedTooltipsPanel = ({ tooltips, onRemove, selectedId, onSelect, onMove, onRename, onSetCamera, onClearCamera, onUpdateTooltip, panelOpen, setPanelOpen, editMode }) => {
  const open = panelOpen;
  const setOpen = setPanelOpen;
  const [copied, setCopied] = useState(false);

  const handleCopyAll = () => {
    const data = tooltips.map(({ label, x, y, z, hasCamera, description, details }) => ({
      label,
      position: { x, y, z },
      hasCamera: hasCamera ?? false,
      description: description || '',
      details: details || [],
    }));
    const prefix = `Use these tooltip settings for the scene. Create them if they don't exist, or update them if the name matches an existing tooltip.\n`;
    navigator.clipboard.writeText(prefix + JSON.stringify(data, null, 2)).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  };

  return (
    <>
      {/* Toggle tab */}
      <div
        onClick={() => setOpen((v) => !v)}
        style={{
          position: 'fixed',
          top: '50%',
          right: open ? '280px' : '0px',
          transform: 'translateY(-50%)',
          transition: 'right 0.3s cubic-bezier(0.4,0,0.2,1)',
          background: '#111111',
          borderTop: `1px solid ${UI.border}`,
          borderBottom: `1px solid ${UI.border}`,
          borderLeft: `1px solid ${UI.border}`,
          width: '36px',
          cursor: 'pointer',
          zIndex: 30,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          userSelect: 'none',
          overflow: 'hidden',
        }}
      >
        <div style={{
          width: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '20px 0',
        }}>
          <div style={{
            writingMode: 'vertical-rl',
            textOrientation: 'mixed',
            transform: 'rotate(180deg)',
            fontFamily: UI.font,
            fontSize: '7.5px',
            letterSpacing: '0.22em',
            color: UI.gold,
            textTransform: 'uppercase',
            fontWeight: '500',
          }}>
            Tooltips
          </div>
        </div>
      </div>

      {/* Drawer */}
      <div style={{
        position: 'fixed',
        top: 0,
        right: open ? '0px' : '-280px',
        width: '280px',
        height: '100%',
        background: UI.bgPanel,
        borderLeft: `1px solid ${UI.border}`,
        transition: 'right 0.3s cubic-bezier(0.4,0,0.2,1)',
        zIndex: 25,
        display: 'flex',
        flexDirection: 'column',
        fontFamily: UI.font,
        boxSizing: 'border-box',
      }}>
        {/* Drawer header */}
        <div style={{
          padding: '18px 16px 14px',
          borderBottom: `1px solid ${UI.border}`,
          flexShrink: 0,
        }}>
          <div style={{ fontSize: '8px', letterSpacing: '0.25em', color: UI.textDim, textTransform: 'uppercase', marginBottom: '8px' }}>
            Annotations
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div style={{ fontSize: '16px', fontFamily: "'Instrument Serif', serif", fontWeight: '400', color: UI.text, letterSpacing: '0.04em' }}>
              Tooltips
            </div>
            {tooltips.length > 0 && (
              <div style={{ fontSize: '10px', color: UI.textDim, letterSpacing: '0.05em' }}>
                {tooltips.length} placed
              </div>
            )}
          </div>
        </div>

        {/* Tooltip list */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0', display: 'flex', flexDirection: 'column' }}>
          {tooltips.length === 0 ? (
            <div style={{
              textAlign: 'center',
              color: UI.textDim,
              fontSize: '11px',
              marginTop: '40px',
              lineHeight: '1.8',
              letterSpacing: '0.05em',
              padding: '0 20px',
            }}>
              No tooltips yet.<br />
              <span style={{ color: '#333' }}>Click on the model to add one.</span>
            </div>
          ) : (
            tooltips.map((t, i) => {
              const isSelected = selectedId === t.id;
              return (
                <div key={t.id}>
                  {/* Separator line */}
                  {i > 0 && <div style={{ height: '1px', background: UI.border }} />}

                  {/* Row */}
                  <div
                    onClick={() => editMode && onSelect(isSelected ? null : t.id)}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      background: isSelected ? `${UI.gold}0f` : 'transparent',
                      padding: '10px 16px',
                      cursor: 'pointer',
                      userSelect: 'none',
                      transition: 'background 0.15s',
                      borderLeft: isSelected ? `2px solid ${UI.gold}` : '2px solid transparent',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', minWidth: 0 }}>
                      <div style={{
                        width: '3px', height: '12px', flexShrink: 0,
                        background: isSelected ? UI.gold : '#2a2a2a',
                        transition: 'background 0.2s',
                      }} />
                      <span style={{
                        fontSize: '11px',
                        color: isSelected ? UI.text : UI.textMid,
                        fontWeight: '400',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                        letterSpacing: '0.05em',
                      }}>
                        {t.label}
                      </span>
                    </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
                      <CopySingleButton tooltip={t} />
                      {editMode && (
                        <span style={{ fontSize: '8px', color: UI.textDim }}>
                          {isSelected ? '▴' : '▾'}
                        </span>
                      )}
                      {editMode && (
                        <button
                          onClick={(e) => { e.stopPropagation(); onRemove(t.id); }}
                          style={{
                            background: 'none', border: 'none', color: UI.textDim,
                            cursor: 'pointer', fontSize: '11px', lineHeight: 1,
                            padding: '0 2px', transition: 'color 0.15s',
                            fontFamily: UI.font,
                          }}
                          onMouseEnter={(e) => e.currentTarget.style.color = UI.red}
                          onMouseLeave={(e) => e.currentTarget.style.color = UI.textDim}
                        >✕</button>
                      )}
                    </div>
                  </div>

                  {/* Expanded XYZ editor — only in edit mode */}
                  {isSelected && editMode && (
                    <ExpandedEditor t={t} onMove={onMove} onRename={onRename} onSetCamera={onSetCamera} onClearCamera={onClearCamera} onUpdateTooltip={onUpdateTooltip} />
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Edit mode hint */}
        {!editMode && tooltips.length === 0 && (
          <div style={{
            textAlign: 'center',
            color: UI.textDim,
            fontSize: '11px',
            marginTop: '40px',
            lineHeight: '1.8',
            letterSpacing: '0.05em',
            padding: '0 20px',
          }}>
            Switch to <span style={{ color: UI.gold }}>Edit</span> mode<br />
            <span style={{ color: '#333' }}>to add tooltips.</span>
          </div>
        )}

        {/* Footer */}
        {tooltips.length > 0 && (
          <div style={{ padding: '12px 16px', borderTop: `1px solid ${UI.border}`, flexShrink: 0 }}>
            <button
              onClick={handleCopyAll}
              onMouseEnter={(e) => { if (!copied) { e.currentTarget.style.background = '#d4b05a'; e.currentTarget.style.borderColor = '#d4b05a'; }}}
              onMouseLeave={(e) => { if (!copied) { e.currentTarget.style.background = UI.gold; e.currentTarget.style.borderColor = UI.gold; }}}
              style={{
                width: '100%',
                background: copied ? 'transparent' : UI.gold,
                border: `1px solid ${copied ? UI.gold : UI.gold}`,
                color: copied ? UI.gold : '#0a0a0a',
                fontFamily: UI.font,
                fontSize: '9px',
                fontWeight: '700',
                letterSpacing: '0.18em',
                textTransform: 'uppercase',
                padding: '9px 0',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
            >
              {copied ? '✓ Copied' : 'Export JSON'}
            </button>
          </div>
        )}
      </div>
    </>
  );
};

// Floating label UI
const ModeToggle = ({ editMode, onToggle }) => (
  <div style={{
    position: 'fixed',
    top: '20px',
    left: '50%',
    transform: 'translateX(-50%)',
    zIndex: 30,
    display: 'flex',
    alignItems: 'center',
    fontFamily: UI.font,
    background: 'rgba(10,10,10,0.75)',
    border: `1px solid ${UI.border}`,
    backdropFilter: 'blur(10px)',
    WebkitBackdropFilter: 'blur(10px)',
    overflow: 'hidden',
    height: '36px',
  }}>
    {[{ label: 'View', value: false }, { label: 'Edit', value: true }].map(({ label, value }, i) => {
      const active = editMode === value;
      return (
        <button
          key={label}
          onClick={() => { if (!active) onToggle(); }}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px',
            padding: '0 16px',
            background: 'transparent',
            border: 'none',
            borderRight: i === 0 ? `1px solid ${UI.border}` : 'none',
            color: active ? (value ? UI.gold : UI.text) : UI.textDim,
            fontFamily: UI.font,
            fontSize: '9px',
            fontWeight: '400',
            letterSpacing: '0.15em',
            textTransform: 'uppercase',
            cursor: active ? 'default' : 'pointer',
            transition: 'all 0.15s ease',
            height: '100%',
          }}
          onMouseEnter={(e) => { if (!active) e.currentTarget.style.color = '#e8e8e8'; }}
          onMouseLeave={(e) => { if (!active) e.currentTarget.style.color = UI.textDim; }}
        >
          <div style={{
            width: '5px', height: '5px', borderRadius: '50%',
            background: active ? (value ? UI.gold : UI.text) : 'transparent',
            border: active ? 'none' : `1px solid ${UI.textDim}`,
            transition: 'background 0.15s, border 0.15s',
            flexShrink: 0,
          }} />
          {label}
        </button>
      );
    })}
  </div>
);

// Overlay shown during camera-edit sub-mode — no longer used but kept for safety
const CameraEditOverlay = ({ tooltip, onSave, onCancel }) => (
  <div style={{
    position: 'fixed',
    inset: 0,
    zIndex: 50,
    pointerEvents: 'none',
    fontFamily: UI.font,
  }}>
    {/* Top banner */}
    <div style={{
      position: 'absolute',
      top: '44px',
      left: 0,
      right: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '12px',
      padding: '10px 20px',
      background: '#0d0d0dcc',
      borderBottom: `1px solid ${UI.gold}44`,
      backdropFilter: 'blur(4px)',
    }}>
      <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
        <circle cx="6" cy="6" r="2" fill={UI.gold}/>
        <path d="M6 1v2M6 9v2M1 6h2M9 6h2" stroke={UI.gold} strokeWidth="1.2" strokeLinecap="round"/>
      </svg>
      <span style={{ fontSize: '9px', letterSpacing: '0.22em', color: UI.gold, textTransform: 'uppercase', fontWeight: '600' }}>
        Camera Edit
      </span>
      <span style={{ fontSize: '9px', color: UI.textMid, letterSpacing: '0.1em' }}>
        —
      </span>
      <span style={{ fontSize: '9px', color: UI.textMid, letterSpacing: '0.1em' }}>
        Orbit to frame <span style={{ color: UI.text }}>"{tooltip.label}"</span>, then save
      </span>
    </div>

    {/* Bottom action bar */}
    <div style={{
      position: 'absolute',
      bottom: '40px',
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      gap: '8px',
      pointerEvents: 'auto',
    }}>
      <button
        onClick={onCancel}
        style={{
          background: '#111', border: `1px solid ${UI.border}`,
          color: UI.textMid, fontFamily: UI.font,
          fontSize: '9px', fontWeight: '600', letterSpacing: '0.18em',
          textTransform: 'uppercase', padding: '9px 24px',
          cursor: 'pointer', transition: 'all 0.15s',
        }}
        onMouseEnter={(e) => { e.currentTarget.style.borderColor = UI.textMid; e.currentTarget.style.color = UI.text; }}
        onMouseLeave={(e) => { e.currentTarget.style.borderColor = UI.border; e.currentTarget.style.color = UI.textMid; }}
      >
        Cancel
      </button>
      <button
        onClick={onSave}
        style={{
          background: UI.gold, border: `1px solid ${UI.gold}`,
          color: '#0a0a0a', fontFamily: UI.font,
          fontSize: '9px', fontWeight: '700', letterSpacing: '0.18em',
          textTransform: 'uppercase', padding: '9px 28px',
          cursor: 'pointer', transition: 'all 0.15s',
        }}
        onMouseEnter={(e) => { e.currentTarget.style.background = '#d4b05a'; e.currentTarget.style.borderColor = '#d4b05a'; }}
        onMouseLeave={(e) => { e.currentTarget.style.background = UI.gold; e.currentTarget.style.borderColor = UI.gold; }}
      >
        Save Camera
      </button>
    </div>
  </div>
);

const ShowcaseUI = ({ clickPoint, onClearClick, onAddTooltip, onUpdatePoint, tooltips, onRemoveTooltip, selectedId, onSelect, onMove, onRename, onSetCamera, onClearCamera, onUpdateTooltip, onResetCamera, onToggleAutoRotate, autoRotate, panelOpen, setPanelOpen, editMode, onToggleEditMode, infoTooltip, onCloseInfo, tooltipsHidden, onToggleTooltips, scene, onUpdateScene, settingsOpen, setSettingsOpen }) => {
  return (
    <>
      {/* Floating title */}
      <div style={{
        position: 'fixed',
        top: '20px',
        left: '20px',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        fontFamily: UI.font,
        pointerEvents: 'none',
        zIndex: 10,
        background: 'rgba(10,10,10,0.75)',
        border: `1px solid ${UI.border}`,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        padding: '0 16px',
        height: '36px',
      }}>
        <div style={{ width: '1px', height: '14px', background: UI.gold, flexShrink: 0, opacity: 0.7 }} />
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '10px' }}>
          <div style={{ fontSize: '14px', fontFamily: "'Instrument Serif', serif", fontWeight: '400', letterSpacing: '0.06em', color: '#e8e8e8' }}>
            Motorbike Viewer
          </div>
          <div style={{ fontSize: '9px', letterSpacing: '0.18em', color: '#aaa', textTransform: 'uppercase' }}>
            3D Showcase
          </div>
        </div>
      </div>

      {/* Floating bottom controls */}
      <div style={{
        position: 'fixed',
        bottom: '20px',
        left: '50%',
        transform: 'translateX(-50%)',
        display: 'flex',
        alignItems: 'center',
        fontFamily: UI.font,
        zIndex: 10,
        background: 'rgba(10,10,10,0.75)',
        border: `1px solid ${UI.border}`,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        overflow: 'hidden',
      }}>
        {/* Hide Tooltips */}
        <button
          onClick={onToggleTooltips}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px',
            background: 'transparent',
            border: 'none',
            borderRight: `1px solid ${UI.border}`,
            color: tooltipsHidden ? UI.gold : UI.barText,
            fontFamily: UI.font,
            fontSize: '9px',
            letterSpacing: '0.15em',
            textTransform: 'uppercase',
            padding: '0 16px',
            height: '36px',
            cursor: 'pointer',
            transition: 'color 0.15s',
          }}
          onMouseEnter={(e) => { if (!tooltipsHidden) e.currentTarget.style.color = '#e8e8e8'; }}
          onMouseLeave={(e) => { if (!tooltipsHidden) e.currentTarget.style.color = UI.barText; }}
        >
          <div style={{
            width: '5px', height: '5px', borderRadius: '50%',
            background: tooltipsHidden ? UI.gold : UI.barText,
            transition: 'background 0.15s', flexShrink: 0,
          }} />
          {tooltipsHidden ? 'Show Pins' : 'Hide Pins'}
        </button>

        {/* Reset Camera */}
        <button
          onClick={onResetCamera}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px',
            background: 'transparent',
            border: 'none',
            borderRight: `1px solid ${UI.border}`,
            color: UI.barText,
            fontFamily: UI.font,
            fontSize: '9px',
            letterSpacing: '0.15em',
            textTransform: 'uppercase',
            padding: '0 16px',
            height: '36px',
            cursor: 'pointer',
            transition: 'color 0.15s',
          }}
          onMouseEnter={(e) => e.currentTarget.style.color = '#e8e8e8'}
          onMouseLeave={(e) => e.currentTarget.style.color = UI.barText}
        >
          Reset Camera
        </button>

        {/* Auto Rotate toggle */}
        <button
          onClick={onToggleAutoRotate}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px',
            background: 'transparent',
            border: 'none',
            color: autoRotate ? UI.gold : UI.barText,
            fontFamily: UI.font,
            fontSize: '9px',
            letterSpacing: '0.15em',
            textTransform: 'uppercase',
            padding: '0 16px',
            height: '36px',
            cursor: 'pointer',
            transition: 'color 0.15s',
          }}
          onMouseEnter={(e) => { if (!autoRotate) e.currentTarget.style.color = '#e8e8e8'; }}
          onMouseLeave={(e) => { if (!autoRotate) e.currentTarget.style.color = UI.barText; }}
        >
          <div style={{
            width: '5px', height: '5px', borderRadius: '50%',
            background: autoRotate ? UI.gold : UI.barText,
            transition: 'background 0.15s', flexShrink: 0,
          }} />
          {autoRotate ? 'Rotating' : 'Auto Rotate'}
        </button>
      </div>

      <ModeToggle editMode={editMode} onToggle={onToggleEditMode} />
      {editMode && <SceneSettingsPanel scene={scene} onUpdate={onUpdateScene} settingsOpen={settingsOpen} setSettingsOpen={setSettingsOpen} />}
      {editMode && <AddTooltipPanel point={clickPoint} onAdd={onAddTooltip} onClear={onClearClick} onUpdatePoint={onUpdatePoint} />}
      {editMode && <SavedTooltipsPanel tooltips={tooltips} onRemove={onRemoveTooltip} selectedId={selectedId} onSelect={onSelect} onMove={onMove} onRename={onRename} onSetCamera={onSetCamera} onClearCamera={onClearCamera} onUpdateTooltip={onUpdateTooltip} panelOpen={panelOpen} setPanelOpen={setPanelOpen} editMode={editMode} />}
    </>
  );
};

const DEFAULT_CAMERA = { position: [-2.4, 1.25, 3.1], target: [0, 1.1, 0] };

// Smooth camera animation hook
const useCameraFlyTo = (orbitRef) => {
  const animRef = useRef(null);

  const flyTo = (position, target, duration = 1000) => {
    if (!orbitRef.current) return;
    const controls = orbitRef.current;
    const cam = controls.object;

    const startPos = cam.position.clone();
    const startTarget = controls.target.clone();
    const endPos = new THREE.Vector3(...position);
    const endTarget = new THREE.Vector3(...target);

    const startTime = performance.now();
    if (animRef.current) cancelAnimationFrame(animRef.current);

    const tick = (now) => {
      const t = Math.min((now - startTime) / duration, 1);
      const e = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      cam.position.lerpVectors(startPos, endPos, e);
      controls.target.lerpVectors(startTarget, endTarget, e);
      controls.update();
      if (t < 1) animRef.current = requestAnimationFrame(tick);
    };
    animRef.current = requestAnimationFrame(tick);
  };

  // Fly toward a target point from the current camera direction, at a set distance
  const flyToTarget = (targetArr, zoomDistance = 2.0, duration = 1000) => {
    if (!orbitRef.current) return;
    const controls = orbitRef.current;
    const cam = controls.object;

    const endTarget = new THREE.Vector3(...targetArr);

    // Keep current camera direction, just re-anchor it to the new target
    const currentDir = cam.position.clone().sub(controls.target).normalize();
    const endPos = endTarget.clone().add(currentDir.multiplyScalar(zoomDistance));

    flyTo(endPos.toArray(), targetArr, duration);
  };

  return { flyTo, flyToTarget };
};

const LoaderOverlay = () => createPortal(
  <>
    <style>{`
      @keyframes spin { to { transform: rotate(360deg); } }

    `}</style>
    <div style={{
      position: 'fixed',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'Inter, sans-serif',
      background: '#c7c7c7',
      zIndex: 9999,
    }}>
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '16px',
        }}>
          <div style={{
            width: '36px',
            height: '36px',
            border: '2px solid rgba(0,0,0,0.15)',
            borderTop: '2px solid #8a6a1f',
            borderRadius: '50%',
            animation: 'spin 0.9s linear infinite',
            flexShrink: 0,
          }} />
          <div style={{
            fontSize: '9px',
            fontWeight: '600',
            letterSpacing: '0.22em',
            textTransform: 'uppercase',
            color: '#3a3a3a',
          }}>
            Loading Model
          </div>
        </div>
    </div>
  </>,
  document.body
);

export default function App() {
  const [modelLoaded, setModelLoaded] = useState(false);
  const [clickPoint, setClickPoint] = useState(null);
  const [tooltips, setTooltips] = useState([
    {
      id: 1,
      label: "Instrument Cluster",
      x: -0.959, y: 1.761, z: -0.001,
      hasCamera: true,
      description: "Full-colour TFT display with real-time ride data, navigation prompts, and ambient light adjustment.",
      details: [
        { key: "Resolution", value: "1920 × 1080" },
        { key: "Size", value: "5.0 inch" },
        { key: "Brightness", value: "1000 nit" },
        { key: "Type", value: "TFT LCD" },
      ],
    },
    {
      id: 2,
      label: "Rear Suspension",
      x: 0.497, y: 1.051, z: 0.012,
      hasCamera: true,
      description: "Piggyback monoshock with adjustable preload and rebound damping for a composed, planted ride.",
      details: [
        { key: "Type", value: "Monoshock" },
        { key: "Travel", value: "130 mm" },
        { key: "Preload", value: "Adjustable" },
        { key: "Damping", value: "Rebound Adj." },
      ],
    },
    {
      id: 3,
      label: "Rear Tyre",
      x: 1.653, y: 0.87, z: 0.016,
      hasCamera: true,
      description: "Wide-profile radial tyre engineered for maximum grip under hard acceleration and high-lean cornering.",
      details: [
        { key: "Size", value: "190/55 ZR17" },
        { key: "Type", value: "Radial" },
        { key: "Compound", value: "Dual Sport" },
        { key: "Rim", value: "17 inch" },
      ],
    },
    {
      id: 4,
      label: "Front Brakes",
      x: -0.974, y: 0.623, z: 0.187,
      hasCamera: true,
      description: "Radially mounted monoblock caliper with petal disc for short, progressive stopping power.",
      details: [
        { key: "Type", value: "Radial Monoblock" },
        { key: "Disc", value: "320 mm Petal" },
        { key: "Pistons", value: "4-Piston" },
        { key: "System", value: "ABS Ready" },
      ],
    },
    {
      id: 5,
      label: "Engine",
      x: 0.024, y: 0.83, z: 0.311,
      hasCamera: true,
      description: "Liquid-cooled parallel-twin with a 270° firing order delivering strong mid-range torque and a distinctive exhaust note.",
      details: [
        { key: "Layout", value: "Parallel Twin" },
        { key: "Displacement", value: "889 cc" },
        { key: "Power", value: "119 hp" },
        { key: "Torque", value: "93 Nm" },
      ],
    },
    {
      id: 6,
      label: "Drive Chain",
      x: 1.125, y: 0.401, z: 0.205,
      hasCamera: true,
      description: "Heavy-duty sealed O-ring chain transferring power from gearbox to rear wheel with minimal energy loss.",
      details: [
        { key: "Type", value: "O-Ring Sealed" },
        { key: "Pitch", value: "525" },
        { key: "Links", value: "116" },
        { key: "Sprocket", value: "17 / 45 T" },
      ],
    },
    {
      id: 7,
      label: "Seat",
      x: 0.781, y: 1.528, z: 0.007,
      hasCamera: true,
      description: "Ergonomically contoured split seat with high-density foam for all-day comfort on both rider and pillion.",
      details: [
        { key: "Height", value: "820 mm" },
        { key: "Material", value: "Alcantara" },
        { key: "Style", value: "Split Dual" },
        { key: "Heating", value: "Optional" },
      ],
    },
  ]);
  const [draggingId, setDraggingId] = useState(null);
  const [autoRotate, setAutoRotate] = useState(true);
  const [editMode, setEditMode] = useState(false);
  const orbitRef = useRef();
  const { flyTo, flyToTarget } = useCameraFlyTo(orbitRef);

  const handleAddTooltip = (t) => {
    setTooltips((prev) => [...prev, t]);
    setClickPoint(null);
  };

  const handleRemoveTooltip = (id) => {
    setTooltips((prev) => prev.filter((t) => t.id !== id));
    setDraggingId((prev) => (prev === id ? null : prev));
  };

  const [panelOpen, setPanelOpen] = useState(false);

  const handleSelectTooltip = (id) => {
    const wasOpen = panelOpen;
    const next = draggingId === id ? null : id;
    setDraggingId(next);
    setClickPoint(null);
    if (next !== null) {
      setPanelOpen(true);
    } else if (!wasOpen) {
      setPanelOpen(false);
    }
  };

  const handleMoveTooltip = (id, pos) => {
    setTooltips((prev) => prev.map((t) => t.id === id ? { ...t, ...pos } : t));
  };

  const handleRenameTooltip = (id, label) => {
    setTooltips((prev) => prev.map((t) => t.id === id ? { ...t, label } : t));
  };

  const handleResetCamera = () => {
    flyTo(DEFAULT_CAMERA.position, DEFAULT_CAMERA.target, 800);
  };

  const handleSetCamera = (id) => {
    setTooltips((prev) => prev.map((t) =>
      t.id === id ? { ...t, hasCamera: true } : t
    ));
  };

  const handleClearCamera = (id) => {
    setTooltips((prev) => prev.map((t) =>
      t.id === id ? { ...t, hasCamera: false } : t
    ));
  };

  const [scene, setScene] = useState(DEFAULT_SCENE);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [activeFlyId, setActiveFlyId] = useState(null);
  const [infoTooltip, setInfoTooltip] = useState(null);
  const [expandedPinId, setExpandedPinId] = useState(null);
  const [tooltipsHidden, setTooltipsHidden] = useState(false);

  const handleFlyTo = (tooltip) => {
    if (!tooltip.hasCamera) return;
    if (activeFlyId === tooltip.id) {
      setActiveFlyId(null);
      // Zoom back out: keep the current look direction but pull camera back to default distance
      if (orbitRef.current) {
        const controls = orbitRef.current;
        const cam = controls.object;
        // Current direction from target to camera
        const currentDir = cam.position.clone().sub(controls.target).normalize();
        const endTarget = new THREE.Vector3(...DEFAULT_CAMERA.target);
        const defaultDist = new THREE.Vector3(...DEFAULT_CAMERA.position)
          .distanceTo(new THREE.Vector3(...DEFAULT_CAMERA.target));
        const endPos = endTarget.clone().add(currentDir.multiplyScalar(defaultDist));
        flyTo(endPos.toArray(), DEFAULT_CAMERA.target, 1000);
      }
    } else {
      setActiveFlyId(tooltip.id);
      setAutoRotate(false);
      flyToTarget([tooltip.x, tooltip.y, tooltip.z], 2.0, 1000);
    }
  };

  const handleUpdateTooltip = (id, patch) => {
    setTooltips(prev => prev.map(t => t.id === id ? { ...t, ...patch } : t));
    // Keep info card in sync
    setInfoTooltip(prev => prev?.id === id ? { ...prev, ...patch } : prev);
  };

  return (
    <div style={{ width: '100vw', height: '100vh', background: UI.bg }}>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet" />
      <ShowcaseUI
        clickPoint={clickPoint}
        onClearClick={() => setClickPoint(null)}
        onAddTooltip={handleAddTooltip}
        onUpdatePoint={setClickPoint}
        tooltips={tooltips}
        onRemoveTooltip={handleRemoveTooltip}
        selectedId={draggingId}
        onSelect={handleSelectTooltip}
        onMove={handleMoveTooltip}
        onRename={handleRenameTooltip}
        onSetCamera={handleSetCamera}
        onClearCamera={handleClearCamera}
        onUpdateTooltip={handleUpdateTooltip}
        onResetCamera={handleResetCamera}
        onToggleAutoRotate={() => setAutoRotate((v) => !v)}
        autoRotate={autoRotate}
        panelOpen={panelOpen}
        setPanelOpen={setPanelOpen}
        editMode={editMode}
        infoTooltip={infoTooltip}
        onCloseInfo={() => { setInfoTooltip(null); setActiveFlyId(null); flyTo(DEFAULT_CAMERA.position, DEFAULT_CAMERA.target, 800); }}
        tooltipsHidden={tooltipsHidden}
        onToggleTooltips={() => setTooltipsHidden(v => !v)}
        scene={scene}
        onUpdateScene={setScene}
        settingsOpen={settingsOpen}
        setSettingsOpen={setSettingsOpen}
        onToggleEditMode={() => {
          setEditMode((v) => {
            const next = !v;
            if (next) {
              setAutoRotate(false);
              setActiveFlyId(null);
              setExpandedPinId(null);
            } else {
              setClickPoint(null);
              setDraggingId(null);
              setAutoRotate(true);
              setActiveFlyId(null);
              setExpandedPinId(null);
            }
            return next;
          });
        }}
      />
      {!modelLoaded && <LoaderOverlay />}
      <Canvas
        shadows={!isMobile}
        camera={{ position: [-2.4, 1.25, 3.1], fov: 47, }}
        dpr={isMobile ? [1, 1.5] : [1, 2]}
        gl={{ antialias: !isMobile, toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: scene.tonemapping, powerPreference: 'high-performance' }}
        performance={{ min: 0.5 }}
      >
        <color attach="background" args={[scene.bgColor]} />
        <fog attach="fog" args={[scene.fogColor, scene.fogNear, scene.fogFar]} />

        <ambientLight intensity={scene.ambientIntensity} color="#fff8f0" />

        {/* Sun — strong directional from upper-right */}
        <directionalLight
          position={[8, 14, 6]}
          intensity={scene.sunIntensity}
          color={scene.sunColor}
          castShadow={!isMobile}
          shadow-mapSize={isMobile ? [512, 512] : [1024, 1024]}
          shadow-camera-near={0.5}
          shadow-camera-far={40}
          shadow-camera-left={-10}
          shadow-camera-right={10}
          shadow-camera-top={10}
          shadow-camera-bottom={-10}
          shadow-bias={-0.001}
          shadow-normalBias={0.02}
          shadow-radius={isMobile ? 4 : 8}
        />
        {/* Sky fill — soft neutral from above */}
        <hemisphereLight args={['#ffffff', '#c8a87a', 1.2]} />
        {/* Bounce light from ground — skip on mobile */}
        {!isMobile && <pointLight position={[0, 0.5, 0]} intensity={scene.bounceIntensity} color="#ffe8c0" />}

        <MotorbikeModel onLoaded={() => setModelLoaded(true)} />
        <RaycastPlane onPick={editMode ? setClickPoint : () => {}} draggingId={draggingId} />
        {clickPoint && !draggingId && editMode && <ClickMarker point={clickPoint} />}
        {!tooltipsHidden && <TooltipPins tooltips={tooltips} onRemove={handleRemoveTooltip} selectedId={draggingId} onSelect={editMode ? handleSelectTooltip : () => {}} editMode={editMode} onFlyTo={handleFlyTo} expandedId={expandedPinId} onSetExpanded={setExpandedPinId} />}

        <Ground color={scene.floorColor} roughness={scene.floorRoughness} metalness={scene.floorMetalness} />
        {!isMobile && (
          <ContactShadows
            position={[0, 0, 0]}
            opacity={0.4}
            scale={14}
            blur={1}
            far={5}
            color="#000000"
            resolution={512}
          />
        )}

        <Environment preset={scene.envPreset} resolution={isMobile ? 128 : 256} />

        <OrbitControls
          ref={orbitRef}
          enabled={true}
          enablePan={true}
          mouseButtons={{ LEFT: 0, MIDDLE: 1, RIGHT: 2 }}
          minPolarAngle={0}
          maxPolarAngle={(95 * Math.PI) / 180}
          minDistance={1}
          maxDistance={10}
          autoRotate={autoRotate}
          autoRotateSpeed={scene.autoRotateSpeed}
          target={[0, 1.1, 0]}
        />
      </Canvas>
    </div>
  );
}