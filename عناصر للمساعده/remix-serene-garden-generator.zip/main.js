// Scene setup
const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf5f0e8);
scene.fog = new THREE.FogExp2(0xf5f0e8, 0.012);

// --- GENERATE BUTTON ---
const btn = document.createElement('button');
btn.textContent = 'Generate';
btn.style.cssText = `
  position: fixed; bottom: 40px; left: 50%; transform: translateX(-50%);
  z-index: 100; padding: 8px 24px; font-family: 'Playfair Display', Georgia, serif;
  font-size: 13px; font-weight: 500; letter-spacing: 0.04em;
  background: #faf7f2; color: #1a1a1a;
  border: 1px solid rgba(0,0,0,0.12); border-radius: 999px;
  cursor: pointer; backdrop-filter: blur(8px); transition: all 0.2s ease; line-height: 1.4;
  box-sizing: border-box;
`;
btn.addEventListener('mouseenter', () => { btn.style.background = '#f0ece4'; btn.style.borderColor = 'rgba(0,0,0,0.25)'; });
btn.addEventListener('mouseleave', () => { btn.style.background = '#faf7f2'; btn.style.borderColor = 'rgba(0,0,0,0.12)'; });
document.body.appendChild(btn);

// --- MUTE/UNMUTE BUTTON ---
let audioMuted = false;
const muteBtn = document.createElement('button');
const svgSoundOn = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>`;
const svgSoundOff = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>`;
muteBtn.innerHTML = svgSoundOn;
muteBtn.style.cssText = `
  position: fixed; bottom: 40px; right: 24px;
  z-index: 100; width: 36px; height: 36px;
  font-size: 16px; line-height: 1;
  background: #faf7f2; color: #1a1a1a;
  border: 1px solid rgba(0,0,0,0.12); border-radius: 50%;
  cursor: pointer; backdrop-filter: blur(8px); transition: all 0.2s ease;
  display: flex; align-items: center; justify-content: center;
  padding: 0; box-sizing: border-box;
`;
muteBtn.addEventListener('mouseenter', () => { muteBtn.style.background = '#f0ece4'; muteBtn.style.borderColor = 'rgba(0,0,0,0.25)'; });
muteBtn.addEventListener('mouseleave', () => { muteBtn.style.background = '#faf7f2'; muteBtn.style.borderColor = 'rgba(0,0,0,0.12)'; });
muteBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  audioMuted = !audioMuted;
  if (audioCtx) {
    if (audioMuted) {
      audioCtx.suspend();
      muteBtn.innerHTML = svgSoundOff;
    } else {
      audioCtx.resume();
      muteBtn.innerHTML = svgSoundOn;
    }
  }
});
document.body.appendChild(muteBtn);

const link = document.createElement('link');
link.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600&display=swap';
link.rel = 'stylesheet';
document.head.appendChild(link);

// --- AMBIENT SOUND (procedural wind/nature) ---
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

// Soft wind noise via filtered noise buffer
function createWindNoise() {
  const bufferSize = audioCtx.sampleRate * 4;
  const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = (Math.random() * 2 - 1);
  }

  const noise = audioCtx.createBufferSource();
  noise.buffer = buffer;
  noise.loop = true;

  // Bandpass filter for soft whoosh
  const bandpass = audioCtx.createBiquadFilter();
  bandpass.type = 'bandpass';
  bandpass.frequency.value = 350;
  bandpass.Q.value = 0.4;

  // Lowpass to soften further
  const lowpass = audioCtx.createBiquadFilter();
  lowpass.type = 'lowpass';
  lowpass.frequency.value = 600;
  lowpass.Q.value = 0.5;

  const windGain = audioCtx.createGain();
  windGain.gain.value = 0.12;

  noise.connect(bandpass);
  bandpass.connect(lowpass);
  lowpass.connect(windGain);
  windGain.connect(audioCtx.destination);
  noise.start();

  // Gentle LFO to modulate wind volume
  function modulateWind() {
    const now = audioCtx.currentTime;
    const cycle = 6 + Math.random() * 4;
    const peakVol = 0.10 + Math.random() * 0.06;
    const lowVol = 0.04 + Math.random() * 0.03;
    windGain.gain.setValueAtTime(windGain.gain.value, now);
    windGain.gain.linearRampToValueAtTime(peakVol, now + cycle * 0.4);
    windGain.gain.linearRampToValueAtTime(lowVol, now + cycle);
    setTimeout(modulateWind, cycle * 1000);
  }
  modulateWind();

  // Modulate bandpass frequency for organic movement
  function modulateFreq() {
    const now = audioCtx.currentTime;
    const cycle = 5 + Math.random() * 5;
    bandpass.frequency.setValueAtTime(bandpass.frequency.value, now);
    bandpass.frequency.linearRampToValueAtTime(250 + Math.random() * 250, now + cycle);
    setTimeout(modulateFreq, cycle * 1000);
  }
  modulateFreq();
}

// Gentle harmonic tone (distant chime / pad)
function createTonePad() {
  const freqs = [174.61, 220, 261.63, 329.63]; // F3, A3, C4, E4
  freqs.forEach((freq, idx) => {
    const osc = audioCtx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = freq;

    const oscGain = audioCtx.createGain();
    oscGain.gain.value = 0;

    osc.connect(oscGain);
    oscGain.connect(audioCtx.destination);
    osc.start();

    // Slowly fade tones in and out
    function pulseTone() {
      const now = audioCtx.currentTime;
      const delay = Math.random() * 3;
      const attack = 2 + Math.random() * 3;
      const hold = 1 + Math.random() * 2;
      const release = 2 + Math.random() * 3;
      const vol = 0.012 + Math.random() * 0.008;
      oscGain.gain.setValueAtTime(0, now + delay);
      oscGain.gain.linearRampToValueAtTime(vol, now + delay + attack);
      oscGain.gain.setValueAtTime(vol, now + delay + attack + hold);
      oscGain.gain.linearRampToValueAtTime(0, now + delay + attack + hold + release);
      setTimeout(pulseTone, (delay + attack + hold + release) * 1000);
    }
    pulseTone();
  });
}

// Resume audio context on first user interaction & start sounds
let audioStarted = false;
function startAudio() {
  if (audioStarted) return;
  audioStarted = true;
  if (audioCtx.state === 'suspended') audioCtx.resume();
  createWindNoise();
  createTonePad();
}
document.addEventListener('click', startAudio, { once: false });
document.addEventListener('keydown', startAudio, { once: false });

const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 8, 25);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);
document.body.appendChild(renderer.domElement);

const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.target.set(0, 8, 0);
controls.autoRotate = true;
controls.autoRotateSpeed = -0.5;
controls.update();

// --- MOUSE INTERACTION ---
const mouse = new THREE.Vector2(9999, 9999);
const raycaster = new THREE.Raycaster();
const mouseWorld = new THREE.Vector3(9999, 9999, 9999);
const interactionPlane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);
const mouseRadius = 3.5;
const mouseStrength = 0.12;
let mouseActive = false;

window.addEventListener('mouseenter', () => {
  mouseActive = true;
});

window.addEventListener('mousemove', (e) => {
  mouseActive = true;
  mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const ray = raycaster.ray;
  // Project onto a plane facing camera at the tree center
  const planeNormal = camera.getWorldDirection(new THREE.Vector3()).negate();
  const dynPlane = new THREE.Plane().setFromNormalAndCoplanarPoint(planeNormal, new THREE.Vector3(0, 8, 0));
  ray.intersectPlane(dynPlane, mouseWorld);
});

window.addEventListener('mouseleave', () => {
  mouseActive = false;
  mouseWorld.set(9999, 9999, 9999);
});

// Create flat solid circle texture
function createFlatCircleTexture(size) {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.beginPath();
  ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
  ctx.fillStyle = 'white';
  ctx.fill();
  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}

const flatCircle = createFlatCircleTexture(64);

// --- TRUNK & BRANCHES ---
const trunkPositions = [];
const trunkColors = [];
const trunkSizes = [];

function addBranch(startX, startY, startZ, angle, pitch, length, radius, depth) {
  const segments = Math.floor(length * 8);
  const brown = new THREE.Color(0x5c3a1e);
  const darkBrown = new THREE.Color(0x3b2410);

  for (let i = 0; i < segments; i++) {
    const t = i / segments;
    const currentRadius = radius * (1 - t * 0.7);
    const particlesInRing = Math.max(3, Math.floor(currentRadius * 20));

    const x = startX + Math.sin(angle) * Math.cos(pitch) * length * t;
    const y = startY + Math.sin(pitch) * length * t;
    const z = startZ + Math.cos(angle) * Math.cos(pitch) * length * t;

    for (let j = 0; j < particlesInRing; j++) {
      const theta = (j / particlesInRing) * Math.PI * 2 + Math.random() * 0.5;
      const r = currentRadius * (0.7 + Math.random() * 0.3);
      const px = x + Math.cos(theta) * r;
      const py = y + (Math.random() - 0.5) * 0.15;
      const pz = z + Math.sin(theta) * r;

      trunkPositions.push(px, py, pz);
      const color = brown.clone().lerp(darkBrown, Math.random());
      trunkColors.push(color.r, color.g, color.b);
      trunkSizes.push(2.5 + Math.random() * 1.5);
    }

    // Spawn sub-branches
    if (depth < 4 && t > 0.3 && Math.random() < 0.04 && length > 0.8) {
      const newAngle = angle + (Math.random() - 0.5) * 2.5;
      const newPitch = pitch + (Math.random() * 0.5 - 0.1);
      const newLength = length * (0.4 + Math.random() * 0.3);
      const newRadius = currentRadius * 0.6;
      addBranch(x, y, z, newAngle, newPitch, newLength, newRadius, depth + 1);
    }
  }

  // End of branch — return tip position for leaf clusters
  const tipX = startX + Math.sin(angle) * Math.cos(pitch) * length;
  const tipY = startY + Math.sin(pitch) * length;
  const tipZ = startZ + Math.cos(angle) * Math.cos(pitch) * length;
  return { x: tipX, y: tipY, z: tipZ };
}

// Main trunk
const branchTips = [];
addBranch(0, 0, 0, 0, Math.PI * 0.47, 10, 0.9, 0);

// Major branches from trunk
const majorBranches = 7;
for (let i = 0; i < majorBranches; i++) {
  const startHeight = 4 + Math.random() * 5;
  const angle = (i / majorBranches) * Math.PI * 2 + Math.random() * 0.4;
  const pitch = Math.PI * (0.15 + Math.random() * 0.25);
  const length = 4 + Math.random() * 4;
  const tip = addBranch(
    Math.sin(angle) * 0.3, startHeight, Math.cos(angle) * 0.3,
    angle, pitch, length, 0.35 + Math.random() * 0.2, 1
  );
  branchTips.push(tip);

  // Secondary branches
  const subCount = 2 + Math.floor(Math.random() * 3);
  for (let j = 0; j < subCount; j++) {
    const t = 0.3 + Math.random() * 0.6;
    const sx = Math.sin(angle) * 0.3 + Math.sin(angle) * Math.cos(pitch) * length * t;
    const sy = startHeight + Math.sin(pitch) * length * t;
    const sz = Math.cos(angle) * 0.3 + Math.cos(angle) * Math.cos(pitch) * length * t;
    const subAngle = angle + (Math.random() - 0.5) * 1.8;
    const subPitch = Math.PI * (0.1 + Math.random() * 0.3);
    const subLength = 2 + Math.random() * 3;
    const subTip = addBranch(sx, sy, sz, subAngle, subPitch, subLength, 0.15 + Math.random() * 0.1, 2);
    branchTips.push(subTip);
  }
}

const trunkGeometry = new THREE.BufferGeometry();
trunkGeometry.setAttribute('position', new THREE.Float32BufferAttribute(trunkPositions, 3));
trunkGeometry.setAttribute('color', new THREE.Float32BufferAttribute(trunkColors, 3));
trunkGeometry.setAttribute('size', new THREE.Float32BufferAttribute(trunkSizes, 1));

const trunkMaterial = new THREE.PointsMaterial({
  map: flatCircle,
  size: 0.1,
  sizeAttenuation: true,
  vertexColors: true,
  transparent: true,
  alphaTest: 0.5,
  opacity: 1.0,
  depthWrite: true,
  blending: THREE.NormalBlending
});

const trunkParticles = new THREE.Points(trunkGeometry, trunkMaterial);
trunkParticles.name = 'trunkParticles';
trunkParticles.renderOrder = 0;
scene.add(trunkParticles);

// --- LEAF CANOPY ---
const leafPositions = [];
const leafColors = [];
const leafSizes = [];
const leafOriginalY = [];

const palettes = [
  // Autumn orange
  [0xef6c00, 0xf57f17, 0xff8f00, 0xd84315, 0xf4511e, 0xffa726, 0xe65100, 0xffb74d],
  // Pastel pink / cherry blossom
  [0xf8bbd0, 0xf48fb1, 0xf06292, 0xec407a, 0xfce4ec, 0xe91e63, 0xf8bbd0, 0xffc1e3],
  // Pastel mint / sage
  [0xa5d6a7, 0x81c784, 0x66bb6a, 0xc8e6c9, 0xb9f6ca, 0x4caf50, 0x80cbc4, 0xa5d6a7],
  // Pastel lavender / purple
  [0xce93d8, 0xba68c8, 0xb39ddb, 0xd1c4e9, 0xe1bee7, 0x9575cd, 0xab47bc, 0xd7bde2],
  // Pastel peach / coral
  [0xffccbc, 0xffab91, 0xff8a65, 0xff7043, 0xfbe9e7, 0xf4a582, 0xffcc80, 0xffab91],
  // Pastel sky / ice blue
  [0x90caf9, 0x64b5f6, 0x42a5f5, 0xbbdefb, 0x81d4fa, 0x4fc3f7, 0x80deea, 0xb3e5fc],
  // Golden yellow
  [0xfff176, 0xffee58, 0xffeb3b, 0xfdd835, 0xfbc02d, 0xf9a825, 0xffe082, 0xffd54f],
  // Pastel rose / dusty pink
  [0xd4a5a5, 0xe8b4b8, 0xc9787c, 0xf2d1d1, 0xdba7a7, 0xc48b8b, 0xf0c1c1, 0xe6a8a8],
];

let currentPaletteIndex = 0;
let leafPalette = palettes[0].map(c => new THREE.Color(c));

const leafCount = 15000;

// Create spherical clusters around branch tips + general canopy
function addLeafCluster(cx, cy, cz, radius, count) {
  for (let i = 0; i < count; i++) {
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    const r = radius * Math.pow(Math.random(), 0.5);

    const x = cx + r * Math.sin(phi) * Math.cos(theta);
    const y = cy + r * Math.sin(phi) * Math.sin(theta) * 0.7;
    const z = cz + r * Math.cos(phi);

    // Skip leaves below trunk base
    if (y < 3) continue;

    leafPositions.push(x, y, z);
    const color = leafPalette[Math.floor(Math.random() * leafPalette.length)].clone();
    // Darken interior leaves
    const distFromCenter = Math.sqrt((x - cx) ** 2 + (z - cz) ** 2);
    if (distFromCenter < radius * 0.4) color.multiplyScalar(0.75);


    leafColors.push(color.r, color.g, color.b);
    leafSizes.push(1.5 + Math.random() * 7);
    leafOriginalY.push(y);
  }
}

// Add clusters at branch tips
branchTips.forEach(tip => {
  addLeafCluster(tip.x, tip.y, tip.z, 2.5 + Math.random() * 1.5, 400);
});

// General canopy dome
addLeafCluster(0, 12, 0, 8, leafCount - branchTips.length * 400);

const leafGeometry = new THREE.BufferGeometry();
leafGeometry.setAttribute('position', new THREE.Float32BufferAttribute(leafPositions, 3));
leafGeometry.setAttribute('color', new THREE.Float32BufferAttribute(leafColors, 3));
leafGeometry.setAttribute('size', new THREE.Float32BufferAttribute(leafSizes, 1));

const leafMaterial = new THREE.PointsMaterial({
  map: flatCircle,
  size: 0.45,
  sizeAttenuation: true,
  vertexColors: true,
  transparent: true,
  alphaTest: 0.3,
  opacity: 0.3,
  depthWrite: false,
  blending: THREE.NormalBlending
});

const leafParticlesMesh = new THREE.Points(leafGeometry, leafMaterial);
leafParticlesMesh.name = 'leafParticles';
leafParticlesMesh.renderOrder = 1;
scene.add(leafParticlesMesh);

// --- FALLING LEAVES ---
const fallingCount = 200;
const fallingPositions = new Float32Array(fallingCount * 3);
const fallingColors = new Float32Array(fallingCount * 3);
const fallingSpeeds = [];
const fallingSwayPhase = [];

for (let i = 0; i < fallingCount; i++) {
  fallingPositions[i * 3] = (Math.random() - 0.5) * 20;
  fallingPositions[i * 3 + 1] = 5 + Math.random() * 18;
  fallingPositions[i * 3 + 2] = (Math.random() - 0.5) * 20;

  const color = leafPalette[Math.floor(Math.random() * leafPalette.length)];
  fallingColors[i * 3] = color.r;
  fallingColors[i * 3 + 1] = color.g;
  fallingColors[i * 3 + 2] = color.b;

  fallingSpeeds.push(0.3 + Math.random() * 0.7);
  fallingSwayPhase.push(Math.random() * Math.PI * 2);
}

const fallingGeometry = new THREE.BufferGeometry();
fallingGeometry.setAttribute('position', new THREE.Float32BufferAttribute(fallingPositions, 3));
fallingGeometry.setAttribute('color', new THREE.Float32BufferAttribute(fallingColors, 3));

const fallingMaterial = new THREE.PointsMaterial({
  map: flatCircle,
  size: 0.35,
  sizeAttenuation: true,
  vertexColors: true,
  transparent: true,
  alphaTest: 0.3,
  opacity: 0.45,
  depthWrite: false,
  blending: THREE.NormalBlending
});

const fallingLeaves = new THREE.Points(fallingGeometry, fallingMaterial);
fallingLeaves.name = 'fallingLeaves';
fallingLeaves.renderOrder = 2;
scene.add(fallingLeaves);



// --- GROUND PARTICLES ---
const groundCount = 5000;
const groundPositions = new Float32Array(groundCount * 3);
const groundColors = new Float32Array(groundCount * 3);

for (let i = 0; i < groundCount; i++) {
  const angle = Math.random() * Math.PI * 2;
  const r = Math.random() * 18;
  groundPositions[i * 3] = Math.cos(angle) * r;
  groundPositions[i * 3 + 1] = (Math.random() - 0.5) * 0.15;
  groundPositions[i * 3 + 2] = Math.sin(angle) * r;

  const base = 0.15 + Math.random() * 0.15;
  const green = 0.25 + Math.random() * 0.2;
  groundColors[i * 3] = base * 0.7;
  groundColors[i * 3 + 1] = green;
  groundColors[i * 3 + 2] = base * 0.3;
}

const groundGeometry = new THREE.BufferGeometry();
groundGeometry.setAttribute('position', new THREE.Float32BufferAttribute(groundPositions, 3));
groundGeometry.setAttribute('color', new THREE.Float32BufferAttribute(groundColors, 3));

const groundMaterial = new THREE.PointsMaterial({
  size: 0.08,
  sizeAttenuation: true,
  vertexColors: true,
  transparent: true,
  alphaTest: 0.5,
  opacity: 1.0,
  map: flatCircle,
  depthWrite: true,
  blending: THREE.NormalBlending
});

const groundParticlesMesh = new THREE.Points(groundGeometry, groundMaterial);
groundParticlesMesh.name = 'groundParticles';
groundParticlesMesh.renderOrder = -1;
scene.add(groundParticlesMesh);

// --- LIGHTING (for atmosphere, won't affect points but scene mood) ---
const ambientLight = new THREE.AmbientLight(0xfff5e6, 0.8);
ambientLight.name = 'ambientLight';
scene.add(ambientLight);

// --- MORPH ANIMATION STATE ---
let morphing = false;
let morphStartTime = 0;
const morphDuration = 2.0;

// Store target positions/colors/sizes for morphing
let trunkTargetPos = null, trunkTargetCol = null, trunkTargetSize = null;
let leafTargetPos = null, leafTargetCol = null, leafTargetSize = null, leafTargetOrigY = null;
let trunkStartPos = null, trunkStartCol = null, trunkStartSize = null;
let leafStartPos = null, leafStartCol = null, leafStartSize = null, leafStartOrigY = null;
let fallingStartCol = null, fallingTargetCol = null;

function easeInOutCubic(t) {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function generateTreeData(palette) {
  const tPos = [], tCol = [], tSiz = [];
  const tips = [];

  function genBranch(startX, startY, startZ, angle, pitch, length, radius, depth) {
    const segments = Math.floor(length * 8);
    const brown = new THREE.Color(0x5c3a1e);
    const darkBrown = new THREE.Color(0x3b2410);
    for (let i = 0; i < segments; i++) {
      const t = i / segments;
      const currentRadius = radius * (1 - t * 0.7);
      const particlesInRing = Math.max(3, Math.floor(currentRadius * 20));
      const x = startX + Math.sin(angle) * Math.cos(pitch) * length * t;
      const y = startY + Math.sin(pitch) * length * t;
      const z = startZ + Math.cos(angle) * Math.cos(pitch) * length * t;
      for (let j = 0; j < particlesInRing; j++) {
        const theta = (j / particlesInRing) * Math.PI * 2 + Math.random() * 0.5;
        const r = currentRadius * (0.7 + Math.random() * 0.3);
        tPos.push(x + Math.cos(theta) * r, y + (Math.random() - 0.5) * 0.15, z + Math.sin(theta) * r);
        const color = brown.clone().lerp(darkBrown, Math.random());
        tCol.push(color.r, color.g, color.b);
        tSiz.push(2.5 + Math.random() * 1.5);
      }
      if (depth < 4 && t > 0.3 && Math.random() < 0.04 && length > 0.8) {
        genBranch(x, y, z, angle + (Math.random() - 0.5) * 2.5, pitch + (Math.random() * 0.5 - 0.1),
          length * (0.4 + Math.random() * 0.3), currentRadius * 0.6, depth + 1);
      }
    }
    const tipX = startX + Math.sin(angle) * Math.cos(pitch) * length;
    const tipY = startY + Math.sin(pitch) * length;
    const tipZ = startZ + Math.cos(angle) * Math.cos(pitch) * length;
    return { x: tipX, y: tipY, z: tipZ };
  }

  genBranch(0, 0, 0, 0, Math.PI * 0.47, 10, 0.9, 0);
  const majors = 5 + Math.floor(Math.random() * 5);
  for (let i = 0; i < majors; i++) {
    const startH = 4 + Math.random() * 5;
    const ang = (i / majors) * Math.PI * 2 + Math.random() * 0.4;
    const pit = Math.PI * (0.15 + Math.random() * 0.25);
    const len = 4 + Math.random() * 4;
    const tip = genBranch(Math.sin(ang) * 0.3, startH, Math.cos(ang) * 0.3, ang, pit, len, 0.35 + Math.random() * 0.2, 1);
    tips.push(tip);
    const subCount = 2 + Math.floor(Math.random() * 3);
    for (let j = 0; j < subCount; j++) {
      const tt = 0.3 + Math.random() * 0.6;
      const sx = Math.sin(ang) * 0.3 + Math.sin(ang) * Math.cos(pit) * len * tt;
      const sy = startH + Math.sin(pit) * len * tt;
      const sz = Math.cos(ang) * 0.3 + Math.cos(ang) * Math.cos(pit) * len * tt;
      const subTip = genBranch(sx, sy, sz, ang + (Math.random() - 0.5) * 1.8, Math.PI * (0.1 + Math.random() * 0.3),
        2 + Math.random() * 3, 0.15 + Math.random() * 0.1, 2);
      tips.push(subTip);
    }
  }

  // Generate leaves
  const lPos = [], lCol = [], lSiz = [], lOrigY = [];
  function addCluster(cx, cy, cz, radius, count) {
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = radius * Math.pow(Math.random(), 0.5);
      const x = cx + r * Math.sin(phi) * Math.cos(theta);
      const y = cy + r * Math.sin(phi) * Math.sin(theta) * 0.7;
      const z = cz + r * Math.cos(phi);
      if (y < 3) continue;
      lPos.push(x, y, z);
      const color = palette[Math.floor(Math.random() * palette.length)].clone();
      const distFromCenter = Math.sqrt((x - cx) ** 2 + (z - cz) ** 2);
      if (distFromCenter < radius * 0.4) color.multiplyScalar(0.75);
      lCol.push(color.r, color.g, color.b);
      lSiz.push(1.5 + Math.random() * 7);
      lOrigY.push(y);
    }
  }

  tips.forEach(tip => addCluster(tip.x, tip.y, tip.z, 2.5 + Math.random() * 1.5, 400));
  const remaining = 15000 - tips.length * 400;
  if (remaining > 0) addCluster(0, 12, 0, 8, remaining);

  return { tPos, tCol, tSiz, lPos, lCol, lSiz, lOrigY };
}

function matchArrayLength(source, target, stride) {
  // Pad or truncate target to match source length
  const srcLen = Math.floor(source.length / stride);
  const tgtLen = Math.floor(target.length / stride);
  if (tgtLen >= srcLen) return new Float32Array(target.slice(0, srcLen * stride));
  // Need to pad — duplicate random existing entries
  const result = new Float32Array(srcLen * stride);
  for (let i = 0; i < tgtLen * stride; i++) result[i] = target[i];
  for (let i = tgtLen; i < srcLen; i++) {
    const src = Math.floor(Math.random() * tgtLen);
    for (let s = 0; s < stride; s++) result[i * stride + s] = target[src * stride + s];
  }
  return result;
}

function startMorph() {
  if (morphing) return;

  // Pick a different palette
  let newIndex;
  do { newIndex = Math.floor(Math.random() * palettes.length); } while (newIndex === currentPaletteIndex);
  currentPaletteIndex = newIndex;
  const newPalette = palettes[newIndex].map(c => new THREE.Color(c));

  const data = generateTreeData(newPalette);

  // Save current state as start
  const tPosArr = trunkGeometry.attributes.position.array;
  const tColArr = trunkGeometry.attributes.color.array;
  const tSizArr = trunkGeometry.attributes.size.array;
  trunkStartPos = new Float32Array(tPosArr);
  trunkStartCol = new Float32Array(tColArr);
  trunkStartSize = new Float32Array(tSizArr);

  const lPosArr = leafGeometry.attributes.position.array;
  const lColArr = leafGeometry.attributes.color.array;
  const lSizArr = leafGeometry.attributes.size.array;
  leafStartPos = new Float32Array(lPosArr);
  leafStartCol = new Float32Array(lColArr);
  leafStartSize = new Float32Array(lSizArr);
  leafStartOrigY = leafOriginalY.slice();

  // Match lengths to current geometry
  const trunkLen = tPosArr.length;
  const leafLen = lPosArr.length;

  trunkTargetPos = matchArrayLength(tPosArr, data.tPos, 3);
  trunkTargetCol = matchArrayLength(tColArr, data.tCol, 3);
  trunkTargetSize = matchArrayLength(tSizArr, data.tSiz, 1);

  leafTargetPos = matchArrayLength(lPosArr, data.lPos, 3);
  leafTargetCol = matchArrayLength(lColArr, data.lCol, 3);
  leafTargetSize = matchArrayLength(lSizArr, data.lSiz, 1);
  // Build leafTargetOrigY
  const leafTargetOrigYRaw = matchArrayLength(new Float32Array(leafOriginalY), new Float32Array(data.lOrigY), 1);
  leafTargetOrigY = Array.from(leafTargetOrigYRaw);

  // Snapshot falling leaf colors and generate target colors from new palette
  const fColArr = fallingGeometry.attributes.color.array;
  fallingStartCol = new Float32Array(fColArr);
  fallingTargetCol = new Float32Array(fColArr.length);
  for (let i = 0; i < fallingCount; i++) {
    const color = newPalette[Math.floor(Math.random() * newPalette.length)];
    fallingTargetCol[i * 3] = color.r;
    fallingTargetCol[i * 3 + 1] = color.g;
    fallingTargetCol[i * 3 + 2] = color.b;
  }

  morphStartTime = clock.getElapsedTime();
  morphing = true;
}

btn.addEventListener('click', startMorph);

// --- ANIMATION ---
const clock = new THREE.Clock();

function animate() {
  requestAnimationFrame(animate);
  const time = clock.getElapsedTime();

  // Sway canopy leaves gently + mouse repulsion
  const leafPos = leafGeometry.attributes.position.array;
  const mxW = mouseWorld.x, myW = mouseWorld.y, mzW = mouseWorld.z;
  const mRadSq = mouseRadius * mouseRadius;
  for (let i = 0; i < leafPos.length / 3; i++) {
    const origY = leafOriginalY[i];
    if (origY === undefined) continue;
    // Base sway
    leafPos[i * 3] += Math.sin(time * 0.8 + i * 0.01) * 0.001;
    leafPos[i * 3 + 1] = origY + Math.sin(time * 1.2 + i * 0.05) * 0.03;

    // Mouse repulsion (only when mouse is active)
    if (mouseActive) {
      const dx = leafPos[i * 3] - mxW;
      const dy = leafPos[i * 3 + 1] - myW;
      const dz = leafPos[i * 3 + 2] - mzW;
      const distSq = dx * dx + dy * dy + dz * dz;
      if (distSq < mRadSq && distSq > 0.001) {
        const dist = Math.sqrt(distSq);
        const force = (1 - dist / mouseRadius) * mouseStrength;
        leafPos[i * 3] += (dx / dist) * force;
        leafPos[i * 3 + 1] += (dy / dist) * force;
        leafPos[i * 3 + 2] += (dz / dist) * force;
      }
    }
  }
  leafGeometry.attributes.position.needsUpdate = true;

  // Animate falling leaves + mouse repulsion
  const fallPos = fallingGeometry.attributes.position.array;
  for (let i = 0; i < fallingCount; i++) {
    fallPos[i * 3 + 1] -= fallingSpeeds[i] * 0.01;
    fallPos[i * 3] += Math.sin(time * 1.5 + fallingSwayPhase[i]) * 0.008;
    fallPos[i * 3 + 2] += Math.cos(time * 1.2 + fallingSwayPhase[i]) * 0.005;

    // Mouse repulsion on falling leaves (only when mouse is active)
    if (mouseActive) {
      const fdx = fallPos[i * 3] - mxW;
      const fdy = fallPos[i * 3 + 1] - myW;
      const fdz = fallPos[i * 3 + 2] - mzW;
      const fdistSq = fdx * fdx + fdy * fdy + fdz * fdz;
      if (fdistSq < mRadSq && fdistSq > 0.001) {
        const fdist = Math.sqrt(fdistSq);
        const fforce = (1 - fdist / mouseRadius) * mouseStrength * 1.5;
        fallPos[i * 3] += (fdx / fdist) * fforce;
        fallPos[i * 3 + 1] += (fdy / fdist) * fforce;
        fallPos[i * 3 + 2] += (fdz / fdist) * fforce;
      }
    }

    if (fallPos[i * 3 + 1] < 0) {
      fallPos[i * 3 + 1] = 12 + Math.random() * 6;
      fallPos[i * 3] = (Math.random() - 0.5) * 16;
      fallPos[i * 3 + 2] = (Math.random() - 0.5) * 16;
    }
  }
  fallingGeometry.attributes.position.needsUpdate = true;

  // --- MORPH ANIMATION ---
  if (morphing) {
    const elapsed = time - morphStartTime;
    const rawT = Math.min(elapsed / morphDuration, 1.0);
    const t = easeInOutCubic(rawT);

    // Interpolate trunk
    const tPos = trunkGeometry.attributes.position.array;
    const tCol = trunkGeometry.attributes.color.array;
    const tSiz = trunkGeometry.attributes.size.array;
    for (let i = 0; i < tPos.length; i++) {
      tPos[i] = trunkStartPos[i] + (trunkTargetPos[i] - trunkStartPos[i]) * t;
    }
    for (let i = 0; i < tCol.length; i++) {
      tCol[i] = trunkStartCol[i] + (trunkTargetCol[i] - trunkStartCol[i]) * t;
    }
    for (let i = 0; i < tSiz.length; i++) {
      tSiz[i] = trunkStartSize[i] + (trunkTargetSize[i] - trunkStartSize[i]) * t;
    }
    trunkGeometry.attributes.position.needsUpdate = true;
    trunkGeometry.attributes.color.needsUpdate = true;
    trunkGeometry.attributes.size.needsUpdate = true;

    // Interpolate leaves
    const lPosA = leafGeometry.attributes.position.array;
    const lColA = leafGeometry.attributes.color.array;
    const lSizA = leafGeometry.attributes.size.array;
    for (let i = 0; i < lPosA.length; i++) {
      lPosA[i] = leafStartPos[i] + (leafTargetPos[i] - leafStartPos[i]) * t;
    }
    for (let i = 0; i < lColA.length; i++) {
      lColA[i] = leafStartCol[i] + (leafTargetCol[i] - leafStartCol[i]) * t;
    }
    for (let i = 0; i < lSizA.length; i++) {
      lSizA[i] = leafStartSize[i] + (leafTargetSize[i] - leafStartSize[i]) * t;
    }
    for (let i = 0; i < leafOriginalY.length; i++) {
      leafOriginalY[i] = leafStartOrigY[i] + (leafTargetOrigY[i] - leafStartOrigY[i]) * t;
    }
    leafGeometry.attributes.position.needsUpdate = true;
    leafGeometry.attributes.color.needsUpdate = true;
    leafGeometry.attributes.size.needsUpdate = true;

    // Smoothly interpolate falling leaves colors
    const fCol = fallingGeometry.attributes.color.array;
    if (fallingStartCol && fallingTargetCol) {
      for (let i = 0; i < fCol.length; i++) {
        fCol[i] = fallingStartCol[i] + (fallingTargetCol[i] - fallingStartCol[i]) * t;
      }
      fallingGeometry.attributes.color.needsUpdate = true;
    }

    if (rawT >= 1.0) {
      morphing = false;
      fallingStartCol = null;
      fallingTargetCol = null;
    }
  }



  // Mouse repulsion on trunk particles (only when mouse is active)
  if (mouseActive) {
    const tPosArr2 = trunkGeometry.attributes.position.array;
    for (let i = 0; i < tPosArr2.length / 3; i++) {
      const tdx = tPosArr2[i * 3] - mxW;
      const tdy = tPosArr2[i * 3 + 1] - myW;
      const tdz = tPosArr2[i * 3 + 2] - mzW;
      const tdistSq = tdx * tdx + tdy * tdy + tdz * tdz;
      if (tdistSq < mRadSq && tdistSq > 0.001) {
        const tdist = Math.sqrt(tdistSq);
        const tforce = (1 - tdist / mouseRadius) * mouseStrength * 0.5;
        tPosArr2[i * 3] += (tdx / tdist) * tforce;
        tPosArr2[i * 3 + 1] += (tdy / tdist) * tforce;
        tPosArr2[i * 3 + 2] += (tdz / tdist) * tforce;
      }
    }
  }
  trunkGeometry.attributes.position.needsUpdate = true;

  // Sort leaf particles infrequently to avoid jitter
  if (!window._leafSortTimer) window._leafSortTimer = 0;
  window._leafSortTimer++;

  if (window._leafSortTimer % 60 === 0) {
    const leafPosArr = leafGeometry.attributes.position.array;
    const leafColArr = leafGeometry.attributes.color.array;
    const leafSizeArr = leafGeometry.attributes.size.array;
    const numLeaves = leafPosArr.length / 3;
    const camPos = camera.position;

    if (!window._leafIndices) {
      window._leafIndices = new Uint32Array(numLeaves);
      window._leafDists = new Float32Array(numLeaves);
      for (let i = 0; i < numLeaves; i++) window._leafIndices[i] = i;
    }

    const indices = window._leafIndices;
    const dists = window._leafDists;

    for (let i = 0; i < numLeaves; i++) {
      indices[i] = i;
      const dx = leafPosArr[i * 3] - camPos.x;
      const dy = leafPosArr[i * 3 + 1] - camPos.y;
      const dz = leafPosArr[i * 3 + 2] - camPos.z;
      dists[i] = dx * dx + dy * dy + dz * dz;
    }

    indices.sort((a, b) => dists[b] - dists[a]);

    const sortedPos = new Float32Array(numLeaves * 3);
    const sortedCol = new Float32Array(numLeaves * 3);
    const sortedSize = new Float32Array(numLeaves);
    const sortedOrigY = new Float64Array(numLeaves);

    for (let i = 0; i < numLeaves; i++) {
      const src = indices[i];
      sortedPos[i * 3] = leafPosArr[src * 3];
      sortedPos[i * 3 + 1] = leafPosArr[src * 3 + 1];
      sortedPos[i * 3 + 2] = leafPosArr[src * 3 + 2];
      sortedCol[i * 3] = leafColArr[src * 3];
      sortedCol[i * 3 + 1] = leafColArr[src * 3 + 1];
      sortedCol[i * 3 + 2] = leafColArr[src * 3 + 2];
      sortedSize[i] = leafSizeArr[src];
      sortedOrigY[i] = leafOriginalY[src];
    }

    leafGeometry.attributes.position.array.set(sortedPos);
    leafGeometry.attributes.color.array.set(sortedCol);
    leafGeometry.attributes.size.array.set(sortedSize);
    for (let i = 0; i < numLeaves; i++) leafOriginalY[i] = sortedOrigY[i];

    leafGeometry.attributes.color.needsUpdate = true;
    leafGeometry.attributes.size.needsUpdate = true;
  }

  controls.update();
  renderer.render(scene, camera);
}

animate();

// Handle resize
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});