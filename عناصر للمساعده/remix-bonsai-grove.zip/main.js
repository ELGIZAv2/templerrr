// Growing Tree Interaction in 3D
const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf5f0eb);
scene.fog = new THREE.FogExp2(0xf5f0eb, 0.012);

const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 200);
camera.position.set(0, 8, 20);

// Use WebGPURenderer for better performance via GPU compute and reduced driver overhead
let renderer;
let rendererReady = false;

async function initRenderer() {
  // Check for WebGPU support, fall back to WebGL if unavailable
  if (navigator.gpu) {
    try {
      renderer = new THREE.WebGPURenderer({ antialias: true });
      await renderer.init();
      console.log('Using WebGPU renderer');
    } catch (e) {
      console.warn('WebGPU init failed, falling back to WebGL:', e);
      renderer = new THREE.WebGLRenderer({ antialias: true });
    }
  } else {
    console.log('WebGPU not supported, using WebGL');
    renderer = new THREE.WebGLRenderer({ antialias: true });
  }
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;
  document.body.appendChild(renderer.domElement);
  rendererReady = true;

  // Now set up controls (need renderer.domElement to exist)
  setupControls();
  // Start the animation loop
  animate();
}

let controls;

function setupControls() {
  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.05;
  controls.target.set(0, 6, 0);
  controls.maxPolarAngle = Math.PI * 0.85;
  controls.minDistance = 5;
  controls.maxDistance = 40;
}

// Lights
const ambientLight = new THREE.AmbientLight(0xfff5f0, 0.8);
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0xfff8f0, 1.8);
dirLight.position.set(10, 20, 8);
dirLight.castShadow = true;
dirLight.shadow.mapSize.set(2048, 2048);
dirLight.shadow.camera.left = -20;
dirLight.shadow.camera.right = 20;
dirLight.shadow.camera.top = 20;
dirLight.shadow.camera.bottom = -20;
dirLight.shadow.camera.near = 1;
dirLight.shadow.camera.far = 50;
dirLight.shadow.bias = -0.001;
scene.add(dirLight);

const rimLight = new THREE.DirectionalLight(0xffd4c4, 0.5);
rimLight.position.set(-8, 10, -10);
scene.add(rimLight);

const fillLight = new THREE.DirectionalLight(0xffe8e0, 0.3);
fillLight.position.set(-5, 5, 10);
scene.add(fillLight);

const pointLight = new THREE.PointLight(0xffccbb, 0.4, 30);
pointLight.position.set(5, 3, 5);
scene.add(pointLight);

// Ground
const groundGeo = new THREE.CircleGeometry(30, 64);
const groundMat = new THREE.MeshStandardMaterial({
  color: 0xe8e0d8,
  roughness: 0.95,
  metalness: 0.0,
});
const ground = new THREE.Mesh(groundGeo, groundMat);
ground.rotation.x = -Math.PI / 2;
ground.position.y = -0.05;
ground.receiveShadow = true;
scene.add(ground);

// Scattered fallen petals on ground
// Ground petals as InstancedMesh — single draw call instead of 120
const groundPetalCount = 120;
const groundPetalGeo = new THREE.SphereGeometry(0.06, 5, 3);
groundPetalGeo.scale(1.5, 0.3, 1);
const groundPetalMat = new THREE.MeshStandardMaterial({
  color: 0xf5b8c8,
  roughness: 0.6,
});
const groundPetalIM = new THREE.InstancedMesh(groundPetalGeo, groundPetalMat, groundPetalCount);
groundPetalIM.receiveShadow = true;
const _gpDummy = new THREE.Object3D();
for (let i = 0; i < groundPetalCount; i++) {
  const angle = Math.random() * Math.PI * 2;
  const dist = 0.5 + Math.random() * 8;
  _gpDummy.position.set(Math.cos(angle) * dist, 0.02, Math.sin(angle) * dist);
  _gpDummy.rotation.set(Math.random() * 0.3, Math.random() * Math.PI * 2, Math.random() * 0.3);
  const s = 0.6 + Math.random() * 0.8;
  _gpDummy.scale.set(s, s, s);
  _gpDummy.updateMatrix();
  groundPetalIM.setMatrixAt(i, _gpDummy.matrix);
  // Vary color per instance via random hue tint
  groundPetalIM.setColorAt(i, new THREE.Color().setHSL(0.95 + Math.random() * 0.05, 0.4 + Math.random() * 0.3, 0.78 + Math.random() * 0.15));
}
groundPetalIM.instanceMatrix.needsUpdate = true;
groundPetalIM.instanceColor.needsUpdate = true;
scene.add(groundPetalIM);

// Tree system
const treeGroup = new THREE.Group();
scene.add(treeGroup);

const clock = new THREE.Clock();
let growthProgress = 0;
let isGrowing = false;
let targetGrowth = 0;
let growthSpeed = 0.18;

// Branch data structure
const branches = [];
const leaves = [];
const flowers = [];
const fallingLeaves = [];

// Materials
const barkMat = new THREE.MeshStandardMaterial({
  color: 0x6b5a4e,
  roughness: 0.92,
  metalness: 0.02,
});

const darkBarkMat = new THREE.MeshStandardMaterial({
  color: 0x5a4a3e,
  roughness: 0.95,
  metalness: 0.02,
});

// Cherry blossom pinks and whites
const leafColors = [0xf5b0c0, 0xf8c4d0, 0xfad4de, 0xeea0b4, 0xfce4ec, 0xf48ca8];
const flowerColors = [0xffb7c5, 0xffc1cc, 0xffd4dc, 0xff9eb5, 0xffffff, 0xffe0e8];

function createTaperedTube(curve, segments, radiusStart, radiusEnd, radialSegments) {
  const frames = curve.computeFrenetFrames(segments, false);
  const vertices = [];
  const normals = [];
  const uvs = [];
  const indices = [];

  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const r = radiusStart * (1 - t) + radiusEnd * t;
    const P = curve.getPointAt(t);
    const N = frames.normals[i];
    const B = frames.binormals[i];

    for (let j = 0; j <= radialSegments; j++) {
      const v = (j / radialSegments) * Math.PI * 2;
      const sin = Math.sin(v);
      const cos = -Math.cos(v);

      const nx = cos * N.x + sin * B.x;
      const ny = cos * N.y + sin * B.y;
      const nz = cos * N.z + sin * B.z;

      vertices.push(P.x + r * nx, P.y + r * ny, P.z + r * nz);
      normals.push(nx, ny, nz);
      uvs.push(j / radialSegments, t);
    }
  }

  for (let i = 0; i < segments; i++) {
    for (let j = 0; j < radialSegments; j++) {
      const a = i * (radialSegments + 1) + j;
      const b = a + radialSegments + 1;
      indices.push(a, b, a + 1);
      indices.push(b, b + 1, a + 1);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setIndex(indices);
  geo.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  return geo;
}

function createBranch(startPos, direction, length, radius, depth, parentGrowth) {
  // More organic curves — trunk is straighter, deeper branches wander more
  const wobble = depth === 0 ? 0.08 : 0.12 + depth * 0.04;
  const gravityDroop = depth >= 3 ? -0.06 * depth : 0;
  const pts = [];
  const numPts = depth < 2 ? 5 : 4;
  for (let i = 0; i <= numPts; i++) {
    const t = i / numPts;
    const p = startPos.clone().add(direction.clone().multiplyScalar(length * t));
    if (i > 0 && i < numPts) {
      p.x += (Math.random() - 0.5) * length * wobble;
      p.y += (Math.random() - 0.3) * length * wobble * 0.5 + gravityDroop * t;
      p.z += (Math.random() - 0.5) * length * wobble;
    }
    pts.push(p);
  }

  const curve = new THREE.CatmullRomCurve3(pts);

  const segments = Math.max(8, Math.floor(length * 4));
  const radialSegments = depth < 2 ? 8 : 5;

  // Tapered tube — thick at base, thin at tip; base slightly wider for overlap with parent
  const radiusBase = depth === 0 ? radius : radius * 1.15; // fatten base to embed into parent
  const radiusEnd = radius * (depth === 0 ? 0.45 : 0.25);
  const geo = createTaperedTube(curve, segments, radiusBase, radiusEnd, radialSegments);

  const mesh = new THREE.Mesh(geo, depth < 2 ? barkMat : darkBarkMat);
  mesh.castShadow = true;
  mesh.receiveShadow = true;

  // Store curve for growth animation
  const endPos = curve.getPointAt(1);
  const tangentEnd = curve.getTangentAt(1).normalize();

  // Progressive growth windows: deeper branches get longer windows for uniform visual speed
  const baseWindow = 0.08;
  const depthBonus = depth * 0.045;
  const lengthFactor = length / 6; // normalize by trunk length
  const growthWindow = (baseWindow + depthBonus) * (0.7 + lengthFactor * 0.3);

  const branchData = {
    mesh,
    curve,
    depth,
    growthStart: parentGrowth,
    growthEnd: parentGrowth + growthWindow,
    parentStartT: 0, // will be set for child branches
    endPos,
    endDirection: tangentEnd,
    length,
    radius,
    radiusEnd,
    segments,
    radialSegments,
    children: [],
    leavesAdded: false,
    fullGeo: geo,
    _lastVisibleSeg: -1,
    startPos: startPos.clone(),
    parentBranch: null,
  };

  // Set initial draw range to 0 so it's hidden
  geo.setDrawRange(0, 0);
  mesh.visible = false;
  mesh.frustumCulled = false;
  treeGroup.add(mesh);
  branches.push(branchData);

  // Create child branches with more natural structure
  if (depth < 5) {
    const numChildren = depth === 0 ? 3 + Math.floor(Math.random() * 3) :
                        depth === 1 ? 2 + Math.floor(Math.random() * 3) :
                        depth === 2 ? 2 + Math.floor(Math.random() * 2) :
                        depth === 3 ? 1 + Math.floor(Math.random() * 2) :
                        Math.random() > 0.4 ? 1 : 0;

    for (let i = 0; i < numChildren; i++) {
        // Branches emerge along the parent, not just at the tip
      const childStartT = depth === 0 ? 0.5 + Math.random() * 0.45 : 0.35 + Math.random() * 0.6;
      const childStart = curve.getPointAt(childStartT);
      const parentTangent = curve.getTangentAt(childStartT).normalize();

      // Nudge child start slightly inward along parent tangent for seamless connection
      const connectionOverlap = radius * 0.3;
      childStart.addScaledVector(parentTangent, -connectionOverlap);

      // Natural branching angles — wide for lower branches, tighter near top
      const spreadAngle = depth < 2 ? 0.9 + Math.random() * 0.5 : 0.7 + Math.random() * 0.6;
      const upwardBias = depth < 2 ? 0.5 : depth < 4 ? 0.35 : 0.2;

      // Create a random direction perpendicular to parent
      const randomPerp = new THREE.Vector3(
        (Math.random() - 0.5),
        0,
        (Math.random() - 0.5)
      ).normalize();

      const childDir = new THREE.Vector3()
        .addScaledVector(parentTangent, 0.5)
        .addScaledVector(randomPerp, spreadAngle)
        .add(new THREE.Vector3(0, upwardBias, 0))
        .normalize();

      // Longer lower branches, shorter upper ones
      const lengthMult = depth === 0 ? 0.55 + Math.random() * 0.25 :
                         depth <= 2 ? 0.5 + Math.random() * 0.3 :
                         0.45 + Math.random() * 0.25;
      const childLength = length * lengthMult;
      const childRadius = radius * (0.45 + Math.random() * 0.2);

      // Child growth starts when parent has grown past the child's spawn point
      const childGrowthStart = branchData.growthStart + (branchData.growthEnd - branchData.growthStart) * childStartT;
      const childBranch = createBranch(childStart, childDir, childLength, childRadius, depth + 1, childGrowthStart);
      childBranch.parentBranch = branchData;
      childBranch.parentStartT = childStartT;
      branchData.children.push(childBranch);
    }
  }

  return branchData;
}

// InstancedMesh system for leaves — one draw call per color
const MAX_LEAVES = 1200;
const leafInstanceGeo = new THREE.SphereGeometry(0.2, 5, 3);
leafInstanceGeo.scale(1, 0.3, 0.7);

const leafInstanceMats = leafColors.map(c => new THREE.MeshStandardMaterial({
  color: c,
  roughness: 0.5,
  metalness: 0.02,
  side: THREE.DoubleSide,
  emissive: new THREE.Color(c).multiplyScalar(0.08),
}));

const leafInstancedMeshes = [];
const leafInstancesPerMesh = Math.ceil(MAX_LEAVES / leafColors.length);

for (let i = 0; i < leafColors.length; i++) {
  const im = new THREE.InstancedMesh(leafInstanceGeo, leafInstanceMats[i], leafInstancesPerMesh);
  im.count = 0;
  im.castShadow = true;
  im.frustumCulled = false;
  treeGroup.add(im);
  leafInstancedMeshes.push(im);
}

const _leafDummy = new THREE.Object3D();
const _leafMatrix = new THREE.Matrix4();
const _tempVec3 = new THREE.Vector3();
const _tempQuat = new THREE.Quaternion();
const _tempScale = new THREE.Vector3();
const _tempEuler = new THREE.Euler();

function createLeaf(position, normal) {
  const colorIdx = (Math.random() * leafColors.length) | 0;
  const im = leafInstancedMeshes[colorIdx];
  const idx = im.count;
  if (idx >= leafInstancesPerMesh) return;
  im.count = idx + 1;

  // Store colorIdx for O(1) dirty flag lookup

  const px = position.x + (Math.random() - 0.5) * 0.5;
  const py = position.y + (Math.random() - 0.5) * 0.3;
  const pz = position.z + (Math.random() - 0.5) * 0.5;

  const rx = Math.random() * Math.PI;
  const ry = Math.random() * Math.PI;
  const rz = Math.random() * Math.PI;

  // Start hidden (scale 0)
  _leafDummy.position.set(px, py, pz);
  _leafDummy.rotation.set(rx, ry, rz);
  _leafDummy.scale.set(0.001, 0.001, 0.001);
  _leafDummy.updateMatrix();
  im.setMatrixAt(idx, _leafDummy.matrix);
  im.instanceMatrix.needsUpdate = true;

  const leafData = {
    instancedMesh: im,
    instanceIdx: idx,
    colorIdx,
    growthStart: 0.5 + Math.random() * 0.3,
    targetScale: 0.8 + Math.random() * 0.5,
    swayOffset: Math.random() * Math.PI * 2,
    swaySpeed: 0.5 + Math.random() * 1.5,
    originalPos: new THREE.Vector3(px, py, pz),
    baseRotX: rx,
    baseRotY: ry,
    baseRotZ: rz,
    currentScale: 0,
  };

  leaves.push(leafData);
}

// InstancedMesh system for flower petals — one draw call per color
const MAX_FLOWERS = 300;
const MAX_PETALS = MAX_FLOWERS * 5;
const flowerPetalGeo = new THREE.SphereGeometry(0.1, 5, 4);
flowerPetalGeo.scale(1.8, 0.25, 1.2);

const flowerPetalMats = flowerColors.map(c => new THREE.MeshStandardMaterial({
  color: c,
  roughness: 0.4,
  metalness: 0.02,
  emissive: new THREE.Color(c).multiplyScalar(0.06),
  transparent: true,
  opacity: 0.92,
}));

const flowerInstancedMeshes = [];
const petalsPerColorMesh = Math.ceil(MAX_PETALS / flowerColors.length);

for (let i = 0; i < flowerColors.length; i++) {
  const im = new THREE.InstancedMesh(flowerPetalGeo, flowerPetalMats[i], petalsPerColorMesh);
  im.count = 0;
  im.castShadow = true;
  im.frustumCulled = false;
  treeGroup.add(im);
  flowerInstancedMeshes.push(im);
}

// Flower centers instanced
const flowerCenterGeo = new THREE.SphereGeometry(0.04, 6, 6);
const flowerCenterMat = new THREE.MeshStandardMaterial({ color: 0xf5d76e, emissive: 0x4a3520, roughness: 0.6 });
const flowerCenterIM = new THREE.InstancedMesh(flowerCenterGeo, flowerCenterMat, MAX_FLOWERS);
flowerCenterIM.count = 0;
flowerCenterIM.castShadow = true;
flowerCenterIM.frustumCulled = false;
treeGroup.add(flowerCenterIM);

const _flowerDummy = new THREE.Object3D();

function createFlower(position) {
  const colorIdx = Math.floor(Math.random() * flowerColors.length);
  const im = flowerInstancedMeshes[colorIdx];

  const baseRotX = Math.random() * 0.5;
  const baseRotY = Math.random() * Math.PI * 2;
  const baseRotZ = Math.random() * 0.5;
  const targetScale = 0.8 + Math.random() * 0.6;

  const petalIndices = [];
  const numPetals = 5;

  for (let i = 0; i < numPetals; i++) {
    const idx = im.count;
    if (idx >= petalsPerColorMesh) return;
    im.count = idx + 1;

    // Start hidden
    _flowerDummy.position.set(0, 0, 0);
    _flowerDummy.scale.set(0.001, 0.001, 0.001);
    _flowerDummy.updateMatrix();
    im.setMatrixAt(idx, _flowerDummy.matrix);
    petalIndices.push(idx);
  }
  im.instanceMatrix.needsUpdate = true;

  // Center
  const centerIdx = flowerCenterIM.count;
  if (centerIdx >= MAX_FLOWERS) return;
  flowerCenterIM.count = centerIdx + 1;
  _flowerDummy.position.set(0, 0, 0);
  _flowerDummy.scale.set(0.001, 0.001, 0.001);
  _flowerDummy.updateMatrix();
  flowerCenterIM.setMatrixAt(centerIdx, _flowerDummy.matrix);
  flowerCenterIM.instanceMatrix.needsUpdate = true;

  const flowerData = {
    instancedMesh: im,
    petalIndices,
    centerIdx,
    colorIdx,
    position: position.clone(),
    growthStart: 0.7 + Math.random() * 0.25,
    targetScale,
    swayOffset: Math.random() * Math.PI * 2,
    baseRotX,
    baseRotY,
    baseRotZ,
    currentScale: 0,
  };

  flowers.push(flowerData);
}

// Pre-allocated falling leaf pool — single InstancedMesh, zero runtime allocations
const FALLING_LEAF_POOL_SIZE = 20;
const fallingLeafPool = [];
let fallingLeafNextIdx = 0;

const fallingLeafGeo = new THREE.PlaneGeometry(0.2, 0.26);
const fallingLeafMat = new THREE.MeshStandardMaterial({
  roughness: 0.45,
  side: THREE.DoubleSide,
  transparent: true,
  opacity: 1.0,
});
const fallingLeafIM = new THREE.InstancedMesh(fallingLeafGeo, fallingLeafMat, FALLING_LEAF_POOL_SIZE);
fallingLeafIM.count = FALLING_LEAF_POOL_SIZE;
fallingLeafIM.castShadow = true;
fallingLeafIM.frustumCulled = false;
treeGroup.add(fallingLeafIM);

// Hide all instances off-screen initially and assign per-instance colors
const _flDummy = new THREE.Object3D();
for (let i = 0; i < FALLING_LEAF_POOL_SIZE; i++) {
  _flDummy.position.set(0, -100, 0);
  _flDummy.scale.set(0.001, 0.001, 0.001);
  _flDummy.updateMatrix();
  fallingLeafIM.setMatrixAt(i, _flDummy.matrix);
  const colorIdx = Math.floor(Math.random() * leafColors.length);
  const c = new THREE.Color(leafColors[colorIdx]);
  fallingLeafIM.setColorAt(i, c);
  fallingLeafPool.push({
    idx: i,
    position: new THREE.Vector3(0, -100, 0),
    rotation: new THREE.Euler(),
    scale: 1,
    velocity: new THREE.Vector3(),
    rotSpeed: new THREE.Vector3(),
    swayOffset: 0,
    life: 0,
    opacity: 0,
    active: false,
  });
}
fallingLeafIM.instanceMatrix.needsUpdate = true;
fallingLeafIM.instanceColor.needsUpdate = true;

function spawnFallingLeaf() {
  const entry = fallingLeafPool[fallingLeafNextIdx];
  fallingLeafNextIdx = (fallingLeafNextIdx + 1) % FALLING_LEAF_POOL_SIZE;

  const startAngle = Math.random() * Math.PI * 2;
  const startRadius = Math.random() * 4;
  const s = 0.7 + Math.random() * 0.8;

  entry.position.set(
    Math.cos(startAngle) * startRadius,
    8 + Math.random() * 8,
    Math.sin(startAngle) * startRadius
  );
  entry.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
  entry.scale = s;
  entry.opacity = 0.85;
  entry.velocity.set(
    (Math.random() - 0.5) * 0.02,
    -0.01 - Math.random() * 0.02,
    (Math.random() - 0.5) * 0.02
  );
  entry.rotSpeed.set(
    (Math.random() - 0.5) * 0.05,
    (Math.random() - 0.5) * 0.05,
    (Math.random() - 0.5) * 0.03
  );
  entry.swayOffset = Math.random() * Math.PI * 2;
  entry.life = 1;
  entry.active = true;

  // Assign a new random color on recycle
  const colorIdx = Math.floor(Math.random() * leafColors.length);
  fallingLeafIM.setColorAt(entry.idx, new THREE.Color(leafColors[colorIdx]));
}

// Build the tree
function buildTree() {
  // Clear old tree
  while (treeGroup.children.length) {
    const child = treeGroup.children[0];
    treeGroup.remove(child);
    if (child.geometry && !child.isInstancedMesh) child.geometry.dispose();
    if (child.material && !Array.isArray(child.material) && !child.isInstancedMesh) child.material.dispose();
  }
  branches.length = 0;
  leaves.length = 0;
  flowers.length = 0;
  fallingLeaves.length = 0;

  // Re-add instanced meshes and reset counts
  for (let i = 0; i < leafInstancedMeshes.length; i++) {
    leafInstancedMeshes[i].count = 0;
    treeGroup.add(leafInstancedMeshes[i]);
  }
  for (let i = 0; i < flowerInstancedMeshes.length; i++) {
    flowerInstancedMeshes[i].count = 0;
    treeGroup.add(flowerInstancedMeshes[i]);
  }
  flowerCenterIM.count = 0;
  treeGroup.add(flowerCenterIM);

  // Trunk — slightly tilted for organic feel, thicker base
  const trunkDir = new THREE.Vector3(0.03, 1, 0.02).normalize();
  createBranch(new THREE.Vector3(0, 0, 0), trunkDir, 6, 0.6, 0, 0);

  // Add leaves on higher depth branches
  branches.forEach((b) => {
    if (b.depth >= 3) {
      const numLeaves = 3 + Math.floor(Math.random() * 5);
      for (let i = 0; i < numLeaves; i++) {
        createLeaf(b.endPos, b.endDirection);
      }
      if (Math.random() > 0.6) {
        createFlower(b.endPos);
      }
    }
  });

  // Leaf clusters for canopy fullness
  branches.forEach((b) => {
    if (b.depth >= 2 && b.depth <= 4) {
      const numExtra = Math.floor(Math.random() * 4);
      for (let i = 0; i < numExtra; i++) {
        const mid = b.endPos.clone().lerp(
          new THREE.Vector3(0, b.endPos.y + 1, 0),
          Math.random() * 0.3
        );
        createLeaf(mid, b.endDirection);
      }
    }
  });
}

buildTree();

// Auto-grow on load
setTimeout(() => {
  targetGrowth = 1;
  isGrowing = true;
  growthSpeed = 0.15;
}, 300);

// UI
const uiContainer = document.createElement('div');
uiContainer.style.cssText = `
  position: fixed;
  bottom: 30px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
  font-family: 'Inter', -apple-system, sans-serif;
  z-index: 10;
  pointer-events: none;
`;
document.body.appendChild(uiContainer);

// FPS Counter
const fpsDisplay = document.createElement('div');
fpsDisplay.style.cssText = `
  position: fixed;
  top: 14px;
  left: 14px;
  font-family: 'Inter', -apple-system, monospace;
  font-size: 12px;
  color: rgba(90,70,65,0.5);
  letter-spacing: 0.04em;
  z-index: 10;
  pointer-events: none;
`;
document.body.appendChild(fpsDisplay);

let fpsFrames = 0;
let fpsLastTime = performance.now();
function updateFPS() {
  fpsFrames++;
  const now = performance.now();
  if (now - fpsLastTime >= 500) {
    const fps = Math.round((fpsFrames * 1000) / (now - fpsLastTime));
    fpsDisplay.textContent = `${fps} FPS`;
    fpsFrames = 0;
    fpsLastTime = now;
  }
}

const infoText = document.createElement('div');
infoText.style.cssText = `
  color: rgba(90,70,65,0.5);
  font-size: 12px;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  pointer-events: none;
`;
infoText.textContent = 'Click to grow · Scroll to zoom';
uiContainer.appendChild(infoText);

const buttonRow = document.createElement('div');
buttonRow.style.cssText = `
  display: flex;
  gap: 10px;
  pointer-events: all;
`;
uiContainer.appendChild(buttonRow);

function createButton(text, onClick) {
  const btn = document.createElement('button');
  btn.textContent = text;
  btn.style.cssText = `
    background: rgba(120,80,70,0.06);
    border: 1px solid rgba(120,80,70,0.18);
    color: rgba(90,60,55,0.8);
    padding: 10px 22px;
    font-size: 13px;
    font-family: 'Inter', -apple-system, sans-serif;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    backdrop-filter: blur(10px);
    letter-spacing: 0.03em;
  `;
  btn.addEventListener('mouseenter', () => {
    btn.style.background = 'rgba(120,80,70,0.12)';
    btn.style.borderColor = 'rgba(120,80,70,0.3)';
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.background = 'rgba(120,80,70,0.06)';
    btn.style.borderColor = 'rgba(120,80,70,0.18)';
  });
  btn.addEventListener('click', onClick);
  buttonRow.appendChild(btn);
  return btn;
}

const growBtn = createButton('Grow', () => {
  targetGrowth = Math.min(1, targetGrowth + 0.25);
  isGrowing = true;
});

createButton('Full Bloom', () => {
  targetGrowth = 1;
  isGrowing = true;
});

createButton('New Seed', () => {
  growthProgress = 0;
  targetGrowth = 0;
  isGrowing = false;
  buildTree();
});

// Progress bar
const progressContainer = document.createElement('div');
progressContainer.style.cssText = `
  width: 200px;
  height: 3px;
  background: rgba(120,80,70,0.1);
  border-radius: 2px;
  overflow: hidden;
  pointer-events: none;
`;
uiContainer.appendChild(progressContainer);

const progressBar = document.createElement('div');
progressBar.style.cssText = `
  width: 0%;
  height: 100%;
  background: rgba(245, 150, 170, 0.7);
  border-radius: 2px;
  transition: width 0.1s ease;
`;
progressContainer.appendChild(progressBar);

// Click on canvas to grow — deferred until renderer exists
function setupCanvasClick() {
  if (renderer && renderer.domElement) {
    renderer.domElement.addEventListener('click', () => {
      targetGrowth = Math.min(1, targetGrowth + 0.12);
      isGrowing = true;
    });
  }
}

// Particle system for floating pollen/fireflies
const particleCount = 50;
const particleGeo = new THREE.BufferGeometry();
const particlePositions = new Float32Array(particleCount * 3);
const particleSizes = new Float32Array(particleCount);
const particleData = [];

for (let i = 0; i < particleCount; i++) {
  const angle = Math.random() * Math.PI * 2;
  const radius = 2 + Math.random() * 12;
  particlePositions[i * 3] = Math.cos(angle) * radius;
  particlePositions[i * 3 + 1] = 1 + Math.random() * 18;
  particlePositions[i * 3 + 2] = Math.sin(angle) * radius;
  particleSizes[i] = 0.02 + Math.random() * 0.05;

  particleData.push({
    speed: 0.2 + Math.random() * 0.5,
    offset: Math.random() * Math.PI * 2,
    radius: radius,
    baseY: particlePositions[i * 3 + 1],
  });
}

particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));

const particleMat = new THREE.PointsMaterial({
  color: 0xffccd5,
  size: 0.1,
  transparent: true,
  opacity: 0.5,
  blending: THREE.NormalBlending,
  depthWrite: false,
});

const particles = new THREE.Points(particleGeo, particleMat);
scene.add(particles);

// Falling leaf timer
let leafTimer = 0;
let frameCount = 0;

// Animation
function animate() {
  requestAnimationFrame(animate);
  if (!rendererReady) return;
  frameCount++;
  const dt = Math.min(clock.getDelta(), 0.05);
  const time = clock.elapsedTime;

  if (controls) controls.update();

  // Growth animation
  if (isGrowing && growthProgress < targetGrowth) {
    growthProgress += dt * growthSpeed;
    if (growthProgress >= targetGrowth) {
      growthProgress = targetGrowth;
      if (growthProgress >= 1) isGrowing = false;
    }
  }

  progressBar.style.width = `${growthProgress * 100}%`;

  // Update branches — use draw range instead of rebuilding geometry
  for (let bi = 0, bl = branches.length; bi < bl; bi++) {
    const b = branches[bi];
    const branchT = (growthProgress - b.growthStart) / (b.growthEnd - b.growthStart);

    if (branchT <= 0) {
      if (b.mesh.visible) b.mesh.visible = false;
      continue;
    }

    if (!b.mesh.visible) b.mesh.visible = true;

    // Smooth ease-out for organic feel
    const clamped = branchT > 1 ? 1 : branchT;
    const eased = 1 - Math.pow(1 - clamped, 2.5);

    // Use draw range on the full geometry instead of rebuilding each frame
    const visibleSegments = Math.max(1, (eased * b.segments) | 0);
    const indexCount = visibleSegments * b.radialSegments * 6;
    b.mesh.geometry.setDrawRange(0, indexCount);

    // Gentle sway for smaller branches — applied at the branch start (pivot)
    // We accumulate parent sway so children stay connected
    if (eased > 0.5 && b.depth >= 2) {
      const phaseZ = time * 0.6 + b.depth * 1.2 + b.growthStart * 10;
      const ownSwayZ = Math.sin(phaseZ) * 0.004 * b.depth;
      const ownSwayX = Math.sin(time * 0.5 + b.growthStart * 5) * 0.002 * b.depth;

      // Accumulate parent sway chain
      let totalSwayZ = ownSwayZ;
      let totalSwayX = ownSwayX;
      let parent = b.parentBranch;
      while (parent && parent.depth >= 2) {
        const pPhaseZ = time * 0.6 + parent.depth * 1.2 + parent.growthStart * 10;
        totalSwayZ += Math.sin(pPhaseZ) * 0.004 * parent.depth;
        totalSwayX += Math.sin(time * 0.5 + parent.growthStart * 5) * 0.002 * parent.depth;
        parent = parent.parentBranch;
      }

      // Rotate around the branch start point (pivot at base)
      const sp = b.startPos;
      b.mesh.position.set(0, 0, 0);
      b.mesh.rotation.set(0, 0, 0);

      // Apply rotation around the start position
      b.mesh.position.sub(sp);
      b.mesh.rotation.z = totalSwayZ;
      b.mesh.rotation.x = totalSwayX;
      b.mesh.position.applyEuler(b.mesh.rotation);
      b.mesh.position.add(sp);
    } else if (b.depth >= 2) {
      // Reset transform when not swaying
      b.mesh.position.set(0, 0, 0);
      b.mesh.rotation.set(0, 0, 0);
    }
  }

  // Update instanced leaves — compose matrix directly, skip Object3D overhead
  const leafDirtyFlags = new Uint8Array(leafInstancedMeshes.length);

  for (let li = 0, ll = leaves.length; li < ll; li++) {
    const l = leaves[li];
    const leafT = (growthProgress - l.growthStart) * 6.6667; // 1/0.15
    if (leafT <= 0) {
      if (l.currentScale > 0) {
        l.currentScale = 0;
        _leafMatrix.makeScale(0.001, 0.001, 0.001);
        _leafMatrix.setPosition(l.originalPos.x, l.originalPos.y, l.originalPos.z);
        l.instancedMesh.setMatrixAt(l.instanceIdx, _leafMatrix);
        leafDirtyFlags[l.colorIdx] = 1;
      }
      continue;
    }

    const t = leafT > 1 ? 1 : leafT;
    // Inline elastic easing
    const omt = 1 - t;
    const elastic = t < 1 ? 1 - omt * omt * omt * Math.cos(t * 2.5133) : 1;
    const scale = elastic * l.targetScale;
    if (scale < 0.001) continue;

    // Only update sway every ~3 frames for fully grown leaves
    if (t >= 1 && l.currentScale === scale && (li & 3) !== (frameCount & 3)) continue;

    const phase = time * l.swaySpeed + l.swayOffset;
    _tempEuler.set(
      l.baseRotX + Math.sin(phase * 0.5) * 0.1,
      l.baseRotY + time * 0.15,
      l.baseRotZ
    );
    _tempQuat.setFromEuler(_tempEuler);
    _tempScale.set(scale, scale, scale);
    _tempVec3.set(
      l.originalPos.x + Math.sin(phase) * 0.06,
      l.originalPos.y + Math.sin(phase * 0.7) * 0.03,
      l.originalPos.z
    );
    _leafMatrix.compose(_tempVec3, _tempQuat, _tempScale);
    l.instancedMesh.setMatrixAt(l.instanceIdx, _leafMatrix);
    l.currentScale = scale;
    leafDirtyFlags[l.colorIdx] = 1;
  }

  for (let i = 0; i < leafInstancedMeshes.length; i++) {
    if (leafDirtyFlags[i]) leafInstancedMeshes[i].instanceMatrix.needsUpdate = true;
  }

  // Update instanced flowers — compose matrix directly, stagger sway updates
  const flowerDirtyFlags = new Uint8Array(flowerInstancedMeshes.length);
  let centerDirty = false;
  const petalAngleStep = Math.PI * 2 / 5;
  // Precompute petal angles
  const petalCos = [1, 0.309, -0.809, -0.809, 0.309];
  const petalSin = [0, 0.951, 0.588, -0.588, -0.951];

  for (let fi = 0, fl = flowers.length; fi < fl; fi++) {
    const f = flowers[fi];
    const flowerT = (growthProgress - f.growthStart) * 8.3333; // 1/0.12
    const t = flowerT <= 0 ? 0 : (flowerT > 1 ? 1 : flowerT);

    // Skip sway-only updates on staggered frames for fully bloomed flowers
    if (t >= 1 && f.currentScale === f.targetScale && (fi & 3) !== (frameCount & 3)) continue;

    const omt = 1 - t;
    const elastic = t > 0 && t < 1 ? 1 - omt * omt * omt * Math.cos(t * 1.885) : t;
    const scale = elastic * f.targetScale;
    const s = scale < 0.001 ? 0.001 : scale;

    const rotY = f.baseRotY + time * 0.15;

    for (let pi = 0; pi < f.petalIndices.length; pi++) {
      _tempVec3.set(
        f.position.x + petalCos[pi] * 0.1 * s,
        f.position.y,
        f.position.z + petalSin[pi] * 0.1 * s
      );
      _tempEuler.set(f.baseRotX, rotY - pi * petalAngleStep, f.baseRotZ + 0.5);
      _tempQuat.setFromEuler(_tempEuler);
      _tempScale.set(s, s, s);
      _leafMatrix.compose(_tempVec3, _tempQuat, _tempScale);
      f.instancedMesh.setMatrixAt(f.petalIndices[pi], _leafMatrix);
    }

    flowerDirtyFlags[f.colorIdx] = 1;

    // Center
    _tempVec3.copy(f.position);
    _tempEuler.set(f.baseRotX, rotY, f.baseRotZ);
    _tempQuat.setFromEuler(_tempEuler);
    _tempScale.set(s, s, s);
    _leafMatrix.compose(_tempVec3, _tempQuat, _tempScale);
    flowerCenterIM.setMatrixAt(f.centerIdx, _leafMatrix);
    centerDirty = true;
    f.currentScale = scale;
  }

  for (let i = 0; i < flowerInstancedMeshes.length; i++) {
    if (flowerDirtyFlags[i]) flowerInstancedMeshes[i].instanceMatrix.needsUpdate = true;
  }
  if (centerDirty) flowerCenterIM.instanceMatrix.needsUpdate = true;

  // Falling leaves — pool-based, zero allocations
  if (growthProgress > 0.8) {
    leafTimer += dt;
    if (leafTimer > 1.2) {
      leafTimer = 0;
      spawnFallingLeaf();
    }
  }

  let fallingDirty = false;
  let fallingColorDirty = false;
  // Track min opacity across active leaves for shared material
  let minOpacity = 1;
  let hasActiveLeaves = false;

  for (let i = 0; i < FALLING_LEAF_POOL_SIZE; i++) {
    const fl = fallingLeafPool[i];
    if (!fl.active) continue;
    hasActiveLeaves = true;

    const pos = fl.position;
    const vel = fl.velocity;
    pos.x += vel.x + Math.sin(time * 2 + fl.swayOffset) * 0.01;
    pos.y += vel.y;
    pos.z += vel.z;
    fl.rotation.x += fl.rotSpeed.x;
    fl.rotation.y += fl.rotSpeed.y;
    fl.rotation.z += fl.rotSpeed.z;
    vel.y -= 0.0001;

    if (pos.y < 0.1) {
      fl.life -= dt * 0.5;
      if (fl.life <= 0) {
        fl.active = false;
        // Hide by moving off-screen and scaling to zero
        _leafMatrix.makeScale(0.001, 0.001, 0.001);
        _leafMatrix.setPosition(0, -100, 0);
        fallingLeafIM.setMatrixAt(fl.idx, _leafMatrix);
        fallingDirty = true;
        continue;
      } else {
        fl.opacity = fl.life;
        // Encode opacity into per-instance color alpha by dimming the color
        const colorIdx = Math.floor(Math.random() * leafColors.length);
        const c = new THREE.Color(leafColors[colorIdx]).multiplyScalar(fl.life);
        fallingLeafIM.setColorAt(fl.idx, c);
        fallingColorDirty = true;
      }
    }

    // Compose instance matrix
    _tempEuler.set(fl.rotation.x, fl.rotation.y, fl.rotation.z);
    _tempQuat.setFromEuler(_tempEuler);
    _tempScale.set(fl.scale, fl.scale, fl.scale);
    _tempVec3.copy(pos);
    _leafMatrix.compose(_tempVec3, _tempQuat, _tempScale);
    fallingLeafIM.setMatrixAt(fl.idx, _leafMatrix);
    fallingDirty = true;
  }

  if (fallingDirty) fallingLeafIM.instanceMatrix.needsUpdate = true;
  if (fallingColorDirty) fallingLeafIM.instanceColor.needsUpdate = true;

  // Update particles — every 4th frame
  if ((frameCount & 3) === 0) {
    const positions = particles.geometry.attributes.position.array;
    for (let i = 0; i < particleCount; i++) {
      const pd = particleData[i];
      const angle = time * pd.speed * 0.1 + pd.offset;
      positions[i * 3] = Math.cos(angle) * pd.radius;
      positions[i * 3 + 1] = pd.baseY + Math.sin(time * pd.speed * 0.5 + pd.offset) * 1.5;
      positions[i * 3 + 2] = Math.sin(angle) * pd.radius;
    }
    particles.geometry.attributes.position.needsUpdate = true;
  }
  particleMat.opacity = 0.15 + Math.sin(time * 0.5) * 0.1 + growthProgress * 0.25;

  // Dynamic light
  pointLight.intensity = 0.2 + growthProgress * 0.3 + Math.sin(time * 1.5) * 0.08;
  pointLight.position.y = 3 + growthProgress * 5;

  renderer.render(scene, camera);
  updateFPS();
}

animate();

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  if (renderer) renderer.setSize(window.innerWidth, window.innerHeight);
});

// Initialize everything — async renderer init, then start
initRenderer().then(() => {
  setupCanvasClick();
});