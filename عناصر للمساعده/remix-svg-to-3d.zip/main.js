

// --- WebGPU Renderer Setup ---
let renderer;
const canvas = document.createElement('canvas');
document.body.appendChild(canvas);

renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1a1a1a);
scene.fog = new THREE.FogExp2(0x1a1a1a, 0.015);

const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 2, 8);

const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.06;
controls.autoRotate = true;
controls.autoRotateSpeed = 0.8;
controls.minDistance = 2;
controls.maxDistance = 50;
controls.target.set(0, 0, 0);

// --- Lighting ---
const ambientLight = new THREE.AmbientLight(0x303050, 0.8);
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0xffffff, 2.5);
dirLight.position.set(5, 10, 7);
dirLight.castShadow = true;
dirLight.shadow.mapSize.set(2048, 2048);
dirLight.shadow.camera.near = 0.1;
dirLight.shadow.camera.far = 50;
dirLight.shadow.camera.left = -15;
dirLight.shadow.camera.right = 15;
dirLight.shadow.camera.top = 15;
dirLight.shadow.camera.bottom = -15;
dirLight.shadow.bias = -0.001;
scene.add(dirLight);

const fillLight = new THREE.DirectionalLight(0x6688ff, 1.0);
fillLight.position.set(-5, 3, -5);
scene.add(fillLight);

const rimLight = new THREE.DirectionalLight(0xff6644, 0.8);
rimLight.position.set(0, -3, -8);
scene.add(rimLight);

const pointLight1 = new THREE.PointLight(0x4488ff, 3, 20);
pointLight1.position.set(-4, 5, 4);
scene.add(pointLight1);

const pointLight2 = new THREE.PointLight(0xff4488, 2, 20);
pointLight2.position.set(4, 2, -4);
scene.add(pointLight2);

// --- Environment Map (PMREM) for realistic reflections ---
const pmremGenerator = new THREE.PMREMGenerator(renderer);
pmremGenerator.compileEquirectangularShader();

// Create a procedural environment scene
const envScene = new THREE.Scene();
const envGradientCanvas = document.createElement('canvas');
envGradientCanvas.width = 1024;
envGradientCanvas.height = 512;
const ctx = envGradientCanvas.getContext('2d');

// Create a rich gradient environment
const gradient = ctx.createLinearGradient(0, 0, 0, 512);
gradient.addColorStop(0, '#0a0a1a');
gradient.addColorStop(0.2, '#1a1a3a');
gradient.addColorStop(0.4, '#2a2a4a');
gradient.addColorStop(0.5, '#3a3a5a');
gradient.addColorStop(0.6, '#2a2a4a');
gradient.addColorStop(0.8, '#1a1a2a');
gradient.addColorStop(1, '#0a0a15');
ctx.fillStyle = gradient;
ctx.fillRect(0, 0, 1024, 512);

// Add some bright spots to simulate light sources
function addGlow(x, y, r, color, alpha) {
  const grd = ctx.createRadialGradient(x, y, 0, x, y, r);
  grd.addColorStop(0, color);
  grd.addColorStop(1, 'transparent');
  ctx.globalAlpha = alpha;
  ctx.fillStyle = grd;
  ctx.fillRect(x - r, y - r, r * 2, r * 2);
  ctx.globalAlpha = 1.0;
}

addGlow(256, 128, 120, '#4488ff', 0.6);
addGlow(768, 160, 100, '#ff4488', 0.5);
addGlow(512, 80, 150, '#ffffff', 0.4);
addGlow(128, 300, 80, '#44ffaa', 0.3);
addGlow(900, 350, 90, '#ffaa44', 0.3);

// Add subtle horizontal streaks for studio-like reflections
ctx.globalAlpha = 0.08;
for (let i = 0; i < 20; i++) {
  const yPos = Math.random() * 512;
  const width = 200 + Math.random() * 600;
  const xPos = Math.random() * 1024;
  const hgt = 1 + Math.random() * 3;
  ctx.fillStyle = `hsl(${Math.random() * 360}, 30%, 70%)`;
  ctx.fillRect(xPos, yPos, width, hgt);
}
ctx.globalAlpha = 1.0;

const envTexture = new THREE.CanvasTexture(envGradientCanvas);
envTexture.mapping = THREE.EquirectangularReflectionMapping;

const envMap = pmremGenerator.fromEquirectangular(envTexture).texture;
scene.environment = envMap;

envTexture.dispose();
pmremGenerator.dispose();





// --- SVG Group ---
let svgGroup = null;
let extrusionDepth = 20;
let currentSVGData = null;
let meshMaterialType = 'standard';
let bevelScale = 0.5; // 0 to 1

// --- Color Palette ---
const colorPalette = [
  0x4488ff, 0xff4488, 0x44ff88, 0xff8844,
  0x8844ff, 0x44ffff, 0xff44ff, 0xffff44,
  0x66aaff, 0xff6666, 0x66ff99, 0xffaa66,
];

function getColorForIndex(index) {
  return colorPalette[index % colorPalette.length];
}

function createMaterial(color, type) {
  switch (type) {
    case 'metallic':
      return new THREE.MeshStandardMaterial({
        color,
        metalness: 0.95,
        roughness: 0.08,
        side: THREE.DoubleSide,
        envMapIntensity: 2.0,
        flatShading: false,
      });
    case 'glass':
      return new THREE.MeshPhysicalMaterial({
        color,
        metalness: 0.0,
        roughness: 0.02,
        transmission: 0.85,
        thickness: 0.8,
        ior: 1.5,
        clearcoat: 1.0,
        clearcoatRoughness: 0.05,
        side: THREE.DoubleSide,
        envMapIntensity: 2.5,
        flatShading: false,
      });
    case 'emissive':
      return new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.5,
        metalness: 0.4,
        roughness: 0.3,
        side: THREE.DoubleSide,
        envMapIntensity: 1.2,
        flatShading: false,
      });
    default:
      return new THREE.MeshStandardMaterial({
        color,
        metalness: 0.4,
        roughness: 0.35,
        side: THREE.DoubleSide,
        envMapIntensity: 1.5,
        flatShading: false,
      });
  }
}

// --- Build 3D from SVG ---
function buildSVG3D(svgData, depth, materialType) {
  if (svgGroup) {
    scene.remove(svgGroup);
    svgGroup.traverse((child) => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) child.material.forEach(m => m.dispose());
        else child.material.dispose();
      }
    });
  }

  svgGroup = new THREE.Group();
  svgGroup.name = 'svgGroup';
  const paths = svgData.paths;

  paths.forEach((pathData, pathIndex) => {
    const fillColor = pathData.userData.style.fill;
    const strokeColor = pathData.userData.style.stroke;
    const shapePath = pathData.shapePath;

    // Fill shapes
    if (fillColor !== undefined && fillColor !== 'none' && fillColor !== 'transparent') {
      // Convert ShapePath subPaths to Shapes - try both winding orders
      let shapes = [];
      try {
        shapes = shapePath.toShapes(true);
      } catch (e) {
        // ignore
      }
      if (!shapes || shapes.length === 0) {
        try {
          shapes = shapePath.toShapes(false);
        } catch (e2) {
          console.warn('Could not create shapes for path', pathIndex, e2);
          shapes = [];
        }
      }
      // Fallback: if toShapes fails, try extracting individual subPaths as shapes
      if (shapes.length === 0 && shapePath.subPaths && shapePath.subPaths.length > 0) {
        shapePath.subPaths.forEach(subPath => {
          try {
            const pts = subPath.getPoints();
            if (pts.length >= 3) {
              const fallbackShape = new THREE.Shape(pts);
              shapes.push(fallbackShape);
            }
          } catch(e3) { /* skip */ }
        });
      }

      shapes.forEach((shape, shapeIndex) => {
        // Compute shape bounding box to scale bevel safely
        const pts = shape.getPoints();
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        pts.forEach(p => { minX = Math.min(minX, p.x); minY = Math.min(minY, p.y); maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y); });
        const shapeSize = Math.min(maxX - minX, maxY - minY);
        // Limit bevel to avoid self-intersecting geometry
        const maxBevelSize = Math.max(0.01, shapeSize * 0.06);
        const bevelSize = Math.min(depth * 0.15, maxBevelSize) * bevelScale;
        const bevelThickness = Math.min(depth * 0.2, maxBevelSize) * bevelScale;

        const extrudeSettings = {
          depth: depth,
          bevelEnabled: bevelScale > 0.01 && bevelSize > 0.001,
          bevelThickness: bevelThickness,
          bevelSize: bevelSize,
          bevelOffset: 0,
          bevelSegments: 8,
          curveSegments: 48,
        };

        let geometry;
        try {
          geometry = new THREE.ExtrudeGeometry(shape, extrudeSettings);
        } catch (extErr) {
          // If extrusion fails with bevel, try without bevel
          try {
            geometry = new THREE.ExtrudeGeometry(shape, {
              depth: depth,
              bevelEnabled: false,
              curveSegments: 48,
            });
          } catch (extErr2) {
            console.warn('Extrusion failed for shape', shapeIndex, extErr2);
            return;
          }
        }
        geometry.deleteAttribute('normal');
        geometry.computeVertexNormals();
        let color;
        try {
          color = new THREE.Color(fillColor);
        } catch (e) {
          color = new THREE.Color(getColorForIndex(pathIndex));
        }

        const material = createMaterial(color, materialType);
        const mesh = new THREE.Mesh(geometry, material);
        mesh.name = `svgFill_${pathIndex}_${shapeIndex}`;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        svgGroup.add(mesh);
      });
    }

    // Stroke lines as tubes
    if (strokeColor !== undefined && strokeColor !== 'none' && strokeColor !== 'transparent') {
      const strokeWidth = pathData.userData.style.strokeWidth || 1;
      shapePath.subPaths.forEach((subPath, subIndex) => {
        const points = subPath.getPoints(24);
        if (points.length < 2) return;

        // Remove duplicate consecutive points to avoid zero-length segments
        const cleaned = [points[0]];
        for (let i = 1; i < points.length; i++) {
          const prev = cleaned[cleaned.length - 1];
          if (Math.abs(points[i].x - prev.x) > 0.001 || Math.abs(points[i].y - prev.y) > 0.001) {
            cleaned.push(points[i]);
          }
        }
        if (cleaned.length < 2) return;

        const points3D = cleaned.map(p => new THREE.Vector3(p.x, p.y, depth / 2));
        
        let curve;
        if (points3D.length === 2) {
          curve = new THREE.LineCurve3(points3D[0], points3D[1]);
        } else {
          curve = new THREE.CatmullRomCurve3(points3D, false, 'centripetal', 0.5);
        }
        const tubularSegments = Math.max(cleaned.length * 4, 16);
        const tubeGeo = new THREE.TubeGeometry(curve, tubularSegments, strokeWidth * 0.15, 16, false);
        tubeGeo.deleteAttribute('normal');
        tubeGeo.computeVertexNormals();

        let color;
        try {
          color = new THREE.Color(strokeColor);
        } catch (e) {
          color = new THREE.Color(0xffffff);
        }

        const tubeMat = createMaterial(color, materialType);
        const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
        tubeMesh.name = `svgStroke_${pathIndex}_${subIndex}`;
        tubeMesh.castShadow = true;
        svgGroup.add(tubeMesh);
      });
    }
  });

  // Center and scale the group
  const box = new THREE.Box3().setFromObject(svgGroup);
  const center = box.getCenter(new THREE.Vector3());
  const size = box.getSize(new THREE.Vector3());

  const maxDim = Math.max(size.x, size.y, size.z);
  const scale = 3.75 / maxDim;

  svgGroup.scale.set(scale, -scale, scale);

  const boxAfter = new THREE.Box3().setFromObject(svgGroup);
  const centerAfter = boxAfter.getCenter(new THREE.Vector3());
  svgGroup.position.sub(centerAfter);

  scene.add(svgGroup);

  controls.target.set(0, 0, 0);
  controls.update();

  updateStatus(`Loaded: ${paths.length} paths, ${svgGroup.children.length} meshes`);
}

// --- SVG Parser (manual implementation since SVGLoader is not available) ---

function parseSVGText(svgText) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(svgText, 'image/svg+xml');
  const svgEl = doc.querySelector('svg');
  if (!svgEl) throw new Error('No <svg> element found');

  const paths = [];

  // Get viewBox or width/height for coordinate system
  const viewBox = svgEl.getAttribute('viewBox');
  let vbX = 0, vbY = 0, vbW = 300, vbH = 150;
  if (viewBox) {
    const parts = viewBox.split(/[\s,]+/).map(Number);
    if (parts.length === 4) { vbX = parts[0]; vbY = parts[1]; vbW = parts[2]; vbH = parts[3]; }
  } else {
    const w = parseFloat(svgEl.getAttribute('width')) || 300;
    const h = parseFloat(svgEl.getAttribute('height')) || 150;
    vbW = w; vbH = h;
  }

  // Collect all shape elements
  const elements = svgEl.querySelectorAll('path, rect, circle, ellipse, polygon, polyline, line');

  elements.forEach((el) => {
    const style = {
      fill: el.getAttribute('fill') || getComputedStyleAttr(el, 'fill') || '#000000',
      stroke: el.getAttribute('stroke') || getComputedStyleAttr(el, 'stroke') || 'none',
      strokeWidth: parseFloat(el.getAttribute('stroke-width') || getComputedStyleAttr(el, 'stroke-width') || '1'),
    };
    if (style.fill === 'inherit' || style.fill === '') style.fill = '#000000';

    // Parse inline style attribute
    const inlineStyle = el.getAttribute('style') || '';
    const fillMatch = inlineStyle.match(/fill\s*:\s*([^;]+)/);
    const strokeMatch = inlineStyle.match(/stroke\s*:\s*([^;]+)/);
    const strokeWMatch = inlineStyle.match(/stroke-width\s*:\s*([^;]+)/);
    if (fillMatch) style.fill = fillMatch[1].trim();
    if (strokeMatch) style.stroke = strokeMatch[1].trim();
    if (strokeWMatch) style.strokeWidth = parseFloat(strokeWMatch[1].trim());

    // Get transform
    const transform = getElementTransform(el);

    let d = '';
    const tag = el.tagName.toLowerCase();

    if (tag === 'path') {
      d = el.getAttribute('d') || '';
    } else if (tag === 'rect') {
      const x = parseFloat(el.getAttribute('x') || 0);
      const y = parseFloat(el.getAttribute('y') || 0);
      const w = parseFloat(el.getAttribute('width') || 0);
      const h = parseFloat(el.getAttribute('height') || 0);
      let rx = parseFloat(el.getAttribute('rx') || 0);
      let ry = parseFloat(el.getAttribute('ry') || rx);
      if (rx === 0 && ry === 0) {
        d = `M${x},${y} L${x+w},${y} L${x+w},${y+h} L${x},${y+h} Z`;
      } else {
        rx = Math.min(rx, w / 2);
        ry = Math.min(ry, h / 2);
        d = `M${x+rx},${y} L${x+w-rx},${y} A${rx},${ry} 0 0 1 ${x+w},${y+ry} L${x+w},${y+h-ry} A${rx},${ry} 0 0 1 ${x+w-rx},${y+h} L${x+rx},${y+h} A${rx},${ry} 0 0 1 ${x},${y+h-ry} L${x},${y+ry} A${rx},${ry} 0 0 1 ${x+rx},${y} Z`;
      }
    } else if (tag === 'circle') {
      const cx = parseFloat(el.getAttribute('cx') || 0);
      const cy = parseFloat(el.getAttribute('cy') || 0);
      const r = parseFloat(el.getAttribute('r') || 0);
      d = `M${cx-r},${cy} A${r},${r} 0 1 0 ${cx+r},${cy} A${r},${r} 0 1 0 ${cx-r},${cy} Z`;
    } else if (tag === 'ellipse') {
      const cx = parseFloat(el.getAttribute('cx') || 0);
      const cy = parseFloat(el.getAttribute('cy') || 0);
      const rx = parseFloat(el.getAttribute('rx') || 0);
      const ry = parseFloat(el.getAttribute('ry') || 0);
      d = `M${cx-rx},${cy} A${rx},${ry} 0 1 0 ${cx+rx},${cy} A${rx},${ry} 0 1 0 ${cx-rx},${cy} Z`;
    } else if (tag === 'polygon' || tag === 'polyline') {
      const pts = (el.getAttribute('points') || '').trim().split(/[\s,]+/).map(Number);
      if (pts.length >= 4) {
        d = `M${pts[0]},${pts[1]}`;
        for (let i = 2; i < pts.length; i += 2) {
          d += ` L${pts[i]},${pts[i + 1]}`;
        }
        if (tag === 'polygon') d += ' Z';
      }
    } else if (tag === 'line') {
      const x1 = parseFloat(el.getAttribute('x1') || 0);
      const y1 = parseFloat(el.getAttribute('y1') || 0);
      const x2 = parseFloat(el.getAttribute('x2') || 0);
      const y2 = parseFloat(el.getAttribute('y2') || 0);
      d = `M${x1},${y1} L${x2},${y2}`;
    }

    if (!d) return;

    // Parse path data into ShapePath
    const shapePath = parsePathData(d, transform);

    paths.push({
      userData: { style },
      shapePath: shapePath,
    });
  });

  return { paths };
}

function getComputedStyleAttr(el, attr) {
  // Walk up parents checking for style or attribute
  let node = el;
  while (node && node.nodeType === 1) {
    const val = node.getAttribute(attr);
    if (val && val !== 'inherit') return val;
    const st = node.getAttribute('style') || '';
    const m = st.match(new RegExp(attr + '\\s*:\\s*([^;]+)'));
    if (m) return m[1].trim();
    node = node.parentNode;
  }
  return null;
}

function getElementTransform(el) {
  // Accumulate transforms from element to SVG root
  const transforms = [];
  let node = el;
  while (node && node.nodeType === 1 && node.tagName.toLowerCase() !== 'svg') {
    const t = node.getAttribute('transform');
    if (t) transforms.unshift(t);
    node = node.parentNode;
  }
  if (transforms.length === 0) return null;
  return transforms.join(' ');
}

function parseTransformToMatrix(transformStr) {
  // Returns a 2D affine transform as [a, b, c, d, e, f]
  let m = [1, 0, 0, 1, 0, 0]; // identity

  const ops = transformStr.match(/(matrix|translate|scale|rotate|skewX|skewY)\s*\([^)]*\)/gi);
  if (!ops) return m;

  ops.forEach(op => {
    const name = op.match(/^(\w+)/)[1].toLowerCase();
    const args = op.match(/\(([^)]*)\)/)[1].split(/[\s,]+/).map(Number);
    let t;
    switch (name) {
      case 'matrix':
        t = args;
        break;
      case 'translate':
        t = [1, 0, 0, 1, args[0] || 0, args[1] || 0];
        break;
      case 'scale':
        const sx = args[0] || 1;
        const sy = args.length > 1 ? args[1] : sx;
        t = [sx, 0, 0, sy, 0, 0];
        break;
      case 'rotate': {
        const angle = (args[0] || 0) * Math.PI / 180;
        const cos = Math.cos(angle), sin = Math.sin(angle);
        if (args.length === 3) {
          const cx = args[1], cy = args[2];
          // translate(cx,cy) rotate translate(-cx,-cy)
          t = [cos, sin, -sin, cos, cx - cos * cx + sin * cy, cy - sin * cx - cos * cy];
        } else {
          t = [cos, sin, -sin, cos, 0, 0];
        }
        break;
      }
      case 'skewx': {
        const a = Math.tan((args[0] || 0) * Math.PI / 180);
        t = [1, 0, a, 1, 0, 0];
        break;
      }
      case 'skewy': {
        const a = Math.tan((args[0] || 0) * Math.PI / 180);
        t = [1, a, 0, 1, 0, 0];
        break;
      }
      default: return;
    }
    // Multiply m * t
    m = multiplyMatrix(m, t);
  });

  return m;
}

function multiplyMatrix(a, b) {
  return [
    a[0] * b[0] + a[2] * b[1],
    a[1] * b[0] + a[3] * b[1],
    a[0] * b[2] + a[2] * b[3],
    a[1] * b[2] + a[3] * b[3],
    a[0] * b[4] + a[2] * b[5] + a[4],
    a[1] * b[4] + a[3] * b[5] + a[5],
  ];
}

function transformPoint(x, y, m) {
  return {
    x: m[0] * x + m[2] * y + m[4],
    y: m[1] * x + m[3] * y + m[5],
  };
}

function parsePathData(d, transformStr) {
  const shapePath = new THREE.ShapePath();
  const mat = transformStr ? parseTransformToMatrix(transformStr) : null;

  function tx(x, y) {
    if (!mat) return { x, y };
    return transformPoint(x, y, mat);
  }

  // Tokenize the path
  const tokens = [];
  const re = /([MmZzLlHhVvCcSsQqTtAa])|([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)/g;
  let match;
  while ((match = re.exec(d)) !== null) {
    if (match[1]) tokens.push({ type: 'cmd', value: match[1] });
    else tokens.push({ type: 'num', value: parseFloat(match[2]) });
  }

  let idx = 0;
  function nextNum() {
    while (idx < tokens.length && tokens[idx].type !== 'num') idx++;
    if (idx < tokens.length) return tokens[idx++].value;
    return 0;
  }

  let cx = 0, cy = 0; // current point
  let sx = 0, sy = 0; // start of subpath
  let prevCmd = '';
  let prevCpx = 0, prevCpy = 0; // previous control point for S/T

  idx = 0;
  while (idx < tokens.length) {
    if (tokens[idx].type === 'cmd') {
      const cmd = tokens[idx].value;
      idx++;

      // Count how many numbers follow until the next command
      let numCount = 0;
      let peekIdx = idx;
      while (peekIdx < tokens.length && tokens[peekIdx].type === 'num') { numCount++; peekIdx++; }

      const argsPerCmd = {
        M: 2, m: 2, L: 2, l: 2, H: 1, h: 1, V: 1, v: 1,
        C: 6, c: 6, S: 4, s: 4, Q: 4, q: 4, T: 2, t: 2, A: 7, a: 7, Z: 0, z: 0
      };
      const needed = argsPerCmd[cmd] || 0;

      if (cmd === 'Z' || cmd === 'z') {
        shapePath.currentPath && shapePath.currentPath.closePath && (() => {
          // Close by adding autoClose to the current subpath
          if (shapePath.currentPath) {
            const pts = shapePath.currentPath.getPoints();
            // Manually lineTo start then we'll let shapes figure it out
          }
        })();
        cx = sx;
        cy = sy;
        // We need to close the current path - add a lineTo start point
        if (shapePath.currentPath) {
          const p = tx(sx, sy);
          shapePath.currentPath.autoClose = true;
        }
        prevCmd = cmd;
        continue;
      }

      if (needed === 0) { prevCmd = cmd; continue; }

      // Process all repeated coordinate sets
      let first = true;
      while (numCount >= needed) {
        if (cmd === 'M' || cmd === 'm') {
          let x = nextNum(), y = nextNum();
          if (cmd === 'm') { x += cx; y += cy; }
          if (first) {
            const p = tx(x, y);
            shapePath.moveTo(p.x, p.y);
            sx = x; sy = y;
            first = false;
          } else {
            // Subsequent pairs after M are treated as L
            const p = tx(x, y);
            shapePath.currentPath.lineTo(p.x, p.y);
          }
          cx = x; cy = y;
          numCount -= 2;
        } else if (cmd === 'L' || cmd === 'l') {
          let x = nextNum(), y = nextNum();
          if (cmd === 'l') { x += cx; y += cy; }
          const p = tx(x, y);
          if (shapePath.currentPath) shapePath.currentPath.lineTo(p.x, p.y);
          cx = x; cy = y;
          numCount -= 2;
        } else if (cmd === 'H' || cmd === 'h') {
          let x = nextNum();
          if (cmd === 'h') x += cx;
          const p = tx(x, cy);
          if (shapePath.currentPath) shapePath.currentPath.lineTo(p.x, p.y);
          cx = x;
          numCount -= 1;
        } else if (cmd === 'V' || cmd === 'v') {
          let y = nextNum();
          if (cmd === 'v') y += cy;
          const p = tx(cx, y);
          if (shapePath.currentPath) shapePath.currentPath.lineTo(p.x, p.y);
          cy = y;
          numCount -= 1;
        } else if (cmd === 'C' || cmd === 'c') {
          let x1 = nextNum(), y1 = nextNum();
          let x2 = nextNum(), y2 = nextNum();
          let x = nextNum(), y = nextNum();
          if (cmd === 'c') { x1 += cx; y1 += cy; x2 += cx; y2 += cy; x += cx; y += cy; }
          const p1 = tx(x1, y1), p2 = tx(x2, y2), p = tx(x, y);
          if (shapePath.currentPath) shapePath.currentPath.bezierCurveTo(p1.x, p1.y, p2.x, p2.y, p.x, p.y);
          prevCpx = x2; prevCpy = y2;
          cx = x; cy = y;
          numCount -= 6;
        } else if (cmd === 'S' || cmd === 's') {
          let x2 = nextNum(), y2 = nextNum();
          let x = nextNum(), y = nextNum();
          if (cmd === 's') { x2 += cx; y2 += cy; x += cx; y += cy; }
          // Reflect previous control point
          let x1, y1;
          if ('CcSs'.includes(prevCmd)) {
            x1 = 2 * cx - prevCpx;
            y1 = 2 * cy - prevCpy;
          } else {
            x1 = cx; y1 = cy;
          }
          const p1 = tx(x1, y1), p2 = tx(x2, y2), p = tx(x, y);
          if (shapePath.currentPath) shapePath.currentPath.bezierCurveTo(p1.x, p1.y, p2.x, p2.y, p.x, p.y);
          prevCpx = x2; prevCpy = y2;
          cx = x; cy = y;
          numCount -= 4;
        } else if (cmd === 'Q' || cmd === 'q') {
          let x1 = nextNum(), y1 = nextNum();
          let x = nextNum(), y = nextNum();
          if (cmd === 'q') { x1 += cx; y1 += cy; x += cx; y += cy; }
          const p1 = tx(x1, y1), p = tx(x, y);
          if (shapePath.currentPath) shapePath.currentPath.quadraticCurveTo(p1.x, p1.y, p.x, p.y);
          prevCpx = x1; prevCpy = y1;
          cx = x; cy = y;
          numCount -= 4;
        } else if (cmd === 'T' || cmd === 't') {
          let x = nextNum(), y = nextNum();
          if (cmd === 't') { x += cx; y += cy; }
          let x1, y1;
          if ('QqTt'.includes(prevCmd)) {
            x1 = 2 * cx - prevCpx;
            y1 = 2 * cy - prevCpy;
          } else {
            x1 = cx; y1 = cy;
          }
          const p1 = tx(x1, y1), p = tx(x, y);
          if (shapePath.currentPath) shapePath.currentPath.quadraticCurveTo(p1.x, p1.y, p.x, p.y);
          prevCpx = x1; prevCpy = y1;
          cx = x; cy = y;
          numCount -= 2;
        } else if (cmd === 'A' || cmd === 'a') {
          const rx = Math.abs(nextNum());
          const ry = Math.abs(nextNum());
          const xRot = nextNum() * Math.PI / 180;
          const largeArc = nextNum();
          const sweep = nextNum();
          let ex = nextNum(), ey = nextNum();
          if (cmd === 'a') { ex += cx; ey += cy; }

          // Arc to bezier conversion
          const arcBeziers = arcToBeziers(cx, cy, rx, ry, xRot, largeArc, sweep, ex, ey);
          arcBeziers.forEach(seg => {
            const p1 = tx(seg[0], seg[1]);
            const p2 = tx(seg[2], seg[3]);
            const p3 = tx(seg[4], seg[5]);
            if (shapePath.currentPath) shapePath.currentPath.bezierCurveTo(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y);
          });

          cx = ex; cy = ey;
          numCount -= 7;
        } else {
          break;
        }
        prevCmd = cmd;
      }
    } else {
      idx++;
    }
  }

  return shapePath;
}

// Convert SVG arc to cubic bezier curves
function arcToBeziers(x1, y1, rx, ry, phi, fA, fS, x2, y2) {
  if (rx === 0 || ry === 0) return [[x2, y2, x2, y2, x2, y2]];

  const cosPhi = Math.cos(phi);
  const sinPhi = Math.sin(phi);

  const dx = (x1 - x2) / 2;
  const dy = (y1 - y2) / 2;

  const x1p = cosPhi * dx + sinPhi * dy;
  const y1p = -sinPhi * dx + cosPhi * dy;

  let rxSq = rx * rx;
  let rySq = ry * ry;
  const x1pSq = x1p * x1p;
  const y1pSq = y1p * y1p;

  // Correct radii
  const lambda = x1pSq / rxSq + y1pSq / rySq;
  if (lambda > 1) {
    const lambdaSqrt = Math.sqrt(lambda);
    rx *= lambdaSqrt;
    ry *= lambdaSqrt;
    rxSq = rx * rx;
    rySq = ry * ry;
  }

  let num = Math.max(0, rxSq * rySq - rxSq * y1pSq - rySq * x1pSq);
  let den = rxSq * y1pSq + rySq * x1pSq;
  let sq = den === 0 ? 0 : Math.sqrt(num / den);

  if (fA === fS) sq = -sq;

  const cxp = sq * rx * y1p / ry;
  const cyp = -sq * ry * x1p / rx;

  const cxr = cosPhi * cxp - sinPhi * cyp + (x1 + x2) / 2;
  const cyr = sinPhi * cxp + cosPhi * cyp + (y1 + y2) / 2;

  function angle(ux, uy, vx, vy) {
    const dot = ux * vx + uy * vy;
    const len = Math.sqrt((ux * ux + uy * uy) * (vx * vx + vy * vy));
    let ang = Math.acos(Math.max(-1, Math.min(1, dot / len)));
    if (ux * vy - uy * vx < 0) ang = -ang;
    return ang;
  }

  let theta1 = angle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry);
  let dtheta = angle((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry);

  if (fS === 0 && dtheta > 0) dtheta -= 2 * Math.PI;
  if (fS === 1 && dtheta < 0) dtheta += 2 * Math.PI;

  // Split into segments of max PI/2
  const segments = Math.ceil(Math.abs(dtheta) / (Math.PI / 2));
  const delta = dtheta / segments;
  const alpha = 4 / 3 * Math.tan(delta / 4);

  const result = [];
  let prevCos = Math.cos(theta1);
  let prevSin = Math.sin(theta1);

  for (let i = 0; i < segments; i++) {
    const theta2 = theta1 + (i + 1) * delta;
    const cos2 = Math.cos(theta2);
    const sin2 = Math.sin(theta2);

    const ep1x = prevCos - alpha * prevSin;
    const ep1y = prevSin + alpha * prevCos;
    const ep2x = cos2 + alpha * sin2;
    const ep2y = sin2 - alpha * cos2;

    const cp1x = cosPhi * rx * ep1x - sinPhi * ry * ep1y + cxr;
    const cp1y = sinPhi * rx * ep1x + cosPhi * ry * ep1y + cyr;
    const cp2x = cosPhi * rx * ep2x - sinPhi * ry * ep2y + cxr;
    const cp2y = sinPhi * rx * ep2x + cosPhi * ry * ep2y + cyr;
    const epx = cosPhi * rx * cos2 - sinPhi * ry * sin2 + cxr;
    const epy = sinPhi * rx * cos2 + cosPhi * ry * sin2 + cyr;

    result.push([cp1x, cp1y, cp2x, cp2y, epx, epy]);

    prevCos = cos2;
    prevSin = sin2;
  }

  return result;
}

function loadSVGFromText(svgText) {
  try {
    const data = parseSVGText(svgText);
    currentSVGData = data;
    buildSVG3D(data, extrusionDepth, meshMaterialType);
    dropZone.classList.add('hidden');
  } catch (err) {
    updateStatus('Error parsing SVG: ' + err.message);
    console.error(err);
  }
}

function handleFile(file) {
  if (!file) {
    updateStatus('No file provided');
    return;
  }
  // Accept SVG by name or MIME type
  const isSVG = file.name.toLowerCase().endsWith('.svg') || 
                file.type === 'image/svg+xml' ||
                file.type === 'text/xml' ||
                file.type === '';
  if (!isSVG) {
    updateStatus('Please upload a valid .svg file');
    return;
  }
  updateStatus('Loading file...');
  const reader = new FileReader();
  reader.onload = (e) => {
    const text = e.target.result;
    if (text.includes('<svg') || text.includes('<SVG')) {
      loadSVGFromText(text);
    } else {
      updateStatus('File does not contain valid SVG content');
    }
  };
  reader.onerror = () => {
    updateStatus('Error reading file');
  };
  reader.readAsText(file);
}

// --- UI Creation ---
const uiContainer = document.createElement('div');
uiContainer.id = 'ui';
uiContainer.innerHTML = `
  <div class="panel">
    <div class="panel-header">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5z"/>
        <path d="M2 17l10 5 10-5"/>
        <path d="M2 12l10 5 10-5"/>
      </svg>
      <span>SVG → 3D</span>
    </div>
    
    <div class="control-group">
      <label>Extrusion Depth</label>
      <div class="slider-row">
        <input type="range" id="depthSlider" min="0.1" max="100" step="0.5" value="20">
        <span id="depthValue">20.0</span>
      </div>
    </div>
    
    <div class="control-group">
      <label>Bevel Size</label>
      <div class="slider-row">
        <input type="range" id="bevelSlider" min="0" max="100" step="1" value="50">
        <span id="bevelValue">50%</span>
      </div>
    </div>
    
    <div class="control-group">
      <label>Material</label>
      <div class="btn-group">
        <button class="mat-btn active" data-mat="standard">Standard</button>
        <button class="mat-btn" data-mat="metallic">Metallic</button>
        <button class="mat-btn" data-mat="glass">Glass</button>
        <button class="mat-btn" data-mat="emissive">Glow</button>
      </div>
    </div>
    
    <div class="control-group">
      <label>Auto Rotate</label>
      <div class="toggle-row">
        <label class="toggle">
          <input type="checkbox" id="autoRotate" checked>
          <span class="toggle-slider"></span>
        </label>
        <span class="toggle-label">Enabled</span>
      </div>
    </div>

    <div class="control-group">
      <label>Rotate Speed</label>
      <div class="slider-row">
        <input type="range" id="rotateSpeed" min="0.1" max="5" step="0.1" value="0.8">
        <span id="rotateSpeedVal">0.8</span>
      </div>
    </div>
    
    <button id="uploadBtn" class="upload-btn">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
      Upload SVG
    </button>
    
    <input type="file" id="fileInput" accept=".svg" style="display:none">
    
    <div id="status" class="status">Drop any SVG file to extrude it in 3D</div>
  </div>
`;
document.body.appendChild(uiContainer);

// --- Drop Zone ---
const dropZone = document.createElement('div');
dropZone.id = 'dropZone';
dropZone.innerHTML = `
  <div class="drop-content">
    <div class="drop-icon">
      <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
        <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
    </div>
    <h2>Drop your SVG here</h2>
    <p>or click to browse files</p>
    <div class="supported">Supports .svg files</div>
  </div>
`;
document.body.appendChild(dropZone);

// --- Drag Active Overlay ---
const dragOverlay = document.createElement('div');
dragOverlay.id = 'dragOverlay';
dragOverlay.innerHTML = `
  <div class="drag-content">
    <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
      <polyline points="17 8 12 3 7 8"/>
      <line x1="12" y1="3" x2="12" y2="15"/>
    </svg>
    <span>Release to load</span>
  </div>
`;
document.body.appendChild(dragOverlay);

const bottomHint = document.createElement('div');
bottomHint.id = 'bottomHint';
bottomHint.textContent = 'Drop any SVG file to convert to 3D';
document.body.appendChild(bottomHint);

// --- Style ---
const style = document.createElement('style');
style.textContent = `
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    overflow: hidden;
    background: #1a1a1a;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  }
  canvas { display: block; }
  
  #ui {
    position: fixed;
    top: 14px;
    right: 14px;
    z-index: 100;
    user-select: none;
  }
  
  .panel {
    background: rgba(0, 0, 0, 0.75);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 10px;
    padding: 14px;
    width: 200px;
    color: #d0d0d0;
  }
  
  .panel-header {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    font-weight: 500;
    letter-spacing: 0.5px;
    margin-bottom: 12px;
    color: #fff;
    text-transform: uppercase;
  }
  
  .control-group {
    margin-bottom: 10px;
  }
  
  .control-group label {
    display: block;
    font-size: 10px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: rgba(255,255,255,0.45);
    margin-bottom: 5px;
  }
  
  .slider-row {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .slider-row input[type="range"] {
    flex: 1;
    -webkit-appearance: none;
    height: 3px;
    background: rgba(255,255,255,0.1);
    border-radius: 2px;
    outline: none;
  }
  
  .slider-row input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #ffffff;
    cursor: pointer;
    border: none;
    transition: transform 0.15s;
  }
  
  .slider-row input[type="range"]::-webkit-slider-thumb:hover {
    transform: scale(1.2);
  }
  
  .slider-row span {
    font-size: 10px;
    font-weight: 500;
    color: rgba(255,255,255,0.6);
    min-width: 26px;
    text-align: right;
    font-variant-numeric: tabular-nums;
  }
  
  .btn-group {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4px;
  }
  
  .mat-btn {
    background: transparent;
    border: 1px solid rgba(255,255,255,0.12);
    color: rgba(255,255,255,0.4);
    padding: 4px 0;
    border-radius: 5px;
    font-size: 10px;
    font-weight: 400;
    cursor: pointer;
    transition: all 0.2s;
    font-family: inherit;
  }
  
  .mat-btn:hover {
    border-color: rgba(255,255,255,0.3);
    color: rgba(255,255,255,0.7);
  }
  
  .mat-btn.active {
    background: rgba(255,255,255,0.1);
    border-color: rgba(255,255,255,0.4);
    color: #ffffff;
  }
  
  .toggle-row {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .toggle {
    position: relative;
    width: 34px;
    height: 18px;
    cursor: pointer;
  }
  
  .toggle input { opacity: 0; width: 0; height: 0; }
  
  .toggle-slider {
    position: absolute;
    inset: 0;
    background: rgba(255,255,255,0.1);
    border-radius: 9px;
    transition: 0.3s;
  }
  
  .toggle-slider:before {
    content: '';
    position: absolute;
    width: 12px;
    height: 12px;
    left: 3px;
    top: 3px;
    background: rgba(255,255,255,0.4);
    border-radius: 50%;
    transition: 0.3s;
  }
  
  .toggle input:checked + .toggle-slider {
    background: rgba(255, 255, 255, 0.2);
  }
  
  .toggle input:checked + .toggle-slider:before {
    transform: translateX(16px);
    background: #ffffff;
  }
  
  .toggle-label {
    font-size: 11px;
    color: rgba(255,255,255,0.5);
  }
  
  .upload-btn {
    width: 100%;
    padding: 7px;
    background: transparent;
    border: 1px solid rgba(255,255,255,0.2);
    color: rgba(255,255,255,0.7);
    border-radius: 6px;
    font-size: 11px;
    font-weight: 400;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    font-family: inherit;
    margin-bottom: 8px;
  }
  
  .upload-btn:hover {
    background: rgba(255,255,255,0.06);
    border-color: rgba(255,255,255,0.4);
    color: #fff;
  }
  
  .status {
    font-size: 10px;
    color: rgba(255,255,255,0.5);
    text-align: center;
    line-height: 1.3;
    padding-top: 4px;
    border-top: 1px solid rgba(255,255,255,0.06);
  }
  
  /* Drop Zone */
  #dropZone {
    position: fixed;
    inset: 0;
    z-index: 50;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: opacity 0.4s;
  }
  
  #dropZone.hidden {
    opacity: 0;
    pointer-events: none;
  }
  
  .drop-content {
    text-align: center;
    color: rgba(255,255,255,0.6);
  }
  
  .drop-icon {
    margin-bottom: 20px;
    opacity: 0.3;
    animation: float 3s ease-in-out infinite;
  }
  
  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
  }
  
  .drop-content h2 {
    font-size: 22px;
    font-weight: 500;
    margin-bottom: 6px;
    color: rgba(255,255,255,0.7);
  }
  
  .drop-content p {
    font-size: 14px;
    color: rgba(255,255,255,0.3);
    margin-bottom: 16px;
  }
  
  .supported {
    font-size: 11px;
    color: rgba(255,255,255,0.15);
    text-transform: uppercase;
    letter-spacing: 1px;
  }
  
  #bottomHint {
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 100;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 13px;
    font-weight: 400;
    color: rgba(255,255,255,0.35);
    letter-spacing: 0.3px;
    pointer-events: none;
    user-select: none;
    white-space: nowrap;
  }
  
  /* Drag Overlay */
  #dragOverlay {
    position: fixed;
    inset: 0;
    z-index: 200;
    background: rgba(255, 255, 255, 0.03);
    backdrop-filter: blur(8px);
    display: none;
    align-items: center;
    justify-content: center;
    border: 2px dashed rgba(255, 255, 255, 0.3);
    margin: 16px;
    border-radius: 20px;
  }
  
  #dragOverlay.active {
    display: flex;
  }
  
  .drag-content {
    text-align: center;
    color: rgba(255,255,255,0.7);
  }
  
  .drag-content svg {
    margin-bottom: 16px;
    animation: pulse 1.5s ease-in-out infinite;
  }
  
  @keyframes pulse {
    0%, 100% { opacity: 0.6; transform: scale(1); }
    50% { opacity: 1; transform: scale(1.05); }
  }
  
  .drag-content span {
    display: block;
    font-size: 18px;
    font-weight: 500;
    letter-spacing: 0.5px;
  }
`;
document.head.appendChild(style);

// --- UI Logic ---
const depthSlider = document.getElementById('depthSlider');
const depthValue = document.getElementById('depthValue');
const bevelSlider = document.getElementById('bevelSlider');
const bevelValue = document.getElementById('bevelValue');
const autoRotateToggle = document.getElementById('autoRotate');
const rotateSpeedSlider = document.getElementById('rotateSpeed');
const rotateSpeedVal = document.getElementById('rotateSpeedVal');
const uploadBtn = document.getElementById('uploadBtn');
const fileInput = document.getElementById('fileInput');
const statusEl = document.getElementById('status');

function updateStatus(msg) {
  statusEl.textContent = msg;
}

depthSlider.addEventListener('input', (e) => {
  extrusionDepth = parseFloat(e.target.value);
  depthValue.textContent = extrusionDepth.toFixed(1);
  if (currentSVGData) buildSVG3D(currentSVGData, extrusionDepth, meshMaterialType);
});

bevelSlider.addEventListener('input', (e) => {
  bevelScale = parseFloat(e.target.value) / 100;
  bevelValue.textContent = Math.round(bevelScale * 100) + '%';
  if (currentSVGData) buildSVG3D(currentSVGData, extrusionDepth, meshMaterialType);
});

autoRotateToggle.addEventListener('change', (e) => {
  controls.autoRotate = e.target.checked;
  document.querySelector('.toggle-label').textContent = e.target.checked ? 'Enabled' : 'Disabled';
});

rotateSpeedSlider.addEventListener('input', (e) => {
  controls.autoRotateSpeed = parseFloat(e.target.value);
  rotateSpeedVal.textContent = parseFloat(e.target.value).toFixed(1);
});

document.querySelectorAll('.mat-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.mat-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    meshMaterialType = btn.dataset.mat;
    if (currentSVGData) buildSVG3D(currentSVGData, extrusionDepth, meshMaterialType);
  });
});

uploadBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', (e) => {
  if (e.target.files[0]) handleFile(e.target.files[0]);
});

dropZone.addEventListener('click', () => fileInput.click());

// --- Drag & Drop ---
let dragCounter = 0;

document.addEventListener('dragenter', (e) => {
  e.preventDefault();
  e.stopPropagation();
  dragCounter++;
  dragOverlay.classList.add('active');
});

document.addEventListener('dragleave', (e) => {
  e.preventDefault();
  e.stopPropagation();
  dragCounter--;
  if (dragCounter <= 0) {
    dragCounter = 0;
    dragOverlay.classList.remove('active');
  }
});

document.addEventListener('dragover', (e) => {
  e.preventDefault();
  e.stopPropagation();
});

document.addEventListener('drop', (e) => {
  e.preventDefault();
  e.stopPropagation();
  dragCounter = 0;
  dragOverlay.classList.remove('active');
  
  const files = e.dataTransfer.files;
  if (files && files.length > 0) {
    handleFile(files[0]);
  } else {
    // Try getting data as text (some browsers)
    const text = e.dataTransfer.getData('text');
    if (text && (text.includes('<svg') || text.includes('<SVG'))) {
      loadSVGFromText(text);
    }
  }
});

// --- Animation ---
const clock = new THREE.Clock();

function animate() {
  requestAnimationFrame(animate);
  
  const elapsed = clock.getElapsedTime();
  
  // Animate lights
  pointLight1.position.x = Math.sin(elapsed * 0.5) * 6;
  pointLight1.position.z = Math.cos(elapsed * 0.5) * 6;
  pointLight2.position.x = Math.cos(elapsed * 0.3) * 5;
  pointLight2.position.z = Math.sin(elapsed * 0.3) * 5;
  

  
  controls.update();
  renderer.render(scene, camera);
}

animate();

// --- Resize ---
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// --- Load default SVG on startup ---
const defaultSVG = `<svg width="212" height="212" viewBox="0 0 212 212" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M172.124 0C172.207 1.36402 172.251 2.73903 172.251 4.12402C172.251 40.1595 143.769 69.5072 108.197 70.6699C108.114 69.3059 108.071 67.9309 108.071 66.5459C108.071 30.5108 136.553 1.16301 172.124 0Z" fill="white"/>
<path d="M39.8848 0C75.4526 1.1668 103.931 30.5133 103.931 66.5459C103.931 67.9306 103.887 69.3052 103.804 70.6689C68.236 69.5019 39.7588 40.1566 39.7588 4.12402C39.7588 2.73904 39.8018 1.36401 39.8848 0Z" fill="white"/>
<path d="M212.01 172.124C210.646 172.207 209.271 172.251 207.886 172.251C171.85 172.251 142.503 143.769 141.34 108.197C142.704 108.114 144.079 108.071 145.464 108.071C181.499 108.071 210.847 136.553 212.01 172.124Z" fill="white"/>
<path d="M212.01 39.8848C210.843 75.4526 181.497 103.931 145.464 103.931C144.079 103.931 142.705 103.887 141.341 103.804C142.508 68.236 171.853 39.7588 207.886 39.7588C209.271 39.7588 210.646 39.8018 212.01 39.8848Z" fill="white"/>
<path d="M39.8857 212.01C39.8028 210.646 39.7588 209.271 39.7588 207.886C39.7588 171.85 68.2408 142.503 103.812 141.34C103.895 142.704 103.938 144.079 103.938 145.464C103.938 181.499 75.457 210.847 39.8857 212.01Z" fill="white"/>
<path d="M172.125 212.01C136.557 210.843 108.079 181.497 108.079 145.464C108.079 144.079 108.123 142.705 108.206 141.341C143.774 142.508 172.251 171.853 172.251 207.886C172.251 209.271 172.208 210.646 172.125 212.01Z" fill="white"/>
<path d="M1.57693e-06 39.8857C1.36402 39.8028 2.73903 39.7588 4.12402 39.7588C40.1595 39.7588 69.5072 68.2408 70.6699 103.812C69.3059 103.895 67.9309 103.938 66.5459 103.938C30.5108 103.938 1.16301 75.457 1.57693e-06 39.8857Z" fill="white"/>
<path d="M0 172.125C1.1668 136.557 30.5133 108.079 66.5459 108.079C67.9306 108.079 69.3052 108.123 70.6689 108.206C69.5019 143.774 40.1566 172.251 4.12402 172.251C2.73904 172.251 1.36401 172.208 0 172.125Z" fill="white"/>
</svg>`;

loadSVGFromText(defaultSVG);

