// WebGPU 20x20x20 Cube of Cubes with Three.js
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x808080);

const aspect = window.innerWidth / window.innerHeight;
const perspCamera = new THREE.PerspectiveCamera(60, aspect, 0.1, 500);
perspCamera.position.set(30, 25, 30);
perspCamera.lookAt(0, 0, 0);
perspCamera.name = 'perspCamera';

const frustumSize = 30;
const orthoCamera = new THREE.OrthographicCamera(
  -frustumSize * aspect, frustumSize * aspect,
  frustumSize, -frustumSize, 0.1, 500
);
orthoCamera.position.set(30, 25, 30);
orthoCamera.lookAt(0, 0, 0);
orthoCamera.name = 'orthoCamera';

let camera = perspCamera;
let isOrtho = false;

// Use standard WebGL renderer (WebGPURenderer not available in this environment)
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);

// UI Panel
const panel = document.createElement('div');
panel.style.cssText = `
  position: fixed; top: 10px; right: 10px; background: rgba(255,255,255,0.95); border: 1px solid #ddd;
  border-radius: 8px; padding: 10px 12px; font-family: 'Inter', sans-serif; font-size: 11px;
  color: #333; width: 200px; z-index: 1000; user-select: none; max-height: calc(100vh - 20px);
  overflow-y: auto; line-height: 1.3;
`;
const sectionStyle = `cursor:pointer; font-weight:600; font-size:11px; margin:0; padding:4px 0; display:flex; justify-content:space-between; align-items:center; border-top:1px solid #eee;`;
const rowStyle = `display:flex; align-items:center; margin-bottom:3px; gap:4px;`;
const labelStyle = `flex-shrink:0; width:52px; font-size:10px; color:#555;`;
const valStyle = `flex-shrink:0; width:28px; text-align:right; font-size:10px; color:#888; font-variant-numeric:tabular-nums;`;
const sliderStyle = `flex:1; accent-color:#333; height:14px; min-width:0;`;
const colorStyle = `width:28px; height:18px; border:1px solid #ccc; border-radius:3px; cursor:pointer; padding:0;`;
const selectStyle = `width:100%; padding:2px 4px; border:1px solid #ccc; border-radius:3px; font-family:'Inter',sans-serif; font-size:10px; margin-top:2px;`;

function makeSection(title, id, contentHTML, open) {
  return `<div>
    <div style="${sectionStyle}" onclick="document.getElementById('${id}').style.display=document.getElementById('${id}').style.display==='none'?'block':'none'; this.querySelector('span').textContent=document.getElementById('${id}').style.display==='none'?'+':'−'">
      ${title}<span style="font-size:12px; color:#aaa;">${open ? '−' : '+'}</span>
    </div>
    <div id="${id}" style="display:${open ? 'block' : 'none'}; padding:4px 0 2px;">
      ${contentHTML}
    </div>
  </div>`;
}

function row(label, id, valId) {
  return `<div style="${rowStyle}"><span style="${labelStyle}">${label}</span><input type="range" id="${id}" style="${sliderStyle}"><span id="${valId}" style="${valStyle}"></span></div>`;
}

panel.innerHTML = `
  <div style="font-weight:600; margin-bottom:6px; font-size:12px;">Parameters</div>
  ${makeSection('Noise', 'sec-noise', `
    <div style="${rowStyle}"><span style="${labelStyle}">Type</span>
      <select id="noiseType" style="${selectStyle}">
        <option value="perlin" selected>Perlin</option><option value="ridged">Ridged</option>
        <option value="billow">Billow</option><option value="fbm">FBM</option>
        <option value="waveRadial">Radial</option><option value="wavePlanar">Planar</option>
        <option value="waveCross">Cross</option><option value="waveSpiral">Spiral</option>
        <option value="waveDiamond">Diamond</option>
      </select>
    </div>
    ${row('Speed', 'speed', 'speedVal')}
    ${row('Freq', 'freq', 'freqVal')}
    ${row('Exag', 'exag', 'exagVal')}
    ${row('Scale', 'scaleMax', 'scaleVal')}
  `, true)}
  ${makeSection('Color', 'sec-color', `
    <div style="${rowStyle}">
      <span style="${labelStyle}">Bright</span><input type="color" id="colorBright" value="#ffffff" style="${colorStyle}">
      <span style="${labelStyle}; margin-left:4px;">Dark</span><input type="color" id="colorDark" value="#000000" style="${colorStyle}">
    </div>
    ${row('Mix', 'colorMix', 'mixVal')}
    ${row('Contrast', 'contrast', 'contrastVal')}
    <div style="${rowStyle}">
      <span style="${labelStyle}">BG</span><input type="color" id="colorBg" value="#808080" style="${colorStyle}">
    </div>
  `, false)}
  ${makeSection('Scale Axis', 'sec-scale', `
    ${row('X', 'scaleX', 'scaleXVal')}
    ${row('Y', 'scaleY', 'scaleYVal')}
    ${row('Z', 'scaleZ', 'scaleZVal')}
  `, false)}
  ${makeSection('Grid Size', 'sec-grid', `
    ${row('X', 'gridX', 'gridXVal')}
    ${row('Y', 'gridY', 'gridYVal')}
    ${row('Z', 'gridZ', 'gridZVal')}
  `, false)}
  <div style="margin-top:6px; border-top:1px solid #eee; padding-top:6px;">
    <button id="camToggle" style="width:100%; padding:4px 0; border:1px solid #ccc; border-radius:4px; background:#f5f5f5; font-family:'Inter',sans-serif; font-size:10px; font-weight:600; color:#333; cursor:pointer;">Camera: Perspective</button>
  </div>
`;

// Set initial slider values after innerHTML is set
function initSlider(id, min, max, step, value) {
  const el = document.getElementById(id);
  el.min = min; el.max = max; el.step = step; el.value = value;
}
document.body.appendChild(panel);
initSlider('speed', 0, 2, 0.01, 1.01);
initSlider('freq', 0.05, 0.8, 0.01, 0.25);
initSlider('exag', 0.1, 2.0, 0.01, 1.30);
initSlider('scaleMax', 0.5, 3.0, 0.01, 3.00);
initSlider('colorMix', 0, 3, 0.01, 3.00);
initSlider('contrast', 0.1, 5.0, 0.01, 2.78);
initSlider('scaleX', 0, 3, 0.01, 1.00);
initSlider('scaleY', 0, 3, 0.01, 1.00);
initSlider('scaleZ', 0, 3, 0.01, 1.00);
initSlider('gridX', 1, 20, 1, 20);
initSlider('gridY', 1, 20, 1, 20);
initSlider('gridZ', 1, 20, 1, 20);

// Link to Inter font
const fontLink = document.createElement('link');
fontLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap';
fontLink.rel = 'stylesheet';
document.head.appendChild(fontLink);

// UI state
const params = {
  speed: 1.01, freq: 0.25, exag: 1.3, scaleMax: 3.0,
  brightColor: new THREE.Color(1, 1, 1),
  darkColor: new THREE.Color(0, 0, 0),
  colorMix: 3.0,
  contrast: 2.78,
  noiseType: 'perlin',
  scaleX: 1.0,
  scaleY: 1.0,
  scaleZ: 1.0,
  gridX: 20,
  gridY: 20,
  gridZ: 20
};

function bindSlider(id, key, valId) {
  const el = document.getElementById(id);
  const val = document.getElementById(valId);
  el.addEventListener('input', () => { params[key] = parseFloat(el.value); if (val) val.textContent = el.value; });
}
bindSlider('speed', 'speed', 'speedVal');
bindSlider('freq', 'freq', 'freqVal');
bindSlider('exag', 'exag', 'exagVal');
bindSlider('scaleMax', 'scaleMax', 'scaleVal');
bindSlider('colorMix', 'colorMix', 'mixVal');
bindSlider('contrast', 'contrast', 'contrastVal');
bindSlider('scaleX', 'scaleX', 'scaleXVal');
bindSlider('scaleY', 'scaleY', 'scaleYVal');
bindSlider('scaleZ', 'scaleZ', 'scaleZVal');
bindSlider('gridX', 'gridX', 'gridXVal');
bindSlider('gridY', 'gridY', 'gridYVal');
bindSlider('gridZ', 'gridZ', 'gridZVal');

document.getElementById('noiseType').addEventListener('change', (e) => { params.noiseType = e.target.value; });

document.getElementById('colorBright').addEventListener('input', (e) => { params.brightColor.set(e.target.value); });
document.getElementById('colorDark').addEventListener('input', (e) => { params.darkColor.set(e.target.value); });
document.getElementById('colorBg').addEventListener('input', (e) => { scene.background.set(e.target.value); });

// Lights
const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
ambientLight.name = 'ambientLight';
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
dirLight.name = 'directionalLight';
dirLight.position.set(40, 60, 30);
dirLight.castShadow = true;
dirLight.shadow.mapSize.width = 2048;
dirLight.shadow.mapSize.height = 2048;
dirLight.shadow.camera.near = 0.5;
dirLight.shadow.camera.far = 200;
dirLight.shadow.camera.left = -40;
dirLight.shadow.camera.right = 40;
dirLight.shadow.camera.top = 40;
dirLight.shadow.camera.bottom = -40;
dirLight.shadow.bias = -0.001;
dirLight.shadow.normalBias = 0.02;
scene.add(dirLight);

const hemLight = new THREE.HemisphereLight(0xaaccff, 0x446644, 0.4);
hemLight.name = 'hemisphereLight';
scene.add(hemLight);

// Cube of Cubes using InstancedMesh — dynamic grid size
const maxGrid = 20;
const cubeSize = 0.85;
const gap = 1.0;
const maxCubes = maxGrid * maxGrid * maxGrid;

const geometry = new THREE.BoxGeometry(cubeSize, cubeSize, cubeSize);
const material = new THREE.MeshStandardMaterial({
  metalness: 0.15,
  roughness: 0.6
});

let instancedMesh = new THREE.InstancedMesh(geometry, material, maxCubes);
instancedMesh.name = 'cubeGrid';
instancedMesh.castShadow = true;
instancedMesh.receiveShadow = true;

const dummy = new THREE.Object3D();
const color = new THREE.Color();

// Hide all instances initially
const zeroMatrix = new THREE.Matrix4().makeScale(0, 0, 0);
for (let i = 0; i < maxCubes; i++) {
  instancedMesh.setMatrixAt(i, zeroMatrix);
  instancedMesh.setColorAt(i, color.setRGB(0, 0, 0));
}
instancedMesh.instanceMatrix.needsUpdate = true;
instancedMesh.instanceColor.needsUpdate = true;
scene.add(instancedMesh);



// Controls
let controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.minDistance = 10;
controls.maxDistance = 100;
controls.target.set(0, 0, 0);

// Camera toggle button
document.getElementById('camToggle').addEventListener('click', () => {
  isOrtho = !isOrtho;
  const oldTarget = controls.target.clone();
  const oldPos = camera.position.clone();
  controls.dispose();

  if (isOrtho) {
    const a = window.innerWidth / window.innerHeight;
    orthoCamera.left = -frustumSize * a;
    orthoCamera.right = frustumSize * a;
    orthoCamera.top = frustumSize;
    orthoCamera.bottom = -frustumSize;
    orthoCamera.position.copy(oldPos);
    orthoCamera.updateProjectionMatrix();
    camera = orthoCamera;
  } else {
    perspCamera.position.copy(oldPos);
    camera = perspCamera;
  }

  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.minDistance = 10;
  controls.maxDistance = 100;
  controls.target.copy(oldTarget);

  document.getElementById('camToggle').textContent = isOrtho ? 'Camera: Orthographic' : 'Camera: Perspective';
});

// 3D Simplex-like noise
function mod289(x) { return x - Math.floor(x / 289.0) * 289.0; }
function permute(x) { return mod289((x * 34.0 + 1.0) * x); }

function noise3D(x, y, z) {
  const X = Math.floor(x) & 255;
  const Y = Math.floor(y) & 255;
  const Z = Math.floor(z) & 255;
  const fx = x - Math.floor(x);
  const fy = y - Math.floor(y);
  const fz = z - Math.floor(z);
  const u = fx * fx * (3 - 2 * fx);
  const v = fy * fy * (3 - 2 * fy);
  const w = fz * fz * (3 - 2 * fz);

  const A  = permute(X) + Y;
  const AA = permute(A) + Z;
  const AB = permute(A + 1) + Z;
  const B  = permute(X + 1) + Y;
  const BA = permute(B) + Z;
  const BB = permute(B + 1) + Z;

  function grad(hash, gx, gy, gz) {
    const h = hash & 15;
    const gu = h < 8 ? gx : gy;
    const gv = h < 4 ? gy : (h === 12 || h === 14 ? gx : gz);
    return ((h & 1) === 0 ? gu : -gu) + ((h & 2) === 0 ? gv : -gv);
  }

  const p0 = grad(permute(AA), fx, fy, fz);
  const p1 = grad(permute(BA), fx - 1, fy, fz);
  const p2 = grad(permute(AB), fx, fy - 1, fz);
  const p3 = grad(permute(BB), fx - 1, fy - 1, fz);
  const p4 = grad(permute(AA + 1), fx, fy, fz - 1);
  const p5 = grad(permute(BA + 1), fx - 1, fy, fz - 1);
  const p6 = grad(permute(AB + 1), fx, fy - 1, fz - 1);
  const p7 = grad(permute(BB + 1), fx - 1, fy - 1, fz - 1);

  const x0 = p0 + u * (p1 - p0);
  const x1 = p2 + u * (p3 - p2);
  const x2 = p4 + u * (p5 - p4);
  const x3 = p6 + u * (p7 - p6);
  const y0 = x0 + v * (x1 - x0);
  const y1 = x2 + v * (x3 - x2);
  return y0 + w * (y1 - y0);
}

// Animation
const clock = new THREE.Clock();
const tempMatrix = new THREE.Matrix4();
const tempPos = new THREE.Vector3();
const tempQuat = new THREE.Quaternion();
const tempScale = new THREE.Vector3();
const noiseColor = new THREE.Color();

function animate() {
  requestAnimationFrame(animate);
  const t = clock.getElapsedTime();

  const noiseSpeed = params.speed;
  const noiseFreq = params.freq;

  const gx = Math.round(params.gridX);
  const gy = Math.round(params.gridY);
  const gz = Math.round(params.gridZ);
  const activeCount = gx * gy * gz;
  const offsetX = (gx - 1) * gap * 0.5;
  const offsetY = (gy - 1) * gap * 0.5;
  const offsetZ = (gz - 1) * gap * 0.5;

  let idx = 0;
  for (let x = 0; x < gx; x++) {
    for (let y = 0; y < gy; y++) {
      for (let z = 0; z < gz; z++) {
        const baseX = x * gap - offsetX;
        const baseY = y * gap - offsetY;
        const baseZ = z * gap - offsetZ;


        // Normalize grid coords so noise looks consistent at any grid size
        const normX = gx > 1 ? x / (gx - 1) * 19 : 9.5;
        const normY = gy > 1 ? y / (gy - 1) * 19 : 9.5;
        const normZ = gz > 1 ? z / (gz - 1) * 19 : 9.5;

        const nx = normX * noiseFreq + t * noiseSpeed;
        const ny = normY * noiseFreq + t * noiseSpeed * 0.7;
        const nz = normZ * noiseFreq + t * noiseSpeed * 0.5;

        let n;
        const type = params.noiseType;

        if (type === 'perlin') {
          n = noise3D(nx, ny, nz);
        } else if (type === 'ridged') {
          n = 1.0 - Math.abs(noise3D(nx, ny, nz)) * 2.0;
        } else if (type === 'billow') {
          n = Math.abs(noise3D(nx, ny, nz)) * 2.0 - 0.5;
        } else if (type === 'fbm') {
          n = noise3D(nx, ny, nz) * 0.5
            + noise3D(nx * 2, ny * 2, nz * 2) * 0.25
            + noise3D(nx * 4, ny * 4, nz * 4) * 0.125;
        } else if (type === 'waveRadial') {
          const cx = (normX - 9.5);
          const cy = (normY - 9.5);
          const cz = (normZ - 9.5);
          const dist = Math.sqrt(cx * cx + cy * cy + cz * cz);
          n = Math.sin(dist * noiseFreq * 2.0 - t * noiseSpeed * 3.0);
        } else if (type === 'wavePlanar') {
          n = Math.sin(x * noiseFreq * 1.5 + t * noiseSpeed * 2.0)
            * Math.sin(y * noiseFreq * 1.5 + t * noiseSpeed * 1.7)
            * Math.sin(z * noiseFreq * 1.5 + t * noiseSpeed * 1.3);
        } else if (type === 'waveCross') {
          n = (Math.sin(x * noiseFreq * 2.0 + t * noiseSpeed * 2.5)
            + Math.sin(y * noiseFreq * 2.0 + t * noiseSpeed * 2.0)
            + Math.sin(z * noiseFreq * 2.0 + t * noiseSpeed * 1.5)) / 3.0;
        } else if (type === 'waveSpiral') {
          const cx = (normX - 9.5);
          const cz = (normZ - 9.5);
          const angle = Math.atan2(cz, cx);
          const dist = Math.sqrt(cx * cx + cz * cz);
          n = Math.sin(dist * noiseFreq * 2.0 + angle * 3.0 - t * noiseSpeed * 3.0)
            * Math.cos(y * noiseFreq * 1.5 + t * noiseSpeed);
        } else if (type === 'waveDiamond') {
          const cx = Math.abs(normX - 9.5);
          const cy = Math.abs(normY - 9.5);
          const cz = Math.abs(normZ - 9.5);
          const manhattan = cx + cy + cz;
          n = Math.sin(manhattan * noiseFreq * 1.2 - t * noiseSpeed * 3.0);
        }

        // Normalize noise to 0-1 range — exaggerated with power curve
        const nNorm = Math.pow(Math.max(0, Math.min(1, n * 0.5 + 0.5)), params.exag);
        const s = 0.02 + nNorm * nNorm * params.scaleMax;

        tempPos.set(baseX, baseY, baseZ);
        tempScale.set(s * params.scaleX, s * params.scaleY, s * params.scaleZ);
        tempMatrix.compose(tempPos, tempQuat.identity(), tempScale);
        instancedMesh.setMatrixAt(idx, tempMatrix);

        // Apply contrast curve to sharpen or flatten color blending
        const contrasted = Math.pow(nNorm, params.contrast);

        // Interpolate between dark and bright color based on contrasted noise
        noiseColor.copy(params.darkColor).lerp(params.brightColor, contrasted);
        noiseColor.multiplyScalar(params.colorMix);
        instancedMesh.setColorAt(idx, noiseColor);

        idx++;
      }
    }
  }
  // Hide unused instances beyond active grid
  for (let i = activeCount; i < maxCubes; i++) {
    instancedMesh.setMatrixAt(i, zeroMatrix);
  }

  instancedMesh.instanceMatrix.needsUpdate = true;
  instancedMesh.instanceColor.needsUpdate = true;
  instancedMesh.count = maxCubes;

  controls.update();
  renderer.render(scene, camera);
}

// Start animation
animate();

// Handle resize
window.addEventListener('resize', () => {
  const a = window.innerWidth / window.innerHeight;
  perspCamera.aspect = a;
  perspCamera.updateProjectionMatrix();
  orthoCamera.left = -frustumSize * a;
  orthoCamera.right = frustumSize * a;
  orthoCamera.top = frustumSize;
  orthoCamera.bottom = -frustumSize;
  orthoCamera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});