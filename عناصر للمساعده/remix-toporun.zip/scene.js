import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { BokehPass } from 'three/examples/jsm/postprocessing/BokehPass.js';
import { Line2 } from 'three/examples/jsm/lines/Line2.js';
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js';
import { LineGeometry } from 'three/examples/jsm/lines/LineGeometry.js';
import { LineSegments2 } from 'three/examples/jsm/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/examples/jsm/lines/LineSegmentsGeometry.js';
import * as BufferGeometryUtils from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { GPX_DEFAULT_XML_DATA } from './gpx-data.js';

// Make the imported GPX data available globally
window.GPX_DEFAULT_XML = GPX_DEFAULT_XML_DATA;

// --- DEBUG LOGGING ---
function debugLog(msg, type = '') {
  const logEl = document.getElementById('debug-log');
  if (logEl) {
    const line = document.createElement('div');
    line.className = 'log-line' + (type ? ' ' + type : '');
    const ts = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    line.textContent = `[${ts}] ${msg}`;
    logEl.appendChild(line);
    logEl.scrollTop = logEl.scrollHeight;
  }
  console.log('[DEBUG]', msg);
}

// Wire debug console UI
(function setupDebugConsole() {
  const panel = document.getElementById('debug-console');
  const toggleBtn = document.getElementById('debug-toggle-btn');
  const closeBtn = document.getElementById('debug-close-btn');
  const copyBtn = document.getElementById('debug-copy-btn');
  if (toggleBtn && panel) {
    toggleBtn.addEventListener('click', () => {
      panel.classList.toggle('visible');
      toggleBtn.style.display = panel.classList.contains('visible') ? 'none' : 'flex';
    });
  }
  if (closeBtn && panel) {
    closeBtn.addEventListener('click', () => {
      panel.classList.remove('visible');
      if (toggleBtn) toggleBtn.style.display = 'flex';
    });
  }
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const logEl = document.getElementById('debug-log');
      if (logEl) {
        const text = logEl.innerText;
        navigator.clipboard.writeText(text).then(() => {
          copyBtn.textContent = 'COPIED!';
          setTimeout(() => copyBtn.textContent = 'COPY', 1500);
        });
      }
    });
  }
})();

debugLog('Scene module loading…');

// --- LAYER STATE ---
const layerState = {
  satellite: true,
  highways: true,
  majorRoads: true,
  minorRoads: true,
  paths: true,
  contours: true,
  gpsPath: true,
  gpxTrack: true,
};

const renderState = {
  bloom: false,
  grain: false,
  fog: false,
  wireframe: false,
  vectorMap: false,
  satelliteOverlay: false,
  satelliteOverlayOpacity: 0.55,
  bloomStrength: 0.85,
  bloomRadius: 0.35,
  grainAmount: 0.032,
  terrainExaggeration: 1.0,
  // Terrain material
  terrainRoughness: 0.85,
  terrainMetalness: 0.05,
  terrainEnvIntensity: 1.0,
  // Lighting
  ambientIntensity: 1.8,
  sunIntensity: 1.2,
  sunAzimuth: 0.55,
  sunElevation: 0.72,
  fogDensity: 0.018,
  // Contours
  contourLevels: 22,
  contourThickness: 1,
  contourMajorOpacity: 0.55,
  contourMinorOpacity: 0.22,
  contourMajorEvery: 4,
  contourMajorColor: 0xffffff,
  contourMinorColor: 0x888888,
  // Roads
  highwayWidth: 0.18,
  majorRoadWidth: 0.11,
  minorRoadWidth: 0.055,
  pathWidth: 0.04,
  roadEmissiveIntensity: 1.0,
  roadFlatStyle: false,
  roadExtrusionHeight: 0.18,
  highwayColor: 0xffe566,
  majorRoadColor: 0x6e6e6e,
  minorRoadColor: 0x8888aa,
  pathColor: 0x66ffcc,
  // HDRI
  hdriEnabled: false,
  hdriPreset: 'studio',
  hdriExposure: 1.2,
  // Sky
  skyEnabled: false,
  skyTurbidity: 8,
  skyRayleigh: 1.0,
  // Depth of Field
  dofEnabled: false,
  dofFocus: 50.0,
  dofAperture: 0.0008,
  dofMaxBlur: 0.008,
  // Diagnostics
  fpsCounter: false,
};

// --- SCENE PRESETS ---
const SCENE_PRESETS = {
  dark: {
    label: 'Dark',
    bloom: true, bloomStrength: 1.1, bloomRadius: 0.4,
    grain: true, grainAmount: 0.04,
    fog: true, fogDensity: 0.022,
    wireframe: false, vectorMap: false,
    terrainRoughness: 0.9, terrainMetalness: 0.05, terrainEnvIntensity: 0.5,
    ambientIntensity: 0.8, sunIntensity: 0.6, sunAzimuth: 0.55, sunElevation: 0.4,
    hdriEnabled: false, skyEnabled: false, hdriExposure: 0.85,
    highwayWidth: 0.18, majorRoadWidth: 0.11, minorRoadWidth: 0.055, pathWidth: 0.04,
    roadEmissiveIntensity: 2.0, roadFlatStyle: false, roadExtrusionHeight: 0.18,
    terrainExaggeration: 1.2,
  },
  topo: {
    label: 'Topo Map',
    bloom: false, bloomStrength: 0.3, bloomRadius: 0.2,
    grain: false, grainAmount: 0.01,
    fog: false, fogDensity: 0.005,
    wireframe: false, vectorMap: true,
    terrainRoughness: 0.95, terrainMetalness: 0.0, terrainEnvIntensity: 0.2,
    ambientIntensity: 3.0, sunIntensity: 0.5, sunAzimuth: 0.3, sunElevation: 0.85,
    hdriEnabled: false, skyEnabled: false, hdriExposure: 1.0,
    highwayWidth: 0.14, majorRoadWidth: 0.09, minorRoadWidth: 0.045, pathWidth: 0.03,
    roadEmissiveIntensity: 0.5, roadFlatStyle: true, roadExtrusionHeight: 0.0,
    terrainExaggeration: 0.8,
  },
  neon: {
    label: 'Neon Night',
    bloom: true, bloomStrength: 2.0, bloomRadius: 0.6,
    grain: true, grainAmount: 0.055,
    fog: true, fogDensity: 0.035,
    wireframe: false, vectorMap: false,
    terrainRoughness: 0.3, terrainMetalness: 0.4, terrainEnvIntensity: 2.5,
    ambientIntensity: 0.3, sunIntensity: 0.1, sunAzimuth: 0.7, sunElevation: 0.1,
    hdriEnabled: true, hdriPreset: 'night', skyEnabled: false, hdriExposure: 0.6,
    highwayWidth: 0.22, majorRoadWidth: 0.14, minorRoadWidth: 0.07, pathWidth: 0.05,
    roadEmissiveIntensity: 3.5, roadFlatStyle: false, roadExtrusionHeight: 0.22,
    terrainExaggeration: 1.5,
  },
  daylight: {
    label: 'Daylight',
    bloom: false, bloomStrength: 0.4, bloomRadius: 0.2,
    grain: false, grainAmount: 0.008,
    fog: true, fogDensity: 0.008,
    wireframe: false, vectorMap: false,
    terrainRoughness: 0.75, terrainMetalness: 0.0, terrainEnvIntensity: 1.5,
    ambientIntensity: 2.5, sunIntensity: 3.5, sunAzimuth: 0.28, sunElevation: 0.78,
    hdriEnabled: true, hdriPreset: 'noon', skyEnabled: true, hdriExposure: 1.4,
    highwayWidth: 0.16, majorRoadWidth: 0.10, minorRoadWidth: 0.05, pathWidth: 0.035,
    roadEmissiveIntensity: 0.4, roadFlatStyle: true, roadExtrusionHeight: 0.0,
    terrainExaggeration: 1.0,
  },
  sunset: {
    label: 'Sunset',
    bloom: true, bloomStrength: 0.9, bloomRadius: 0.5,
    grain: true, grainAmount: 0.025,
    fog: true, fogDensity: 0.014,
    wireframe: false, vectorMap: false,
    terrainRoughness: 0.65, terrainMetalness: 0.08, terrainEnvIntensity: 2.0,
    ambientIntensity: 1.2, sunIntensity: 2.8, sunAzimuth: 0.88, sunElevation: 0.18,
    hdriEnabled: true, hdriPreset: 'sunset', skyEnabled: true, hdriExposure: 1.15,
    highwayWidth: 0.18, majorRoadWidth: 0.11, minorRoadWidth: 0.055, pathWidth: 0.04,
    roadEmissiveIntensity: 1.6, roadFlatStyle: false, roadExtrusionHeight: 0.15,
    terrainExaggeration: 1.1,
  },
  wire: {
    label: 'Wireframe',
    bloom: true, bloomStrength: 0.6, bloomRadius: 0.3,
    grain: false, grainAmount: 0.01,
    fog: true, fogDensity: 0.025,
    wireframe: true, vectorMap: false,
    terrainRoughness: 0.5, terrainMetalness: 0.2, terrainEnvIntensity: 1.0,
    ambientIntensity: 1.0, sunIntensity: 0.5, sunAzimuth: 0.55, sunElevation: 0.72,
    hdriEnabled: false, skyEnabled: false, hdriExposure: 1.0,
    highwayWidth: 0.1, majorRoadWidth: 0.07, minorRoadWidth: 0.04, pathWidth: 0.025,
    roadEmissiveIntensity: 2.5, roadFlatStyle: false, roadExtrusionHeight: 0.1,
    terrainExaggeration: 1.8,
  },
};

function applyScenePreset(key) {
  const p = SCENE_PRESETS[key];
  if (!p) return;
  Object.keys(p).forEach(k => { if (k !== 'label' && renderState[k] !== undefined) renderState[k] = p[k]; });
  syncRenderUI();
  applyRenderSettings();
  if (p.vectorMap) applyVectorMapMode(true);
  else if (!p.vectorMap && renderState.vectorMap === false) applyVectorMapMode(false);
  // sync vector map toggle
  const vmT = document.querySelector('[data-render="vectorMap"]');
  if (vmT) { vmT.checked = renderState.vectorMap; vmT.dispatchEvent(new Event('change')); }
}

function randomizeScene() {
  const rand = (a, b) => a + Math.random() * (b - a);
  const bool = (p = 0.5) => Math.random() < p;
  renderState.bloom = bool(0.6);
  renderState.bloomStrength = rand(0.3, 2.2);
  renderState.bloomRadius = rand(0.1, 0.7);
  renderState.grain = bool(0.4);
  renderState.grainAmount = rand(0.005, 0.08);
  renderState.fog = bool(0.5);
  renderState.fogDensity = rand(0.005, 0.05);
  renderState.wireframe = bool(0.12);
  renderState.terrainRoughness = rand(0.1, 1.0);
  renderState.terrainMetalness = rand(0.0, 0.5);
  renderState.terrainEnvIntensity = rand(0.2, 3.0);
  renderState.ambientIntensity = rand(0.3, 3.5);
  renderState.sunIntensity = rand(0.1, 4.0);
  renderState.sunAzimuth = rand(0, 1);
  renderState.sunElevation = rand(0.05, 1.0);
  renderState.hdriExposure = rand(0.5, 2.0);
  renderState.roadEmissiveIntensity = rand(0.2, 4.0);
  renderState.roadFlatStyle = bool(0.4);
  renderState.roadExtrusionHeight = rand(0.05, 0.35);
  renderState.terrainExaggeration = rand(0.4, 3.0);
  renderState.highwayWidth = rand(0.08, 0.35);
  renderState.majorRoadWidth = rand(0.05, 0.22);
  renderState.minorRoadWidth = rand(0.02, 0.14);
  renderState.pathWidth = rand(0.01, 0.1);
  syncRenderUI();
  applyRenderSettings();
}

function syncRenderUI() {
  document.querySelectorAll('.render-toggle').forEach(el => {
    const key = el.dataset.render;
    if (renderState[key] !== undefined) el.checked = renderState[key];
  });
  document.querySelectorAll('.render-slider').forEach(el => {
    const key = el.dataset.render;
    if (renderState[key] !== undefined) {
      el.value = renderState[key];
      const valEl = document.getElementById(`render-val-${key}`);
      const decimals = (key.includes('Aperture') || key.includes('MaxBlur')) ? 4
        : (key.includes('Width') || key.includes('Amount') || key.includes('Density')) ? 3 : 2;
      if (valEl) valEl.textContent = parseFloat(renderState[key]).toFixed(decimals);
    }
  });
  const hdriSelect = document.getElementById('hdri-preset-select');
  if (hdriSelect) hdriSelect.value = renderState.hdriPreset;
}

let geoContext = null;
let _cachedOsmData = null;  // Cache OSM road data to avoid re-fetching on style changes
let gpxTrackGroup = null;
let gpxCurve = null;
let gpxStats = null;
// Cached per-frame references (invalidated on GPX/road rebuild)
let _cachedHaloRef = null;
let _cachedGlowRef = null;
let _cachedHwGlows = null;

// --- TILE / PROJECTION HELPERS ---
function latLngToTile(lat, lng, zoom) {
  const n = Math.pow(2, zoom);
  const x = Math.floor((lng + 180) / 360 * n);
  const latRad = lat * Math.PI / 180;
  const y = Math.floor((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2 * n);
  return { x, y, z: zoom };
}

function latLngToTileFrac(lat, lng, zoom) {
  const n = Math.pow(2, zoom);
  const fx = (lng + 180) / 360 * n;
  const latRad = lat * Math.PI / 180;
  const fy = (1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2 * n;
  return { fx, fy };
}

function latLngToWorld(lat, lng, ctx) {
  const degLat = ctx.radiusKm / 111.0;
  const degLng = ctx.radiusKm / (111.0 * Math.cos(ctx.centerLat * Math.PI / 180));
  const nx = (lng - ctx.centerLng) / degLng;
  const nz = (lat - ctx.centerLat) / degLat;
  return new THREE.Vector3(nx * (TERRAIN_SIZE / 2), 0, -nz * (TERRAIN_SIZE / 2));
}

function sampleTerrainHeight(wx, wz) {
  // Clamp world coords to terrain bounds
  const hwx = Math.max(-TERRAIN_SIZE / 2, Math.min(TERRAIN_SIZE / 2, wx));
  const hwz = Math.max(-TERRAIN_SIZE / 2, Math.min(TERRAIN_SIZE / 2, wz));
  const gx = ((hwx + TERRAIN_SIZE / 2) / TERRAIN_SIZE) * TERRAIN_SEGS;
  const gz = ((hwz + TERRAIN_SIZE / 2) / TERRAIN_SIZE) * TERRAIN_SEGS;
  const gxi = Math.max(0, Math.min(TERRAIN_SEGS - 1, Math.floor(gx)));
  const gzi = Math.max(0, Math.min(TERRAIN_SEGS - 1, Math.floor(gz)));
  const gxf = Math.max(0, Math.min(1, gx - gxi));
  const gzf = Math.max(0, Math.min(1, gz - gzi));
  const x0 = gxi, z0 = gzi;
  const x1 = Math.min(x0 + 1, TERRAIN_SEGS), z1 = Math.min(z0 + 1, TERRAIN_SEGS);
  const i00 = z0 * (TERRAIN_SEGS + 1) + x0, i10 = z0 * (TERRAIN_SEGS + 1) + x1;
  const i01 = z1 * (TERRAIN_SEGS + 1) + x0, i11 = z1 * (TERRAIN_SEGS + 1) + x1;
  const h00 = heights[i00] ?? 0, h10 = heights[i10] ?? 0;
  const h01 = heights[i01] ?? 0, h11 = heights[i11] ?? 0;
  return h00*(1-gxf)*(1-gzf) + h10*gxf*(1-gzf) + h01*(1-gxf)*gzf + h11*gxf*gzf;
}

function bestZoom(radiusKm) {
  if (radiusKm <= 3) return 14;
  if (radiusKm <= 8) return 13;
  if (radiusKm <= 15) return 12;
  if (radiusKm <= 30) return 11;
  if (radiusKm <= 50) return 10;
  return 9;
}

// --- MAP TILE PROVIDERS ---
const TILE_PROVIDERS = {
  satellite: {
    label: 'Satellite',
    url: (z, y, x) => `https://services.arcgisonline.com/arcgis/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`,
  },
  esriTopo: {
    label: 'ESRI Topo',
    url: (z, y, x) => `https://services.arcgisonline.com/arcgis/rest/services/World_Topo_Map/MapServer/tile/${z}/${y}/${x}`,
  },
  esriStreet: {
    label: 'ESRI Streets',
    url: (z, y, x) => `https://services.arcgisonline.com/arcgis/rest/services/World_Street_Map/MapServer/tile/${z}/${y}/${x}`,
  },
  esriShaded: {
    label: 'Shaded Relief',
    url: (z, y, x) => `https://services.arcgisonline.com/arcgis/rest/services/World_Shaded_Relief/MapServer/tile/${z}/${y}/${x}`,
  },
  esriNatGeo: {
    label: 'Nat Geo',
    url: (z, y, x) => `https://services.arcgisonline.com/arcgis/rest/services/NatGeo_World_Map/MapServer/tile/${z}/${y}/${x}`,
  },
  osm: {
    label: 'OSM Standard',
    url: (z, y, x) => `https://tile.openstreetmap.org/${z}/${x}/${y}.png`,
  },
  cartoLight: {
    label: 'Carto Light',
    url: (z, y, x) => `https://cartodb-basemaps-a.global.ssl.fastly.net/light_all/${z}/${x}/${y}.png`,
  },
  cartoDark: {
    label: 'Carto Dark',
    url: (z, y, x) => `https://cartodb-basemaps-a.global.ssl.fastly.net/dark_all/${z}/${x}/${y}.png`,
  },
  openTopo: {
    label: 'OpenTopoMap',
    url: (z, y, x) => `https://tile.opentopomap.org/${z}/${x}/${y}.png`,
  },
  cyclosm: {
    label: 'CyclOSM',
    url: (z, y, x) => `https://tile.waymarkedtrails.org/hiking/${z}/${x}/${y}.png`,
  },
};

let currentTileProvider = 'satellite';

// --- SATELLITE IMAGERY ---
async function fetchSatelliteTiles(centerLat, centerLng, radiusKm, providerKey) {
  const provider = TILE_PROVIDERS[providerKey || currentTileProvider] || TILE_PROVIDERS.satellite;
  const zoom = bestZoom(radiusKm);
  const center = latLngToTile(centerLat, centerLng, zoom);
  const tileRange = radiusKm <= 6 ? 1 : radiusKm <= 15 ? 2 : radiusKm <= 35 ? 3 : 4;
  const tiles = [];
  for (let dy = -tileRange; dy <= tileRange; dy++)
    for (let dx = -tileRange; dx <= tileRange; dx++)
      tiles.push({ x: center.x + dx, y: center.y + dy, z: zoom });

  const tileSize = 256, cols = tileRange * 2 + 1, rows = tileRange * 2 + 1;
  const canvas = document.createElement('canvas');
  canvas.width = cols * tileSize; canvas.height = rows * tileSize;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#111318';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  await Promise.allSettled(tiles.map(async (tile, i) => {
    const col = i % cols, row = Math.floor(i / cols);
    const url = provider.url(tile.z, tile.y, tile.x);
    try {
      const img = await loadImageCORS(url);
      ctx.drawImage(img, col * tileSize, row * tileSize, tileSize, tileSize);
    } catch(e) {}
  }));

  const tileLeft = center.x - tileRange, tileTop = center.y - tileRange;
  const p = terrainGeo.attributes.position;
  const uvAttr = terrainGeo.attributes.uv;
  const degLat = radiusKm / 111.0;
  const degLng = radiusKm / (111.0 * Math.cos(centerLat * Math.PI / 180));

  for (let i = 0; i < p.count; i++) {
    const wx = p.getX(i), wz = p.getZ(i);
    const vlng = centerLng + (wx / (TERRAIN_SIZE / 2)) * degLng;
    const vlat = centerLat - (wz / (TERRAIN_SIZE / 2)) * degLat;
    const { fx, fy } = latLngToTileFrac(vlat, vlng, zoom);
    uvAttr.setXY(i, (fx - tileLeft) / cols, 1.0 - (fy - tileTop) / rows);
  }
  uvAttr.needsUpdate = true;

  // Convert to black & white
  const bwCtx = canvas.getContext('2d');
  const imgData = bwCtx.getImageData(0, 0, canvas.width, canvas.height);
  const d = imgData.data;
  for (let i = 0; i < d.length; i += 4) {
    const gray = d[i] * 0.299 + d[i+1] * 0.587 + d[i+2] * 0.114;
    d[i] = d[i+1] = d[i+2] = gray;
  }
  bwCtx.putImageData(imgData, 0, 0);

  const tex = new THREE.CanvasTexture(canvas);
  tex.name = 'satelliteTex';
  return tex;
}

function loadImageCORS(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

let _lastSatelliteTex = null;

function applySatelliteTexture(tex) {
  if (tex) _lastSatelliteTex = tex;
  const t = tex || _lastSatelliteTex;
  if (renderState.vectorMap) {
    // In vector map mode: apply to vectorMapMat if overlay is on
    if (renderState.satelliteOverlay && t) {
      vectorMapMat.map = t;
      vectorMapMat.color.set(0xffffff);
      vectorMapMat.opacity = renderState.satelliteOverlayOpacity;
      vectorMapMat.transparent = true;
      // Blend vertex colors with texture via onBeforeCompile is complex;
      // instead we tint the material color to blend — use mix via color
      vectorMapMat.color.set(0x888888);
    } else {
      vectorMapMat.map = null;
      vectorMapMat.color.set(0xffffff);
      vectorMapMat.opacity = 1.0;
      vectorMapMat.transparent = false;
    }
    vectorMapMat.needsUpdate = true;
    return;
  }
  if (t) { terrainMat.map = t; terrainMat.color.set(0x888888); }
  else { terrainMat.map = null; terrainMat.color.set(0x111318); }
  terrainMat.needsUpdate = true;
}

// --- VECTOR MAP MATERIAL ---
const vectorMapMat = new THREE.MeshLambertMaterial({
  vertexColors: true,
  wireframe: false,
});
vectorMapMat.name = 'vectorMapMat';

function buildVectorMapColors(heightsArr, posAttr, terrainSegs) {
  const count = posAttr.count;
  const colors = new Float32Array(count * 3);

  // Find height range
  let minH = Infinity, maxH = -Infinity;
  for (let i = 0; i < count; i++) {
    if (heightsArr[i] < minH) minH = heightsArr[i];
    if (heightsArr[i] > maxH) maxH = heightsArr[i];
  }
  const range = maxH - minH || 1;

  // Elevation bands — dark cinematic topo palette
  // Each band: [normalizedStart, r, g, b]
  const bands = [
    [0.00, 0.02, 0.08, 0.28],  // deep water — vivid navy blue
    [0.06, 0.04, 0.22, 0.38],  // lowland — deep teal-blue
    [0.14, 0.05, 0.38, 0.22],  // low ground — rich forest green
    [0.26, 0.12, 0.50, 0.14],  // mid-low — vivid green
    [0.38, 0.30, 0.56, 0.10],  // mid ground — yellow-green
    [0.52, 0.60, 0.52, 0.08],  // upper-mid — warm olive-gold
    [0.65, 0.78, 0.42, 0.06],  // high — bright amber-orange
    [0.76, 0.85, 0.28, 0.08],  // higher — deep orange
    [0.86, 0.75, 0.18, 0.12],  // near peak — burnt sienna
    [0.93, 0.82, 0.78, 0.72],  // peak — warm light grey
    [1.00, 0.96, 0.95, 0.94],  // summit — near white
  ];

  function getBandColor(t) {
    for (let b = bands.length - 2; b >= 0; b--) {
      if (t >= bands[b][0]) {
        const next = bands[b + 1];
        const f = (t - bands[b][0]) / (next[0] - bands[b][0]);
        return [
          bands[b][1] + f * (next[1] - bands[b][1]),
          bands[b][2] + f * (next[2] - bands[b][2]),
          bands[b][3] + f * (next[3] - bands[b][3]),
        ];
      }
    }
    return [bands[0][1], bands[0][2], bands[0][3]];
  }

  // Compute slope per vertex using neighbors
  const W = terrainSegs + 1;
  for (let i = 0; i < count; i++) {
    const t = (heightsArr[i] - minH) / range;
    let [r, g, b] = getBandColor(t);

    // Slope darkening: sample neighbors if available
    const col = i % W, row = Math.floor(i / W);
    let slope = 0;
    if (col > 0 && col < W - 1 && row > 0 && row < W - 1) {
      const hL = heightsArr[row * W + (col - 1)];
      const hR = heightsArr[row * W + (col + 1)];
      const hU = heightsArr[(row - 1) * W + col];
      const hD = heightsArr[(row + 1) * W + col];
      const dx = (hR - hL) * 0.5;
      const dy = (hD - hU) * 0.5;
      slope = Math.sqrt(dx * dx + dy * dy);
    }

    // Slope darkens the color (steep = darker, more contrast)
    const slopeDark = Math.min(slope * 0.22, 0.62);
    r = Math.max(0, r - slopeDark);
    g = Math.max(0, g - slopeDark);
    b = Math.max(0, b - slopeDark);

    // Subtle emissive tint on ridges (high slope + high elevation)
    const ridgeness = slope * t * 0.5;
    r += ridgeness * 0.18;
    g += ridgeness * 0.10;
    b += ridgeness * 0.06;

    colors[i * 3]     = Math.min(1, r);
    colors[i * 3 + 1] = Math.min(1, g);
    colors[i * 3 + 2] = Math.min(1, b);
  }

  return colors;
}

function applyVectorMapMode(enabled) {
  if (enabled) {
    const cols = buildVectorMapColors(heights, terrainGeo.attributes.position, TERRAIN_SEGS);
    if (!terrainGeo.attributes.color) {
      terrainGeo.setAttribute('color', new THREE.BufferAttribute(cols, 3));
    } else {
      terrainGeo.attributes.color.array.set(cols);
      terrainGeo.attributes.color.needsUpdate = true;
    }
    terrain.material = vectorMapMat;
    vectorMapMat.wireframe = renderState.wireframe;
    // Apply satellite overlay if enabled
    if (renderState.satelliteOverlay && _lastSatelliteTex) {
      vectorMapMat.map = _lastSatelliteTex;
      vectorMapMat.color.set(0x888888);
      vectorMapMat.transparent = true;
      vectorMapMat.opacity = renderState.satelliteOverlayOpacity;
    } else {
      vectorMapMat.map = null;
      vectorMapMat.color.set(0xffffff);
      vectorMapMat.transparent = false;
      vectorMapMat.opacity = 1.0;
    }
    vectorMapMat.needsUpdate = true;
  } else {
    terrain.material = terrainMat;
    terrainMat.wireframe = renderState.wireframe;
    if (layerState.satellite && geoContext) {
      loadSatelliteForCurrentContext();
    }
  }
}

// --- ROAD VECTOR LAYERS ---
const ROAD_STYLES = {
  highway:   { color: 0xffe566, emissive: 0xbba830, width: 0.18, opacity: 0.7, order: 3 },
  majorRoad: { color: 0x6e6e6e, emissive: 0x3a3a3a, width: 0.11, opacity: 0.45, order: 2 },
  minorRoad: { color: 0x8888aa, emissive: 0x444466, width: 0.055, opacity: 0.4, order: 1 },
  path:      { color: 0x66ffcc, emissive: 0x00ffaa, width: 0.04,  opacity: 0.55, order: 0 },
};

// Old buildFlatRoadMesh removed — replaced by buildFlatRoadGeo (geometry-only, for merging)

function classifyRoad(tags) {
  const hw = tags.highway || '';
  if (['motorway','trunk','motorway_link','trunk_link'].includes(hw)) return 'highway';
  if (['primary','secondary','primary_link','secondary_link'].includes(hw)) return 'majorRoad';
  if (['tertiary','unclassified','residential','tertiary_link'].includes(hw)) return 'minorRoad';
  if (['footway','cycleway','path','track','service','steps','pedestrian'].includes(hw)) return 'path';
  return null;
}

async function fetchRoadData(centerLat, centerLng, radiusKm) {
  const r = Math.min(radiusKm * 1000, 60000);
  // For large areas (>20km), skip minor paths/tracks/service roads to keep data size manageable
  const roadTypes = radiusKm > 30
    ? 'motorway|trunk|primary|secondary|tertiary|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link'
    : radiusKm > 15
    ? 'motorway|trunk|primary|secondary|tertiary|residential|unclassified|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link|footway|cycleway'
    : 'motorway|trunk|primary|secondary|tertiary|residential|unclassified|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link|footway|cycleway|path|track|service';
  const timeout = radiusKm > 30 ? 45 : 30;
  const query = `[out:json][timeout:${timeout}];(way["highway"~"${roadTypes}"](around:${r},${centerLat},${centerLng}););out body;>;out skel qt;`.trim();
  const res = await fetch('https://overpass-api.de/api/interpreter', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'data=' + encodeURIComponent(query),
  });
  if (!res.ok) throw new Error(`Overpass API error: ${res.status}`);
  return await res.json();
}

function buildRoadLayers(osmData, ctx) {
  const old = scene.getObjectByName('roadLayers');
  if (old) { old.traverse(c => { if (c.geometry) c.geometry.dispose(); if (c.material) c.material.dispose(); }); scene.remove(old); }

  const nodeMap = new Map();
  osmData.elements.forEach(el => { if (el.type === 'node') nodeMap.set(el.id, { lat: el.lat, lon: el.lon }); });

  const buckets = { highway: [], majorRoad: [], minorRoad: [], path: [] };
  osmData.elements.forEach(el => {
    if (el.type !== 'way' || !el.tags) return;
    const type = classifyRoad(el.tags);
    if (!type) return;
    const nodes = (el.nodes || []).map(id => nodeMap.get(id)).filter(Boolean);
    if (nodes.length < 2) return;
    buckets[type].push(nodes);
  });

  const group = new THREE.Group();
  group.name = 'roadLayers';
  const layerGroupNames = { highway: 'roadLayer_highway', majorRoad: 'roadLayer_majorRoad', minorRoad: 'roadLayer_minorRoad', path: 'roadLayer_path' };

  // Y-lift per road type so layers don't z-fight each other
  const Y_LIFT = { path: 0.28, minorRoad: 0.42, majorRoad: 0.58, highway: 0.78 };
  // Tube radial segments — reduced for perf
  const TUBE_SEGS = { highway: 4, majorRoad: 3, minorRoad: 3, path: 3 };
  // Max tube curve segments per road — scale down for large datasets
  const totalWays = Object.values(buckets).reduce((s, b) => s + b.length, 0);
  const isLargeDataset = totalWays > 800;
  const MAX_CURVE_SEGS = isLargeDataset ? 40 : 80;

  const flat = renderState.roadFlatStyle;
  const extH = renderState.roadExtrusionHeight;

  Object.entries(buckets).forEach(([type, ways]) => {
    const style = ROAD_STYLES[type];
    const layerGroup = new THREE.Group();
    layerGroup.name = layerGroupNames[type];
    const layerKey = type === 'highway' ? 'highways' : type === 'majorRoad' ? 'majorRoads' : type === 'minorRoad' ? 'minorRoads' : 'paths';
    layerGroup.visible = layerState[layerKey];
    const yLift = Y_LIFT[type];

    // Shared material per road type — one material for all roads of this type
    const baseEmissive = type === 'highway' ? 1.0 : type === 'majorRoad' ? 0.2 : 0.3;
    const sharedMat = new THREE.MeshLambertMaterial({
      color: style.color, emissive: style.emissive,
      emissiveIntensity: baseEmissive * renderState.roadEmissiveIntensity,
      transparent: true, opacity: style.opacity,
      side: flat ? THREE.DoubleSide : THREE.FrontSide,
    });
    sharedMat.name = `roadMat_${type}`;

    // Collect geometries for batch merging
    const geometries = [];
    const MERGE_BATCH = 200; // merge up to N roads per batch mesh

    ways.forEach((nodes) => {
      const validNodes = nodes.filter(node => {
        const wp = latLngToWorld(node.lat, node.lon, ctx);
        return Math.abs(wp.x) <= TERRAIN_SIZE * 0.52 && Math.abs(wp.z) <= TERRAIN_SIZE * 0.52;
      });
      if (validNodes.length < 2) return;

      const points = validNodes.map(node => {
        const wp = latLngToWorld(node.lat, node.lon, ctx);
        const wy = sampleTerrainHeight(wp.x, wp.z) + yLift;
        return new THREE.Vector3(wp.x, Math.max(wy, -3.0 + yLift), wp.z);
      });

      // Deduplicate with distance threshold scaled for large maps
      const minDist = isLargeDataset ? 0.05 : 0.001;
      const deduped = [points[0]];
      for (let i = 1; i < points.length; i++) {
        if (points[i].distanceTo(deduped[deduped.length - 1]) > minDist) deduped.push(points[i]);
      }
      if (deduped.length < 2) return;

      let geo;
      if (flat) {
        geo = buildFlatRoadGeo(deduped, style.width);
      } else {
        const curve = new THREE.CatmullRomCurve3(deduped, false, 'centripetal', 0.5);
        const segments = Math.max(4, Math.min(deduped.length * 2, MAX_CURVE_SEGS));
        const radius = style.width * (extH > 0 ? Math.min(extH / 0.18, 2.0) : 1.0);
        geo = new THREE.TubeGeometry(curve, segments, radius, TUBE_SEGS[type], false);
      }
      if (geo) geometries.push(geo);

      // Flush batch to avoid merging too many at once (memory)
      if (geometries.length >= MERGE_BATCH) {
        const merged = BufferGeometryUtils.mergeGeometries(geometries, false);
        if (merged) {
          const mesh = new THREE.Mesh(merged, sharedMat);
          mesh.name = `road_${type}_batch_${layerGroup.children.length}`;
          mesh.renderOrder = style.order;
          layerGroup.add(mesh);
        }
        // Dispose source geos
        geometries.forEach(g => g.dispose());
        geometries.length = 0;
      }
    });

    // Flush remaining geometries
    if (geometries.length > 0) {
      const merged = BufferGeometryUtils.mergeGeometries(geometries, false);
      if (merged) {
        const mesh = new THREE.Mesh(merged, sharedMat);
        mesh.name = `road_${type}_batch_${layerGroup.children.length}`;
        mesh.renderOrder = style.order;
        layerGroup.add(mesh);
      }
      geometries.forEach(g => g.dispose());
      geometries.length = 0;
    }

    // Highway glow — single merged mesh (tube mode only)
    if (type === 'highway' && !flat && layerGroup.children.length > 0) {
      const glowMat = new THREE.MeshLambertMaterial({
        color: 0xffee00, emissive: 0xffcc00, emissiveIntensity: 3.5,
        transparent: true, opacity: 0.18, depthWrite: false,
      });
      glowMat.name = 'roadMat_highway_glow';
      layerGroup.children.forEach(mesh => {
        const glowGeo = mesh.geometry.clone();
        const glow = new THREE.Mesh(glowGeo, glowMat);
        glow.name = mesh.name + '_glow';
        glow.scale.setScalar(1.8);
        glow.renderOrder = style.order - 0.5;
        layerGroup.add(glow);
      });
    }

    group.add(layerGroup);
  });

  scene.add(group);
  _cachedHwGlows = null; // invalidate cached road glow refs
  return group;
}

// Build flat road geometry only (no mesh) for merging
function buildFlatRoadGeo(points, width) {
  if (points.length < 2) return null;
  const positions = [], indices = [], uvs = [];
  let totalLen = 0;
  const lens = [0];
  for (let i = 1; i < points.length; i++) {
    totalLen += points[i].distanceTo(points[i-1]);
    lens.push(totalLen);
  }
  for (let i = 0; i < points.length; i++) {
    const curr = points[i];
    let dir;
    if (i === 0) dir = points[1].clone().sub(points[0]);
    else if (i === points.length - 1) dir = points[i].clone().sub(points[i-1]);
    else dir = points[i+1].clone().sub(points[i-1]);
    dir.y = 0; dir.normalize();
    const right = new THREE.Vector3(-dir.z, 0, dir.x).multiplyScalar(width * 0.5);
    const uv = lens[i] / (totalLen || 1);
    positions.push(curr.x + right.x, curr.y + 0.04, curr.z + right.z);
    positions.push(curr.x - right.x, curr.y + 0.04, curr.z - right.z);
    uvs.push(0, uv, 1, uv);
  }
  for (let i = 0; i < points.length - 1; i++) {
    const a = i * 2, b = a + 1, c = a + 2, d = a + 3;
    indices.push(a, b, c, b, d, c);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

// --- GPX PARSING & VISUALIZATION ---
function parseGPX(xmlString) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlString, 'text/xml');
  const points = [];

  // Check for XML parse errors
  const parseError = doc.querySelector('parsererror');
  if (parseError) {
    console.error('[GPX] XML parse error:', parseError.textContent);
    return points;
  }

  // Support namespaced and non-namespaced GPX
  // getElementsByTagNameNS with '*' wildcard handles both cases
  let trkpts = doc.getElementsByTagNameNS('*', 'trkpt');
  let wpts = doc.getElementsByTagNameNS('*', 'wpt');
  const src = trkpts.length > 0 ? trkpts : wpts;

  console.log(`[GPX] Parsing: found ${trkpts.length} trkpt, ${wpts.length} wpt`);

  for (let i = 0; i < src.length; i++) {
    const pt = src[i];
    const lat = parseFloat(pt.getAttribute('lat'));
    const lon = parseFloat(pt.getAttribute('lon'));
    const eleEl = pt.getElementsByTagNameNS('*', 'ele')[0];
    const timeEl = pt.getElementsByTagNameNS('*', 'time')[0];
    const ele = eleEl ? parseFloat(eleEl.textContent) : null;
    const time = timeEl ? new Date(timeEl.textContent) : null;
    // Extract speed from extensions if available
    const speedEl = pt.getElementsByTagNameNS('*', 'speed')[0];
    const speed = speedEl ? parseFloat(speedEl.textContent) : null;
    if (!isNaN(lat) && !isNaN(lon)) points.push({ lat, lon, ele, time, speed });
  }

  console.log(`[GPX] Parsed ${points.length} valid points`);
  return points;
}

function calcGPXStats(points) {
  if (points.length < 2) return null;
  let distKm = 0, elevGain = 0, elevLoss = 0;
  let minEle = Infinity, maxEle = -Infinity;
  let duration = null;

  for (let i = 1; i < points.length; i++) {
    const a = points[i-1], b = points[i];
    const dLat = (b.lat - a.lat) * Math.PI / 180;
    const dLon = (b.lon - a.lon) * Math.PI / 180;
    const hs = Math.sin(dLat/2)**2 + Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dLon/2)**2;
    distKm += 6371 * 2 * Math.atan2(Math.sqrt(hs), Math.sqrt(1-hs));
    if (a.ele != null && b.ele != null) {
      const dEle = b.ele - a.ele;
      if (dEle > 0) elevGain += dEle;
      else elevLoss += Math.abs(dEle);
    }
  }

  points.forEach(p => {
    if (p.ele != null) { if (p.ele < minEle) minEle = p.ele; if (p.ele > maxEle) maxEle = p.ele; }
  });
  if (points[0].time && points[points.length-1].time)
    duration = (points[points.length-1].time - points[0].time) / 60000;

  return {
    distKm: distKm.toFixed(2),
    elevGain: Math.round(elevGain),
    elevLoss: Math.round(elevLoss),
    minEle: minEle === Infinity ? null : Math.round(minEle),
    maxEle: maxEle === -Infinity ? null : Math.round(maxEle),
    pointCount: points.length,
    duration,
    startLat: points[0].lat,
    startLon: points[0].lon,
    endLat: points[points.length-1].lat,
    endLon: points[points.length-1].lon,
    centerLat: points.reduce((s,p) => s+p.lat,0)/points.length,
    centerLon: points.reduce((s,p) => s+p.lon,0)/points.length,
  };
}

// --- GPX DRAG & DROP ---
function setupGPXDrop() {
  const zone = document.getElementById('gpx-drop-zone');
  const overlay = document.getElementById('gpx-overlay');

  // Global drag-over to show overlay
  document.addEventListener('dragover', e => {
    e.preventDefault();
    overlay.classList.add('active');
  });
  document.addEventListener('dragleave', e => {
    if (e.relatedTarget === null || e.relatedTarget === document.documentElement) {
      overlay.classList.remove('active');
    }
  });
  document.addEventListener('drop', e => {
    e.preventDefault();
    overlay.classList.remove('active');
    const file = e.dataTransfer.files[0];
    if (file && (file.name.endsWith('.gpx') || file.type === 'application/gpx+xml' || file.type === 'text/xml')) {
      handleGPXFile(file);
    } else {
      setStatus('Drop a .gpx file to load a track.', 'error');
    }
  });

  // Also support click-to-upload in the panel
  const fileInput = document.getElementById('gpx-file-input');
  document.getElementById('gpx-upload-btn').addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', e => {
    if (e.target.files[0]) handleGPXFile(e.target.files[0]);
  });
}

async function handleGPXFile(file) {
  setStatus('Parsing GPX track…', 'loading');
  try {
    const text = await file.text();
    const points = parseGPX(text);
    if (points.length < 2) throw new Error('GPX file has fewer than 2 trackpoints.');

    gpxStats = calcGPXStats(points);
    updateGPXStatsUI(gpxStats);

    // Auto-center on the GPX track
    const cLat = gpxStats.centerLat, cLon = gpxStats.centerLon;
    // Estimate radius from bounding box
    const lats = points.map(p => p.lat), lons = points.map(p => p.lon);
    const dLat = (Math.max(...lats) - Math.min(...lats));
    const dLon = (Math.max(...lons) - Math.min(...lons));
    const radiusKm = Math.max(
      dLat * 111 * 0.7,
      dLon * 111 * Math.cos(cLat * Math.PI / 180) * 0.7,
      2
    );

    document.getElementById('geo-lat').value = cLat.toFixed(6);
    document.getElementById('geo-lng').value = cLon.toFixed(6);
    document.getElementById('geo-radius').value = Math.min(Math.round(radiusKm * 1.4), 60);
    document.getElementById('geo-radius-val').textContent = document.getElementById('geo-radius').value;

    setStatus(`GPX loaded (${gpxStats.pointCount} pts, ${gpxStats.distKm}km). Loading terrain…`, 'loading');

    // Load terrain for the GPX area
    await loadTerrainForGPX(cLat, cLon, parseFloat(document.getElementById('geo-radius').value), points);

  } catch(err) {
    setStatus(`GPX error: ${err.message}`, 'error');
    console.error(err);
  }
}

async function loadTerrainForGPX(lat, lng, radius, gpxPoints) {
  try {
    const { grid, gridSize } = await fetchElevationGrid(lat, lng, radius, 32);
    setStatus('Building terrain…', 'loading');
    const newHeights = buildHeightsFromElevation(terrainGeo.attributes.position, TERRAIN_SIZE, TERRAIN_SEGS, grid, gridSize);
    rebuildTerrain(newHeights);
    geoContext = { centerLat: lat, centerLng: lng, radiusKm: radius };

    if (layerState.satellite) {
      setStatus('Loading satellite imagery…', 'loading');
      try {
        const tex = await fetchSatelliteTiles(lat, lng, radius, currentTileProvider);
        applySatelliteTexture(tex);
      } catch(e) { console.warn('Satellite failed:', e.message); }
    }

    setStatus('Loading roads…', 'loading');
    try {
      const osmData = await fetchRoadData(lat, lng, radius);
      _cachedOsmData = osmData;
      buildRoadLayers(osmData, geoContext);
    } catch(e) { console.warn('Roads failed:', e.message); }

    // Build GPX track on the new terrain
    buildGPXTrack(gpxPoints, geoContext);
    layerState.gpxTrack = true;
    document.querySelector('[data-layer="gpxTrack"]').checked = true;

    const s = gpxStats;
    setStatus(`Track loaded — ${s.distKm}km · ↑${s.elevGain}m ↓${s.elevLoss}m`, 'success');
    updateHUD(lat, lng, s.maxEle || 0);

    // Expand GPX stats panel
    document.getElementById('gpx-stats-panel').classList.add('visible');
  } catch(err) {
    setStatus(`Error: ${err.message}`, 'error');
    console.error(err);
  }
}

function updateGPXStatsUI(stats) {
  if (!stats) return;
  document.getElementById('gpx-dist').textContent = stats.distKm + ' km';
  document.getElementById('gpx-gain').textContent = '+' + stats.elevGain + ' m';
  document.getElementById('gpx-loss').textContent = '-' + stats.elevLoss + ' m';
  document.getElementById('gpx-maxele').textContent = (stats.maxEle ?? '—') + ' m';
  document.getElementById('gpx-minele').textContent = (stats.minEle ?? '—') + ' m';
  document.getElementById('gpx-pts').textContent = stats.pointCount;
  if (stats.duration != null) {
    const h = Math.floor(stats.duration / 60), m = Math.round(stats.duration % 60);
    document.getElementById('gpx-time').textContent = h > 0 ? `${h}h ${m}m` : `${m}m`;
  } else {
    document.getElementById('gpx-time').textContent = '—';
  }
}

// --- LAYER TOGGLES ---
function applyLayerVisibility() {
  const roadLayers = scene.getObjectByName('roadLayers');
  if (roadLayers) {
    const map = { highways: 'roadLayer_highway', majorRoads: 'roadLayer_majorRoad', minorRoads: 'roadLayer_minorRoad', paths: 'roadLayer_path' };
    Object.entries(map).forEach(([key, name]) => {
      const g = roadLayers.getObjectByName(name);
      if (g) g.visible = layerState[key];
    });
  }

  const contours = scene.getObjectByName('contours');
  if (contours) contours.visible = layerState.contours;

  const gpsPath = scene.getObjectByName('gpsPath');
  if (gpsPath) gpsPath.visible = layerState.gpsPath;

  if (gpxTrackGroup) gpxTrackGroup.visible = layerState.gpxTrack;
  if (gpxMarker) gpxMarker.visible = layerState.gpxTrack;

  if (layerState.satellite) {
    if (!terrainMat.map && geoContext) loadSatelliteForCurrentContext();
    else { terrainMat.color.set(0x888888); terrainMat.needsUpdate = true; }
  } else {
    terrainMat.map = null;
    terrainMat.color.set(0x111318);
    terrainMat.needsUpdate = true;
  }
}

function applyRenderSettings() {
  // Post-processing
  bloom.strength = renderState.bloomStrength;
  bloom.radius = renderState.bloomRadius;
  bloom.enabled = renderState.bloom;
  grainPass.uniforms.amount.value = renderState.grainAmount;
  grainPass.enabled = renderState.grain;

  // Depth of Field
  bokehPass.enabled = renderState.dofEnabled;
  bokehPass.uniforms['focus'].value = renderState.dofFocus;
  bokehPass.uniforms['aperture'].value = renderState.dofAperture;
  bokehPass.uniforms['maxblur'].value = renderState.dofMaxBlur;

  // Fog
  scene.fog = renderState.fog ? new THREE.FogExp2(0x0a0a0a, renderState.fogDensity) : null;

  // Wireframe
  terrainMat.wireframe = renderState.wireframe;
  vectorMapMat.wireframe = renderState.wireframe;

  // Terrain material props
  terrainMat.roughness = renderState.terrainRoughness;
  terrainMat.metalness = renderState.terrainMetalness;
  terrainMat.envMapIntensity = renderState.terrainEnvIntensity;
  terrainMat.needsUpdate = true;
  vectorMapMat.needsUpdate = true;

  // Lighting
  ambient.intensity = renderState.ambientIntensity;
  dirLight.intensity = renderState.sunIntensity;
  const az = renderState.sunAzimuth * Math.PI * 2;
  const el = renderState.sunElevation * Math.PI / 2;
  dirLight.position.set(
    Math.cos(el) * Math.sin(az) * 60,
    Math.sin(el) * 60,
    Math.cos(el) * Math.cos(az) * 60
  );

  // Contour style updates
  applyContourStyle();

  // Road line widths — rebuild only if width values changed
  applyRoadWidths();

  // HDRI / env map
  applyHDRI();

  // Sky
  applySky();

  // Exposure
  renderer.toneMappingExposure = renderState.hdriExposure;

  // Vector map
  if (renderState.vectorMap) applyVectorMapMode(true);
  if (renderState.vectorMap && vectorMapMat.map) {
    vectorMapMat.opacity = renderState.satelliteOverlayOpacity;
    vectorMapMat.needsUpdate = true;
  }
}

// Road style state tracking to avoid unnecessary rebuilds
let _lastRoadWidths = {};
function applyRoadWidths() {
  const w = {
    highway: renderState.highwayWidth,
    majorRoad: renderState.majorRoadWidth,
    minorRoad: renderState.minorRoadWidth,
    path: renderState.pathWidth,
    emissive: renderState.roadEmissiveIntensity,
    flat: renderState.roadFlatStyle,
    extrusion: renderState.roadExtrusionHeight,
  };
  const changed = Object.keys(w).some(k => _lastRoadWidths[k] !== w[k]);
  if (!changed) return;
  _lastRoadWidths = { ...w };

  // Update ROAD_STYLES live
  ROAD_STYLES.highway.width   = w.highway;
  ROAD_STYLES.majorRoad.width = w.majorRoad;
  ROAD_STYLES.minorRoad.width = w.minorRoad;
  ROAD_STYLES.path.width      = w.path;

  // Rebuild from cached OSM data (no re-fetch needed)
  if (_cachedOsmData && geoContext) {
    buildRoadLayers(_cachedOsmData, geoContext);
  }
}

// HDRI presets (procedural via PMREMGenerator from a color gradient)
let _hdriEnvMap = null;
let _lastHdriPreset = null;
function applyHDRI() {
  if (!renderState.hdriEnabled) {
    scene.environment = null;
    scene.background = new THREE.Color(0x0a0a0a);
    return;
  }
  if (renderState.hdriPreset === _lastHdriPreset && _hdriEnvMap) {
    scene.environment = _hdriEnvMap;
    return;
  }
  _lastHdriPreset = renderState.hdriPreset;

  // Build a procedural gradient env map via a small canvas cube texture
  const presets = {
    studio:  { top: 0x404858, mid: 0x1a2030, bot: 0x0a0a10 },
    sunset:  { top: 0x1a0a2e, mid: 0xff4400, bot: 0xff9900 },
    noon:    { top: 0x3a6fd8, mid: 0x88aadd, bot: 0xeeeedd },
    night:   { top: 0x000510, mid: 0x030815, bot: 0x000000 },
    overcast:{ top: 0x556677, mid: 0x778899, bot: 0x445566 },
  };
  const p = presets[renderState.hdriPreset] || presets.studio;

  const size = 128;
  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileCubemapShader();

  // Build a sphere scene as env
  const envScene = new THREE.Scene();
  const envGeo = new THREE.SphereGeometry(50, 32, 16);
  // Gradient canvas texture
  const cvs = document.createElement('canvas'); cvs.width = size; cvs.height = size;
  const cx = cvs.getContext('2d');
  const grad = cx.createLinearGradient(0, 0, 0, size);
  grad.addColorStop(0,   '#' + p.top.toString(16).padStart(6,'0'));
  grad.addColorStop(0.5, '#' + p.mid.toString(16).padStart(6,'0'));
  grad.addColorStop(1,   '#' + p.bot.toString(16).padStart(6,'0'));
  cx.fillStyle = grad; cx.fillRect(0, 0, size, size);
  const envTex = new THREE.CanvasTexture(cvs);
  const envMat = new THREE.MeshBasicMaterial({ map: envTex, side: THREE.BackSide });
  const envSphere = new THREE.Mesh(envGeo, envMat);
  envSphere.name = 'envSphere';
  envScene.add(envSphere);

  _hdriEnvMap = pmrem.fromScene(envScene).texture;
  scene.environment = _hdriEnvMap;
  if (renderState.skyEnabled) {
    scene.background = _hdriEnvMap;
  }
  pmrem.dispose();
}

// Sky dome (simple procedural)
let _skyMesh = null;
function applySky() {
  if (!renderState.skyEnabled) {
    if (_skyMesh) { scene.remove(_skyMesh); _skyMesh = null; }
    if (!renderState.hdriEnabled) scene.background = new THREE.Color(0x0a0a0a);
    return;
  }
  if (!_skyMesh) {
    const geo = new THREE.SphereGeometry(400, 32, 16);
    const mat = new THREE.ShaderMaterial({
      uniforms: {
        uTurbidity: { value: renderState.skyTurbidity },
        uRayleigh: { value: renderState.skyRayleigh },
        uSunDir: { value: new THREE.Vector3(0.5, 0.5, 0.5).normalize() },
      },
      vertexShader: `varying vec3 vWorldPos; void main(){ vWorldPos = (modelMatrix * vec4(position,1.0)).xyz; gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(position,1.0); }`,
      fragmentShader: `
        uniform float uTurbidity;
        uniform float uRayleigh;
        uniform vec3 uSunDir;
        varying vec3 vWorldPos;
        void main(){
          vec3 dir = normalize(vWorldPos);
          float sunDot = max(0.0, dot(dir, uSunDir));
          float skyGrad = max(0.0, dir.y) * 0.5 + 0.5;
          vec3 zenith = vec3(0.08, 0.14, 0.32) * uRayleigh;
          vec3 horizon = vec3(0.28, 0.22, 0.18) * (uTurbidity / 10.0);
          vec3 sun = vec3(1.0, 0.85, 0.5) * pow(sunDot, 64.0) * 4.0;
          vec3 col = mix(horizon, zenith, skyGrad) + sun;
          gl_FragColor = vec4(col, 1.0);
        }
      `,
      side: THREE.BackSide,
    });
    _skyMesh = new THREE.Mesh(geo, mat);
    _skyMesh.name = 'skyDome';
    scene.add(_skyMesh);
  }
  const mat = _skyMesh.material;
  mat.uniforms.uTurbidity.value = renderState.skyTurbidity;
  mat.uniforms.uRayleigh.value = renderState.skyRayleigh;
  const az = renderState.sunAzimuth * Math.PI * 2;
  const el = renderState.sunElevation * Math.PI / 2;
  mat.uniforms.uSunDir.value.set(
    Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az)
  ).normalize();
  scene.background = null;
}

async function loadSatelliteForCurrentContext(providerKey) {
  if (!geoContext) return;
  try {
    const tex = await fetchSatelliteTiles(geoContext.centerLat, geoContext.centerLng, geoContext.radiusKm, providerKey || currentTileProvider);
    applySatelliteTexture(tex);
  } catch(e) { console.warn('Satellite reload failed:', e.message); }
}

// --- GEO / ELEVATION HELPERS ---
async function geocodePlace(name) {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1&language=en&format=json`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Geocoding request failed (${res.status})`);
  const data = await res.json();
  if (!data.results || !data.results.length) throw new Error(`Place not found: "${name}"`);
  const r = data.results[0];
  return { lat: r.latitude, lng: r.longitude, display: [r.name, r.admin1, r.country].filter(Boolean).join(', ') };
}

// --- Terrarium tile helpers ---
// latLngToTile already defined above in TILE / PROJECTION HELPERS
function tileBounds(x, y, z) {
  const n = Math.pow(2, z);
  const lngW = x / n * 360 - 180;
  const lngE = (x + 1) / n * 360 - 180;
  const latN = Math.atan(Math.sinh(Math.PI * (1 - 2 * y / n))) * 180 / Math.PI;
  const latS = Math.atan(Math.sinh(Math.PI * (1 - 2 * (y + 1) / n))) * 180 / Math.PI;
  return { latN, latS, lngW, lngE };
}
function loadTerrariumTile(x, y, z) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      debugLog(`Tile ${z}/${x}/${y} timed out`, 'warn');
      resolve(null);
    }, 8000);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      clearTimeout(timeout);
      try {
        const c = document.createElement('canvas');
        c.width = img.width; c.height = img.height;
        const ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0);
        resolve({ imageData: ctx.getImageData(0, 0, c.width, c.height), bounds: tileBounds(x, y, z) });
      } catch(e) {
        debugLog(`Tile ${z}/${x}/${y} canvas error: ${e.message}`, 'warn');
        resolve(null);
      }
    };
    img.onerror = () => {
      clearTimeout(timeout);
      debugLog(`Tile ${z}/${x}/${y} load error`, 'warn');
      resolve(null);
    };
    img.src = `https://s3.amazonaws.com/elevation-tiles-prod/terrarium/${z}/${x}/${y}.png`;
  });
}
function sampleTerrariumPixel(imageData, lat, lng, bounds) {
  const tx = (lng - bounds.lngW) / (bounds.lngE - bounds.lngW) * (imageData.width - 1);
  const ty = (bounds.latN - lat) / (bounds.latN - bounds.latS) * (imageData.height - 1);
  const px = Math.max(0, Math.min(imageData.width - 1, Math.round(tx)));
  const py = Math.max(0, Math.min(imageData.height - 1, Math.round(ty)));
  const i = (py * imageData.width + px) * 4;
  const r = imageData.data[i], g = imageData.data[i+1], b = imageData.data[i+2];
  return (r * 256 + g + b / 256) - 32768;
}

async function fetchElevationGrid(centerLat, centerLng, radiusKm, gridSize = 32) {
  // Scale grid resolution with radius for better terrain detail on large maps
  // Small (≤8km): 48, Medium (≤20km): 64, Large (≤40km): 80, Huge (>40km): 96
  if (gridSize <= 32) {
    gridSize = radiusKm <= 8 ? 48 : radiusKm <= 20 ? 64 : radiusKm <= 40 ? 80 : 96;
  }
  const degLat = radiusKm / 111.0;
  const degLng = radiusKm / (111.0 * Math.cos(centerLat * Math.PI / 180));

  // Try Terrarium tiles first
  try {
    const result = await fetchElevationFromTerrarium(centerLat, centerLng, degLat, degLng, radiusKm, gridSize);
    if (result) return result;
  } catch(e) {
    debugLog(`Terrarium tiles failed: ${e.message}, trying API fallback…`, 'warn');
  }

  // Fallback: Open-Meteo elevation API (CORS-friendly, no key needed)
  debugLog('Using Open-Meteo elevation API fallback…');
  try {
    return await fetchElevationFromOpenMeteo(centerLat, centerLng, degLat, degLng, gridSize);
  } catch(e) {
    debugLog(`Open-Meteo fallback failed: ${e.message}`, 'warn');
  }

  // Last resort: generate procedural terrain based on coordinates
  debugLog('All elevation sources failed, using procedural terrain', 'warn');
  return generateProceduralElevation(centerLat, centerLng, radiusKm, gridSize);
}

async function fetchElevationFromTerrarium(centerLat, centerLng, degLat, degLng, radiusKm, gridSize) {
  const latN = centerLat + degLat, latS = centerLat - degLat;
  const lngW = centerLng - degLng, lngE = centerLng + degLng;
  const zoom = radiusKm < 5 ? 12 : radiusKm < 15 ? 11 : radiusKm < 30 ? 10 : radiusKm < 50 ? 9 : 8;

  const tileMin = latLngToTile(latN, lngW, zoom);
  const tileMax = latLngToTile(latS, lngE, zoom);
  const tileSet = new Map();
  for (let ty = tileMin.y; ty <= tileMax.y; ty++)
    for (let tx = tileMin.x; tx <= tileMax.x; tx++)
      tileSet.set(`${tx},${ty}`, { x: tx, y: ty, z: zoom });

  const tileEntries = [...tileSet.entries()];
  const tileResults = await Promise.all(tileEntries.map(([, t]) => loadTerrariumTile(t.x, t.y, t.z)));
  const tiles = new Map();
  let validCount = 0;
  tileEntries.forEach(([key], i) => {
    tiles.set(key, tileResults[i]);
    if (tileResults[i]) validCount++;
  });

  if (validCount === 0) return null; // all tiles failed

  const grid = new Float32Array(gridSize * gridSize);
  for (let row = 0; row < gridSize; row++) {
    for (let col = 0; col < gridSize; col++) {
      const lat = centerLat + degLat - (2 * degLat * row) / (gridSize - 1);
      const lng = centerLng - degLng + (2 * degLng * col) / (gridSize - 1);
      const t = latLngToTile(lat, lng, zoom);
      const key = `${t.x},${t.y}`;
      const tile = tiles.get(key);
      grid[row * gridSize + col] = tile ? sampleTerrariumPixel(tile.imageData, lat, lng, tile.bounds) : 0;
    }
  }
  return { grid, gridSize };
}

async function fetchElevationFromOpenMeteo(centerLat, centerLng, degLat, degLng, gridSize) {
  // Open-Meteo elevation API accepts up to 100 coordinates per call
  const allLats = [], allLngs = [];
  for (let row = 0; row < gridSize; row++) {
    for (let col = 0; col < gridSize; col++) {
      allLats.push(centerLat + degLat - (2 * degLat * row) / (gridSize - 1));
      allLngs.push(centerLng - degLng + (2 * degLng * col) / (gridSize - 1));
    }
  }

  const BATCH = 100;
  const grid = new Float32Array(gridSize * gridSize);
  for (let i = 0; i < allLats.length; i += BATCH) {
    const batchLats = allLats.slice(i, i + BATCH);
    const batchLngs = allLngs.slice(i, i + BATCH);
    const url = `https://api.open-meteo.com/v1/elevation?latitude=${batchLats.join(',')}&longitude=${batchLngs.join(',')}`;
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`Open-Meteo HTTP ${resp.status}`);
    const data = await resp.json();
    const elev = data.elevation || [];
    for (let j = 0; j < elev.length; j++) {
      grid[i + j] = elev[j] ?? 0;
    }
  }
  return { grid, gridSize };
}

function generateProceduralElevation(centerLat, centerLng, radiusKm, gridSize) {
  const grid = new Float32Array(gridSize * gridSize);
  const seed = (centerLat * 1000 + centerLng * 100) % 1000;
  for (let row = 0; row < gridSize; row++) {
    for (let col = 0; col < gridSize; col++) {
      const nx = col / gridSize * 4 + seed;
      const ny = row / gridSize * 4 + seed;
      const e = Math.sin(nx * 0.7 + ny * 0.4) * 80 +
                Math.sin(nx * 1.3 - ny * 0.9) * 40 +
                Math.cos(nx * 0.5 + ny * 1.2) * 60 +
                200 + radiusKm * 2;
      grid[row * gridSize + col] = Math.max(0, e);
    }
  }
  return { grid, gridSize };
}

function buildHeightsFromElevation(pos, terrainSize, terrainSegs, elevGrid, gridSize) {
  const h = new Float32Array(pos.count);
  const base = new Float32Array(pos.count); // normalized 0-1 heights
  let minE = Infinity, maxE = -Infinity;
  for (let i = 0; i < elevGrid.length; i++) { if (elevGrid[i]<minE) minE=elevGrid[i]; if (elevGrid[i]>maxE) maxE=elevGrid[i]; }
  const range = maxE - minE || 1;
  for (let i = 0; i < pos.count; i++) {
    const wx = pos.getX(i), wz = pos.getZ(i);
    const gx = ((wx + terrainSize/2) / terrainSize) * (gridSize - 1);
    const gz = ((wz + terrainSize/2) / terrainSize) * (gridSize - 1);
    const gxi = Math.max(0, Math.min(gridSize - 2, Math.floor(gx)));
    const gzi = Math.max(0, Math.min(gridSize - 2, Math.floor(gz)));
    const gxf = gx - gxi, gzf = gz - gzi;
    const e00 = elevGrid[ gzi    * gridSize + gxi    ] ?? minE;
    const e10 = elevGrid[ gzi    * gridSize + gxi + 1] ?? minE;
    const e01 = elevGrid[(gzi+1) * gridSize + gxi    ] ?? minE;
    const e11 = elevGrid[(gzi+1) * gridSize + gxi + 1] ?? minE;
    const elev = e00*(1-gxf)*(1-gzf) + e10*gxf*(1-gzf) + e01*(1-gxf)*gzf + e11*gxf*gzf;
    base[i] = (elev - minE) / range;
    h[i] = base[i] * 17.5 * renderState.terrainExaggeration - 3.5;
    pos.setY(i, h[i]);
  }
  // Store base heights for live exaggeration updates
  _baseHeights = base;
  _elevMinMax = { min: minE, max: maxE };
  return h;
}

// --- ROAD COLOR PICKERS (live) ---
function applyRoadColors() {
  const roadLayers = scene.getObjectByName('roadLayers');
  if (!roadLayers) return;
  const colorMap = {
    roadLayer_highway:   renderState.highwayColor   ?? ROAD_STYLES.highway.color,
    roadLayer_majorRoad: renderState.majorRoadColor ?? ROAD_STYLES.majorRoad.color,
    roadLayer_minorRoad: renderState.minorRoadColor ?? ROAD_STYLES.minorRoad.color,
    roadLayer_path:      renderState.pathColor      ?? ROAD_STYLES.path.color,
  };
  const tmpColor = new THREE.Color();
  Object.entries(colorMap).forEach(([groupName, col]) => {
    const g = roadLayers.getObjectByName(groupName);
    if (!g) return;
    // With merged batches, there are fewer children but each shares a material
    // Update the shared material(s) directly
    const seen = new Set();
    g.children.forEach(mesh => {
      if (!mesh.material || mesh.name.endsWith('_glow')) return;
      if (seen.has(mesh.material)) return;
      seen.add(mesh.material);
      mesh.material.color.set(col);
      tmpColor.set(col);
      mesh.material.emissive.copy(tmpColor).multiplyScalar(0.35);
      mesh.material.needsUpdate = true;
    });
  });
}

// --- SCENE SETUP ---
const root = document.getElementById('root');
const W = window.innerWidth, H = window.innerHeight;
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setSize(W, H);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
root.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0a0a0a);
scene.fog = new THREE.FogExp2(0x0a0a0a, 0.018);

const camera = new THREE.PerspectiveCamera(55, W/H, 0.1, 500);
camera.position.set(0, 28, 48);
camera.lookAt(0, 0, 0);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; controls.dampingFactor = 0.06;
controls.minDistance = 8; controls.maxDistance = 200;
controls.maxPolarAngle = Math.PI / 2.1;

const TERRAIN_SIZE = 80, TERRAIN_SEGS = 180;
const terrainGeo = new THREE.PlaneGeometry(TERRAIN_SIZE, TERRAIN_SIZE, TERRAIN_SEGS, TERRAIN_SEGS);
terrainGeo.rotateX(-Math.PI / 2);

function smoothNoise(x, y) {
  const s = Math.sin(x*0.7+y*0.4)*Math.cos(x*0.3-y*0.6);
  const m = Math.sin(x*1.4+0.8)*Math.sin(y*1.1+0.5);
  const f = Math.cos(x*2.8-y*2.1)*0.3;
  const g = Math.sin(x*0.15+y*0.2)*2.5;
  return s*2.8 + m*1.6 + f*0.8 + g;
}

const pos = terrainGeo.attributes.position;
let heights = new Float32Array(pos.count);
// Start flat — real elevation loaded from GPX/geo context
for (let i = 0; i < pos.count; i++) {
  heights[i] = 0;
  pos.setY(i, 0);
}
terrainGeo.computeVertexNormals();

const terrainMat = new THREE.MeshStandardMaterial({ color: 0x111318, roughness: 0.85, metalness: 0.05 });
const terrain = new THREE.Mesh(terrainGeo, terrainMat);
terrain.name = 'terrain'; terrain.receiveShadow = true;
scene.add(terrain);

function rebuildTerrain(newHeights) {
  heights = newHeights;
  const p = terrainGeo.attributes.position;
  for (let i = 0; i < p.count; i++) p.setY(i, heights[i]);
  p.needsUpdate = true;
  terrainGeo.computeVertexNormals();
  const old2 = scene.getObjectByName('gpsPath'); if (old2) scene.remove(old2);
  buildContours(); gpsCurve = buildGPSPath();
  // Refresh vector map colors if active
  if (renderState.vectorMap) applyVectorMapMode(true);
}

// --- CONTOUR LINES (optimized: batch major/minor into 2 draw calls, pre-alloc buffers) ---
function buildContours() {
  const old = scene.getObjectByName('contours');
  if (old) { old.traverse(c => { if (c.geometry) c.geometry.dispose(); if (c.material) c.material.dispose(); }); scene.remove(old); }
  const group = new THREE.Group(); group.name = 'contours';
  const levels = renderState.contourLevels || 22;
  const majorEvery = renderState.contourMajorEvery || 4;
  const thickness = renderState.contourThickness ?? 1;
  const majorOpacity = renderState.contourMajorOpacity ?? 0.55;
  const minorOpacity = renderState.contourMinorOpacity ?? 0.22;
  const majorColor = renderState.contourMajorColor ?? 0xffffff;
  const minorColor = renderState.contourMinorColor ?? 0x888888;

  let minH = Infinity, maxH = -Infinity;
  for (let i = 0; i < heights.length; i++) { if (heights[i] < minH) minH = heights[i]; if (heights[i] > maxH) maxH = heights[i]; }
  if (!isFinite(minH)) { minH = -3.5; maxH = 14; }
  const step = (maxH - minH) / levels;

  const res = new THREE.Vector2(window.innerWidth, window.innerHeight);
  const W = TERRAIN_SEGS + 1;

  // Pre-cache position x/z from geometry (avoid repeated getX/getZ calls)
  const posX = new Float32Array(pos.count);
  const posZ = new Float32Array(pos.count);
  for (let i = 0; i < pos.count; i++) { posX[i] = pos.getX(i); posZ[i] = pos.getZ(i); }

  // Batch all major segments and all minor segments separately
  const majorSegs = [];
  const minorSegs = [];

  // Pre-allocate reusable arrays for marching squares
  const cx = new Float64Array(4), cy = new Float64Array(4), cz = new Float64Array(4);
  const edgeA = [0,1,2,3], edgeB = [1,2,3,0];

  for (let li = 0; li < levels; li++) {
    const targetH = minH + li * step;
    const isMajor = li % majorEvery === 0;
    const dest = isMajor ? majorSegs : minorSegs;

    for (let i = 0; i < TERRAIN_SEGS; i++) {
      const rowOff = i * W, nextRowOff = (i + 1) * W;
      for (let j = 0; j < TERRAIN_SEGS; j++) {
        const i00 = rowOff + j, i10 = i00 + 1, i01 = nextRowOff + j, i11 = i01 + 1;
        const h0 = heights[i00], h1 = heights[i10], h2 = heights[i11], h3 = heights[i01];

        // Quick reject: if all corners are on the same side, skip
        const a0 = h0 >= targetH, a1 = h1 >= targetH, a2 = h2 >= targetH, a3 = h3 >= targetH;
        if (a0 === a1 && a1 === a2 && a2 === a3) continue;

        cx[0] = posX[i00]; cy[0] = h0; cz[0] = posZ[i00];
        cx[1] = posX[i10]; cy[1] = h1; cz[1] = posZ[i10];
        cx[2] = posX[i11]; cy[2] = h2; cz[2] = posZ[i11];
        cx[3] = posX[i01]; cy[3] = h3; cz[3] = posZ[i01];
        const above = [a0, a1, a2, a3];

        let crossCount = 0;
        for (let e = 0; e < 4; e++) {
          const ea = edgeA[e], eb = edgeB[e];
          if (above[ea] !== above[eb]) {
            const t = (targetH - cy[ea]) / (cy[eb] - cy[ea]);
            dest.push(
              cx[ea] + t * (cx[eb] - cx[ea]),
              targetH + 0.05,
              cz[ea] + t * (cz[eb] - cz[ea])
            );
            crossCount++;
          }
        }
        // If we got an odd number of crossings (shouldn't happen normally), pop extra
        if (crossCount % 2 !== 0 && dest.length >= 3) {
          dest.pop(); dest.pop(); dest.pop();
        }
      }
    }
  }

  // Build one merged draw call for major contours, one for minor
  if (majorSegs.length >= 6) {
    const lineGeo = new LineSegmentsGeometry();
    lineGeo.setPositions(majorSegs);
    const mat = new LineMaterial({
      color: majorColor, transparent: true, opacity: majorOpacity,
      linewidth: thickness, resolution: res, depthTest: true, depthWrite: false,
    });
    const line = new LineSegments2(lineGeo, mat); line.name = 'contour_major'; line.computeLineDistances();
    group.add(line);
  }
  if (minorSegs.length >= 6) {
    const lineGeo = new LineSegmentsGeometry();
    lineGeo.setPositions(minorSegs);
    const mat = new LineMaterial({
      color: minorColor, transparent: true, opacity: minorOpacity,
      linewidth: thickness, resolution: res, depthTest: true, depthWrite: false,
    });
    const line = new LineSegments2(lineGeo, mat); line.name = 'contour_minor'; line.computeLineDistances();
    group.add(line);
  }

  group.visible = layerState.contours;
  scene.add(group);
}

// Live-update contour visual properties without full geometry rebuild
function applyContourStyle() {
  const group = scene.getObjectByName('contours');
  if (!group) return;
  const majorOpacity = renderState.contourMajorOpacity ?? 0.55;
  const minorOpacity = renderState.contourMinorOpacity ?? 0.22;
  const majorColor = renderState.contourMajorColor ?? 0xffffff;
  const minorColor = renderState.contourMinorColor ?? 0x888888;
  const thickness = renderState.contourThickness ?? 1;
  const res = new THREE.Vector2(window.innerWidth, window.innerHeight);
  group.children.forEach(child => {
    if (!child.material) return;
    const isMajor = child.name === 'contour_major';
    child.material.color.set(isMajor ? majorColor : minorColor);
    child.material.opacity = isMajor ? majorOpacity : minorOpacity;
    child.material.linewidth = thickness;
    child.material.resolution = res;
    child.material.needsUpdate = true;
  });
}

buildContours();

// --- AUTO-LOAD DEFAULT GPX DATA ---
async function autoLoadDefaultGPX() {
  debugLog('autoLoadDefaultGPX() called');
  // Support both raw GPX XML (GPX_DEFAULT_XML) and legacy object (GPX_DEFAULT_DATA)
  let points, data;

  debugLog(`GPX_DEFAULT_XML: type=${typeof window.GPX_DEFAULT_XML}, len=${(window.GPX_DEFAULT_XML||'').length}`);
  debugLog(`GPX_DEFAULT_DATA: type=${typeof window.GPX_DEFAULT_DATA}`);

  if (typeof window.GPX_DEFAULT_XML === 'string' && window.GPX_DEFAULT_XML.length > 50) {
    // Parse raw GPX XML
    debugLog('Parsing GPX XML…');
    points = parseGPX(window.GPX_DEFAULT_XML);
    debugLog(`parseGPX returned ${points ? points.length : 0} points`);
    if (!points || points.length < 2) {
      debugLog('Not enough points (<2), aborting', 'error');
      return;
    }

    // Compute elapsed seconds from start for each point (for tooltip)
    const t0 = points[0].time ? points[0].time.getTime() : 0;
    let cumDist = 0;
    const enrichedTrack = points.map((p, i) => {
      const timeSec = (p.time && t0) ? (p.time.getTime() - t0) / 1000 : i;
      if (i > 0) {
        const a = points[i-1], b = p;
        const dLat = (b.lat - a.lat)*Math.PI/180, dLon = (b.lon - a.lon)*Math.PI/180;
        const h = Math.sin(dLat/2)**2 + Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dLon/2)**2;
        cumDist += 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1-h));
      }
      return { lat: p.lat, lon: p.lon, ele: p.ele || 0, time: timeSec, speed: p.speed || null, hr: 0, cadence: 0, cumDistKm: cumDist };
    });

    // Derive HR and cadence from speed heuristically (this GPX has speed but no HR/cadence)
    // Estimate HR from speed: ~120bpm at rest, up to ~175 at 4m/s
    enrichedTrack.forEach(p => {
      const spd = p.speed || 0;
      p.hr = Math.round(120 + Math.min(spd, 4.5) * 12.5);
      p.cadence = Math.round(150 + Math.min(spd, 4) * 7.5);
    });

    const totalDist = enrichedTrack[enrichedTrack.length-1].cumDistKm;
    const totalTime = enrichedTrack[enrichedTrack.length-1].time;
    const eles = enrichedTrack.map(p => p.ele);
    let elevGain = 0, elevLoss = 0;
    for (let i = 1; i < enrichedTrack.length; i++) {
      const d = enrichedTrack[i].ele - enrichedTrack[i-1].ele;
      if (d > 0) elevGain += d; else elevLoss += Math.abs(d);
    }

    // Build splits
    const splits = [];
    let nextKm = 1;
    for (let i = 0; i < enrichedTrack.length; i++) {
      if (enrichedTrack[i].cumDistKm >= nextKm) {
        const t = enrichedTrack[i].time;
        const avgPaceSec = nextKm > 1 ? (t - (splits.length > 0 ? splits[splits.length-1].time : 0)) : t;
        const mm = Math.floor(avgPaceSec / 60), ss = Math.round(avgPaceSec % 60);
        splits.push({ km: nextKm, time: Math.round(t), avgHR: enrichedTrack[i].hr, avgPace: `${mm}:${String(ss).padStart(2,'0')}` });
        nextKm++;
      }
    }

    // Build the GPX_DEFAULT_DATA-compatible object
    data = {
      meta: { name: 'Route 2026-03-13', date: points[0].time ? points[0].time.toISOString() : '', sport: 'running', device: 'Apple Watch' },
      track: enrichedTrack,
      splits,
      waypoints: [],
      stats: {
        totalDistKm: parseFloat(totalDist.toFixed(2)),
        totalTimeMin: Math.round(totalTime / 60),
        elevGainM: Math.round(elevGain),
        elevLossM: Math.round(elevLoss),
        maxEleM: Math.round(Math.max(...eles)),
        minEleM: Math.round(Math.min(...eles)),
        avgHR: Math.round(enrichedTrack.reduce((s,p) => s + p.hr, 0) / enrichedTrack.length),
        maxHR: Math.max(...enrichedTrack.map(p => p.hr)),
        avgPaceMinKm: (() => { const s = totalTime / totalDist; const mm = Math.floor(s/60); const ss = Math.round(s%60); return `${mm}:${String(ss).padStart(2,'0')}`; })(),
        avgCadenceSpm: Math.round(enrichedTrack.reduce((s,p) => s + p.cadence, 0) / enrichedTrack.length),
        calories: Math.round(totalTime / 60 * 8.5),
        vo2maxEst: 48.0,
      },
      hrZones: [
        { zone:1, label:"Easy",      color:"#44aaff", pct:0.15 },
        { zone:2, label:"Aerobic",   color:"#44dd88", pct:0.30 },
        { zone:3, label:"Tempo",     color:"#ffdd44", pct:0.30 },
        { zone:4, label:"Threshold", color:"#ff8833", pct:0.20 },
        { zone:5, label:"Max",       color:"#ff3355", pct:0.05 },
      ],
      paceBands: [
        { label:"<6:00 /km", color:0x00ffcc, minPace:0,   maxPace:360  },
        { label:"6–7 /km",   color:0x44ddff, minPace:360, maxPace:420  },
        { label:"7–8 /km",   color:0xffcc00, minPace:420, maxPace:480  },
        { label:"8–9 /km",   color:0xff7733, minPace:480, maxPace:540  },
        { label:">9:00 /km", color:0xff3344, minPace:540, maxPace:9999 },
      ],
    };
    // Expose globally so the tooltip and other UI can use it
    window.GPX_DEFAULT_DATA = data;

  } else if (typeof window.GPX_DEFAULT_DATA !== 'undefined') {
    debugLog('Using legacy GPX_DEFAULT_DATA object');
    data = window.GPX_DEFAULT_DATA;
    const track = data.track;
    if (!track || track.length < 2) { debugLog('Legacy data has <2 track points, aborting', 'error'); return; }
    points = track.map(p => ({ lat: p.lat, lon: p.lon, ele: p.ele, time: null, hr: p.hr, cadence: p.cadence }));
  } else {
    debugLog('No GPX data found (neither XML nor DATA), aborting', 'warn');
    return;
  }

  gpxStats = calcGPXStats(points);
  updateGPXStatsUI(gpxStats);
  updateRichGPXStats(data);

  const lats = points.map(p => p.lat), lons = points.map(p => p.lon);
  const cLat = lats.reduce((a, b) => a + b, 0) / lats.length;
  const cLon = lons.reduce((a, b) => a + b, 0) / lons.length;
  const dLat = Math.max(...lats) - Math.min(...lats);
  const dLon = Math.max(...lons) - Math.min(...lons);
  const radiusKm = Math.max(dLat * 111 * 0.75, dLon * 111 * Math.cos(cLat * Math.PI/180) * 0.75, 3);
  const r = Math.min(Math.round(radiusKm * 1.5), 30);

  document.getElementById('geo-lat').value = cLat.toFixed(6);
  document.getElementById('geo-lng').value = cLon.toFixed(6);
  document.getElementById('geo-radius').value = r;
  document.getElementById('geo-radius-val').textContent = r;

  geoContext = { centerLat: cLat, centerLng: cLon, radiusKm: r };

  const camDist = Math.max(r * 1.2, 18);
  camera.position.set(0, camDist * 0.6, camDist);
  camera.lookAt(0, 0, 0);
  controls.target.set(0, 0, 0);
  controls.update();

  // Don't build the GPX track yet — terrain is still flat.
  // The track will be built after terrain elevation data arrives (below).
  layerState.gpxTrack = true;
  const lt = document.querySelector('[data-layer="gpxTrack"]');
  if (lt) lt.checked = true;
  document.getElementById('gpx-stats-panel').classList.add('visible');
  updateHUD(cLat, cLon, data.stats ? data.stats.maxEleM : gpxStats.maxEle || 0);
  debugLog(`GPX center: ${cLat.toFixed(4)}, ${cLon.toFixed(4)}, radius: ${r}km`);
  debugLog(`Parsed ${points.length} points, fetching terrain…`);
  setStatus('Loading terrain for default GPX…', 'loading');

  try {
    debugLog(`Fetching elevation grid at ${cLat.toFixed(4)}, ${cLon.toFixed(4)}, r=${r}…`);
    const { grid, gridSize } = await fetchElevationGrid(cLat, cLon, r, 32);
    debugLog(`Elevation grid received: ${gridSize}x${gridSize}`);
    setStatus('Building terrain…', 'loading');
    const newHeights = buildHeightsFromElevation(terrainGeo.attributes.position, TERRAIN_SIZE, TERRAIN_SEGS, grid, gridSize);
    rebuildTerrain(newHeights);
    debugLog('Terrain rebuilt successfully');

    if (layerState.satellite) {
      setStatus('Loading map tiles…', 'loading');
      try {
        debugLog('Fetching satellite tiles…');
        const tex = await fetchSatelliteTiles(cLat, cLon, r, currentTileProvider);
        applySatelliteTexture(tex);
        debugLog('Satellite tiles applied');
      } catch(e) {
        debugLog(`Satellite tile error (non-fatal): ${e.message}`, 'warn');
      }
    }

    setStatus('Loading roads…', 'loading');
    try {
      debugLog('Fetching road data…');
      const osmData = await fetchRoadData(cLat, cLon, r);
      _cachedOsmData = osmData;
      buildRoadLayers(osmData, geoContext);
      debugLog('Roads built');
    } catch(e) {
      debugLog(`Road data error (non-fatal): ${e.message}`, 'warn');
    }

    buildGPXTrackFromData(points, geoContext, data);
    debugLog(`Default route loaded — ${data.meta.name}`, 'success');
    setStatus(`Default route loaded — ${data.meta.name}`, 'success');
  } catch(err) {
    debugLog(`Auto-load terrain error: ${err.message}`, 'error');
    console.error('Auto-load terrain error:', err);
    setStatus(`Auto-load error: ${err.message}`, 'error');
  }
}

function updateRichGPXStats(data) {
  if (!data || !data.stats) return;
  const s = data.stats;
  document.getElementById('gpx-dist').textContent = s.totalDistKm + ' km';
  document.getElementById('gpx-gain').textContent = '+' + s.elevGainM + ' m';
  document.getElementById('gpx-loss').textContent = '-' + s.elevLossM + ' m';
  document.getElementById('gpx-maxele').textContent = s.maxEleM + ' m';
  document.getElementById('gpx-minele').textContent = s.minEleM + ' m';
  document.getElementById('gpx-pts').textContent = data.track.length;
  const h = Math.floor(s.totalTimeMin / 60), m = s.totalTimeMin % 60;
  document.getElementById('gpx-time').textContent = h > 0 ? `${h}h ${m}m` : `${m}m`;
  // Rich stats
  const el = id => document.getElementById(id);
  if (el('gpx-avg-hr'))     el('gpx-avg-hr').textContent = s.avgHR + ' bpm';
  if (el('gpx-max-hr'))     el('gpx-max-hr').textContent = s.maxHR + ' bpm';
  if (el('gpx-avg-pace'))   el('gpx-avg-pace').textContent = s.avgPaceMinKm + ' /km';
  if (el('gpx-cadence'))    el('gpx-cadence').textContent = s.avgCadenceSpm + ' spm';
  if (el('gpx-calories'))   el('gpx-calories').textContent = s.calories + ' kcal';
  if (el('gpx-vo2max'))     el('gpx-vo2max').textContent = s.vo2maxEst;
  if (el('gpx-track-name')) el('gpx-track-name').textContent = window.GPX_DEFAULT_DATA?.meta?.name || '—';
  // Render HR zone mini-chart
  renderHRZoneBar();
  // Render elevation mini sparkline
  renderElevationSparkline();
}

function renderHRZoneBar() {
  const canvas = document.getElementById('gpx-hrzone-canvas');
  if (!canvas || !window.GPX_DEFAULT_DATA) return;
  const zones = window.GPX_DEFAULT_DATA.hrZones;
  const ctx = canvas.getContext('2d');
  canvas.width = canvas.offsetWidth || 260;
  canvas.height = 20;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  let x = 0;
  zones.forEach(z => {
    const w = z.pct * canvas.width;
    ctx.fillStyle = z.color;
    ctx.fillRect(x, 0, w, canvas.height);
    x += w;
  });
}

function renderElevationSparkline() {
  const canvas = document.getElementById('gpx-elev-canvas');
  if (!canvas || !window.GPX_DEFAULT_DATA) return;
  const track = window.GPX_DEFAULT_DATA.track;
  const eles = track.map(p => p.ele);
  const minE = Math.min(...eles), maxE = Math.max(...eles), range = maxE - minE || 1;
  const W = canvas.offsetWidth || 260, H = 52;
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, W, H);

  // Gradient fill
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, 'rgba(0,204,255,0.55)');
  grad.addColorStop(1, 'rgba(0,204,255,0.04)');
  ctx.beginPath();
  ctx.moveTo(0, H);
  track.forEach((p, i) => {
    const x = (i / (track.length-1)) * W;
    const y = H - ((p.ele - minE) / range) * (H - 6) - 2;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.lineTo(W, H); ctx.closePath();
  ctx.fillStyle = grad; ctx.fill();

  // HR overlay line
  const hrs = track.map(p => p.hr);
  const minHR = Math.min(...hrs), maxHR = Math.max(...hrs), hrRange = maxHR - minHR || 1;
  ctx.beginPath();
  track.forEach((p, i) => {
    const x = (i / (track.length-1)) * W;
    const y = H - ((p.hr - minHR) / hrRange) * (H - 6) - 2;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.strokeStyle = 'rgba(255,80,100,0.75)'; ctx.lineWidth = 1.5; ctx.stroke();
}

// Build GPX track with color-coded visualization
function buildGPXTrackFromData(points, ctx, data) {
  const colorMode = renderState.gpxColorMode || 'solid';
  const old = scene.getObjectByName('gpxTrack');
  if (old) { old.traverse(c => { if (c.geometry) c.geometry.dispose(); if (c.material) c.material.dispose(); }); scene.remove(old); gpxTrackGroup = null; gpxCurve = null; _cachedGlowRef = null; _cachedHaloRef = null; }

  const group = new THREE.Group();
  group.name = 'gpxTrack';

  const worldPts = points.map(p => {
    const wp = latLngToWorld(p.lat, p.lon, ctx);
    const wy = sampleTerrainHeight(wp.x, wp.z) + 0.38;
    return new THREE.Vector3(wp.x, wy, wp.z);
  });
  if (worldPts.length < 2) return;

  const curve = new THREE.CatmullRomCurve3(worldPts);
  gpxCurve = curve;

  const tubeRadius = renderState.gpxTubeRadius ?? 0.09;
  const tubeOpacity = renderState.gpxOpacity ?? 0.92;

  // Cap tube curve segments based on point count — enough detail without excess
  const maxTubeSegs = Math.min(worldPts.length * 1.5, 500);
  const tubeRadialSegs = 5; // 5 sides is enough for small radius tubes

  if (colorMode === 'pace' && data && data.track) {
    buildGPXSegmentsByPace(group, points, worldPts, data, tubeRadius, tubeOpacity);
  } else if (colorMode === 'hr' && data && data.track) {
    buildGPXSegmentsByHR(group, points, worldPts, data, tubeRadius, tubeOpacity);
  } else if (colorMode === 'elevation') {
    buildGPXSegmentsByElevation(group, worldPts, tubeRadius, tubeOpacity);
  } else {
    // Solid single tube
    const tubeGeo = new THREE.TubeGeometry(curve, maxTubeSegs, tubeRadius, tubeRadialSegs, false);
    const gpxColor = renderState.gpxColor ?? 0xff6600;
    const tubeMat = new THREE.MeshLambertMaterial({
      color: gpxColor, emissive: gpxColor, emissiveIntensity: 2.5,
      transparent: true, opacity: tubeOpacity,
      depthWrite: false,
    });
    const tube = new THREE.Mesh(tubeGeo, tubeMat);
    tube.name = 'gpxTube'; group.add(tube);

    // Glow — lower detail
    const glowGeo = new THREE.TubeGeometry(curve, Math.min(worldPts.length, 250), tubeRadius * 2.2, 4, false);
    const glowMat = new THREE.MeshLambertMaterial({
      color: gpxColor, emissive: gpxColor, emissiveIntensity: 3.5,
      transparent: true, opacity: 0.12, depthWrite: false,
    });
    group.add(Object.assign(new THREE.Mesh(glowGeo, glowMat), { name: 'gpxGlow' }));
  }

  // Start/end markers
  const startMat = new THREE.MeshLambertMaterial({ color: 0x00ff88, emissive: 0x00cc44, emissiveIntensity: 3.5 });
  const endMat   = new THREE.MeshLambertMaterial({ color: 0xff3344, emissive: 0xff1122, emissiveIntensity: 3.5 });
  const mGeo = new THREE.SphereGeometry(0.32, 8, 8);
  const startM = new THREE.Mesh(mGeo, startMat); startM.position.copy(worldPts[0]); startM.position.y += 0.28; startM.name = 'gpxStart'; group.add(startM);
  const endM   = new THREE.Mesh(mGeo.clone(), endMat); endM.position.copy(worldPts[worldPts.length-1]); endM.position.y += 0.28; endM.name = 'gpxEnd'; group.add(endM);

  // Waypoint dots from data
  if (data && data.waypoints) {
    const dotGeo = new THREE.SphereGeometry(0.18, 6, 6);
    const dotMat = new THREE.MeshLambertMaterial({ color: 0xffdd44, emissive: 0xffaa00, emissiveIntensity: 3.0 });
    data.waypoints.forEach((wp, i) => {
      const pt = curve.getPoint(Math.min(wp.t, 0.999));
      const dot = new THREE.Mesh(dotGeo, dotMat.clone());
      dot.position.copy(pt); dot.position.y += 0.18;
      dot.name = `gpxWpt_${i}`; group.add(dot);
    });
  }

  group.visible = layerState.gpxTrack;
  scene.add(group);
  gpxTrackGroup = group;

  if (!gpxMarker) {
    // Playhead: glowing orange sphere with a halo ring
    const markerGroup = new THREE.Group(); markerGroup.name = 'gpxMarker';
    const coreMat = new THREE.MeshLambertMaterial({ color: 0xff6600, emissive: 0xff4400, emissiveIntensity: 6.0 });
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), coreMat); core.name = 'gpxMarkerCore';
    const haloMat = new THREE.MeshLambertMaterial({ color: 0xff6600, emissive: 0xff6600, emissiveIntensity: 4.0, transparent: true, opacity: 0.22, depthWrite: false });
    const halo = new THREE.Mesh(new THREE.SphereGeometry(0.52, 8, 8), haloMat); halo.name = 'gpxMarkerHalo';
    markerGroup.add(core); markerGroup.add(halo);
    gpxMarker = markerGroup; scene.add(gpxMarker);
  }
  return group;
}

function getPaceColor(paceSecPerKm) {
  if (typeof window.GPX_DEFAULT_DATA === 'undefined') return 0x44ddff;
  const bands = window.GPX_DEFAULT_DATA.paceBands || [];
  for (const b of bands) { if (paceSecPerKm >= b.minPace && paceSecPerKm < b.maxPace) return b.color; }
  return 0x44ddff;
}

function getHRZoneColor(hr) {
  if (hr < 120) return 0x44aaff;
  if (hr < 140) return 0x44dd88;
  if (hr < 155) return 0xffdd44;
  if (hr < 168) return 0xff8833;
  return 0xff3355;
}

// Shared segment builder: groups segments by color, merges geos per color bucket
function _buildGPXColoredSegments(group, worldPts, segSize, radius, opacity, colorFn) {
  const colorBuckets = new Map(); // color hex → [geo, ...]
  for (let i = 0; i < worldPts.length - segSize; i += segSize) {
    const seg = worldPts.slice(i, i + segSize + 1);
    if (seg.length < 2) continue;
    const col = colorFn(i, seg);
    const curve = new THREE.CatmullRomCurve3(seg);
    const geo = new THREE.TubeGeometry(curve, Math.min(seg.length * 2, 16), radius, 4, false);
    if (!colorBuckets.has(col)) colorBuckets.set(col, []);
    colorBuckets.get(col).push(geo);
  }
  // Merge each color bucket into one mesh
  let bIdx = 0;
  colorBuckets.forEach((geos, col) => {
    const merged = geos.length > 1 ? BufferGeometryUtils.mergeGeometries(geos, false) : geos[0];
    if (!merged) return;
    const mat = new THREE.MeshLambertMaterial({
      color: col, emissive: col, emissiveIntensity: 2.2,
      transparent: true, opacity, depthWrite: false,
    });
    const mesh = new THREE.Mesh(merged, mat);
    mesh.name = `gpxSegBatch_${bIdx++}`;
    group.add(mesh);
    geos.forEach(g => { if (g !== merged) g.dispose(); });
  });
}

function buildGPXSegmentsByPace(group, points, worldPts, data, radius, opacity) {
  _buildGPXColoredSegments(group, worldPts, 6, radius, opacity, (i) => {
    const segEnd = Math.min(i + 6, points.length - 1);
    const dt = (points[segEnd].time || 0) - (points[i].time || 0);
    let dist = 0;
    for (let j = i; j < segEnd; j++) {
      const a = points[j], b = points[j+1];
      const dLat = (b.lat - a.lat)*Math.PI/180, dLon = (b.lon - a.lon)*Math.PI/180;
      const h = Math.sin(dLat/2)**2 + Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dLon/2)**2;
      dist += 6371000 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1-h));
    }
    return getPaceColor(dist > 0 ? (dt / (dist / 1000)) : 480);
  });
}

function buildGPXSegmentsByHR(group, points, worldPts, data, radius, opacity) {
  _buildGPXColoredSegments(group, worldPts, 6, radius, opacity, (i) => {
    const segEnd = Math.min(i + 6, points.length - 1);
    let sum = 0, cnt = 0;
    for (let j = i; j <= segEnd; j++) { sum += points[j].hr || 150; cnt++; }
    return getHRZoneColor(sum / cnt);
  });
}

function buildGPXSegmentsByElevation(group, worldPts, radius, opacity) {
  let minE = Infinity, maxE = -Infinity;
  for (let i = 0; i < worldPts.length; i++) { const y = worldPts[i].y; if (y < minE) minE = y; if (y > maxE) maxE = y; }
  const range = maxE - minE || 1;
  _buildGPXColoredSegments(group, worldPts, 6, radius, opacity, (i, seg) => {
    let sum = 0; for (let j = 0; j < seg.length; j++) sum += seg[j].y;
    const t = (sum / seg.length - minE) / range;
    let r, g, b2;
    if (t < 0.33) { r = 0; g = t * 3; b2 = 1 - t * 3; }
    else if (t < 0.66) { r = (t - 0.33) * 3; g = 1; b2 = 0; }
    else { r = 1; g = 1 - (t - 0.66) * 3; b2 = 0; }
    return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b2 * 255);
  });
}

// Keep original buildGPXTrack for file-dropped GPX
function buildGPXTrack(points, ctx) {
  return buildGPXTrackFromData(points, ctx, null);
}

// --- GPS PATH (disabled) ---
function buildGPSPath() {
  const group = new THREE.Group(); group.name = 'gpsPath';
  const pathPoints2D = [];
  let px=-28, pz=-22;
  for (let i = 0; i < 90; i++) {
    const t = i/90;
    px += Math.sin(t*5.1+0.3)*0.9+0.65; pz += Math.cos(t*4.7-0.7)*0.7+0.5;
    pathPoints2D.push([px,pz]);
  }
  function sampleH(wx,wz){const nx=wx*0.12,nz=wz*0.12;return(smoothNoise(nx,nz)+smoothNoise(nx*2.1,nz*2.1)*0.5+smoothNoise(nx*4.3,nz*4.3)*0.25)*3.5;}
  const pathVecs = pathPoints2D.map(([x,z]) => new THREE.Vector3(x,sampleH(x,z)+0.18,z));
  const curve = new THREE.CatmullRomCurve3(pathVecs);
  group.visible = false;
  scene.add(group);
  return curve;
}
let gpsCurve = buildGPSPath();

// --- GPS MARKER (hidden) ---
const markerGeo = new THREE.ConeGeometry(0.35,0.9,6); markerGeo.rotateX(Math.PI);
const marker = new THREE.Mesh(markerGeo, new THREE.MeshStandardMaterial({color:0xff6600,emissive:0xff3300,emissiveIntensity:4.0}));
marker.name='gpsMarker'; marker.visible = false; scene.add(marker);

let gpxMarker = null;

// --- LIGHTING ---
const ambient = new THREE.AmbientLight(0x1a2030, renderState.ambientIntensity); ambient.name='ambientLight'; scene.add(ambient);
const dirLight = new THREE.DirectionalLight(0xffffff, renderState.sunIntensity); dirLight.position.set(30,50,20); dirLight.name='dirLight'; scene.add(dirLight);
const orangePoint = new THREE.PointLight(0xff5500, 6, 40); orangePoint.position.set(0,6,0); orangePoint.name='orangePointLight'; scene.add(orangePoint);

// --- POST-PROCESSING ---
const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
// Bloom at half-res for performance
const bloomRes = new THREE.Vector2(Math.round(W * 0.5), Math.round(H * 0.5));
const bloom = new UnrealBloomPass(bloomRes, 0.85, 0.35, 0.1);
composer.addPass(bloom);
const grainPass = new ShaderPass({
  uniforms: { tDiffuse:{value:null}, time:{value:0}, amount:{value:0.032} },
  vertexShader: `varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
  fragmentShader: `uniform sampler2D tDiffuse;uniform float time;uniform float amount;varying vec2 vUv;float rand(vec2 co){return fract(sin(dot(co,vec2(12.9898,78.233)+time))*43758.5453);}void main(){vec4 c=texture2D(tDiffuse,vUv);float g=rand(vUv)*amount-amount*0.5;gl_FragColor=vec4(c.rgb+g,c.a);}`,
});
composer.addPass(grainPass);
const bokehPass = new BokehPass(scene, camera, {
  focus: renderState.dofFocus,
  aperture: renderState.dofAperture,
  maxblur: renderState.dofMaxBlur,
});
bokehPass.enabled = renderState.dofEnabled;
composer.addPass(bokehPass);
composer.addPass(new OutputPass());

// --- HUD UPDATE ---
function updateHUD(lat, lng, alt) {
  const el = document.getElementById('hud-alt');
  if (el) el.textContent = `ALT ${Math.round(alt)}M`;
  const coords = document.getElementById('hud-coords');
  if (coords) coords.textContent = `${lat.toFixed(4)}° N / ${lng.toFixed(4)}° E`;
}

// --- LIVE TERRAIN EXAGGERATION ---
let _lastExaggeration = renderState.terrainExaggeration;
let _baseHeights = null; // normalized 0-1 heights before exaggeration
let _elevMinMax = null;  // { min, max } of the raw elevation grid

function applyTerrainExaggeration() {
  if (!geoContext || !_baseHeights) {
    // No real terrain loaded yet — nothing to re-exaggerate
    return;
  }
  const ex = renderState.terrainExaggeration;
  const p = terrainGeo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    heights[i] = _baseHeights[i] * 17.5 * ex - 3.5;
    p.setY(i, heights[i]);
  }
  p.needsUpdate = true;
  terrainGeo.computeVertexNormals();
  // Rebuild contours for new heights
  buildContours();
  // Update vector map colors if active
  if (renderState.vectorMap) applyVectorMapMode(true);
  // Rebuild GPX track so it follows the new terrain heights
  if (geoContext && window.GPX_DEFAULT_DATA) {
    const pts = window.GPX_DEFAULT_DATA.track.map(tp => ({ lat: tp.lat, lon: tp.lon, ele: tp.ele, hr: tp.hr }));
    buildGPXTrackFromData(pts, geoContext, window.GPX_DEFAULT_DATA);
  }
  // Rebuild road layers so they follow the new terrain heights
  if (_cachedOsmData && geoContext) {
    buildRoadLayers(_cachedOsmData, geoContext);
  }
  _lastExaggeration = ex;
}

// --- RENDER COLOR PICKERS ---
function setupColorPickers() {
  document.querySelectorAll('.render-color').forEach(el => {
    const key = el.dataset.render;
    // Convert hex number to css hex
    const defaultVal = renderState[key];
    if (defaultVal !== undefined) {
      el.value = '#' + defaultVal.toString(16).padStart(6,'0');
    }
    el.addEventListener('input', () => {
      renderState[key] = parseInt(el.value.replace('#',''), 16);
      applyRoadColors();
    });
  });

  // Contour color pickers
  document.querySelectorAll('.contour-color').forEach(el => {
    const key = el.dataset.contour;
    if (renderState[key] !== undefined) {
      el.value = '#' + renderState[key].toString(16).padStart(6, '0');
    }
    el.addEventListener('input', () => {
      renderState[key] = parseInt(el.value.replace('#', ''), 16);
      applyContourStyle();
    });
  });
}

// --- GEO UI WIRING ---
function setStatus(msg, type='') {
  const el = document.getElementById('geo-status');
  if (!el) return;
  el.textContent = msg; el.className = type;
}

async function loadTerrain() {
  const lat = parseFloat(document.getElementById('geo-lat').value);
  const lng = parseFloat(document.getElementById('geo-lng').value);
  const radius = parseFloat(document.getElementById('geo-radius').value);
  const btn = document.getElementById('geo-load-btn');
  if (isNaN(lat)||isNaN(lng)) { setStatus('Enter valid coordinates.','error'); return; }
  btn.disabled = true;
  setStatus('Fetching elevation data…','loading');
  try {
    const { grid, gridSize } = await fetchElevationGrid(lat, lng, radius, 32);
    setStatus('Building terrain…','loading');
    const newHeights = buildHeightsFromElevation(terrainGeo.attributes.position, TERRAIN_SIZE, TERRAIN_SEGS, grid, gridSize);
    rebuildTerrain(newHeights);
    geoContext = { centerLat:lat, centerLng:lng, radiusKm:radius };
    if (layerState.satellite) {
      setStatus('Loading satellite imagery…','loading');
      try { const tex = await fetchSatelliteTiles(lat,lng,radius); applySatelliteTexture(tex); } catch(e) { console.warn(e); }
    }
    setStatus('Loading road data…','loading');
    try {
      const osmData = await fetchRoadData(lat,lng,radius);
      _cachedOsmData = osmData;
      buildRoadLayers(osmData, geoContext);
      setStatus(`Loaded — ${lat.toFixed(4)}, ${lng.toFixed(4)}`, 'success');
    } catch(e) { setStatus(`Terrain loaded. Roads unavailable.`, 'success'); }
    updateHUD(lat, lng, 0);
  } catch(err) { setStatus(`Error: ${err.message}`, 'error'); }
  finally { btn.disabled = false; }
}

document.getElementById('geo-load-btn').addEventListener('click', loadTerrain);
document.getElementById('geo-search-btn').addEventListener('click', async () => {
  const query = document.getElementById('geo-search').value.trim();
  if (!query) { setStatus('Type a place name.','error'); return; }
  const btn = document.getElementById('geo-search-btn'); btn.disabled=true;
  setStatus('Searching…','loading');
  try {
    const { lat, lng, display } = await geocodePlace(query);
    document.getElementById('geo-lat').value = lat.toFixed(6);
    document.getElementById('geo-lng').value = lng.toFixed(6);
    setStatus(`Found: ${display.split(',').slice(0,2).join(',')}`, 'success');
  } catch(err) { setStatus(`Not found: ${err.message}`, 'error'); }
  finally { btn.disabled=false; }
});
document.getElementById('geo-search').addEventListener('keydown', e => { if (e.key==='Enter') document.getElementById('geo-search-btn').click(); });
document.getElementById('geo-radius').addEventListener('input', e => { document.getElementById('geo-radius-val').textContent = e.target.value; });
document.querySelectorAll('.preset').forEach(btn => {
  btn.addEventListener('click', () => {
    document.getElementById('geo-lat').value = btn.dataset.lat;
    document.getElementById('geo-lng').value = btn.dataset.lng;
    document.getElementById('geo-search').value = btn.dataset.name;
    document.getElementById('geo-radius').value = btn.dataset.radius || 12;
    document.getElementById('geo-radius-val').textContent = btn.dataset.radius || 12;
    setStatus(`Preset: ${btn.dataset.name} — click Load Terrain`, '');
  });
});

// Layer toggles
document.querySelectorAll('.layer-toggle').forEach(el => {
  const key = el.dataset.layer;
  el.checked = layerState[key];
  el.addEventListener('change', () => { layerState[key] = el.checked; applyLayerVisibility(); });
});

// Expose renderState needed for GPX controls
renderState.gpxColorMode = 'solid';
renderState.gpxTubeRadius = 0.09;
renderState.gpxOpacity = 0.92;
renderState.gpxColor = 0xff6600;
renderState.gpxAnimSpeed = 1.0;

// GPX color mode
const gpxColorModeEl = document.getElementById('gpx-color-mode');
if (gpxColorModeEl) {
  gpxColorModeEl.value = renderState.gpxColorMode;
  gpxColorModeEl.addEventListener('change', () => {
    renderState.gpxColorMode = gpxColorModeEl.value;
    if (geoContext && window.GPX_DEFAULT_DATA) {
      const pts = window.GPX_DEFAULT_DATA.track.map(p => ({ lat: p.lat, lon: p.lon, ele: p.ele, hr: p.hr }));
      buildGPXTrackFromData(pts, geoContext, window.GPX_DEFAULT_DATA);
    }
  });
}

// GPX tube radius slider
const gpxRadiusEl = document.getElementById('gpx-tube-radius');
if (gpxRadiusEl) {
  gpxRadiusEl.value = renderState.gpxTubeRadius;
  gpxRadiusEl.addEventListener('input', () => {
    renderState.gpxTubeRadius = parseFloat(gpxRadiusEl.value);
    document.getElementById('gpx-tube-radius-val').textContent = gpxRadiusEl.value;
    if (geoContext && window.GPX_DEFAULT_DATA) {
      const pts = window.GPX_DEFAULT_DATA.track.map(p => ({ lat: p.lat, lon: p.lon, ele: p.ele, hr: p.hr }));
      buildGPXTrackFromData(pts, geoContext, window.GPX_DEFAULT_DATA);
    }
  });
}

// GPX opacity slider
const gpxOpacityEl = document.getElementById('gpx-opacity');
if (gpxOpacityEl) {
  gpxOpacityEl.value = renderState.gpxOpacity;
  gpxOpacityEl.addEventListener('input', () => {
    renderState.gpxOpacity = parseFloat(gpxOpacityEl.value);
    document.getElementById('gpx-opacity-val').textContent = gpxOpacityEl.value;
    // Live update opacity on existing track
    if (gpxTrackGroup) {
      gpxTrackGroup.traverse(c => { if (c.material && c.material.transparent) c.material.opacity = renderState.gpxOpacity; });
    }
  });
}

// GPX anim speed
const gpxSpeedEl = document.getElementById('gpx-anim-speed');
if (gpxSpeedEl) {
  gpxSpeedEl.value = renderState.gpxAnimSpeed;
  gpxSpeedEl.addEventListener('input', () => {
    renderState.gpxAnimSpeed = parseFloat(gpxSpeedEl.value);
    document.getElementById('gpx-anim-speed-val').textContent = gpxSpeedEl.value;
  });
}

// GPX solid color picker
const gpxColorPickerEl = document.getElementById('gpx-color-picker');
if (gpxColorPickerEl) {
  gpxColorPickerEl.addEventListener('input', () => {
    renderState.gpxColor = parseInt(gpxColorPickerEl.value.replace('#',''), 16);
    if (renderState.gpxColorMode === 'solid' && geoContext && window.GPX_DEFAULT_DATA) {
      const pts = window.GPX_DEFAULT_DATA.track.map(p => ({ lat: p.lat, lon: p.lon, ele: p.ele, hr: p.hr }));
      buildGPXTrackFromData(pts, geoContext, window.GPX_DEFAULT_DATA);
    }
  });
}

// Tile provider selector
const tileProviderEl = document.getElementById('tile-provider-select');
if (tileProviderEl) {
  tileProviderEl.value = currentTileProvider;
  tileProviderEl.addEventListener('change', () => {
    currentTileProvider = tileProviderEl.value;
    if (layerState.satellite && geoContext) {
      setStatus('Switching map tiles…', 'loading');
      loadSatelliteForCurrentContext(currentTileProvider).then(() => setStatus('Map tiles updated', 'success'));
    }
  });
}

// Render setting toggles
document.querySelectorAll('.render-toggle').forEach(el => {
  const key = el.dataset.render;
  el.checked = renderState[key];
  el.addEventListener('change', () => {
    renderState[key] = el.checked;
    // FPS counter is purely a DOM toggle — skip the full render pipeline
    if (key === 'fpsCounter') return;
    applyRenderSettings();
  });
});

// Contour keys that require a full geometry rebuild vs style-only update
const CONTOUR_REBUILD_KEYS = new Set(['contourLevels', 'contourMajorEvery']);
const CONTOUR_STYLE_KEYS = new Set(['contourThickness', 'contourMajorOpacity', 'contourMinorOpacity']);

// Render sliders
document.querySelectorAll('.render-slider').forEach(el => {
  const key = el.dataset.render;
  if (renderState[key] !== undefined) el.value = renderState[key];
  const valEl = document.getElementById(`render-val-${key}`);
  if (valEl && renderState[key] !== undefined) valEl.textContent = parseFloat(renderState[key]).toFixed(
    key.includes('Width') || key.includes('Amount') || key.includes('Density') || key.includes('Opacity') ? 3 : key.includes('Thickness') ? 1 : 2
  );
  el.addEventListener('input', () => {
    renderState[key] = parseFloat(el.value);
    if (valEl) valEl.textContent = el.value;
    if (CONTOUR_REBUILD_KEYS.has(key)) {
      buildContours();
    } else if (CONTOUR_STYLE_KEYS.has(key)) {
      applyContourStyle();
    } else if (key === 'terrainExaggeration') {
      applyTerrainExaggeration();
    } else {
      applyRenderSettings();
    }
  });
});

// Panel collapse/expand
document.querySelectorAll('.panel-header').forEach(header => {
  header.addEventListener('click', () => {
    const panel = header.closest('.collapsible-panel');
    panel.classList.toggle('collapsed');
  });
});

// Main panel toggle
document.getElementById('panel-toggle').addEventListener('click', () => {
  document.getElementById('main-panel').classList.toggle('hidden');
  document.getElementById('panel-toggle').classList.toggle('open');
});

// Tab switching
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
  });
});

setupGPXDrop();
setupColorPickers();

// Expose autoLoadDefaultGPX so the "Load Project GPX" button can call it
window.autoLoadDefaultGPX = autoLoadDefaultGPX;

// Wire up the "Load Project GPX" button
const gpxProjectBtn = document.getElementById('gpx-load-project-btn');
if (gpxProjectBtn) {
  gpxProjectBtn.addEventListener('click', async () => {
    debugLog('[BTN] Load Project GPX clicked');
    debugLog(`[BTN] GPX_DEFAULT_XML type=${typeof window.GPX_DEFAULT_XML}, len=${(window.GPX_DEFAULT_XML||'').length}`);

    if (typeof window.GPX_DEFAULT_XML !== 'string' || window.GPX_DEFAULT_XML.length < 50) {
      const msg = 'No GPX data found — gpx-data.js module did not load.';
      setStatus(msg, 'error');
      debugLog('[BTN] ' + msg, 'error');
      return;
    }

    gpxProjectBtn.disabled = true;
    gpxProjectBtn.textContent = 'LOADING…';
    debugLog('[BTN] Calling autoLoadDefaultGPX()…');
    try {
      await autoLoadDefaultGPX();
      debugLog('[BTN] autoLoadDefaultGPX() completed successfully', 'success');
    } catch(err) {
      debugLog('[BTN] autoLoadDefaultGPX() ERROR: ' + err.message, 'error');
    } finally {
      gpxProjectBtn.disabled = false;
      gpxProjectBtn.textContent = '⊕ LOAD PROJECT GPX';
    }
  });
} else {
  console.warn('[GPX] #gpx-load-project-btn not found in DOM');
  debugLog('#gpx-load-project-btn NOT FOUND in DOM!', 'error');
}

// Auto-load default GPX data on startup — no delay, fire immediately
debugLog('Auto-loading default GPX data…');
(async () => {
  try {
    await autoLoadDefaultGPX();
    debugLog('Auto-load completed successfully', 'success');
  } catch(err) {
    debugLog('Auto-load ERROR: ' + err.message, 'error');
    console.error('Auto-load error:', err);
  }
})();

// Preset buttons
document.querySelectorAll('.scene-preset-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    applyScenePreset(btn.dataset.preset);
    document.querySelectorAll('.scene-preset-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
});

// Randomize button
const randBtn = document.getElementById('scene-randomize-btn');
if (randBtn) {
  randBtn.addEventListener('click', () => {
    document.querySelectorAll('.scene-preset-btn').forEach(b => b.classList.remove('active'));
    randomizeScene();
  });
}

// HDRI preset select wiring (also handle from scene.js directly)
const hdriSelectEl = document.getElementById('hdri-preset-select');
if (hdriSelectEl) {
  hdriSelectEl.value = renderState.hdriPreset;
  hdriSelectEl.addEventListener('change', () => {
    renderState.hdriPreset = hdriSelectEl.value;
    _lastHdriPreset = null;
    applyRenderSettings();
  });
}

// --- RESIZE ---
window.addEventListener('resize', () => {
  const w=window.innerWidth, h=window.innerHeight;
  camera.aspect=w/h; camera.updateProjectionMatrix();
  renderer.setSize(w,h); composer.setSize(w,h);
  bloom.resolution.set(Math.round(w * 0.5), Math.round(h * 0.5));
});

// --- PLAYHEAD TOOLTIP ---
const playheadTooltip = document.createElement('div');
playheadTooltip.id = 'playhead-tooltip';
playheadTooltip.style.cssText = `
  position: fixed; pointer-events: none; display: none;
  font-family: 'Inter', sans-serif; font-size: 11px;
  color: #fff; z-index: 100;
`;
document.body.appendChild(playheadTooltip);

function updatePlayheadTooltip(gt, screenX, screenY) {
  const data = window.GPX_DEFAULT_DATA;
  if (!data || !data.track || !layerState.gpxTrack) {
    playheadTooltip.style.display = 'none';
    return;
  }
  const track = data.track;
  const stats = data.stats || {};
  // Interpolate between two nearest track points
  const rawIdx = gt * (track.length - 1);
  const idx0 = Math.max(0, Math.min(track.length - 2, Math.floor(rawIdx)));
  const idx1 = idx0 + 1;
  const f = rawIdx - idx0;
  const p0 = track[idx0], p1 = track[idx1];
  const ele  = p0.ele  + (p1.ele  - p0.ele)  * f;
  const hr   = p0.hr   + (p1.hr   - p0.hr)   * f;
  const cad  = p0.cadence + (p1.cadence - p0.cadence) * f;
  const time = p0.time + (p1.time - p0.time) * f;
  const distKm = p0.cumDistKm != null ? (p0.cumDistKm + (p1.cumDistKm - p0.cumDistKm) * f) : (gt * (stats.totalDistKm || track.length / 100));

  // Pace: compute from adjacent points
  let paceStr = stats.avgPaceMinKm || '—';
  if (idx1 < track.length) {
    const dt = (p1.time - p0.time); // seconds
    // Haversine distance
    const dLat = (p1.lat - p0.lat) * Math.PI / 180;
    const dLon = (p1.lon - p0.lon) * Math.PI / 180;
    const hs = Math.sin(dLat/2)**2 + Math.cos(p0.lat*Math.PI/180)*Math.cos(p1.lat*Math.PI/180)*Math.sin(dLon/2)**2;
    const segM = 6371000 * 2 * Math.atan2(Math.sqrt(hs), Math.sqrt(1-hs));
    if (segM > 1 && dt > 0) {
      const secPerKm = dt / (segM / 1000);
      const mm = Math.floor(secPerKm / 60);
      const ss = Math.round(secPerKm % 60);
      paceStr = `${mm}:${String(ss).padStart(2,'0')}`;
    }
  }

  // Elapsed time
  const elMin = Math.floor(time / 60);
  const elSec = Math.round(time % 60);
  const timeStr = `${elMin}:${String(elSec).padStart(2,'0')}`;

  // HR zone label + color
  let hrColor = '#88ff88', hrZone = 'EASY';
  if (hr >= 168) { hrColor = '#ff3355'; hrZone = 'MAX'; }
  else if (hr >= 155) { hrColor = '#ff8833'; hrZone = 'THRESHOLD'; }
  else if (hr >= 140) { hrColor = '#ffdd44'; hrZone = 'TEMPO'; }
  else if (hr >= 120) { hrColor = '#44dd88'; hrZone = 'AEROBIC'; }

  // Nearest split
  let splitInfo = '';
  const splits = data.splits || [];
  const nearestSplit = splits.reduce((prev, s) => {
    return Math.abs(s.time - time) < Math.abs((prev ? prev.time : Infinity) - time) ? s : prev;
  }, null);
  if (nearestSplit && Math.abs(nearestSplit.time - time) < 200) {
    splitInfo = `<div style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.08);color:rgba(255,255,255,0.5);font-size:9px;letter-spacing:0.08em;">KM ${nearestSplit.km} SPLIT · ${nearestSplit.avgPace} /km</div>`;
  }

  playheadTooltip.innerHTML = `
    <div style="background:rgba(8,8,14,0.96);border:1px solid rgba(255,102,0,0.5);border-radius:8px;padding:12px 14px;min-width:180px;box-shadow:0 0 24px rgba(255,102,0,0.2),0 4px 20px rgba(0,0,0,0.6);">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
        <div style="width:7px;height:7px;border-radius:50%;background:#ff6600;box-shadow:0 0 6px #ff6600;flex-shrink:0;"></div>
        <span style="color:rgba(255,102,0,0.95);font-weight:700;letter-spacing:0.12em;font-size:9.5px;">LIVE · ${timeStr}</span>
        <span style="margin-left:auto;color:rgba(255,255,255,0.35);font-size:9px;">${distKm.toFixed(2)} km</span>
      </div>
      <div style="display:grid;grid-template-columns:auto 1fr;gap:5px 14px;align-items:center;">
        <span style="color:rgba(255,255,255,0.42);font-size:9px;letter-spacing:0.08em;white-space:nowrap;">ELEVATION</span>
        <span style="font-weight:600;font-size:12px;">${Math.round(ele)} m</span>
        <span style="color:rgba(255,255,255,0.42);font-size:9px;letter-spacing:0.08em;">HEART RATE</span>
        <div style="display:flex;align-items:baseline;gap:5px;">
          <span style="font-weight:700;font-size:12px;color:${hrColor};">${Math.round(hr)}</span>
          <span style="color:rgba(255,255,255,0.3);font-size:9px;">bpm</span>
          <span style="font-size:8.5px;color:${hrColor};opacity:0.7;letter-spacing:0.06em;">${hrZone}</span>
        </div>
        <span style="color:rgba(255,255,255,0.42);font-size:9px;letter-spacing:0.08em;">PACE</span>
        <div style="display:flex;align-items:baseline;gap:4px;">
          <span style="font-weight:600;font-size:12px;">${paceStr}</span>
          <span style="color:rgba(255,255,255,0.3);font-size:9px;">/km</span>
        </div>
        <span style="color:rgba(255,255,255,0.42);font-size:9px;letter-spacing:0.08em;">CADENCE</span>
        <div style="display:flex;align-items:baseline;gap:4px;">
          <span style="font-weight:600;font-size:12px;">${Math.round(cad)}</span>
          <span style="color:rgba(255,255,255,0.3);font-size:9px;">spm</span>
        </div>
      </div>
      ${splitInfo}
    </div>
  `;
  playheadTooltip.style.display = 'block';

  // Position near playhead on screen, clamped to viewport
  const tw = 210, th = 160;
  let tx = screenX + 18, ty = screenY - 70;
  if (tx + tw > window.innerWidth - 10) tx = screenX - tw - 18;
  if (ty < 10) ty = 10;
  if (ty + th > window.innerHeight - 10) ty = window.innerHeight - th - 10;
  playheadTooltip.style.left = tx + 'px';
  playheadTooltip.style.top  = ty + 'px';
}

// --- FPS COUNTER ---
let _fpsFrames = 0, _fpsLastTime = performance.now(), _fpsValue = 0;
const _fpsEl = document.getElementById('fps-counter');

let _fpsVisible = false;
function updateFPSCounter() {
  _fpsFrames++;
  const now = performance.now();
  if (now - _fpsLastTime >= 500) {
    _fpsValue = Math.round(_fpsFrames / ((now - _fpsLastTime) / 1000));
    _fpsFrames = 0;
    _fpsLastTime = now;
    if (_fpsEl && _fpsVisible) _fpsEl.textContent = _fpsValue + ' FPS';
  }
  // Only toggle class when state changes
  if (_fpsEl && renderState.fpsCounter !== _fpsVisible) {
    _fpsVisible = renderState.fpsCounter;
    _fpsEl.classList.toggle('visible', _fpsVisible);
  }
}

// --- ANIMATE ---
let t = 0;
let _tooltipThrottle = 0;
const _screenVec = new THREE.Vector3(); // reuse to avoid alloc

function animate() {
  requestAnimationFrame(animate);
  t += 0.004;
  updateFPSCounter();

  if (gpxCurve && gpxMarker && layerState.gpxTrack) {
    const speed = renderState.gpxAnimSpeed ?? 1.0;
    const gt = (t * 0.08 * speed) % 1;
    const gp = gpxCurve.getPoint(gt);
    gpxMarker.position.set(gp.x, gp.y + 0.35, gp.z);

    // Pulse the halo — cache reference
    if (!_cachedHaloRef) _cachedHaloRef = gpxMarker.getObjectByName('gpxMarkerHalo');
    if (_cachedHaloRef && _cachedHaloRef.material) {
      const sinVal = Math.abs(Math.sin(t * 3.5));
      _cachedHaloRef.material.opacity = 0.15 + sinVal * 0.25;
      _cachedHaloRef.scale.setScalar(1.0 + sinVal * 0.4);
    }

    // DoF auto-focus on playhead
    if (bokehPass.enabled) {
      const dx = camera.position.x - gp.x;
      const dy = camera.position.y - gp.y;
      const dz = camera.position.z - gp.z;
      bokehPass.uniforms['focus'].value = Math.sqrt(dx*dx + dy*dy + dz*dz);
      const valEl = document.getElementById('render-val-dofFocus');
      if (valEl) valEl.textContent = bokehPass.uniforms['focus'].value.toFixed(1);
    }

    // Throttle tooltip updates to ~20fps (every 3rd frame at 60fps)
    _tooltipThrottle++;
    if (_tooltipThrottle >= 3) {
      _tooltipThrottle = 0;
      _screenVec.copy(gp).project(camera);
      const sx = (_screenVec.x * 0.5 + 0.5) * window.innerWidth;
      const sy = (-_screenVec.y * 0.5 + 0.5) * window.innerHeight;
      if (_screenVec.z < 1.0) {
        updatePlayheadTooltip(gt, sx, sy);
      } else {
        playheadTooltip.style.display = 'none';
      }
    }
  } else {
    if (playheadTooltip.style.display !== 'none') playheadTooltip.style.display = 'none';
  }

  // Animate GPX glow pulse (every other frame is fine)
  if (gpxTrackGroup && (t * 250 | 0) % 2 === 0) {
    if (!_cachedGlowRef) _cachedGlowRef = gpxTrackGroup.getObjectByName('gpxGlow');
    if (_cachedGlowRef && _cachedGlowRef.material) _cachedGlowRef.material.opacity = 0.08 + Math.abs(Math.sin(t * 1.5)) * 0.16;
  }

  // Road glow animation — cached refs, only highway glows
  if (!_cachedHwGlows) {
    const rl = scene.getObjectByName('roadLayers');
    if (rl) {
      const hwGroup = rl.getObjectByName('roadLayer_highway');
      if (hwGroup) {
        _cachedHwGlows = hwGroup.children.filter(c => c.name && c.name.endsWith('_glow') && c.material);
      }
    }
  }
  if (_cachedHwGlows && _cachedHwGlows.length > 0) {
    const glowOpacity = 0.10 + Math.abs(Math.sin(t * 1.8)) * 0.20;
    for (let i = 0; i < _cachedHwGlows.length; i++) {
      _cachedHwGlows[i].material.opacity = glowOpacity;
    }
  }

  grainPass.uniforms.time.value = t;
  controls.update();
  composer.render();
}

animate();