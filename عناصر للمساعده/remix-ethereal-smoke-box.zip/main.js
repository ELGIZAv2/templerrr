// 3D Volumetric Fluid/Smoke Simulation inspired by dli/fluid
// Using 3D textures and ray marching for volumetric rendering

// ============ SETUP ============
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 100);
camera.position.set(0, 0.5, 3.5);

const renderer = new THREE.WebGLRenderer({ antialias: false });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
document.body.appendChild(renderer.domElement);

const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.target.set(0, 0.3, 0);

const clock = new THREE.Clock();

// ============ 3D FLUID SIMULATION ON GPU ============
// We simulate a 3D velocity + density field using ping-pong 3D render targets
// Since Three.js doesn't natively support 3D render targets easily,
// we use a flat 3D texture atlas approach (NxN slices tiled in a 2D texture)

const SIM_RES = 64; // 64^3 volume
const SLICES_PER_ROW = 8; // 8x8 = 64 slices
const ATLAS_SIZE = SIM_RES * SLICES_PER_ROW; // 512

// Helper: create a 2D render target that stores a 3D volume as a slice atlas
function createVolumeRT() {
  return new THREE.WebGLRenderTarget(ATLAS_SIZE, ATLAS_SIZE, {
    type: THREE.FloatType,
    minFilter: THREE.LinearFilter,
    magFilter: THREE.LinearFilter,
    wrapS: THREE.ClampToEdgeWrapping,
    wrapT: THREE.ClampToEdgeWrapping,
    format: THREE.RGBAFormat,
  });
}

// Ping-pong buffers for velocity (xyz) and density/temperature (w)
let fluidA = createVolumeRT();
let fluidB = createVolumeRT();

// Common GLSL for 3D atlas addressing
const atlas3DCommon = `
  const float GRID = ${SIM_RES}.0;
  const float SLICES_PER_ROW = ${SLICES_PER_ROW}.0;
  const float ATLAS = ${ATLAS_SIZE}.0;

  // Convert 3D UVW [0,1]^3 to 2D atlas UV
  vec2 uvw_to_atlas(vec3 uvw) {
    float slice = uvw.z * (GRID - 1.0);
    float sliceFloor = floor(slice);
    float col = mod(sliceFloor, SLICES_PER_ROW);
    float row = floor(sliceFloor / SLICES_PER_ROW);
    vec2 sliceOrigin = vec2(col, row) * GRID / ATLAS;
    vec2 withinSlice = uvw.xy * (GRID / ATLAS);
    return sliceOrigin + withinSlice;
  }

  // Sample 3D volume with trilinear interpolation between slices
  vec4 sampleVolume(sampler2D tex, vec3 uvw) {
    uvw = clamp(uvw, vec3(0.5/GRID), vec3(1.0 - 0.5/GRID));
    float slice = uvw.z * (GRID - 1.0);
    float z0 = floor(slice);
    float z1 = min(z0 + 1.0, GRID - 1.0);
    float fz = slice - z0;

    float col0 = mod(z0, SLICES_PER_ROW);
    float row0 = floor(z0 / SLICES_PER_ROW);
    vec2 origin0 = vec2(col0, row0) * GRID / ATLAS;

    float col1 = mod(z1, SLICES_PER_ROW);
    float row1 = floor(z1 / SLICES_PER_ROW);
    vec2 origin1 = vec2(col1, row1) * GRID / ATLAS;

    vec2 withinSlice = uvw.xy * (GRID / ATLAS);

    vec4 s0 = texture2D(tex, origin0 + withinSlice);
    vec4 s1 = texture2D(tex, origin1 + withinSlice);
    return mix(s0, s1, fz);
  }
`;

// ============ SIMULATION PASSES ============
// Full-screen quad for simulation
const simQuadGeo = new THREE.PlaneGeometry(2, 2);

// --- ADVECTION + FORCES + DISSIPATION PASS ---
const advectMat = new THREE.ShaderMaterial({
  uniforms: {
    uFluid: { value: null },
    uDt: { value: 0.016 },
    uTime: { value: 0 },
    uDissipation: { value: 0.98 },
    uBuoyancy: { value: 2.5 },
    uCurlStrength: { value: 3.0 },
    uEmitStrength: { value: 3.5 },
  uFlameWidth: { value: 0.5 },
  uFlameHeight: { value: 0.5 },
  uTurbulence: { value: 0.5 },
  uFlameScaleX: { value: 1.0 },
  uFlameScaleY: { value: 1.0 },
  uFlameScaleZ: { value: 1.0 },
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position.xy, 0.0, 1.0);
    }
  `,
  fragmentShader: `
    precision highp float;
    varying vec2 vUv;
    uniform sampler2D uFluid;
    uniform float uDt;
    uniform float uTime;
    uniform float uDissipation;
    uniform float uBuoyancy;
    uniform float uCurlStrength;
    uniform float uEmitStrength;
    uniform float uFlameWidth;
    uniform float uFlameHeight;
    uniform float uTurbulence;
    uniform float uFlameScaleX;
    uniform float uFlameScaleY;
    uniform float uFlameScaleZ;

    ${atlas3DCommon}

    // Convert atlas UV back to 3D UVW
    vec3 atlas_to_uvw(vec2 atlasUV) {
      vec2 pixel = atlasUV * ATLAS;
      float col = floor(pixel.x / GRID);
      float row = floor(pixel.y / GRID);
      float sliceIndex = row * SLICES_PER_ROW + col;
      float x = mod(pixel.x, GRID);
      float y = mod(pixel.y, GRID);
      return vec3(x / GRID, y / GRID, (sliceIndex + 0.5) / GRID);
    }

    // Simple 3D hash for noise
    vec3 hash3(vec3 p) {
      p = vec3(dot(p, vec3(127.1, 311.7, 74.7)),
               dot(p, vec3(269.5, 183.3, 246.1)),
               dot(p, vec3(113.5, 271.9, 124.6)));
      return -1.0 + 2.0 * fract(sin(p) * 43758.5453123);
    }

    // Gradient noise 3D
    float gnoise(vec3 p) {
      vec3 i = floor(p);
      vec3 f = fract(p);
      vec3 u = f * f * (3.0 - 2.0 * f);
      return mix(mix(mix(dot(hash3(i + vec3(0,0,0)), f - vec3(0,0,0)),
                         dot(hash3(i + vec3(1,0,0)), f - vec3(1,0,0)), u.x),
                     mix(dot(hash3(i + vec3(0,1,0)), f - vec3(0,1,0)),
                         dot(hash3(i + vec3(1,1,0)), f - vec3(1,1,0)), u.x), u.y),
                 mix(mix(dot(hash3(i + vec3(0,0,1)), f - vec3(0,0,1)),
                         dot(hash3(i + vec3(1,0,1)), f - vec3(1,0,1)), u.x),
                     mix(dot(hash3(i + vec3(0,1,1)), f - vec3(0,1,1)),
                         dot(hash3(i + vec3(1,1,1)), f - vec3(1,1,1)), u.x), u.y), u.z);
    }

    vec3 curl(vec3 p) {
      float e = 1.0 / GRID;
      vec4 px1 = sampleVolume(uFluid, p + vec3(e,0,0));
      vec4 px0 = sampleVolume(uFluid, p - vec3(e,0,0));
      vec4 py1 = sampleVolume(uFluid, p + vec3(0,e,0));
      vec4 py0 = sampleVolume(uFluid, p - vec3(0,e,0));
      vec4 pz1 = sampleVolume(uFluid, p + vec3(0,0,e));
      vec4 pz0 = sampleVolume(uFluid, p - vec3(0,0,e));
      
      float curlX = (py1.z - py0.z) - (pz1.y - pz0.y);
      float curlY = (pz1.x - pz0.x) - (px1.z - px0.z);
      float curlZ = (px1.y - px0.y) - (py1.x - py0.x);
      return vec3(curlX, curlY, curlZ);
    }

    void main() {
      vec3 uvw = atlas_to_uvw(vUv);
      vec4 current = sampleVolume(uFluid, uvw);
      vec3 vel = current.xyz;
      float density = current.w;

      // Semi-Lagrangian advection
      vec3 backtraced = uvw - vel * uDt * 0.5;
      vec4 advected = sampleVolume(uFluid, backtraced);

      vec3 newVel = advected.xyz;
      float newDensity = advected.w * uDissipation;

      // Buoyancy force (upward when hot) - scaled by flame height
      float buoyancyMult = 0.7 + uFlameHeight * 1.0;
      newVel.y += newDensity * uBuoyancy * buoyancyMult * uDt;

      // Vorticity confinement
      vec3 c = curl(uvw);
      float cmag = length(c) + 1e-5;
      float e = 1.0 / GRID;
      float cx1 = length(curl(uvw + vec3(e,0,0)));
      float cx0 = length(curl(uvw - vec3(e,0,0)));
      float cy1 = length(curl(uvw + vec3(0,e,0)));
      float cy0 = length(curl(uvw - vec3(0,e,0)));
      float cz1 = length(curl(uvw + vec3(0,0,e)));
      float cz0 = length(curl(uvw - vec3(0,0,e)));
      vec3 eta = vec3(cx1 - cx0, cy1 - cy0, cz1 - cz0);
      float etaMag = length(eta) + 1e-5;
      vec3 N = eta / etaMag;
      vec3 vortForce = cross(N, c) * uCurlStrength * uDt;
      newVel += vortForce;

      // Cylindrical emitter - ring/disc at bottom center
      float emitterY = 0.06;
      vec3 center = vec3(0.5, emitterY, 0.5);
      // Apply per-axis scale to radial calculations
      vec2 scaledRadialVec = (uvw.xz - center.xz) / vec2(uFlameScaleX, uFlameScaleZ);
      vec2 radialVec = uvw.xz - center.xz;
      float radialDist = length(scaledRadialVec);
      float vertDist = uvw.y - center.y;
      
      // Disc-shaped emitter with soft circular falloff
      float discRadius = 0.06 + uFlameWidth * 0.15;
      float discSigma = discRadius * 0.8;
      float discFalloff = exp(-radialDist * radialDist / (discSigma * discSigma));
      float vertSigma = 0.03;
      float vertFalloff = exp(-vertDist * vertDist / (vertSigma * vertSigma));
      float emit = discFalloff * vertFalloff;
      
      // Swirling ring emitters around the disc
      float angle1 = uTime * 1.5;
      float angle2 = uTime * 1.5 + 3.14159;
      float angle3 = uTime * 1.5 + 1.5708;
      float ringR = 0.04 + uFlameWidth * 0.08;
      vec3 ring1 = center + vec3(sin(angle1)*ringR, 0.0, cos(angle1)*ringR);
      vec3 ring2 = center + vec3(sin(angle2)*ringR, 0.0, cos(angle2)*ringR);
      vec3 ring3 = center + vec3(sin(angle3)*ringR, 0.0, cos(angle3)*ringR);
      float ringSize = 0.035 + uFlameWidth * 0.015;
      emit += 0.5 * exp(-dot(uvw-ring1, uvw-ring1) / (ringSize*ringSize));
      emit += 0.5 * exp(-dot(uvw-ring2, uvw-ring2) / (ringSize*ringSize));
      emit += 0.4 * exp(-dot(uvw-ring3, uvw-ring3) / (ringSize*ringSize));
      emit = clamp(emit, 0.0, 1.0);

      newDensity += emit * uEmitStrength * uDt * 50.0;
      float emitLift = 2.0 + uFlameHeight * 3.0;
      newVel.y += emit * emitLift * uDt;
      
      // Turbulence - noise-based perturbation in the emitter/flame region
      float turbFreq = 4.0 + uTurbulence * 12.0;
      float turbAmp = uTurbulence * 2.0;
      float emitRegion = smoothstep(0.0, 0.3, emit + density * 0.15);
      vec3 noiseCoord = uvw * turbFreq + vec3(uTime * 1.2, uTime * 0.8, uTime * 1.0);
      float nx = gnoise(noiseCoord);
      float ny = gnoise(noiseCoord + vec3(31.416, 0.0, 0.0));
      float nz = gnoise(noiseCoord + vec3(0.0, 0.0, 71.063));
      newVel += vec3(nx, ny * 0.5, nz) * turbAmp * emitRegion * uDt;

      // Cylindrical turbulence - swirl around Y axis
      float turbAngle = atan(radialVec.y, radialVec.x);
      float swirlStrength = emit * 0.8 * uDt;
      float baseNoise = 0.4;
      newVel.x += -sin(turbAngle) * swirlStrength + emit * sin(uvw.y * 20.0 + uTime * 2.5) * baseNoise * uDt;
      newVel.z +=  cos(turbAngle) * swirlStrength + emit * cos(uvw.y * 20.0 + uTime * 2.0) * baseNoise * uDt;
      
      // Gentle radial inward pull to keep flame together
      float inwardEdge = 0.1 + uFlameWidth * 0.18;
      float inwardOuter = inwardEdge + 0.15;
      float rawRadialDist = length(radialVec);
      float inwardForce = smoothstep(inwardEdge, inwardOuter, radialDist) * 1.2 * uDt;
      vec2 radialDir = rawRadialDist > 0.001 ? radialVec / rawRadialDist : vec2(0.0);
      float heightInfluence = smoothstep(0.5, 0.0, uvw.y);
      newVel.x -= radialDir.x * inwardForce * heightInfluence;
      newVel.z -= radialDir.y * inwardForce * heightInfluence;

      // Velocity damping
      newVel *= 0.995;

      // Cylindrical boundary - fade at radial edges (using scaled distance)
      float boundary = 2.0 / GRID;
      float cylRadius = length((uvw.xz - vec2(0.5)) / vec2(uFlameScaleX, uFlameScaleZ));
      float cylBoundaryInner = 0.28 + uFlameWidth * 0.15;
      float cylBoundary = smoothstep(cylBoundaryInner, cylBoundaryInner + 0.12, cylRadius);
      newVel *= mix(1.0, 0.05, cylBoundary);
      newDensity *= mix(1.0, 0.3, cylBoundary);
      
      // Square boundary fallback
      if (uvw.x < boundary || uvw.x > 1.0 - boundary ||
          uvw.z < boundary || uvw.z > 1.0 - boundary) {
        newVel *= 0.05;
      }
      if (uvw.y < boundary) {
        newVel.y = max(newVel.y, 0.0);
      }
      // Soft top boundary - flame height and Y scale control where dissipation begins
      float topFadeStart = 0.55 + uFlameHeight * 0.35;
      // Scale Y: remap uvw.y relative to center so taller flames extend higher
      float scaledY = 0.5 + (uvw.y - 0.5) / uFlameScaleY;
      float topFade = smoothstep(topFadeStart, topFadeStart + 0.15, scaledY);
      newDensity *= mix(1.0, 0.15, topFade);
      newVel.y = mix(newVel.y, min(newVel.y, 0.0), topFade);
      
      if (uvw.y > 1.0 - boundary) {
        newDensity *= 0.05;
        newVel.y = min(newVel.y, 0.0);
      }

      gl_FragColor = vec4(newVel, clamp(newDensity, 0.0, 8.0));
    }
  `,
  depthTest: false,
  depthWrite: false,
});

const advectQuad = new THREE.Mesh(simQuadGeo, advectMat);
const advectScene = new THREE.Scene();
advectScene.add(advectQuad);
const simCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

// --- PRESSURE PROJECTION (Jacobi iteration) ---
const pressureRT_A = createVolumeRT();
const pressureRT_B = createVolumeRT();

const divergenceMat = new THREE.ShaderMaterial({
  uniforms: {
    uFluid: { value: null },
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position.xy, 0.0, 1.0);
    }
  `,
  fragmentShader: `
    precision highp float;
    varying vec2 vUv;
    uniform sampler2D uFluid;
    ${atlas3DCommon}

    vec3 atlas_to_uvw(vec2 atlasUV) {
      vec2 pixel = atlasUV * ATLAS;
      float col = floor(pixel.x / GRID);
      float row = floor(pixel.y / GRID);
      float sliceIndex = row * SLICES_PER_ROW + col;
      float x = mod(pixel.x, GRID);
      float y = mod(pixel.y, GRID);
      return vec3(x / GRID, y / GRID, (sliceIndex + 0.5) / GRID);
    }

    void main() {
      vec3 uvw = atlas_to_uvw(vUv);
      float e = 1.0 / GRID;
      
      float vxp = sampleVolume(uFluid, uvw + vec3(e,0,0)).x;
      float vxn = sampleVolume(uFluid, uvw - vec3(e,0,0)).x;
      float vyp = sampleVolume(uFluid, uvw + vec3(0,e,0)).y;
      float vyn = sampleVolume(uFluid, uvw - vec3(0,e,0)).y;
      float vzp = sampleVolume(uFluid, uvw + vec3(0,0,e)).z;
      float vzn = sampleVolume(uFluid, uvw - vec3(0,0,e)).z;

      float div = 0.5 * ((vxp - vxn) + (vyp - vyn) + (vzp - vzn));
      gl_FragColor = vec4(div, 0.0, 0.0, 1.0);
    }
  `,
  depthTest: false,
  depthWrite: false,
});

const divergenceRT = createVolumeRT();
const divQuad = new THREE.Mesh(simQuadGeo, divergenceMat);
const divScene = new THREE.Scene();
divScene.add(divQuad);

const jacobiMat = new THREE.ShaderMaterial({
  uniforms: {
    uPressure: { value: null },
    uDivergence: { value: null },
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position.xy, 0.0, 1.0);
    }
  `,
  fragmentShader: `
    precision highp float;
    varying vec2 vUv;
    uniform sampler2D uPressure;
    uniform sampler2D uDivergence;
    ${atlas3DCommon}

    vec3 atlas_to_uvw(vec2 atlasUV) {
      vec2 pixel = atlasUV * ATLAS;
      float col = floor(pixel.x / GRID);
      float row = floor(pixel.y / GRID);
      float sliceIndex = row * SLICES_PER_ROW + col;
      float x = mod(pixel.x, GRID);
      float y = mod(pixel.y, GRID);
      return vec3(x / GRID, y / GRID, (sliceIndex + 0.5) / GRID);
    }

    void main() {
      vec3 uvw = atlas_to_uvw(vUv);
      float e = 1.0 / GRID;

      float pxp = sampleVolume(uPressure, uvw + vec3(e,0,0)).r;
      float pxn = sampleVolume(uPressure, uvw - vec3(e,0,0)).r;
      float pyp = sampleVolume(uPressure, uvw + vec3(0,e,0)).r;
      float pyn = sampleVolume(uPressure, uvw - vec3(0,e,0)).r;
      float pzp = sampleVolume(uPressure, uvw + vec3(0,0,e)).r;
      float pzn = sampleVolume(uPressure, uvw - vec3(0,0,e)).r;

      float div = sampleVolume(uDivergence, uvw).r;
      float p = (pxp + pxn + pyp + pyn + pzp + pzn - div) / 6.0;

      gl_FragColor = vec4(p, 0.0, 0.0, 1.0);
    }
  `,
  depthTest: false,
  depthWrite: false,
});

const jacobiQuad = new THREE.Mesh(simQuadGeo.clone(), jacobiMat);
const jacobiScene = new THREE.Scene();
jacobiScene.add(jacobiQuad);

// Gradient subtract pass
const gradSubMat = new THREE.ShaderMaterial({
  uniforms: {
    uFluid: { value: null },
    uPressure: { value: null },
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position.xy, 0.0, 1.0);
    }
  `,
  fragmentShader: `
    precision highp float;
    varying vec2 vUv;
    uniform sampler2D uFluid;
    uniform sampler2D uPressure;
    ${atlas3DCommon}

    vec3 atlas_to_uvw(vec2 atlasUV) {
      vec2 pixel = atlasUV * ATLAS;
      float col = floor(pixel.x / GRID);
      float row = floor(pixel.y / GRID);
      float sliceIndex = row * SLICES_PER_ROW + col;
      float x = mod(pixel.x, GRID);
      float y = mod(pixel.y, GRID);
      return vec3(x / GRID, y / GRID, (sliceIndex + 0.5) / GRID);
    }

    void main() {
      vec3 uvw = atlas_to_uvw(vUv);
      float e = 1.0 / GRID;

      vec4 fluid = sampleVolume(uFluid, uvw);
      
      float pxp = sampleVolume(uPressure, uvw + vec3(e,0,0)).r;
      float pxn = sampleVolume(uPressure, uvw - vec3(e,0,0)).r;
      float pyp = sampleVolume(uPressure, uvw + vec3(0,e,0)).r;
      float pyn = sampleVolume(uPressure, uvw - vec3(0,e,0)).r;
      float pzp = sampleVolume(uPressure, uvw + vec3(0,0,e)).r;
      float pzn = sampleVolume(uPressure, uvw - vec3(0,0,e)).r;

      vec3 gradP = 0.5 * vec3(pxp - pxn, pyp - pyn, pzp - pzn);
      fluid.xyz -= gradP;

      gl_FragColor = fluid;
    }
  `,
  depthTest: false,
  depthWrite: false,
});

const gradSubQuad = new THREE.Mesh(simQuadGeo.clone(), gradSubMat);
const gradSubScene = new THREE.Scene();
gradSubScene.add(gradSubQuad);

// ============ VOLUMETRIC RAY MARCHER ============
const volumeMaterial = new THREE.ShaderMaterial({
  uniforms: {
    uFluid: { value: null },
    uCameraPos: { value: new THREE.Vector3() },
    uTime: { value: 0 },
    uInvModelMatrix: { value: new THREE.Matrix4() },
    uBrightness: { value: 1.5 },
    uAbsorption: { value: 8.0 },
    uColorMode: { value: 0 },
    uFlameWidth: { value: 0.5 },
    uFlameHeight: { value: 0.5 },
    uFlameScaleX: { value: 1.0 },
    uFlameScaleY: { value: 1.0 },
    uFlameScaleZ: { value: 1.0 },
  },
  vertexShader: `
    varying vec3 vWorldPos;
    varying vec3 vLocalPos;
    void main() {
      vLocalPos = position;
      vec4 wp = modelMatrix * vec4(position, 1.0);
      vWorldPos = wp.xyz;
      gl_Position = projectionMatrix * viewMatrix * wp;
    }
  `,
  fragmentShader: `
    precision highp float;
    varying vec3 vWorldPos;
    varying vec3 vLocalPos;
    uniform sampler2D uFluid;
    uniform vec3 uCameraPos;
    uniform float uTime;
    uniform mat4 uInvModelMatrix;
    uniform float uBrightness;
    uniform float uAbsorption;
    uniform int uColorMode;
    uniform float uFlameWidth;
    uniform float uFlameHeight;
    uniform float uFlameScaleX;
    uniform float uFlameScaleY;
    uniform float uFlameScaleZ;

    ${atlas3DCommon}

    // Ray-box intersection for unit cube [-0.5, 0.5]
    vec2 intersectBox(vec3 ro, vec3 rd) {
      vec3 invRd = 1.0 / rd;
      vec3 t0 = (-0.5 - ro) * invRd;
      vec3 t1 = (0.5 - ro) * invRd;
      vec3 tmin = min(t0, t1);
      vec3 tmax = max(t0, t1);
      float tNear = max(max(tmin.x, tmin.y), tmin.z);
      float tFar = min(min(tmax.x, tmax.y), tmax.z);
      return vec2(tNear, tFar);
    }

    // Fire/smoke color ramp based on density and temperature
    vec3 fireColor(float density) {
      float t = clamp(density, 0.0, 1.0);
      vec3 c1, c2, c3, c4, c5;

      if (uColorMode == 1) {
        // Blue Plasma
        c1 = vec3(0.0, 0.0, 0.03);
        c2 = vec3(0.05, 0.05, 0.6);
        c3 = vec3(0.1, 0.3, 1.0);
        c4 = vec3(0.4, 0.7, 1.0);
        c5 = vec3(0.8, 0.95, 1.0);
      } else if (uColorMode == 2) {
        // Green Toxic
        c1 = vec3(0.0, 0.02, 0.0);
        c2 = vec3(0.0, 0.4, 0.05);
        c3 = vec3(0.1, 0.8, 0.1);
        c4 = vec3(0.5, 1.0, 0.2);
        c5 = vec3(0.85, 1.0, 0.7);
      } else if (uColorMode == 3) {
        // White Steam
        c1 = vec3(0.03, 0.03, 0.04);
        c2 = vec3(0.15, 0.15, 0.18);
        c3 = vec3(0.4, 0.4, 0.45);
        c4 = vec3(0.7, 0.7, 0.75);
        c5 = vec3(0.95, 0.95, 1.0);
      } else if (uColorMode == 4) {
        // Purple Inferno
        c1 = vec3(0.02, 0.0, 0.03);
        c2 = vec3(0.4, 0.0, 0.5);
        c3 = vec3(0.8, 0.1, 0.6);
        c4 = vec3(1.0, 0.4, 0.5);
        c5 = vec3(1.0, 0.85, 0.7);
      } else {
        // Default Fire
        c1 = vec3(0.02, 0.0, 0.0);
        c2 = vec3(0.6, 0.05, 0.0);
        c3 = vec3(1.0, 0.35, 0.02);
        c4 = vec3(1.0, 0.65, 0.15);
        c5 = vec3(1.0, 0.95, 0.6);
      }

      vec3 col;
      if (t < 0.2) {
        col = mix(c1, c2, t / 0.2);
      } else if (t < 0.45) {
        col = mix(c2, c3, (t - 0.2) / 0.25);
      } else if (t < 0.7) {
        col = mix(c3, c4, (t - 0.45) / 0.25);
      } else {
        col = mix(c4, c5, (t - 0.7) / 0.3);
      }
      return col;
    }

    void main() {
      // Transform ray to local space
      vec3 localCamPos = (uInvModelMatrix * vec4(uCameraPos, 1.0)).xyz;
      vec3 rayDir = normalize(vLocalPos - localCamPos);

      vec2 tHit = intersectBox(localCamPos, rayDir);
      if (tHit.x > tHit.y) discard;

      tHit.x = max(tHit.x, 0.0);

      // Ray march parameters - always march front to back
      int MAX_STEPS = 112;
      float marchLength = tHit.y - tHit.x;
      float stepSize = marchLength / float(MAX_STEPS);
      
      vec3 accumulated = vec3(0.0);
      float transmittance = 1.0;

      // Start from the near hit point (front-to-back)
      vec3 pos = localCamPos + rayDir * tHit.x;
      vec3 stepVec = rayDir * stepSize;

      // Two light sources for more volumetric depth
      vec3 lightDir1 = normalize(vec3(0.3, 1.0, 0.2));
      vec3 lightDir2 = normalize(vec3(-0.4, 0.8, -0.3));

      for (int i = 0; i < 112; i++) {
        // Convert local pos [-0.5, 0.5] to UVW [0, 1]
        vec3 uvw = pos + 0.5;

        if (uvw.x >= 0.0 && uvw.x <= 1.0 && uvw.y >= 0.0 && uvw.y <= 1.0 && uvw.z >= 0.0 && uvw.z <= 1.0) {
          // Cylindrical fade: reduce density at radial edges for round cross-section
          vec2 rVec = uvw.xz - vec2(0.5);
          // Apply per-axis scale for elliptical cross-section
          vec2 scaledRVec = rVec / vec2(uFlameScaleX, uFlameScaleZ);
          float rDist = length(scaledRVec);
          // Wider cylindrical mask with softer falloff to avoid hard edges
          float cylMaskInner = 0.22 + uFlameWidth * 0.15;
          float cylMaskOuter = cylMaskInner + 0.2;
          float cylMask = 1.0 - smoothstep(cylMaskInner, cylMaskOuter, rDist);
          
          vec4 fluid = sampleVolume(uFluid, uvw);
          float density = fluid.w * cylMask;

          if (density > 0.008) {
            // Height-based temperature (hotter at bottom), scaled by Y
            float height = 0.5 + (uvw.y - 0.5) / uFlameScaleY;
            // Flame height extends the hot zone upward
            float tempFalloff = 0.9 - uFlameHeight * 0.3;
            float temperature = density * max(1.0 - height * tempFalloff, 0.0);
            
            // Radial temperature - hotter in center (using scaled distance)
            float radialTemp = 1.0 - smoothstep(0.0, 0.25, rDist);
            temperature *= (0.6 + 0.4 * radialTemp);
            
            // Fire/emission color
            vec3 emitColor = fireColor(temperature * 0.5) * uBrightness;
            
            // Light scattering with two sources for depth
            float lightSamples = 3.0;
            float lightDensity1 = 0.0;
            float lightDensity2 = 0.0;
            for (int ls = 1; ls <= 3; ls++) {
              float lStep = float(ls) * 0.04;
              vec3 lp1 = uvw + lightDir1 * lStep;
              vec3 lp2 = uvw + lightDir2 * lStep;
              if (all(greaterThanEqual(lp1, vec3(0.0))) && all(lessThanEqual(lp1, vec3(1.0)))) {
                lightDensity1 += sampleVolume(uFluid, lp1).w;
              }
              if (all(greaterThanEqual(lp2, vec3(0.0))) && all(lessThanEqual(lp2, vec3(1.0)))) {
                lightDensity2 += sampleVolume(uFluid, lp2).w;
              }
            }
            float lightAtten1 = exp(-lightDensity1 * 0.8);
            float lightAtten2 = exp(-lightDensity2 * 0.6);
            float lightAtten = lightAtten1 * 0.65 + lightAtten2 * 0.35;
            
            // Smoke color for upper regions (cooler = more smoke-like)
            vec3 smokeBase;
            if (uColorMode == 1) smokeBase = vec3(0.15, 0.2, 0.35);
            else if (uColorMode == 2) smokeBase = vec3(0.1, 0.3, 0.12);
            else if (uColorMode == 3) smokeBase = vec3(0.3, 0.3, 0.32);
            else if (uColorMode == 4) smokeBase = vec3(0.25, 0.15, 0.3);
            else smokeBase = vec3(0.35, 0.3, 0.25);
            vec3 smokeColor = smokeBase * lightAtten * 0.4;
            // Warmer inner smoke
            vec3 innerSmoke;
            if (uColorMode == 1) innerSmoke = vec3(0.02, 0.05, 0.15);
            else if (uColorMode == 2) innerSmoke = vec3(0.02, 0.12, 0.02);
            else if (uColorMode == 3) innerSmoke = vec3(0.08, 0.08, 0.1);
            else if (uColorMode == 4) innerSmoke = vec3(0.1, 0.02, 0.12);
            else innerSmoke = vec3(0.15, 0.05, 0.01);
            smokeColor += innerSmoke * radialTemp * lightAtten;
            
            // Blend between fire and smoke based on height and density
            float fireFactor = clamp(temperature * 1.8 - height * 1.5, 0.0, 1.0);
            vec3 color = mix(smokeColor, emitColor, fireFactor);
            
            // Apply light attenuation to fire glow
            color *= (0.5 + 0.5 * lightAtten);

            // Absorption
            float absorption = density * stepSize * uAbsorption;
            float alpha = 1.0 - exp(-absorption);
            
            accumulated += color * alpha * transmittance;
            transmittance *= (1.0 - alpha);
            
            if (transmittance < 0.01) break;
          }
        }

        pos += stepVec;
      }

      // Subtle ambient glow from the core
      float glowIntensity = (1.0 - transmittance) * 0.015;
      vec3 glowCol;
      if (uColorMode == 1) glowCol = vec3(0.1, 0.3, 0.8);
      else if (uColorMode == 2) glowCol = vec3(0.1, 0.7, 0.15);
      else if (uColorMode == 3) glowCol = vec3(0.5, 0.5, 0.55);
      else if (uColorMode == 4) glowCol = vec3(0.6, 0.1, 0.5);
      else glowCol = vec3(0.7, 0.25, 0.05);
      accumulated += glowCol * glowIntensity;

      // Tone mapping (slightly lifted toe for smoke visibility)
      accumulated = accumulated / (accumulated + vec3(0.9));
      // Slight contrast boost
      accumulated = pow(accumulated, vec3(1.05));

      gl_FragColor = vec4(accumulated, 1.0 - transmittance);
    }
  `,
  transparent: true,
  side: THREE.DoubleSide, // Render from all angles
  depthWrite: false,
  blending: THREE.AdditiveBlending,
});

// Volume bounding box - cubic so UVW coordinates are uniform in all directions
const volumeGeo = new THREE.BoxGeometry(2.0, 2.0, 2.0);
const volumeMesh = new THREE.Mesh(volumeGeo, volumeMaterial);
volumeMesh.position.set(0, 0.5, 0);
scene.add(volumeMesh);

// Debug wireframe box to show volume bounds
const wireGeo = new THREE.BoxGeometry(2.0, 2.0, 2.0);
const wireEdges = new THREE.EdgesGeometry(wireGeo);
const wireMat = new THREE.LineBasicMaterial({ color: 0x444444, transparent: true, opacity: 0.4 });
const wireBox = new THREE.LineSegments(wireEdges, wireMat);
wireBox.position.copy(volumeMesh.position);
wireBox.visible = false;
scene.add(wireBox);

// ============ GROUND PLANE ============
const groundMat = new THREE.ShaderMaterial({
  uniforms: {
    uFluid: { value: null },
    uTime: { value: 0 },
    uGroundColorMode: { value: 0 },
  },
  vertexShader: `
    varying vec2 vUv;
    varying vec3 vWorldPos;
    void main() {
      vUv = uv;
      vec4 wp = modelMatrix * vec4(position, 1.0);
      vWorldPos = wp.xyz;
      gl_Position = projectionMatrix * viewMatrix * wp;
    }
  `,
  fragmentShader: `
    precision highp float;
    varying vec2 vUv;
    varying vec3 vWorldPos;
    uniform float uTime;
    uniform int uGroundColorMode;

    void main() {
      float dist = length(vWorldPos.xz);
      float grid = 0.0;
      vec2 gridUv = vWorldPos.xz;
      vec2 gridLine = abs(fract(gridUv - 0.5) - 0.5);
      grid = 1.0 - smoothstep(0.0, 0.03, min(gridLine.x, gridLine.y));
      grid *= 0.15;
      
      // Fire glow on ground
      float glow = exp(-dist * dist * 2.0) * 0.3;
      vec3 groundGlowCol;
      if (uGroundColorMode == 1) groundGlowCol = vec3(0.2, 0.5, 1.0);
      else if (uGroundColorMode == 2) groundGlowCol = vec3(0.2, 1.0, 0.3);
      else if (uGroundColorMode == 3) groundGlowCol = vec3(0.6, 0.6, 0.7);
      else if (uGroundColorMode == 4) groundGlowCol = vec3(0.8, 0.2, 0.7);
      else groundGlowCol = vec3(1.0, 0.4, 0.1);
      vec3 glowColor = groundGlowCol * glow;
      
      float fade = 1.0 - smoothstep(2.0, 5.0, dist);
      vec3 color = vec3(grid * fade * 0.5) + glowColor * fade;
      float alpha = max(grid * fade * 0.5, glow * fade);
      
      gl_FragColor = vec4(color, alpha);
    }
  `,
  transparent: true,
  depthWrite: false,
});

const groundGeo = new THREE.PlaneGeometry(10, 10);
const ground = new THREE.Mesh(groundGeo, groundMat);
ground.rotation.x = -Math.PI / 2;
ground.position.y = -0.5;
scene.add(ground);

// ============ POST PROCESSING ============
const composer = new THREE.EffectComposer(renderer);
const renderPass = new THREE.RenderPass(scene, camera);
composer.addPass(renderPass);

const bloomPass = new THREE.UnrealBloomPass(
  new THREE.Vector2(window.innerWidth, window.innerHeight),
  0.5, // strength
  0.3, // radius
  0.4  // threshold
);
composer.addPass(bloomPass);

const outputPass = new THREE.OutputPass();
composer.addPass(outputPass);

// ============ UI ============
const style = document.createElement('style');
style.textContent = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
  .ctrl-panel {
    position: fixed; top: 20px; left: 20px; z-index: 100;
    font-family: 'Inter', -apple-system, sans-serif;
    color: #e0e0e0; user-select: none;
    background: rgba(10,10,14,0.85);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 10px;
    padding: 16px 18px;
    width: 220px;
    backdrop-filter: blur(12px);
  }
  .ctrl-panel .title {
    font-size: 13px; font-weight: 600; color: #ff8844; margin-bottom: 2px;
  }
  .ctrl-panel .subtitle {
    font-size: 10px; color: #666; margin-bottom: 12px;
  }
  .ctrl-panel label {
    display: flex; justify-content: space-between; align-items: center;
    font-size: 11px; color: #999; margin-bottom: 2px;
  }
  .ctrl-panel label span.val { color: #ccc; font-variant-numeric: tabular-nums; min-width: 32px; text-align: right; }
  .ctrl-panel input[type=range] {
    -webkit-appearance: none; appearance: none; width: 100%; height: 3px;
    background: rgba(255,255,255,0.1); border-radius: 2px; outline: none;
    margin: 2px 0 10px 0; cursor: pointer;
  }
  .ctrl-panel input[type=range]::-webkit-slider-thumb {
    -webkit-appearance: none; width: 12px; height: 12px;
    background: #ff8844; border-radius: 50%; border: none; cursor: pointer;
  }
  .ctrl-panel input[type=range]::-moz-range-thumb {
    width: 12px; height: 12px; background: #ff8844;
    border-radius: 50%; border: none; cursor: pointer;
  }
  .ctrl-panel .fps { font-size: 10px; color: #555; margin-top: 6px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 8px; }
  .ctrl-panel .preset-group {
    display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 12px;
  }
  .ctrl-panel .preset-btn {
    font-family: 'Inter', sans-serif; font-size: 10px; font-weight: 500;
    padding: 4px 8px; border-radius: 5px; cursor: pointer;
    background: rgba(255,255,255,0.06); color: #999;
    border: 1px solid rgba(255,255,255,0.08);
    transition: all 0.2s ease;
  }
  .ctrl-panel .preset-btn:hover {
    background: rgba(255,255,255,0.1); color: #ccc;
  }
  .ctrl-panel .preset-btn.active {
    background: rgba(255,136,68,0.2); color: #ff8844;
    border-color: rgba(255,136,68,0.4);
  }
  .ctrl-panel .section-label {
    font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: 0.5px;
    margin-bottom: 6px; margin-top: 4px;
  }
  .ctrl-panel .toggle-btn {
    font-family: 'Inter', sans-serif; font-size: 10px; font-weight: 500;
    padding: 5px 10px; border-radius: 5px; cursor: pointer;
    background: rgba(255,255,255,0.06); color: #999;
    border: 1px solid rgba(255,255,255,0.08);
    transition: all 0.2s ease; margin-bottom: 10px; display: inline-block;
  }
  .ctrl-panel .toggle-btn:hover {
    background: rgba(255,255,255,0.1); color: #ccc;
  }
  .ctrl-panel .toggle-btn.active {
    background: rgba(255,136,68,0.2); color: #ff8844;
    border-color: rgba(255,136,68,0.4);
  }
`;
document.head.appendChild(style);

const params = {
  dissipation: 0.98,
  buoyancy: 2.5,
  curl: 3.0,
  emitStrength: 3.5,
  flameWidth: 0.5,
  flameHeight: 0.5,
  turbulence: 0.5,
  flameScaleX: 1.0,
  flameScaleY: 1.0,
  flameScaleZ: 1.0,
  showWireframe: false,
  bloomStrength: 0.5,
  bloomThreshold: 0.4,
  brightness: 1.5,
  absorption: 8.0,
  colorMode: 0,
};

const colorPresets = [
  { name: 'Fire', value: 0 },
  { name: 'Blue Plasma', value: 1 },
  { name: 'Green Toxic', value: 2 },
  { name: 'White Steam', value: 3 },
  { name: 'Purple Inferno', value: 4 },
];

function makeSlider(label, key, min, max, step) {
  const val = params[key];
  return `
    <label>${label} <span class="val" id="v_${key}">${val.toFixed(2)}</span></label>
    <input type="range" id="s_${key}" min="${min}" max="${max}" step="${step}" value="${val}">
  `;
}

const panel = document.createElement('div');
panel.className = 'ctrl-panel';
panel.innerHTML = `
  <div class="title">3D Volumetric Fluid</div>
  <div class="subtitle">GPU Navier-Stokes · 64³ · Ray marched</div>
  <div class="section-label">Color Preset</div>
  <div class="preset-group" id="presetGroup">
    ${colorPresets.map(p => `<button class="preset-btn${p.value === 0 ? ' active' : ''}" data-mode="${p.value}">${p.name}</button>`).join('')}
  </div>
  <div class="section-label">Simulation</div>
  ${makeSlider('Dissipation', 'dissipation', 0.9, 1.0, 0.005)}
  ${makeSlider('Buoyancy', 'buoyancy', 0.0, 8.0, 0.1)}
  ${makeSlider('Vorticity', 'curl', 0.0, 10.0, 0.1)}
  ${makeSlider('Emit Strength', 'emitStrength', 0.5, 8.0, 0.1)}
  ${makeSlider('Flame Width', 'flameWidth', 0.0, 1.0, 0.01)}
  ${makeSlider('Flame Height', 'flameHeight', 0.0, 1.0, 0.01)}
  ${makeSlider('Turbulence', 'turbulence', 0.0, 1.0, 0.01)}
  <div class="section-label">Flame Scale</div>
  ${makeSlider('Scale X', 'flameScaleX', 0.3, 2.5, 0.01)}
  ${makeSlider('Scale Y', 'flameScaleY', 0.3, 2.5, 0.01)}
  ${makeSlider('Scale Z', 'flameScaleZ', 0.3, 2.5, 0.01)}
  <div class="section-label">Debug</div>
  <button class="toggle-btn" id="toggleWireframe">Show Volume Box</button>
  <div class="section-label">Rendering</div>
  ${makeSlider('Brightness', 'brightness', 0.3, 4.0, 0.1)}
  ${makeSlider('Absorption', 'absorption', 2.0, 20.0, 0.5)}
  ${makeSlider('Bloom Strength', 'bloomStrength', 0.0, 2.0, 0.05)}
  ${makeSlider('Bloom Threshold', 'bloomThreshold', 0.0, 1.0, 0.05)}
  <div class="fps" id="fpsCounter">FPS: --</div>
`;
document.body.appendChild(panel);

// Wire up sliders
Object.keys(params).forEach(key => {
  const slider = document.getElementById('s_' + key);
  if (!slider) return;
  const valEl = document.getElementById('v_' + key);
  slider.addEventListener('input', () => {
    params[key] = parseFloat(slider.value);
    valEl.textContent = params[key].toFixed(2);
  });
});

// Wire up wireframe toggle
const wireBtn = document.getElementById('toggleWireframe');
wireBtn.addEventListener('click', () => {
  params.showWireframe = !params.showWireframe;
  wireBox.visible = params.showWireframe;
  wireBtn.classList.toggle('active', params.showWireframe);
  wireBtn.textContent = params.showWireframe ? 'Hide Volume Box' : 'Show Volume Box';
});

// Wire up color preset buttons
const presetGroup = document.getElementById('presetGroup');
presetGroup.addEventListener('click', (e) => {
  const btn = e.target.closest('.preset-btn');
  if (!btn) return;
  const mode = parseInt(btn.dataset.mode);
  params.colorMode = mode;
  presetGroup.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
});

// FPS counter
let frameCount = 0;
let lastFpsTime = performance.now();
const fpsEl = document.getElementById('fpsCounter');

// ============ SIMULATION STEP ============
function simulateFluid(dt, time) {
  const gl = renderer.getContext();

  // Sync params to uniforms
  advectMat.uniforms.uDissipation.value = params.dissipation;
  advectMat.uniforms.uBuoyancy.value = params.buoyancy;
  advectMat.uniforms.uCurlStrength.value = params.curl;
  advectMat.uniforms.uEmitStrength.value = params.emitStrength;
  advectMat.uniforms.uFlameWidth.value = params.flameWidth;
  advectMat.uniforms.uFlameHeight.value = params.flameHeight;
  advectMat.uniforms.uTurbulence.value = params.turbulence;
  advectMat.uniforms.uFlameScaleX.value = params.flameScaleX;
  advectMat.uniforms.uFlameScaleY.value = params.flameScaleY;
  advectMat.uniforms.uFlameScaleZ.value = params.flameScaleZ;

  bloomPass.strength = params.bloomStrength;
  bloomPass.threshold = params.bloomThreshold;

  volumeMaterial.uniforms.uBrightness.value = params.brightness;
  volumeMaterial.uniforms.uAbsorption.value = params.absorption;
  volumeMaterial.uniforms.uColorMode.value = params.colorMode;
  volumeMaterial.uniforms.uFlameWidth.value = params.flameWidth;
  volumeMaterial.uniforms.uFlameHeight.value = params.flameHeight;
  volumeMaterial.uniforms.uFlameScaleX.value = params.flameScaleX;
  volumeMaterial.uniforms.uFlameScaleY.value = params.flameScaleY;
  volumeMaterial.uniforms.uFlameScaleZ.value = params.flameScaleZ;
  groundMat.uniforms.uGroundColorMode.value = params.colorMode;

  // 1. Advection + forces
  advectMat.uniforms.uFluid.value = fluidA.texture;
  advectMat.uniforms.uDt.value = Math.min(dt, 0.033);
  advectMat.uniforms.uTime.value = time;
  renderer.setRenderTarget(fluidB);
  renderer.render(advectScene, simCamera);
  
  // Swap
  [fluidA, fluidB] = [fluidB, fluidA];

  // 2. Compute divergence
  divergenceMat.uniforms.uFluid.value = fluidA.texture;
  renderer.setRenderTarget(divergenceRT);
  renderer.render(divScene, simCamera);

  // 3. Jacobi pressure solve (20 iterations)
  // Clear pressure
  renderer.setRenderTarget(pressureRT_A);
  renderer.clearColor();
  
  let pressRead = pressureRT_A;
  let pressWrite = pressureRT_B;

  for (let i = 0; i < 20; i++) {
    jacobiMat.uniforms.uPressure.value = pressRead.texture;
    jacobiMat.uniforms.uDivergence.value = divergenceRT.texture;
    renderer.setRenderTarget(pressWrite);
    renderer.render(jacobiScene, simCamera);
    [pressRead, pressWrite] = [pressWrite, pressRead];
  }

  // 4. Gradient subtraction (pressure projection)
  gradSubMat.uniforms.uFluid.value = fluidA.texture;
  gradSubMat.uniforms.uPressure.value = pressRead.texture;
  renderer.setRenderTarget(fluidB);
  renderer.render(gradSubScene, simCamera);
  
  [fluidA, fluidB] = [fluidB, fluidA];

  renderer.setRenderTarget(null);
}

// ============ ANIMATION LOOP ============
function animate() {
  requestAnimationFrame(animate);

  const dt = Math.min(clock.getDelta(), 0.05);
  const time = clock.getElapsedTime();

  controls.update();

  // Run fluid simulation
  simulateFluid(dt, time);

  // Update volume renderer
  volumeMaterial.uniforms.uFluid.value = fluidA.texture;
  volumeMaterial.uniforms.uCameraPos.value.copy(camera.position);
  volumeMaterial.uniforms.uTime.value = time;
  volumeMesh.updateMatrixWorld();
  volumeMaterial.uniforms.uInvModelMatrix.value.copy(volumeMesh.matrixWorld).invert();

  groundMat.uniforms.uTime.value = time;

  composer.render();

  // FPS
  frameCount++;
  const now = performance.now();
  if (now - lastFpsTime >= 1000) {
    fpsEl.textContent = `FPS: ${frameCount}`;
    frameCount = 0;
    lastFpsTime = now;
  }
}
animate();

// ============ RESIZE ============
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  composer.setSize(window.innerWidth, window.innerHeight);
});