// Scene setup
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x050508);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.z = 2.5;

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);
document.body.appendChild(renderer.domElement);

// Controls
const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.minDistance = 1.5;
controls.maxDistance = 5;

// Lighting
const ambientLight = new THREE.AmbientLight(0xffffff, 0.2);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 0.6);
directionalLight.position.set(5, 3, 5);
scene.add(directionalLight);

// Create Earth globe with darker grayscale texture and fresnel effect
const textureLoader = new THREE.TextureLoader();

// Earth geometry
const earthGeometry = new THREE.SphereGeometry(1, 64, 64);

// Create custom shader material for darker grayscale earth with fresnel
const earthMaterial = new THREE.ShaderMaterial({
  uniforms: {
    earthTexture: { value: null },
    fresnelColor: { value: new THREE.Color(0x4488ff) },
    fresnelPower: { value: 2.5 },
    fresnelIntensity: { value: 0.6 }
  },
  vertexShader: `
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vViewPosition;
    
    void main() {
      vUv = uv;
      vNormal = normalize(normalMatrix * normal);
      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      vViewPosition = -mvPosition.xyz;
      gl_Position = projectionMatrix * mvPosition;
    }
  `,
  fragmentShader: `
    uniform sampler2D earthTexture;
    uniform vec3 fresnelColor;
    uniform float fresnelPower;
    uniform float fresnelIntensity;
    
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vViewPosition;
    
    void main() {
      vec4 texColor = texture2D(earthTexture, vUv);
      float gray = dot(texColor.rgb, vec3(0.299, 0.587, 0.114));
      
      // Make it much darker - land slightly brighter than water
      float adjusted = gray * 0.35 + 0.02;
      
      // Water is darker (detected by lower brightness in original)
      vec3 baseColor;
      if (gray < 0.25) {
        // Water - very dark blue-ish
        baseColor = vec3(0.02, 0.03, 0.06);
      } else {
        // Land - dark gray
        baseColor = vec3(adjusted * 0.8, adjusted * 0.8, adjusted * 0.85);
      }
      
      // Calculate fresnel effect
      vec3 viewDir = normalize(vViewPosition);
      float fresnel = pow(1.0 - abs(dot(viewDir, vNormal)), fresnelPower);
      fresnel *= fresnelIntensity;
      
      // Combine base color with fresnel glow
      vec3 finalColor = baseColor + fresnelColor * fresnel;
      
      gl_FragColor = vec4(finalColor, 1.0);
    }
  `
});

const earth = new THREE.Mesh(earthGeometry, earthMaterial);
scene.add(earth);

// Load earth texture
textureLoader.load(
  'https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg',
  (texture) => {
    earthMaterial.uniforms.earthTexture.value = texture;
  }
);

// Outer atmosphere glow (enhanced to complement fresnel)
const atmosphereGeometry = new THREE.SphereGeometry(1.02, 64, 64);
const atmosphereMaterial = new THREE.ShaderMaterial({
  vertexShader: `
    varying vec3 vNormal;
    varying vec3 vViewPosition;
    
    void main() {
      vNormal = normalize(normalMatrix * normal);
      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      vViewPosition = -mvPosition.xyz;
      gl_Position = projectionMatrix * mvPosition;
    }
  `,
  fragmentShader: `
    varying vec3 vNormal;
    varying vec3 vViewPosition;
    
    void main() {
      vec3 viewDir = normalize(vViewPosition);
      float intensity = pow(0.65 - dot(vNormal, viewDir), 3.0);
      vec3 glowColor = vec3(0.2, 0.5, 1.0);
      gl_FragColor = vec4(glowColor, 1.0) * intensity * 0.4;
    }
  `,
  blending: THREE.AdditiveBlending,
  side: THREE.BackSide,
  transparent: true
});

const atmosphere = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
scene.add(atmosphere);

// World capitals and major cities
const worldCities = [
  { name: "Washington D.C.", country: "USA", lat: 38.9072, lon: -77.0369, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Ottawa", country: "Canada", lat: 45.4215, lon: -75.6972, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Mexico City", country: "Mexico", lat: 19.4326, lon: -99.1332, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Havana", country: "Cuba", lat: 23.1136, lon: -82.3666, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Guatemala City", country: "Guatemala", lat: 14.6349, lon: -90.5069, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "San Salvador", country: "El Salvador", lat: 13.6929, lon: -89.2182, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tegucigalpa", country: "Honduras", lat: 14.0723, lon: -87.1921, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Managua", country: "Nicaragua", lat: 12.1150, lon: -86.2362, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "San Jose", country: "Costa Rica", lat: 9.9281, lon: -84.0907, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Panama City", country: "Panama", lat: 8.9824, lon: -79.5199, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kingston", country: "Jamaica", lat: 17.9714, lon: -76.7920, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Nassau", country: "Bahamas", lat: 25.0480, lon: -77.3554, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Port-au-Prince", country: "Haiti", lat: 18.5944, lon: -72.3074, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Santo Domingo", country: "Dominican Republic", lat: 18.4861, lon: -69.9312, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bogota", country: "Colombia", lat: 4.7110, lon: -74.0721, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Caracas", country: "Venezuela", lat: 10.4806, lon: -66.9036, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Quito", country: "Ecuador", lat: -0.1807, lon: -78.4678, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Lima", country: "Peru", lat: -12.0464, lon: -77.0428, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "La Paz", country: "Bolivia", lat: -16.4897, lon: -68.1193, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Brasilia", country: "Brazil", lat: -15.7975, lon: -47.8919, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Asuncion", country: "Paraguay", lat: -25.2637, lon: -57.5759, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Santiago", country: "Chile", lat: -33.4489, lon: -70.6693, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Buenos Aires", country: "Argentina", lat: -34.6037, lon: -58.3816, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Montevideo", country: "Uruguay", lat: -34.9011, lon: -56.1645, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Georgetown", country: "Guyana", lat: 6.8013, lon: -58.1551, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Paramaribo", country: "Suriname", lat: 5.8520, lon: -55.2038, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Cayenne", country: "French Guiana", lat: 4.9372, lon: -52.3260, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "London", country: "United Kingdom", lat: 51.5074, lon: -0.1278, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Paris", country: "France", lat: 48.8566, lon: 2.3522, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Berlin", country: "Germany", lat: 52.5200, lon: 13.4050, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Madrid", country: "Spain", lat: 40.4168, lon: -3.7038, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Rome", country: "Italy", lat: 41.9028, lon: 12.4964, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Vienna", country: "Austria", lat: 48.2082, lon: 16.3738, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Warsaw", country: "Poland", lat: 52.2297, lon: 21.0122, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Prague", country: "Czech Republic", lat: 50.0755, lon: 14.4378, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Budapest", country: "Hungary", lat: 47.4979, lon: 19.0402, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bucharest", country: "Romania", lat: 44.4268, lon: 26.1025, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Sofia", country: "Bulgaria", lat: 42.6977, lon: 23.3219, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Athens", country: "Greece", lat: 37.9838, lon: 23.7275, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Lisbon", country: "Portugal", lat: 38.7223, lon: -9.1393, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Amsterdam", country: "Netherlands", lat: 52.3676, lon: 4.9041, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Brussels", country: "Belgium", lat: 50.8503, lon: 4.3517, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Copenhagen", country: "Denmark", lat: 55.6761, lon: 12.5683, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Stockholm", country: "Sweden", lat: 59.3293, lon: 18.0686, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Oslo", country: "Norway", lat: 59.9139, lon: 10.7522, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Helsinki", country: "Finland", lat: 60.1699, lon: 24.9384, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Dublin", country: "Ireland", lat: 53.3498, lon: -6.2603, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Reykjavik", country: "Iceland", lat: 64.1466, lon: -21.9426, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bern", country: "Switzerland", lat: 46.9480, lon: 7.4474, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Luxembourg", country: "Luxembourg", lat: 49.6117, lon: 6.1319, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Vaduz", country: "Liechtenstein", lat: 47.1410, lon: 9.5209, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Monaco", country: "Monaco", lat: 43.7384, lon: 7.4246, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Andorra la Vella", country: "Andorra", lat: 42.5063, lon: 1.5218, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "San Marino", country: "San Marino", lat: 43.9424, lon: 12.4578, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Vatican City", country: "Vatican", lat: 41.9029, lon: 12.4534, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Valletta", country: "Malta", lat: 35.8989, lon: 14.5146, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bratislava", country: "Slovakia", lat: 48.1486, lon: 17.1077, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Ljubljana", country: "Slovenia", lat: 46.0569, lon: 14.5058, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Zagreb", country: "Croatia", lat: 45.8150, lon: 15.9819, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Sarajevo", country: "Bosnia", lat: 43.8563, lon: 18.4131, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Belgrade", country: "Serbia", lat: 44.7866, lon: 20.4489, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Podgorica", country: "Montenegro", lat: 42.4304, lon: 19.2594, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Skopje", country: "North Macedonia", lat: 41.9973, lon: 21.4280, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tirana", country: "Albania", lat: 41.3275, lon: 19.8187, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Pristina", country: "Kosovo", lat: 42.6629, lon: 21.1655, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kyiv", country: "Ukraine", lat: 50.4501, lon: 30.5234, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Minsk", country: "Belarus", lat: 53.9006, lon: 27.5590, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Moscow", country: "Russia", lat: 55.7558, lon: 37.6173, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Chisinau", country: "Moldova", lat: 47.0105, lon: 28.8638, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tallinn", country: "Estonia", lat: 59.4370, lon: 24.7536, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Riga", country: "Latvia", lat: 56.9496, lon: 24.1052, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Vilnius", country: "Lithuania", lat: 54.6872, lon: 25.2797, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tokyo", country: "Japan", lat: 35.6762, lon: 139.6503, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Beijing", country: "China", lat: 39.9042, lon: 116.4074, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Seoul", country: "South Korea", lat: 37.5665, lon: 126.9780, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "New Delhi", country: "India", lat: 28.6139, lon: 77.2090, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bangkok", country: "Thailand", lat: 13.7563, lon: 100.5018, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Jakarta", country: "Indonesia", lat: -6.2088, lon: 106.8456, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Manila", country: "Philippines", lat: 14.5995, lon: 120.9842, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Singapore", country: "Singapore", lat: 1.3521, lon: 103.8198, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kuala Lumpur", country: "Malaysia", lat: 3.1390, lon: 101.6869, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Hanoi", country: "Vietnam", lat: 21.0285, lon: 105.8542, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Taipei", country: "Taiwan", lat: 25.0330, lon: 121.5654, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Hong Kong", country: "Hong Kong", lat: 22.3193, lon: 114.1694, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Ankara", country: "Turkey", lat: 39.9334, lon: 32.8597, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tehran", country: "Iran", lat: 35.6892, lon: 51.3890, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Baghdad", country: "Iraq", lat: 33.3152, lon: 44.3661, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Riyadh", country: "Saudi Arabia", lat: 24.7136, lon: 46.6753, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Abu Dhabi", country: "UAE", lat: 24.4539, lon: 54.3773, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Doha", country: "Qatar", lat: 25.2854, lon: 51.5310, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kuwait City", country: "Kuwait", lat: 29.3759, lon: 47.9774, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Muscat", country: "Oman", lat: 23.5880, lon: 58.3829, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Amman", country: "Jordan", lat: 31.9454, lon: 35.9284, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Damascus", country: "Syria", lat: 33.5138, lon: 36.2765, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Beirut", country: "Lebanon", lat: 33.8938, lon: 35.5018, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Jerusalem", country: "Israel", lat: 31.7683, lon: 35.2137, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kabul", country: "Afghanistan", lat: 34.5553, lon: 69.2075, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Islamabad", country: "Pakistan", lat: 33.6844, lon: 73.0479, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Dhaka", country: "Bangladesh", lat: 23.8103, lon: 90.4125, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Colombo", country: "Sri Lanka", lat: 6.9271, lon: 79.8612, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kathmandu", country: "Nepal", lat: 27.7172, lon: 85.3240, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Thimphu", country: "Bhutan", lat: 27.4728, lon: 89.6390, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Naypyidaw", country: "Myanmar", lat: 19.7633, lon: 96.0785, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Vientiane", country: "Laos", lat: 17.9757, lon: 102.6331, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Phnom Penh", country: "Cambodia", lat: 11.5564, lon: 104.9282, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Dili", country: "Timor-Leste", lat: -8.5569, lon: 125.5603, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Ulaanbaatar", country: "Mongolia", lat: 47.8864, lon: 106.9057, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Pyongyang", country: "North Korea", lat: 39.0392, lon: 125.7625, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Baku", country: "Azerbaijan", lat: 40.4093, lon: 49.8671, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tbilisi", country: "Georgia", lat: 41.7151, lon: 44.8271, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Yerevan", country: "Armenia", lat: 40.1792, lon: 44.4991, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Astana", country: "Kazakhstan", lat: 51.1605, lon: 71.4704, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tashkent", country: "Uzbekistan", lat: 41.2995, lon: 69.2401, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bishkek", country: "Kyrgyzstan", lat: 42.8746, lon: 74.5698, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Dushanbe", country: "Tajikistan", lat: 38.5598, lon: 68.7740, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Ashgabat", country: "Turkmenistan", lat: 37.9601, lon: 58.3261, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bandar Seri Begawan", country: "Brunei", lat: 4.9031, lon: 114.9398, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Male", country: "Maldives", lat: 4.1755, lon: 73.5093, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Cairo", country: "Egypt", lat: 30.0444, lon: 31.2357, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Lagos", country: "Nigeria", lat: 6.5244, lon: 3.3792, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Nairobi", country: "Kenya", lat: -1.2921, lon: 36.8219, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Johannesburg", country: "South Africa", lat: -26.2041, lon: 28.0473, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Cape Town", country: "South Africa", lat: -33.9249, lon: 18.4241, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Casablanca", country: "Morocco", lat: 33.5731, lon: -7.5898, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Algiers", country: "Algeria", lat: 36.7538, lon: 3.0588, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tunis", country: "Tunisia", lat: 36.8065, lon: 10.1815, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tripoli", country: "Libya", lat: 32.8872, lon: 13.1913, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Khartoum", country: "Sudan", lat: 15.5007, lon: 32.5599, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Addis Ababa", country: "Ethiopia", lat: 8.9806, lon: 38.7578, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Mogadishu", country: "Somalia", lat: 2.0469, lon: 45.3182, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kampala", country: "Uganda", lat: 0.3476, lon: 32.5825, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kigali", country: "Rwanda", lat: -1.9403, lon: 29.8739, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bujumbura", country: "Burundi", lat: -3.3731, lon: 29.3644, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Dar es Salaam", country: "Tanzania", lat: -6.7924, lon: 39.2083, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Lusaka", country: "Zambia", lat: -15.3875, lon: 28.3228, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Harare", country: "Zimbabwe", lat: -17.8252, lon: 31.0335, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Maputo", country: "Mozambique", lat: -25.9692, lon: 32.5732, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Pretoria", country: "South Africa", lat: -25.7479, lon: 28.2293, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Gaborone", country: "Botswana", lat: -24.6282, lon: 25.9231, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Windhoek", country: "Namibia", lat: -22.5609, lon: 17.0658, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Luanda", country: "Angola", lat: -8.8390, lon: 13.2894, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kinshasa", country: "DR Congo", lat: -4.4419, lon: 15.2663, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Brazzaville", country: "Congo", lat: -4.2634, lon: 15.2429, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Libreville", country: "Gabon", lat: 0.4162, lon: 9.4673, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Yaounde", country: "Cameroon", lat: 3.8480, lon: 11.5021, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Malabo", country: "Equatorial Guinea", lat: 3.7504, lon: 8.7371, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Sao Tome", country: "Sao Tome", lat: 0.3302, lon: 6.7333, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bangui", country: "Central African Republic", lat: 4.3947, lon: 18.5582, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "N'Djamena", country: "Chad", lat: 12.1348, lon: 15.0557, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Niamey", country: "Niger", lat: 13.5116, lon: 2.1254, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Ouagadougou", country: "Burkina Faso", lat: 12.3714, lon: -1.5197, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bamako", country: "Mali", lat: 12.6392, lon: -8.0029, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Dakar", country: "Senegal", lat: 14.7167, lon: -17.4677, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Banjul", country: "Gambia", lat: 13.4549, lon: -16.5790, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bissau", country: "Guinea-Bissau", lat: 11.8816, lon: -15.6178, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Conakry", country: "Guinea", lat: 9.6412, lon: -13.5784, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Freetown", country: "Sierra Leone", lat: 8.4657, lon: -13.2317, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Monrovia", country: "Liberia", lat: 6.2907, lon: -10.7605, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Yamoussoukro", country: "Ivory Coast", lat: 6.8276, lon: -5.2893, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Accra", country: "Ghana", lat: 5.6037, lon: -0.1870, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Lome", country: "Togo", lat: 6.1256, lon: 1.2254, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Porto-Novo", country: "Benin", lat: 6.4969, lon: 2.6289, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Abuja", country: "Nigeria", lat: 9.0765, lon: 7.3986, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Nouakchott", country: "Mauritania", lat: 18.0735, lon: -15.9582, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Rabat", country: "Morocco", lat: 34.0209, lon: -6.8416, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Praia", country: "Cape Verde", lat: 14.9331, lon: -23.5133, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Asmara", country: "Eritrea", lat: 15.3229, lon: 38.9251, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Djibouti", country: "Djibouti", lat: 11.5721, lon: 43.1456, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Antananarivo", country: "Madagascar", lat: -18.8792, lon: 47.5079, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Port Louis", country: "Mauritius", lat: -20.1609, lon: 57.5012, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Victoria", country: "Seychelles", lat: -4.6191, lon: 55.4513, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Moroni", country: "Comoros", lat: -11.7022, lon: 43.2551, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Lilongwe", country: "Malawi", lat: -13.9626, lon: 33.7741, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Mbabane", country: "Eswatini", lat: -26.3054, lon: 31.1367, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Maseru", country: "Lesotho", lat: -29.3167, lon: 27.4833, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Canberra", country: "Australia", lat: -35.2809, lon: 149.1300, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Wellington", country: "New Zealand", lat: -41.2866, lon: 174.7756, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Suva", country: "Fiji", lat: -18.1416, lon: 178.4419, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Port Moresby", country: "Papua New Guinea", lat: -9.4438, lon: 147.1803, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Honiara", country: "Solomon Islands", lat: -9.4456, lon: 159.9729, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Port Vila", country: "Vanuatu", lat: -17.7334, lon: 168.3273, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Noumea", country: "New Caledonia", lat: -22.2558, lon: 166.4505, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Apia", country: "Samoa", lat: -13.8506, lon: -171.7513, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Nuku'alofa", country: "Tonga", lat: -21.2114, lon: -175.1998, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tarawa", country: "Kiribati", lat: 1.3382, lon: 173.0176, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Majuro", country: "Marshall Islands", lat: 7.0897, lon: 171.3803, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Palikir", country: "Micronesia", lat: 6.9248, lon: 158.1610, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Funafuti", country: "Tuvalu", lat: -8.5211, lon: 179.1962, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Yaren", country: "Nauru", lat: -0.5477, lon: 166.9209, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Sydney", country: "Australia", lat: -33.8688, lon: 151.2093, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Melbourne", country: "Australia", lat: -37.8136, lon: 144.9631, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Auckland", country: "New Zealand", lat: -36.8509, lon: 174.7645, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Mumbai", country: "India", lat: 19.0760, lon: 72.8777, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Shanghai", country: "China", lat: 31.2304, lon: 121.4737, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Sao Paulo", country: "Brazil", lat: -23.5505, lon: -46.6333, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Rio de Janeiro", country: "Brazil", lat: -22.9068, lon: -43.1729, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Istanbul", country: "Turkey", lat: 41.0082, lon: 28.9784, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Dubai", country: "UAE", lat: 25.2048, lon: 55.2708, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "St. Petersburg", country: "Russia", lat: 59.9311, lon: 30.3609, temp: null, humidity: null, windSpeed: null, weatherCode: null }
];

// US Cities
const usCities = [
  { name: "New York", country: "USA", lat: 40.7128, lon: -74.0060, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Los Angeles", country: "USA", lat: 34.0522, lon: -118.2437, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Chicago", country: "USA", lat: 41.8781, lon: -87.6298, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Houston", country: "USA", lat: 29.7604, lon: -95.3698, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Phoenix", country: "USA", lat: 33.4484, lon: -112.0740, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Philadelphia", country: "USA", lat: 39.9526, lon: -75.1652, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "San Antonio", country: "USA", lat: 29.4241, lon: -98.4936, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "San Diego", country: "USA", lat: 32.7157, lon: -117.1611, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Dallas", country: "USA", lat: 32.7767, lon: -96.7970, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "San Jose", country: "USA", lat: 37.3382, lon: -121.8863, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Austin", country: "USA", lat: 30.2672, lon: -97.7431, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Jacksonville", country: "USA", lat: 30.3322, lon: -81.6557, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Fort Worth", country: "USA", lat: 32.7555, lon: -97.3308, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Columbus", country: "USA", lat: 39.9612, lon: -82.9988, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Charlotte", country: "USA", lat: 35.2271, lon: -80.8431, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "San Francisco", country: "USA", lat: 37.7749, lon: -122.4194, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Indianapolis", country: "USA", lat: 39.7684, lon: -86.1581, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Seattle", country: "USA", lat: 47.6062, lon: -122.3321, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Denver", country: "USA", lat: 39.7392, lon: -104.9903, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Boston", country: "USA", lat: 42.3601, lon: -71.0589, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "El Paso", country: "USA", lat: 31.7619, lon: -106.4850, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Nashville", country: "USA", lat: 36.1627, lon: -86.7816, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Detroit", country: "USA", lat: 42.3314, lon: -83.0458, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Oklahoma City", country: "USA", lat: 35.4676, lon: -97.5164, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Portland", country: "USA", lat: 45.5155, lon: -122.6789, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Las Vegas", country: "USA", lat: 36.1699, lon: -115.1398, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Memphis", country: "USA", lat: 35.1495, lon: -90.0490, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Louisville", country: "USA", lat: 38.2527, lon: -85.7585, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Baltimore", country: "USA", lat: 39.2904, lon: -76.6122, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Milwaukee", country: "USA", lat: 43.0389, lon: -87.9065, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Albuquerque", country: "USA", lat: 35.0844, lon: -106.6504, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tucson", country: "USA", lat: 32.2226, lon: -110.9747, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Fresno", country: "USA", lat: 36.7378, lon: -119.7871, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Sacramento", country: "USA", lat: 38.5816, lon: -121.4944, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Kansas City", country: "USA", lat: 39.0997, lon: -94.5786, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Mesa", country: "USA", lat: 33.4152, lon: -111.8315, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Atlanta", country: "USA", lat: 33.7490, lon: -84.3880, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Omaha", country: "USA", lat: 41.2565, lon: -95.9345, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Colorado Springs", country: "USA", lat: 38.8339, lon: -104.8214, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Raleigh", country: "USA", lat: 35.7796, lon: -78.6382, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Miami", country: "USA", lat: 25.7617, lon: -80.1918, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Long Beach", country: "USA", lat: 33.7701, lon: -118.1937, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Virginia Beach", country: "USA", lat: 36.8529, lon: -75.9780, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Oakland", country: "USA", lat: 37.8044, lon: -122.2712, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Minneapolis", country: "USA", lat: 44.9778, lon: -93.2650, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tampa", country: "USA", lat: 27.9506, lon: -82.4572, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Tulsa", country: "USA", lat: 36.1540, lon: -95.9928, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Arlington", country: "USA", lat: 32.7357, lon: -97.1081, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "New Orleans", country: "USA", lat: 29.9511, lon: -90.0715, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Wichita", country: "USA", lat: 37.6872, lon: -97.3301, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Cleveland", country: "USA", lat: 41.4993, lon: -81.6944, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bakersfield", country: "USA", lat: 35.3733, lon: -119.0187, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Aurora", country: "USA", lat: 39.7294, lon: -104.8319, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Anaheim", country: "USA", lat: 33.8366, lon: -117.9143, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Honolulu", country: "USA", lat: 21.3069, lon: -157.8583, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Santa Ana", country: "USA", lat: 33.7455, lon: -117.8677, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Riverside", country: "USA", lat: 33.9806, lon: -117.3755, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Corpus Christi", country: "USA", lat: 27.8006, lon: -97.3964, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Lexington", country: "USA", lat: 38.0406, lon: -84.5037, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Henderson", country: "USA", lat: 36.0395, lon: -114.9817, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Stockton", country: "USA", lat: 37.9577, lon: -121.2908, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Saint Paul", country: "USA", lat: 44.9537, lon: -93.0900, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Cincinnati", country: "USA", lat: 39.1031, lon: -84.5120, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "St. Louis", country: "USA", lat: 38.6270, lon: -90.1994, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Pittsburgh", country: "USA", lat: 40.4406, lon: -79.9959, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Greensboro", country: "USA", lat: 36.0726, lon: -79.7920, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Lincoln", country: "USA", lat: 40.8258, lon: -96.6852, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Anchorage", country: "USA", lat: 61.2181, lon: -149.9003, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Plano", country: "USA", lat: 33.0198, lon: -96.6989, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Orlando", country: "USA", lat: 28.5383, lon: -81.3792, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Irvine", country: "USA", lat: 33.6846, lon: -117.8265, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Newark", country: "USA", lat: 40.7357, lon: -74.1724, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Durham", country: "USA", lat: 35.9940, lon: -78.8986, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Chula Vista", country: "USA", lat: 32.6401, lon: -117.0842, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Toledo", country: "USA", lat: 41.6528, lon: -83.5379, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Fort Wayne", country: "USA", lat: 41.0793, lon: -85.1394, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "St. Petersburg", country: "USA", lat: 27.7676, lon: -82.6403, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Laredo", country: "USA", lat: 27.5306, lon: -99.4803, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Jersey City", country: "USA", lat: 40.7282, lon: -74.0776, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Chandler", country: "USA", lat: 33.3062, lon: -111.8413, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Madison", country: "USA", lat: 43.0731, lon: -89.4012, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Lubbock", country: "USA", lat: 33.5779, lon: -101.8552, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Scottsdale", country: "USA", lat: 33.4942, lon: -111.9261, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Reno", country: "USA", lat: 39.5296, lon: -119.8138, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Buffalo", country: "USA", lat: 42.8864, lon: -78.8784, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Gilbert", country: "USA", lat: 33.3528, lon: -111.7890, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Glendale", country: "USA", lat: 33.5387, lon: -112.1860, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "North Las Vegas", country: "USA", lat: 36.1989, lon: -115.1175, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Winston-Salem", country: "USA", lat: 36.0999, lon: -80.2442, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Chesapeake", country: "USA", lat: 36.7682, lon: -76.2875, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Norfolk", country: "USA", lat: 36.8508, lon: -76.2859, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Fremont", country: "USA", lat: 37.5485, lon: -121.9886, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Garland", country: "USA", lat: 32.9126, lon: -96.6389, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Irving", country: "USA", lat: 32.8140, lon: -96.9489, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Hialeah", country: "USA", lat: 25.8576, lon: -80.2781, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Richmond", country: "USA", lat: 37.5407, lon: -77.4360, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Boise", country: "USA", lat: 43.6150, lon: -116.2023, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Spokane", country: "USA", lat: 47.6588, lon: -117.4260, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Baton Rouge", country: "USA", lat: 30.4515, lon: -91.1871, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Des Moines", country: "USA", lat: 41.5868, lon: -93.6250, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Salt Lake City", country: "USA", lat: 40.7608, lon: -111.8910, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Birmingham", country: "USA", lat: 33.5207, lon: -86.8025, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Rochester", country: "USA", lat: 43.1566, lon: -77.6088, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Providence", country: "USA", lat: 41.8240, lon: -71.4128, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Bridgeport", country: "USA", lat: 41.1865, lon: -73.1952, temp: null, humidity: null, windSpeed: null, weatherCode: null },
  { name: "Hartford", country: "USA", lat: 41.7658, lon: -72.6734, temp: null, humidity: null, windSpeed: null, weatherCode: null }
];

// Combine all cities
const allCities = [...worldCities, ...usCities];

// Weather code to description mapping
const weatherDescriptions = {
  0: { text: "Clear sky", icon: "☀️" },
  1: { text: "Mainly clear", icon: "🌤️" },
  2: { text: "Partly cloudy", icon: "⛅" },
  3: { text: "Overcast", icon: "☁️" },
  45: { text: "Foggy", icon: "🌫️" },
  48: { text: "Depositing rime fog", icon: "🌫️" },
  51: { text: "Light drizzle", icon: "🌧️" },
  53: { text: "Moderate drizzle", icon: "🌧️" },
  55: { text: "Dense drizzle", icon: "🌧️" },
  56: { text: "Light freezing drizzle", icon: "🌧️" },
  57: { text: "Dense freezing drizzle", icon: "🌧️" },
  61: { text: "Slight rain", icon: "🌧️" },
  63: { text: "Moderate rain", icon: "🌧️" },
  65: { text: "Heavy rain", icon: "🌧️" },
  66: { text: "Light freezing rain", icon: "🌧️" },
  67: { text: "Heavy freezing rain", icon: "🌧️" },
  71: { text: "Slight snow", icon: "🌨️" },
  73: { text: "Moderate snow", icon: "🌨️" },
  75: { text: "Heavy snow", icon: "🌨️" },
  77: { text: "Snow grains", icon: "🌨️" },
  80: { text: "Slight rain showers", icon: "🌦️" },
  81: { text: "Moderate rain showers", icon: "🌦️" },
  82: { text: "Violent rain showers", icon: "🌦️" },
  85: { text: "Slight snow showers", icon: "🌨️" },
  86: { text: "Heavy snow showers", icon: "🌨️" },
  95: { text: "Thunderstorm", icon: "⛈️" },
  96: { text: "Thunderstorm with hail", icon: "⛈️" },
  99: { text: "Thunderstorm with heavy hail", icon: "⛈️" }
};

function getWeatherDescription(code) {
  return weatherDescriptions[code] || { text: "Unknown", icon: "❓" };
}

// Temperature color function
function getTemperatureColor(temp) {
  if (temp === null) return new THREE.Color(0x444444);
  if (temp <= -10) return new THREE.Color(0x0066ff);
  if (temp <= 0) return new THREE.Color(0x00aaff);
  if (temp <= 10) return new THREE.Color(0x00ddff);
  if (temp <= 15) return new THREE.Color(0x00ffaa);
  if (temp <= 20) return new THREE.Color(0x88ff00);
  if (temp <= 25) return new THREE.Color(0xffee00);
  if (temp <= 30) return new THREE.Color(0xff8800);
  if (temp <= 35) return new THREE.Color(0xff4400);
  return new THREE.Color(0xff0000);
}

// Convert lat/lon to 3D position
function latLonToVector3(lat, lon, radius) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);
  const x = -radius * Math.sin(phi) * Math.cos(theta);
  const y = radius * Math.cos(phi);
  const z = radius * Math.sin(phi) * Math.sin(theta);
  return new THREE.Vector3(x, y, z);
}

// Create city markers group
const cityMarkersGroup = new THREE.Group();
scene.add(cityMarkersGroup);

// Store marker references for updating
const markerData = [];

// Create markers for all cities
const markerGeometry = new THREE.SphereGeometry(0.012, 12, 12);

allCities.forEach((city, index) => {
  const position = latLonToVector3(city.lat, city.lon, 1.01);
  const color = getTemperatureColor(city.temp);
  
  const material = new THREE.MeshBasicMaterial({ 
    color: color,
    transparent: true,
    opacity: 0.9
  });
  
  const marker = new THREE.Mesh(markerGeometry, material);
  marker.position.copy(position);
  marker.userData = { ...city, isUS: usCities.some(c => c.name === city.name), index };
  cityMarkersGroup.add(marker);
  
  markerData.push({ marker, material, city });
});

// Add Google Fonts
const link = document.createElement('link');
link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
link.rel = 'stylesheet';
document.head.appendChild(link);

// Add styles
const styleSheet = document.createElement('style');
styleSheet.textContent = `
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { overflow: hidden; cursor: grab; background: #050508; }
  body:active { cursor: grabbing; }
`;
document.head.appendChild(styleSheet);

// Create bottom status bar for loading
const statusBar = document.createElement('div');
statusBar.style.cssText = `
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 48px;
  background: rgba(5, 5, 8, 0.95);
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  font-family: 'Inter', -apple-system, sans-serif;
  color: white;
  z-index: 1000;
`;

statusBar.innerHTML = `
  <div style="display: flex; align-items: center; gap: 12px;">
    <div id="statusIndicator" style="width: 8px; height: 8px; border-radius: 50%; background: #ffaa00; animation: pulse 1.5s infinite;"></div>
    <span id="statusText" style="font-size: 12px; color: rgba(255,255,255,0.7);">Loading weather data...</span>
  </div>
  <div style="display: flex; align-items: center; gap: 20px;">
    <span id="progressText" style="font-size: 11px; color: rgba(255,255,255,0.4);">0 / ${allCities.length}</span>
    <div style="width: 120px; height: 3px; background: rgba(255,255,255,0.1); border-radius: 2px; overflow: hidden;">
      <div id="progressBar" style="width: 0%; height: 100%; background: #00ccff; transition: width 0.3s ease;"></div>
    </div>
  </div>
`;
document.body.appendChild(statusBar);

// Add pulse animation
const pulseStyle = document.createElement('style');
pulseStyle.textContent = `
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
  }
`;
document.head.appendChild(pulseStyle);

// Fetch real-time weather data asynchronously
let loadedCount = 0;
let lastUpdateTime = null;

async function fetchWeatherData() {
  const statusText = document.getElementById('statusText');
  const statusIndicator = document.getElementById('statusIndicator');
  const progressText = document.getElementById('progressText');
  const progressBar = document.getElementById('progressBar');
  
  loadedCount = 0;
  statusIndicator.style.background = '#ffaa00';
  statusIndicator.style.animation = 'pulse 1.5s infinite';
  
  // Fetch in small batches without blocking
  const batchSize = 20;
  
  for (let i = 0; i < allCities.length; i += batchSize) {
    const batch = allCities.slice(i, Math.min(i + batchSize, allCities.length));
    
    // Process batch concurrently
    batch.forEach(async (city, batchIndex) => {
      const globalIndex = i + batchIndex;
      try {
        const response = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&timezone=auto`
        );
        
        if (response.ok) {
          const data = await response.json();
          if (data.current) {
            allCities[globalIndex].temp = data.current.temperature_2m !== undefined ? Math.round(data.current.temperature_2m) : null;
            allCities[globalIndex].humidity = data.current.relative_humidity_2m;
            allCities[globalIndex].windSpeed = data.current.wind_speed_10m;
            allCities[globalIndex].weatherCode = data.current.weather_code;
            
            // Update marker
            const markerInfo = markerData[globalIndex];
            const color = getTemperatureColor(allCities[globalIndex].temp);
            markerInfo.material.color = color;
            markerInfo.marker.userData = { ...allCities[globalIndex], isUS: usCities.some(c => c.name === city.name), index: globalIndex };
          }
        }
      } catch (error) {
        // Silently fail for individual cities
      }
      
      loadedCount++;
      const progress = Math.round((loadedCount / allCities.length) * 100);
      progressText.textContent = `${loadedCount} / ${allCities.length}`;
      progressBar.style.width = `${progress}%`;
      statusText.textContent = `Loading weather data... ${progress}%`;
    });
    
    // Small delay between batches to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  
  // Wait for all requests to complete
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  lastUpdateTime = new Date();
  statusIndicator.style.background = '#00ff88';
  statusIndicator.style.animation = 'none';
  statusText.textContent = `Live weather data • Updated ${lastUpdateTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
  updateInfoPanel();
}

// Create info panel
const infoPanel = document.createElement('div');
infoPanel.style.cssText = `
  position: fixed;
  top: 20px;
  left: 20px;
  background: rgba(5, 5, 8, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 12px;
  padding: 20px;
  font-family: 'Inter', -apple-system, sans-serif;
  color: white;
  z-index: 1000;
  min-width: 200px;
`;
document.body.appendChild(infoPanel);

function updateInfoPanel() {
  infoPanel.innerHTML = `
    <div style="font-size: 14px; font-weight: 600; margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
      <span style="font-size: 18px;">🌡️</span> Global Temperature
    </div>
    <div style="font-size: 11px; color: rgba(255,255,255,0.5); line-height: 1.8;">
      <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
        <span>World Capitals</span>
        <span style="color: #00ccff; font-weight: 500;">${worldCities.length}</span>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <span>US Cities</span>
        <span style="color: #ff8800; font-weight: 500;">${usCities.length}</span>
      </div>
    </div>
    <div style="margin-top: 16px; padding-top: 12px; border-top: 1px solid rgba(255,255,255,0.08); font-size: 10px; color: rgba(255,255,255,0.3);">
      Hover markers for details
    </div>
  `;
}
updateInfoPanel();

// Create temperature legend
const legend = document.createElement('div');
legend.style.cssText = `
  position: fixed;
  top: 20px;
  right: 20px;
  background: rgba(5, 5, 8, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 12px;
  padding: 16px;
  font-family: 'Inter', -apple-system, sans-serif;
  color: white;
  z-index: 1000;
`;

const legendItems = [
  { color: '#ff0000', label: '> 35°C' },
  { color: '#ff4400', label: '30-35°C' },
  { color: '#ff8800', label: '25-30°C' },
  { color: '#ffee00', label: '20-25°C' },
  { color: '#88ff00', label: '15-20°C' },
  { color: '#00ffaa', label: '10-15°C' },
  { color: '#00ddff', label: '0-10°C' },
  { color: '#00aaff', label: '-10-0°C' },
  { color: '#0066ff', label: '< -10°C' }
];

legend.innerHTML = `
  <div style="font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,0.5); margin-bottom: 12px;">Temperature</div>
  ${legendItems.map(item => `
    <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px; font-size: 10px;">
      <div style="width: 10px; height: 10px; border-radius: 50%; background: ${item.color};"></div>
      <span style="color: rgba(255,255,255,0.6);">${item.label}</span>
    </div>
  `).join('')}
`;
document.body.appendChild(legend);

// Create tooltip
const tooltip = document.createElement('div');
tooltip.style.cssText = `
  position: fixed;
  background: rgba(5, 5, 8, 0.98);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 12px;
  padding: 16px 20px;
  font-family: 'Inter', -apple-system, sans-serif;
  color: white;
  pointer-events: none;
  display: none;
  z-index: 2000;
  min-width: 220px;
  backdrop-filter: blur(10px);
`;
document.body.appendChild(tooltip);

// Raycaster for hover detection
const raycaster = new THREE.Raycaster();
raycaster.params.Points.threshold = 0.02;
const mouse = new THREE.Vector2();

let hoveredMarker = null;

function onMouseMove(event) {
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
  
  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObjects(cityMarkersGroup.children);
  
  if (intersects.length > 0) {
    const cityData = intersects[0].object.userData;
    if (cityData && cityData.name) {
      hoveredMarker = intersects[0].object;
      
      const temp = cityData.temp;
      const humidity = cityData.humidity;
      const windSpeed = cityData.windSpeed;
      const weatherCode = cityData.weatherCode;
      const weather = getWeatherDescription(weatherCode);
      const color = getTemperatureColor(temp);
      const hexColor = '#' + color.getHexString();
      
      const tempC = temp !== null ? `${temp}°C` : '—';
      const tempF = temp !== null ? `${Math.round(temp * 9/5 + 32)}°F` : '';
      const humidityText = humidity !== null ? `${humidity}%` : '—';
      const windText = windSpeed !== null ? `${Math.round(windSpeed)} km/h` : '—';
      
      const typeColor = cityData.isUS ? '#ff8800' : '#00ccff';
      const typeLabel = cityData.isUS ? 'US City' : 'Capital';
      
      tooltip.innerHTML = `
        <div style="display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 12px;">
          <div>
            <div style="font-size: 16px; font-weight: 600;">${cityData.name}</div>
            <div style="font-size: 11px; color: rgba(255,255,255,0.4); margin-top: 2px;">${cityData.country}</div>
          </div>
          <div style="font-size: 9px; padding: 3px 8px; border-radius: 4px; background: ${typeColor}22; color: ${typeColor}; font-weight: 500;">${typeLabel}</div>
        </div>
        
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid rgba(255,255,255,0.08);">
          <div style="width: 48px; height: 48px; border-radius: 12px; background: ${hexColor}22; display: flex; align-items: center; justify-content: center; font-size: 24px;">
            ${weather.icon}
          </div>
          <div>
            <div style="font-size: 28px; font-weight: 700; color: ${hexColor};">${tempC}</div>
            <div style="font-size: 11px; color: rgba(255,255,255,0.4);">${tempF}</div>
          </div>
        </div>
        
        <div style="font-size: 12px; color: rgba(255,255,255,0.7); margin-bottom: 12px;">${weather.text}</div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 11px;">
          <div style="background: rgba(255,255,255,0.04); padding: 8px 10px; border-radius: 6px;">
            <div style="color: rgba(255,255,255,0.4); margin-bottom: 2px;">Humidity</div>
            <div style="font-weight: 500;">${humidityText}</div>
          </div>
          <div style="background: rgba(255,255,255,0.04); padding: 8px 10px; border-radius: 6px;">
            <div style="color: rgba(255,255,255,0.4); margin-bottom: 2px;">Wind</div>
            <div style="font-weight: 500;">${windText}</div>
          </div>
        </div>
        
        <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(255,255,255,0.08); font-size: 10px; color: rgba(255,255,255,0.3);">
          📍 ${Math.abs(cityData.lat).toFixed(2)}°${cityData.lat >= 0 ? 'N' : 'S'}, ${Math.abs(cityData.lon).toFixed(2)}°${cityData.lon >= 0 ? 'E' : 'W'}
        </div>
      `;
      
      tooltip.style.display = 'block';
      
      // Position tooltip
      let left = event.clientX + 20;
      let top = event.clientY - 20;
      
      const tooltipRect = tooltip.getBoundingClientRect();
      if (left + tooltipRect.width > window.innerWidth - 20) {
        left = event.clientX - tooltipRect.width - 20;
      }
      if (top + tooltipRect.height > window.innerHeight - 60) {
        top = window.innerHeight - tooltipRect.height - 60;
      }
      if (top < 20) top = 20;
      
      tooltip.style.left = left + 'px';
      tooltip.style.top = top + 'px';
      
      document.body.style.cursor = 'pointer';
    }
  } else {
    tooltip.style.display = 'none';
    hoveredMarker = null;
    document.body.style.cursor = 'grab';
  }
}

window.addEventListener('mousemove', onMouseMove);

// Start fetching weather data immediately (non-blocking)
fetchWeatherData();

// Refresh weather data every 10 minutes
setInterval(fetchWeatherData, 600000);

// Animation loop
function animate() {
  requestAnimationFrame(animate);
  
  // Slow auto-rotation
  earth.rotation.y += 0.0002;
  atmosphere.rotation.y += 0.0002;
  cityMarkersGroup.rotation.y += 0.0002;
  
  // Pulse hovered marker
  if (hoveredMarker) {
    const scale = 1 + Math.sin(Date.now() * 0.005) * 0.3;
    hoveredMarker.scale.setScalar(scale);
  }
  
  // Reset non-hovered markers
  markerData.forEach(({ marker }) => {
    if (marker !== hoveredMarker) {
      marker.scale.setScalar(1);
    }
  });
  
  controls.update();
  renderer.render(scene, camera);
}

animate();

// Handle resize
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});