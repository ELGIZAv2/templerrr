# Remix: 3D Globe Weather

Created with [Omma](https://omma.build)

## Setup

Open `index.html` in your browser, or:

```bash
npx serve .
```
