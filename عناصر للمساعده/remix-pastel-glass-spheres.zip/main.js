// Scene setup
const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf0eeeb);

const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 0, 18);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = false;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.4;
document.body.appendChild(renderer.domElement);

// Lights
const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
scene.add(ambientLight);

const mainLight = new THREE.DirectionalLight(0xffffff, 1.8);
mainLight.position.set(5, 10, 8);
scene.add(mainLight);

// Sphere cluster
const sphereGroup = new THREE.Group();
scene.add(sphereGroup);

// Modern color palette
const palette = [
  { color: 0xfaf5eb, roughness: 0.3, metalness: 0.08 },   // cream
  { color: 0xb8d8d0, roughness: 0.35, metalness: 0.05 },   // sage mint
  { color: 0xe09080, roughness: 0.28, metalness: 0.1 },   // soft terracotta
  { color: 0xf2c4c4, roughness: 0.3, metalness: 0.08 },   // blush pink
  { color: 0xfaf5eb, roughness: 0.32, metalness: 0.06 },   // cream light
  { color: 0xb8d8d0, roughness: 0.35, metalness: 0.05 },   // sage mint alt
  { color: 0xe09080, roughness: 0.28, metalness: 0.1 },   // soft terracotta alt
  { color: 0xf2c4c4, roughness: 0.35, metalness: 0.05 },   // blush pink alt
];

const sphereMaterials = palette.map((p, i) => {
  if (i % 2 === 0) {
    // Glass material using physical transmission
    return new THREE.MeshPhysicalMaterial({
      color: p.color,
      roughness: 0.05,
      metalness: 0.0,
      transmission: 0.92,
      thickness: 1.5,
      ior: 1.45,
      envMapIntensity: 0.6,
      transparent: true,
      opacity: 1.0,
      attenuationColor: new THREE.Color(p.color),
      attenuationDistance: 2.0,
      specularIntensity: 0.5,
      specularColor: new THREE.Color(0xffffff),
    });
  } else {
    return new THREE.MeshPhysicalMaterial({
      color: p.color,
      roughness: 0,
      metalness: Math.min(0.5, p.metalness + 0.25),
      envMapIntensity: 2.5,
      clearcoat: 0.0,
      clearcoatRoughness: 0.3,
      reflectivity: 1.0,
      specularIntensity: 1.0,
      specularColor: new THREE.Color(0xffffff),
    });
  }
});

const goldMaterial = new THREE.MeshStandardMaterial({
  color: 0xe2c06d,
  roughness: 0.15,
  metalness: 0.95,
});

// Physics state
const spheres = [];
const sphereCount = 55;
const DAMPING = 0.96;
const SPRING_STRENGTH = 0.002;
const REPEL_FORCE = 0.08;
const MOUSE_RADIUS = 4.0;
const MOUSE_STRENGTH = 0.35;

// Mouse 3D position for physics
const mouse3D = new THREE.Vector3();
const raycaster = new THREE.Raycaster();
const mouseNDC = new THREE.Vector2();
const interactionPlane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);

// Camera orbit state (now used for sphere group rotation)
const cameraOrbit = {
  radius: 18,
  theta: 0,    // horizontal angle
  phi: Math.PI / 2, // vertical angle (PI/2 = equator)
  targetTheta: 0,
  targetPhi: Math.PI / 2,
};

// Track current rotation angle for env map counter-rotation
let currentGroupRotationY = 0;
let envRotSpeedMultiplier = 10.0;
let gradientIntensity = 1.0;
let gradientRadiusParam = 3.0;

function randomInSphere(radius) {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = radius * Math.cbrt(Math.random());
  return {
    x: r * Math.sin(phi) * Math.cos(theta),
    y: r * Math.sin(phi) * Math.sin(theta) * 0.65,
    z: r * Math.cos(phi) * 0.7,
  };
}

// Create spheres
for (let i = 0; i < sphereCount; i++) {
  const radius = 0.4 + Math.random() * 0.9;
  const pos = randomInSphere(4.5);
  
  const sphereGeo = new THREE.SphereGeometry(radius, 32, 32);
  const mat = sphereMaterials[i % sphereMaterials.length];
  const sphereMesh = new THREE.Mesh(sphereGeo, mat);
  sphereMesh.position.set(pos.x, pos.y, pos.z);
  sphereMesh.castShadow = false;
  sphereMesh.receiveShadow = false;
  
  sphereGroup.add(sphereMesh);
  
  spheres.push({
    mesh: sphereMesh,
    basePos: { x: pos.x, y: pos.y, z: pos.z },
    velocity: { x: 0, y: 0, z: 0 },
    radius: radius,
    phase: Math.random() * Math.PI * 2,
    floatSpeed: 0.3 + Math.random() * 0.4,
    floatAmp: 0.02 + Math.random() * 0.04,
    mass: radius * radius,
  });
}

// Physics collision with velocity response
function resolveSphereCollisions() {
  for (let i = 0; i < spheres.length; i++) {
    for (let j = i + 1; j < spheres.length; j++) {
      const a = spheres[i];
      const b = spheres[j];
      const dx = a.mesh.position.x - b.mesh.position.x;
      const dy = a.mesh.position.y - b.mesh.position.y;
      const dz = a.mesh.position.z - b.mesh.position.z;
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      const minDist = (a.radius + b.radius) * 1.05;
      
      if (dist < minDist && dist > 0.001) {
        const overlap = (minDist - dist) * 0.5;
        const nx = dx / dist;
        const ny = dy / dist;
        const nz = dz / dist;
        
        // Position correction
        a.mesh.position.x += nx * overlap;
        a.mesh.position.y += ny * overlap;
        a.mesh.position.z += nz * overlap;
        b.mesh.position.x -= nx * overlap;
        b.mesh.position.y -= ny * overlap;
        b.mesh.position.z -= nz * overlap;
        
        // Velocity response
        const totalMass = a.mass + b.mass;
        const relVelX = a.velocity.x - b.velocity.x;
        const relVelY = a.velocity.y - b.velocity.y;
        const relVelZ = a.velocity.z - b.velocity.z;
        const dot = relVelX * nx + relVelY * ny + relVelZ * nz;
        
        if (dot > 0) continue;
        
        const restitution = 0.6;
        const impulse = -(1 + restitution) * dot / totalMass;
        
        a.velocity.x += impulse * b.mass * nx;
        a.velocity.y += impulse * b.mass * ny;
        a.velocity.z += impulse * b.mass * nz;
        b.velocity.x -= impulse * a.mass * nx;
        b.velocity.y -= impulse * a.mass * ny;
        b.velocity.z -= impulse * a.mass * nz;
      }
    }
  }
}

// Apply mouse repulsion force
function applyMouseForce() {
  if (mouseOverPanel) return;
  raycaster.setFromCamera(mouseNDC, camera);
  const hitPoint = new THREE.Vector3();
  raycaster.ray.intersectPlane(interactionPlane, hitPoint);
  
  if (!hitPoint) return;
  
  mouse3D.copy(hitPoint);
  
  spheres.forEach(s => {
    const dx = s.mesh.position.x - mouse3D.x;
    const dy = s.mesh.position.y - mouse3D.y;
    const dz = s.mesh.position.z - mouse3D.z;
    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    
    if (dist < MOUSE_RADIUS && dist > 0.01) {
      const force = (1 - dist / MOUSE_RADIUS) * MOUSE_STRENGTH;
      const nx = dx / dist;
      const ny = dy / dist;
      const nz = dz / dist;
      s.velocity.x += nx * force;
      s.velocity.y += ny * force;
      s.velocity.z += nz * force;
    }
  });
}

// Spring force back to base position
function applySpringForces() {
  spheres.forEach(s => {
    const dx = s.basePos.x - s.mesh.position.x;
    const dy = s.basePos.y - s.mesh.position.y;
    const dz = s.basePos.z - s.mesh.position.z;
    s.velocity.x += dx * SPRING_STRENGTH;
    s.velocity.y += dy * SPRING_STRENGTH;
    s.velocity.z += dz * SPRING_STRENGTH;
  });
}

// Run initial collision passes
for (let pass = 0; pass < 20; pass++) {
  resolveSphereCollisions();
}

// Store final positions as base
spheres.forEach(s => {
  s.basePos.x = s.mesh.position.x;
  s.basePos.y = s.mesh.position.y;
  s.basePos.z = s.mesh.position.z;
});

// Mouse interaction
const mouse = { x: 0, y: 0 };
const mouseTarget = { x: 0, y: 0 };

let mouseOverPanel = false;

document.addEventListener('mousemove', (e) => {
  // Check if mouse is over any panel
  const panels = document.querySelectorAll('.material-panel');
  let overPanel = false;
  panels.forEach(panel => {
    const rect = panel.getBoundingClientRect();
    if (e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom) {
      overPanel = true;
    }
  });
  mouseOverPanel = overPanel;

  if (!mouseOverPanel) {
    mouseTarget.x = (e.clientX / window.innerWidth - 0.5) * 2;
    mouseTarget.y = -(e.clientY / window.innerHeight - 0.5) * 2;
    mouseNDC.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouseNDC.y = -(e.clientY / window.innerHeight) * 2 + 1;
  }
});

// Click burst effect
let isMouseDown = false;
document.addEventListener('mousedown', () => {
  isMouseDown = true;
  cursor.style.transform = 'translate(-50%, -50%) scale(1.6)';
  cursor.style.borderColor = '#b07ae8';
  cursor.style.boxShadow = '0 0 20px rgba(176,122,232,0.4)';
  
  if (mouseOverPanel) return;
  
  // Burst: push spheres away from mouse
  raycaster.setFromCamera(mouseNDC, camera);
  const hitPoint = new THREE.Vector3();
  raycaster.ray.intersectPlane(interactionPlane, hitPoint);
  if (hitPoint) {
    spheres.forEach(s => {
      const dx = s.mesh.position.x - hitPoint.x;
      const dy = s.mesh.position.y - hitPoint.y;
      const dz = s.mesh.position.z - hitPoint.z;
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (dist < 6 && dist > 0.01) {
        const force = (1 - dist / 6) * 0.8;
        s.velocity.x += (dx / dist) * force;
        s.velocity.y += (dy / dist) * force;
        s.velocity.z += (dz / dist) * force;
      }
    });
  }
});

document.addEventListener('mouseup', () => {
  isMouseDown = false;
  cursor.style.transform = 'translate(-50%, -50%) scale(1)';
  cursor.style.borderColor = 'rgba(0,0,0,0.3)';
  cursor.style.boxShadow = 'none';
});

// Custom cursor
const cursor = document.createElement('div');
cursor.style.cssText = `
  position: fixed;
  width: 28px;
  height: 28px;
  border: 1.5px solid rgba(0,0,0,0.3);
  border-radius: 50%;
  pointer-events: none;
  z-index: 10000;
  transform: translate(-50%, -50%);
  transition: transform 0.15s ease, border-color 0.2s ease, box-shadow 0.2s ease;
`;
document.body.appendChild(cursor);
document.body.style.cursor = 'none';

document.addEventListener('mousemove', (e) => {
  cursor.style.left = e.clientX + 'px';
  cursor.style.top = e.clientY + 'px';
});

// Track momentum for energy meter
let currentMomentum = 0;
let smoothMomentum = 0;

// UI Overlay - Redesigned minimal HUD
const overlay = document.createElement('div');
overlay.innerHTML = `
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap');
    
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { overflow: hidden; font-family: 'Inter', sans-serif; cursor: none; background: #f0eeeb; }
    
    .ui-overlay {
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      pointer-events: none;
      z-index: 100;
    }
    
    /* Top bar */
    .top-bar {
      position: absolute;
      top: 0; left: 0; right: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 24px 36px;
    }
    
    .logo {
      font-family: 'Space Grotesk', sans-serif;
      font-size: 13px;
      font-weight: 600;
      letter-spacing: 5px;
      text-transform: uppercase;
      color: rgba(20,20,30,0.8);
    }
    
    .top-status {
      display: flex;
      align-items: center;
      gap: 24px;
    }
    
    .status-pill {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 5px 14px;
      border: 1px solid rgba(0,0,0,0.08);
      border-radius: 20px;
      background: rgba(0,0,0,0.02);
    }
    
    .status-dot {
      width: 5px;
      height: 5px;
      border-radius: 50%;
      background: #34d399;
      box-shadow: 0 0 6px rgba(52,211,153,0.5);
      animation: blink 2s ease-in-out infinite;
    }
    
    @keyframes blink {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.4; }
    }
    
    .status-text {
      font-size: 9px;
      font-weight: 400;
      letter-spacing: 1.5px;
      text-transform: uppercase;
      color: rgba(20,20,30,0.4);
    }
    
    .top-count {
      font-family: 'Space Grotesk', monospace;
      font-size: 10px;
      font-weight: 400;
      letter-spacing: 1px;
      color: rgba(20,20,30,0.25);
    }
    
    /* Energy meter - bottom right horizontal */
    .energy-track {
      position: absolute;
      right: 36px;
      bottom: 24px;
      display: flex;
      flex-direction: row;
      align-items: center;
      gap: 10px;
    }
    
    .energy-label {
      font-family: 'Space Grotesk', sans-serif;
      font-size: 8px;
      font-weight: 500;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: rgba(20,20,30,0.3);
    }
    
    .energy-bar-container {
      width: 100px;
      height: 3px;
      background: rgba(0,0,0,0.06);
      border-radius: 3px;
      position: relative;
      overflow: hidden;
    }
    
    .energy-bar-fill {
      position: absolute;
      bottom: 0;
      left: 0;
      height: 100%;
      width: 0%;
      border-radius: 3px;
      background: linear-gradient(to right, rgba(80,80,85,0.35), rgba(100,100,105,0.55));
      transition: width 0.3s ease, box-shadow 0.3s ease;
    }
    
    .energy-bar-fill.high {
      background: linear-gradient(to right, rgba(90,90,95,0.6), rgba(60,60,65,0.8));
      box-shadow: 0 0 8px rgba(60,60,65,0.2);
    }
    
    .energy-value {
      font-family: 'Space Grotesk', monospace;
      font-size: 11px;
      font-weight: 600;
      color: rgba(20,20,30,0.45);
      transition: color 0.3s ease;
      min-width: 20px;
      text-align: right;
    }
    
    .energy-value.high {
      color: rgba(50,50,55,0.7);
    }
    
    /* Left side - vertical label */
    .side-label {
      position: absolute;
      left: 36px;
      top: 50%;
      transform: translateY(-50%);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 14px;
    }
    
    .side-line {
      width: 1px;
      height: 50px;
      background: linear-gradient(to bottom, rgba(176,122,232,0.35), transparent);
    }
    
    .side-text {
      font-family: 'Space Grotesk', sans-serif;
      font-size: 8px;
      font-weight: 500;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: rgba(20,20,30,0.25);
      writing-mode: vertical-rl;
      text-orientation: mixed;
      transform: rotate(180deg);
    }
    
    /* Bottom bar */
    .bottom-strip {
      position: absolute;
      left: 0; right: 0; bottom: 0;
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      padding: 0 36px 24px;
    }
    
    .bottom-title {
      font-family: 'Space Grotesk', sans-serif;
      font-size: 11px;
      font-weight: 500;
      letter-spacing: 5px;
      text-transform: uppercase;
      color: rgba(20,20,30,0.55);
    }
    
    .bottom-sub {
      font-size: 8px;
      font-weight: 400;
      letter-spacing: 1px;
      color: rgba(20,20,30,0.2);
      margin-top: 4px;
    }
    
    .palette-row {
      display: flex;
      gap: 6px;
      align-items: center;
    }
    
    .palette-swatch {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      opacity: 0.75;
      transition: opacity 0.3s ease, transform 0.3s ease;
    }
    
    .palette-swatch:hover {
      opacity: 1;
      transform: scale(1.3);
    }
    
    .bottom-right-info {
      text-align: right;
    }
    
    .bottom-right-info .year {
      font-family: 'Space Grotesk', monospace;
      font-size: 9px;
      font-weight: 300;
      letter-spacing: 3px;
      color: rgba(20,20,30,0.15);
    }
    
    /* Center interaction hint */
    .interaction-hint {
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, 160px);
      text-align: center;
      opacity: 1;
      transition: opacity 0.8s ease;
    }
    
    .interaction-hint.hidden { opacity: 0; pointer-events: none; }
    
    .hint-ring {
      width: 36px;
      height: 36px;
      border: 1px solid rgba(0,0,0,0.1);
      border-radius: 50%;
      margin: 0 auto 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      animation: hintPulse 2.5s ease-in-out infinite;
    }
    
    .hint-ring::after {
      content: '';
      width: 4px;
      height: 4px;
      background: rgba(20,20,30,0.3);
      border-radius: 50%;
    }
    
    @keyframes hintPulse {
      0%, 100% { transform: scale(1); border-color: rgba(0,0,0,0.1); }
      50% { transform: scale(1.12); border-color: rgba(176,122,232,0.3); }
    }
    
    .hint-label {
      font-size: 8px;
      font-weight: 400;
      letter-spacing: 3px;
      text-transform: uppercase;
      color: rgba(20,20,30,0.25);
    }
    
    /* Ghost number watermark */
    .watermark {
      position: absolute;
      left: 36px;
      bottom: 60px;
      font-family: 'Space Grotesk', sans-serif;
      font-size: 120px;
      font-weight: 200;
      color: rgba(0,0,0,0.03);
      line-height: 0.85;
      letter-spacing: -5px;
      pointer-events: none;
    }
    
    /* Material Control Panel */
    .material-panel {
      position: absolute;
      top: 80px;
      left: 36px;
      width: 180px;
      pointer-events: auto;
      background: rgba(255,255,255,0.65);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      border: 1px solid rgba(0,0,0,0.06);
      border-radius: 10px;
      padding: 16px 18px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      transition: padding 0.35s ease, gap 0.35s ease;
    }
    
    .panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 2px;
    }
    
    .panel-title {
      font-family: 'Space Grotesk', sans-serif;
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 2.5px;
      text-transform: uppercase;
      color: rgba(20,20,30,0.55);
    }
    
    .panel-toggle {
      width: 18px;
      height: 18px;
      border: 1px solid rgba(0,0,0,0.1);
      border-radius: 4px;
      background: transparent;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      color: rgba(20,20,30,0.4);
      transition: background 0.2s ease, color 0.2s ease;
      pointer-events: auto;
    }
    
    .panel-toggle:hover {
      background: rgba(0,0,0,0.04);
      color: rgba(20,20,30,0.7);
    }
    
    .panel-body {
      display: flex;
      flex-direction: column;
      gap: 9px;
      overflow: hidden;
      transition: max-height 0.35s ease, opacity 0.25s ease;
      max-height: 600px;
      opacity: 1;
    }
    
    .panel-body.collapsed {
      max-height: 0;
      opacity: 0;
      margin: 0;
      padding: 0;
    }
    
    .material-panel:has(.panel-body.collapsed) {
      padding-bottom: 14px;
      gap: 0;
    }
    
    .param-row {
      display: flex;
      flex-direction: column;
      gap: 3px;
    }
    
    .param-label-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .param-label {
      font-family: 'Inter', sans-serif;
      font-size: 9px;
      font-weight: 500;
      letter-spacing: 0.5px;
      color: rgba(20,20,30,0.45);
    }
    
    .param-value {
      font-family: 'Space Grotesk', monospace;
      font-size: 9px;
      font-weight: 500;
      color: rgba(20,20,30,0.6);
      min-width: 32px;
      text-align: right;
    }
    
    .param-slider {
      -webkit-appearance: none;
      appearance: none;
      width: 100%;
      height: 3px;
      border-radius: 3px;
      background: rgba(0,0,0,0.08);
      outline: none;
      cursor: pointer;
    }
    
    .param-slider::-webkit-slider-thumb {
      -webkit-appearance: none;
      appearance: none;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #fff;
      border: 1.5px solid rgba(0,0,0,0.15);
      cursor: pointer;
      transition: border-color 0.2s ease;
    }
    
    .param-slider::-webkit-slider-thumb:hover {
      border-color: rgba(176,122,232,0.6);
    }
    
    .param-slider::-moz-range-thumb {
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #fff;
      border: 1.5px solid rgba(0,0,0,0.15);
      cursor: pointer;
    }
    
    .param-divider {
      width: 100%;
      height: 1px;
      background: rgba(0,0,0,0.05);
    }
    
    .param-color-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .param-color-input {
      -webkit-appearance: none;
      appearance: none;
      width: 24px;
      height: 24px;
      border: 1.5px solid rgba(0,0,0,0.1);
      border-radius: 50%;
      cursor: pointer;
      padding: 0;
      overflow: hidden;
      background: transparent;
    }
    
    .param-color-input::-webkit-color-swatch-wrapper {
      padding: 0;
    }
    
    .param-color-input::-webkit-color-swatch {
      border: none;
      border-radius: 50%;
    }
    
    .param-color-input::-moz-color-swatch {
      border: none;
      border-radius: 50%;
    }
  </style>
  
  <div class="ui-overlay">
    <div class="top-bar">
      <div class="logo">KINESIS</div>
      <div class="top-status">
        <div class="status-pill">
          <div class="status-dot"></div>
          <span class="status-text">Live</span>
        </div>
        <span class="top-count" id="sphereCount">55 bodies</span>
      </div>
    </div>
    
    <div class="energy-track">
      <div class="energy-label">Momentum</div>
      <div class="energy-bar-container">
        <div class="energy-bar-fill" id="energyFill"></div>
      </div>
      <div class="energy-value" id="energyValue">0</div>
    </div>
    
    <div class="side-label">
      <div class="side-line"></div>
      <div class="side-text">Physics</div>
    </div>
    
    <div class="interaction-hint" id="interactionHint">
      <div class="hint-ring"></div>
      <div class="hint-label">Move to interact</div>
    </div>
    
    <div class="watermark">55</div>
    
    <div class="material-panel">
      <div class="panel-header">
        <span class="panel-title">Solid Material</span>
        <button class="panel-toggle" id="panelToggle">−</button>
      </div>
      <div class="panel-body" id="panelBody">
        <div class="param-row">
          <div class="param-label-row">
            <span class="param-label">Roughness</span>
            <span class="param-value" id="valRoughness">0.00</span>
          </div>
          <input type="range" class="param-slider" id="sliderRoughness" min="0" max="100" value="0">
        </div>
        
        <div class="param-row">
          <div class="param-label-row">
            <span class="param-label">Metalness</span>
            <span class="param-value" id="valMetalness">0.30</span>
          </div>
          <input type="range" class="param-slider" id="sliderMetalness" min="0" max="100" value="30">
        </div>
        
        <div class="param-divider"></div>
        
        <div class="param-row">
          <div class="param-label-row">
            <span class="param-label">Clearcoat</span>
            <span class="param-value" id="valClearcoat">0.00</span>
          </div>
          <input type="range" class="param-slider" id="sliderClearcoat" min="0" max="100" value="0">
        </div>
        
        <div class="param-row">
          <div class="param-label-row">
            <span class="param-label">Clearcoat Roughness</span>
            <span class="param-value" id="valClearcoatRoughness">0.30</span>
          </div>
          <input type="range" class="param-slider" id="sliderClearcoatRoughness" min="0" max="100" value="30">
        </div>
        
        <div class="param-divider"></div>
        
        <div class="param-row">
          <div class="param-label-row">
            <span class="param-label">Reflectivity</span>
            <span class="param-value" id="valReflectivity">1.00</span>
          </div>
          <input type="range" class="param-slider" id="sliderReflectivity" min="0" max="100" value="100">
        </div>
        
        <div class="param-row">
          <div class="param-label-row">
            <span class="param-label">Env Map Intensity</span>
            <span class="param-value" id="valEnvMap">1.20</span>
          </div>
          <input type="range" class="param-slider" id="sliderEnvMap" min="0" max="500" value="120">
        </div>
        

        
        <div class="param-row">
          <div class="param-label-row">
            <span class="param-label">Specular Intensity</span>
            <span class="param-value" id="valSpecular">1.00</span>
          </div>
          <input type="range" class="param-slider" id="sliderSpecular" min="0" max="100" value="100">
        </div>
        
        <div class="param-divider"></div>
        
        <div class="param-row">
          <div class="param-color-row">
            <span class="param-label">Specular Color</span>
            <input type="color" class="param-color-input" id="colorSpecular" value="#ffffff">
          </div>
        </div>
        
        <div class="param-divider"></div>
        
        <div class="param-divider"></div>
        
        <div class="param-row">
          <div class="param-label-row">
            <span class="param-label">Gradient Intensity</span>
            <span class="param-value" id="valGradientIntensity">1.00</span>
          </div>
          <input type="range" class="param-slider" id="sliderGradientIntensity" min="0" max="100" value="100">
        </div>
        
        <div class="param-row">
          <div class="param-label-row">
            <span class="param-label">Gradient Radius</span>
            <span class="param-value" id="valGradientRadius">3.0</span>
          </div>
          <input type="range" class="param-slider" id="sliderGradientRadius" min="10" max="200" value="30">
        </div>
        

        
        <div class="param-row">
          <div class="param-label-row" style="align-items: center;">
            <span class="param-label">Rotate</span>
            <button id="toggleAutoRotate" style="
              font-family: 'Space Grotesk', monospace;
              font-size: 9px;
              font-weight: 500;
              letter-spacing: 1px;
              text-transform: uppercase;
              color: rgba(20,20,30,0.5);
              background: rgba(0,0,0,0.04);
              border: 1px solid rgba(0,0,0,0.08);
              border-radius: 4px;
              padding: 3px 10px;
              cursor: pointer;
              transition: background 0.2s ease, color 0.2s ease;
              pointer-events: auto;
            ">On</button>
          </div>
        </div>
      </div>
    </div>
    
    <div class="material-panel" style="left: auto; right: 36px; top: 80px;">
      <div class="panel-header">
        <span class="panel-title">Colors</span>
        <button class="panel-toggle" id="colorPanelToggle">−</button>
      </div>
      <div class="panel-body" id="colorPanelBody">
        <div class="param-row">
          <div class="param-color-row">
            <span class="param-label">Cream</span>
            <input type="color" class="param-color-input" id="colorCream" value="#faf5eb">
          </div>
        </div>
        <div class="param-row">
          <div class="param-color-row">
            <span class="param-label">Sage Mint</span>
            <input type="color" class="param-color-input" id="colorSage" value="#b8d8d0">
          </div>
        </div>
        <div class="param-row">
          <div class="param-color-row">
            <span class="param-label">Terracotta</span>
            <input type="color" class="param-color-input" id="colorTerracotta" value="#e09080">
          </div>
        </div>
        <div class="param-row">
          <div class="param-color-row">
            <span class="param-label">Blush Pink</span>
            <input type="color" class="param-color-input" id="colorBlush" value="#f2c4c4">
          </div>
        </div>
        <div class="param-divider"></div>
        <div class="param-row">
          <button id="randomizeColors" style="
            width: 100%;
            font-family: 'Space Grotesk', monospace;
            font-size: 9px;
            font-weight: 600;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: rgba(20,20,30,0.55);
            background: rgba(0,0,0,0.04);
            border: 1px solid rgba(0,0,0,0.08);
            border-radius: 5px;
            padding: 7px 10px;
            cursor: pointer;
            transition: background 0.2s ease, color 0.2s ease;
            pointer-events: auto;
          ">Randomize</button>
        </div>
        <div class="param-row">
          <button id="resetColors" style="
            width: 100%;
            font-family: 'Space Grotesk', monospace;
            font-size: 9px;
            font-weight: 500;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: rgba(20,20,30,0.35);
            background: transparent;
            border: 1px solid rgba(0,0,0,0.06);
            border-radius: 5px;
            padding: 6px 10px;
            cursor: pointer;
            transition: background 0.2s ease, color 0.2s ease;
            pointer-events: auto;
          ">Reset</button>
        </div>
      </div>
    </div>
    
    <div class="bottom-strip">
      <div>
        <div class="bottom-title">Soft Body Dynamics</div>
        <div class="bottom-sub">Real-time collision & spring physics</div>
      </div>
      
      <div class="palette-row">
        <div class="palette-swatch" style="background:#faf5eb;"></div>
        <div class="palette-swatch" style="background:#b8d8d0;"></div>
        <div class="palette-swatch" style="background:#e09080;"></div>
        <div class="palette-swatch" style="background:#f2c4c4;"></div>
      </div>
      
      <div class="bottom-right-info"></div>
    </div>
  </div>
`;
document.body.appendChild(overlay);

// Material panel controls
function setupMaterialPanel() {
  const toggle = document.getElementById('panelToggle');
  const body = document.getElementById('panelBody');
  
  toggle.addEventListener('click', () => {
    body.classList.toggle('collapsed');
    toggle.textContent = body.classList.contains('collapsed') ? '+' : '−';
  });
  
  // Helper to get all non-glass materials (odd indices)
  function getNonGlassMaterials() {
    return sphereMaterials.filter((_, i) => i % 2 !== 0);
  }
  
  function bindSlider(sliderId, valueId, apply, format) {
    const slider = document.getElementById(sliderId);
    const display = document.getElementById(valueId);
    slider.addEventListener('input', () => {
      const val = parseFloat(slider.value);
      const mapped = apply(val, getNonGlassMaterials());
      display.textContent = format ? format(mapped) : mapped.toFixed(2);
    });
  }
  
  bindSlider('sliderRoughness', 'valRoughness', (v, mats) => {
    const val = v / 100;
    mats.forEach(m => { m.roughness = val; m.needsUpdate = true; });
    return val;
  });
  
  bindSlider('sliderMetalness', 'valMetalness', (v, mats) => {
    const val = v / 100;
    mats.forEach(m => { m.metalness = val; m.needsUpdate = true; });
    return val;
  });
  
  bindSlider('sliderClearcoat', 'valClearcoat', (v, mats) => {
    const val = v / 100;
    mats.forEach(m => { m.clearcoat = val; m.needsUpdate = true; });
    return val;
  });
  
  bindSlider('sliderClearcoatRoughness', 'valClearcoatRoughness', (v, mats) => {
    const val = v / 100;
    mats.forEach(m => { m.clearcoatRoughness = val; m.needsUpdate = true; });
    return val;
  });
  
  bindSlider('sliderReflectivity', 'valReflectivity', (v, mats) => {
    const val = v / 100;
    mats.forEach(m => { m.reflectivity = val; m.needsUpdate = true; });
    return val;
  });
  
  bindSlider('sliderEnvMap', 'valEnvMap', (v, mats) => {
    const val = v / 100;
    mats.forEach(m => { m.envMapIntensity = val; m.needsUpdate = true; });
    return val;
  });
  

  
  bindSlider('sliderGradientIntensity', 'valGradientIntensity', (v) => {
    const val = v / 100;
    gradientIntensity = val;
    return val;
  });
  
  bindSlider('sliderGradientRadius', 'valGradientRadius', (v) => {
    const val = v / 10;
    gradientRadiusParam = val;
    return val;
  }, (v) => v.toFixed(1));
  
  bindSlider('sliderSpecular', 'valSpecular', (v, mats) => {
    const val = v / 100;
    mats.forEach(m => { m.specularIntensity = val; m.needsUpdate = true; });
    return val;
  });
  
  // Specular color picker
  const colorInput = document.getElementById('colorSpecular');
  colorInput.addEventListener('input', () => {
    const col = new THREE.Color(colorInput.value);
    getNonGlassMaterials().forEach(m => {
      m.specularColor.copy(col);
      m.needsUpdate = true;
    });
  });
  

  
  // Auto-rotate toggle
  const rotateBtn = document.getElementById('toggleAutoRotate');
  rotateBtn.addEventListener('click', () => {
    autoRotateEnabled = !autoRotateEnabled;
    rotateBtn.textContent = autoRotateEnabled ? 'On' : 'Off';
    rotateBtn.style.color = autoRotateEnabled ? 'rgba(20,20,30,0.5)' : 'rgba(20,20,30,0.25)';
    if (autoRotateEnabled) {
      // Sync autoRotateOffset so rotation continues smoothly from current angle
      autoRotateOffset = cameraOrbit.theta - clock.getElapsedTime() * 0.15;
    }
  });
}

setupMaterialPanel();

// Color panel controls
function setupColorPanel() {
  const toggle = document.getElementById('colorPanelToggle');
  const body = document.getElementById('colorPanelBody');
  
  toggle.addEventListener('click', () => {
    body.classList.toggle('collapsed');
    toggle.textContent = body.classList.contains('collapsed') ? '+' : '−';
  });
  
  const defaultColors = {
    cream: '#faf5eb',
    sage: '#b8d8d0',
    terracotta: '#e09080',
    blush: '#f2c4c4',
  };
  
  // Map palette index pairs: [glassIdx, solidIdx]
  const colorMap = [
    { key: 'cream', inputId: 'colorCream', indices: [0, 4] },
    { key: 'sage', inputId: 'colorSage', indices: [1, 5] },
    { key: 'terracotta', inputId: 'colorTerracotta', indices: [2, 6] },
    { key: 'blush', inputId: 'colorBlush', indices: [3, 7] },
  ];
  
  function applyColor(hex, indices) {
    const col = new THREE.Color(hex);
    indices.forEach(idx => {
      sphereMaterials[idx].color.copy(col);
      if (sphereMaterials[idx].attenuationColor) {
        sphereMaterials[idx].attenuationColor.copy(col);
      }
      sphereMaterials[idx].needsUpdate = true;
    });
  }
  
  function updateSwatches() {
    const swatches = document.querySelectorAll('.palette-swatch');
    const inputs = [
      document.getElementById('colorCream'),
      document.getElementById('colorSage'),
      document.getElementById('colorTerracotta'),
      document.getElementById('colorBlush'),
    ];
    inputs.forEach((inp, i) => {
      if (swatches[i]) swatches[i].style.background = inp.value;
    });
  }
  
  // Helper to sync palette array so the gradient in animate() uses current colors
  function syncPalette() {
    colorMap.forEach((entry) => {
      const input = document.getElementById(entry.inputId);
      const hex = input.value;
      const colorInt = parseInt(hex.replace('#', ''), 16);
      entry.indices.forEach(idx => {
        palette[idx].color = colorInt;
      });
    });
  }

  colorMap.forEach(entry => {
    const input = document.getElementById(entry.inputId);
    input.addEventListener('input', () => {
      applyColor(input.value, entry.indices);
      syncPalette();
      updateSwatches();
    });
  });
  
  // Randomize button
  document.getElementById('randomizeColors').addEventListener('click', () => {
    // Generate harmonious random palette using HSL
    const baseHue = Math.random() * 360;
    const randomPalette = [];
    
    for (let i = 0; i < 4; i++) {
      const hue = (baseHue + i * (70 + Math.random() * 30)) % 360;
      const sat = 20 + Math.random() * 40;
      const light = 70 + Math.random() * 20;
      const c = new THREE.Color();
      c.setHSL(hue / 360, sat / 100, light / 100);
      randomPalette.push('#' + c.getHexString());
    }
    
    colorMap.forEach((entry, i) => {
      const input = document.getElementById(entry.inputId);
      input.value = randomPalette[i];
      applyColor(randomPalette[i], entry.indices);
    });
    syncPalette();
    updateSwatches();
  });
  
  // Reset button
  document.getElementById('resetColors').addEventListener('click', () => {
    const defaults = [defaultColors.cream, defaultColors.sage, defaultColors.terracotta, defaultColors.blush];
    colorMap.forEach((entry, i) => {
      const input = document.getElementById(entry.inputId);
      input.value = defaults[i];
      applyColor(defaults[i], entry.indices);
    });
    syncPalette();
    updateSwatches();
  });
}

setupColorPanel();

// Hide hint after first interaction
let autoRotateEnabled = true;
let autoRotateOffset = 0;
let hintHidden = false;
document.addEventListener('mousemove', () => {
  if (!hintHidden) {
    hintHidden = true;
    setTimeout(() => {
      const hint = document.getElementById('interactionHint');
      if (hint) hint.classList.add('hidden');
    }, 2500);
  }
});

// Load HDR/LDR equirectangular environment map from uploaded image
const pmremGenerator = new THREE.PMREMGenerator(renderer);
pmremGenerator.compileEquirectangularShader();

let envMap = null;

function applyEnvMap(texture) {
  texture.mapping = THREE.EquirectangularReflectionMapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.offset.x = 0.5;
  texture.wrapS = THREE.RepeatWrapping;
  texture.rotation = Math.PI;
  texture.center.set(0.5, 0.5);
  
  envMap = pmremGenerator.fromEquirectangular(texture).texture;
  
  sphereMaterials.forEach(m => {
    m.envMap = envMap;
    if (m.transmission && m.transmission > 0) {
      m.envMapIntensity = 1.5;
    } else {
      m.envMapIntensity = 2.5;
      m.roughness = Math.max(0.05, m.roughness - 0.15);
    }
    m.needsUpdate = true;
  });
  goldMaterial.envMap = envMap;
  goldMaterial.envMapIntensity = 1.5;
  goldMaterial.needsUpdate = true;
  
  // Also set as scene background with subtle visibility
  scene.environment = envMap;
  
  pmremGenerator.dispose();
  texture.dispose();
}

// Load equirectangular environment map for all spheres
{
  const rgbeLoader = new THREE.RGBELoader();
  rgbeLoader.load(
    'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/white_home_studio_1k.hdr',
    (hdrTex) => {
      hdrTex.mapping = THREE.EquirectangularReflectionMapping;
      envMap = pmremGenerator.fromEquirectangular(hdrTex).texture;

      sphereMaterials.forEach(m => {
        m.envMap = envMap;
        m.envMapIntensity = 1.2;
        m.needsUpdate = true;
      });
      goldMaterial.envMap = envMap;
      goldMaterial.envMapIntensity = 1.2;
      goldMaterial.needsUpdate = true;

      scene.environment = envMap;

      pmremGenerator.dispose();
      hdrTex.dispose();
    },
    undefined,
    (err) => {
      console.warn('HDR load failed, generating procedural env map');
      // Fallback: procedural environment with gradient lighting
      const fallbackRT = pmremGenerator.fromScene(new THREE.Scene());
      envMap = fallbackRT.texture;
      sphereMaterials.forEach(m => {
        m.envMap = envMap;
        m.envMapIntensity = m.transmission > 0 ? 1.5 : 2.5;
        m.needsUpdate = true;
      });
      goldMaterial.envMap = envMap;
      goldMaterial.envMapIntensity = 1.5;
      goldMaterial.needsUpdate = true;
      scene.environment = envMap;
      pmremGenerator.dispose();
    }
  );
}

// Floor gradient (subtle)
const floorGeo = new THREE.PlaneGeometry(40, 40);
const floorMat = new THREE.MeshStandardMaterial({
  color: 0xf2efea,
  roughness: 0.92,
  metalness: 0.0,
});
const floor = new THREE.Mesh(floorGeo, floorMat);
floor.rotation.x = -Math.PI / 2;
floor.position.y = -5;
floor.receiveShadow = false;
scene.add(floor);

// === Contact Shadow System (reimplemented) ===
// Strategy: Render spheres from above into a render target.
// Use a custom material that outputs alpha based on proximity to floor.
// The shadow RT stores shadow intensity in the RGB channels.
// We then blur it and display it with MultiplyBlending on a plane just above the floor.
// Key: RT is cleared to WHITE. Spheres render as DARK. Multiply blending then darkens the floor.

const SHADOW_SIZE = 1024;
const shadowCameraSize = 12;

// Two render targets for ping-pong blurring
const shadowRT_A = new THREE.WebGLRenderTarget(SHADOW_SIZE, SHADOW_SIZE, {
  minFilter: THREE.LinearFilter,
  magFilter: THREE.LinearFilter,
});
const shadowRT_B = new THREE.WebGLRenderTarget(SHADOW_SIZE, SHADOW_SIZE, {
  minFilter: THREE.LinearFilter,
  magFilter: THREE.LinearFilter,
});

// Shadow camera looks straight down
const shadowCamera = new THREE.OrthographicCamera(
  -shadowCameraSize, shadowCameraSize,
  shadowCameraSize, -shadowCameraSize,
  0.1, 30
);
shadowCamera.position.set(0, 10, 0);
shadowCamera.lookAt(0, -5, 0);
shadowCamera.updateMatrixWorld(true);
shadowCamera.updateProjectionMatrix();

// Shadow depth material: outputs DARK where spheres are close to floor, transparent elsewhere
const shadowDepthMaterial = new THREE.ShaderMaterial({
  uniforms: {
    floorY: { value: -5.0 },
    maxHeight: { value: 6.0 },
    shadowDarkness: { value: 0.85 },
  },
  vertexShader: `
    varying vec4 vWorldPos;
    void main() {
      vWorldPos = modelMatrix * vec4(position, 1.0);
      gl_Position = projectionMatrix * viewMatrix * vWorldPos;
    }
  `,
  fragmentShader: `
    uniform float floorY;
    uniform float maxHeight;
    uniform float shadowDarkness;
    varying vec4 vWorldPos;
    void main() {
      float h = vWorldPos.y - floorY;
      float shadowStrength = 1.0 - clamp(h / maxHeight, 0.0, 1.0);
      shadowStrength = shadowStrength * shadowStrength;
      float val = 1.0 - shadowStrength * shadowDarkness;
      gl_FragColor = vec4(val, val, val, 1.0);
    }
  `,
  side: THREE.DoubleSide,
});

// === Screen-space Contact Shadow Between Spheres (SSCS) ===
// Fast approach: render a fullscreen pass that darkens pixels where spheres are close to each other.
// We pass sphere world positions and radii as uniforms, then for each pixel we check proximity.
// To keep it fast we limit to a subset of spheres and use early-out.

const MAX_SSCS_SPHERES = 55;

const sscsUniforms = {
  sphereData: { value: [] }, // vec4 array: xyz = world pos, w = radius
  sphereCount: { value: 0 },
  tDiffuse: { value: null },
  resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
  cameraNear: { value: camera.near },
  cameraFar: { value: camera.far },
  projMatrix: { value: camera.projectionMatrix },
  viewMatrix: { value: camera.matrixWorldInverse },
  shadowIntensity: { value: 0.35 },
  shadowRadius: { value: 1.15 }, // multiplier on sum of radii for shadow range
};

// Pre-allocate vec4 array
const sphereDataArray = [];
for (let i = 0; i < MAX_SSCS_SPHERES; i++) {
  sphereDataArray.push(new THREE.Vector4(0, 0, 0, 0));
}
sscsUniforms.sphereData.value = sphereDataArray;

// Pre-compute contact shadow pairs on CPU each frame (much faster than GPU N^2)
const MAX_SHADOW_PAIRS = 64;
const sscsContactPairs = {
  midpoints: [],    // vec4[]: xy = screen midpoint, z = zone radius, w = strength
  count: { value: 0 },
};

const pairData = [];
for (let i = 0; i < MAX_SHADOW_PAIRS; i++) {
  pairData.push(new THREE.Vector4(0, 0, 0, 0));
}

const sscsPairUniforms = {
  pairs: { value: pairData },
  pairCount: { value: 0 },
  tDiffuse: { value: null },
  resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
  aspect: { value: window.innerWidth / window.innerHeight },
};

const sscsMaterial = new THREE.ShaderMaterial({
  uniforms: sscsPairUniforms,
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform vec4 pairs[${MAX_SHADOW_PAIRS}];
    uniform int pairCount;
    uniform sampler2D tDiffuse;
    uniform float aspect;
    varying vec2 vUv;

    void main() {
      vec4 base = texture2D(tDiffuse, vUv);
      float shadow = 0.0;

      for (int i = 0; i < ${MAX_SHADOW_PAIRS}; i++) {
        if (i >= pairCount) break;
        vec4 p = pairs[i];
        // p.xy = screen midpoint, p.z = zone radius, p.w = strength
        vec2 d = vUv - p.xy;
        d.x *= aspect;
        float dist = length(d);
        if (dist < p.z) {
          float falloff = 1.0 - (dist / p.z);
          shadow += falloff * falloff * p.w;
        }
      }

      shadow = clamp(shadow, 0.0, 0.45);
      gl_FragColor = vec4(base.rgb * (1.0 - shadow), base.a);
    }
  `,
});

// We'll apply SSCS as a post-process pass using EffectComposer
const composer = new THREE.EffectComposer(renderer);
const renderPass = new THREE.RenderPass(scene, camera);
composer.addPass(renderPass);

const sscsPass = new THREE.ShaderPass(sscsMaterial, 'tDiffuse');
sscsPass.uniforms = sscsPairUniforms;
composer.addPass(sscsPass);

const outputPass = new THREE.OutputPass();
composer.addPass(outputPass);

// Update composer size
composer.setSize(window.innerWidth, window.innerHeight);
composer.setPixelRatio(Math.min(window.devicePixelRatio, 2));



// Gaussian blur shader
function createBlurMaterial(horizontal) {
  return new THREE.ShaderMaterial({
    uniforms: {
      tDiffuse: { value: null },
      resolution: { value: new THREE.Vector2(SHADOW_SIZE, SHADOW_SIZE) },
      direction: { value: horizontal ? new THREE.Vector2(1, 0) : new THREE.Vector2(0, 1) },
    },
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D tDiffuse;
      uniform vec2 resolution;
      uniform vec2 direction;
      varying vec2 vUv;
      void main() {
        vec2 texel = direction / resolution;
        vec4 result = vec4(0.0);
        // 9-tap Gaussian
        float w[5];
        w[0] = 0.227027;
        w[1] = 0.1945946;
        w[2] = 0.1216216;
        w[3] = 0.054054;
        w[4] = 0.016216;
        result += texture2D(tDiffuse, vUv) * w[0];
        for (int i = 1; i < 5; i++) {
          vec2 off = texel * float(i) * 2.0;
          result += texture2D(tDiffuse, vUv + off) * w[i];
          result += texture2D(tDiffuse, vUv - off) * w[i];
        }
        gl_FragColor = result;
      }
    `,
  });
}

const blurHMaterial = createBlurMaterial(true);
const blurVMaterial = createBlurMaterial(false);

// Fullscreen quad for blur passes
const blurScene = new THREE.Scene();
const blurQuad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), blurHMaterial);
blurScene.add(blurQuad);
const blurCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

// A dedicated scene for shadow rendering (avoids overrideMaterial issues with lights etc.)
const shadowScene = new THREE.Scene();

// Contact shadow display plane - sits just above the floor
const contactShadowMaterial = new THREE.MeshBasicMaterial({
  map: shadowRT_A.texture,
  transparent: true,
  depthWrite: false,
  blending: THREE.MultiplyBlending,
});
const contactShadowPlane = new THREE.Mesh(
  new THREE.PlaneGeometry(shadowCameraSize * 2, shadowCameraSize * 2),
  contactShadowMaterial
);
contactShadowPlane.rotation.x = -Math.PI / 2;
contactShadowPlane.position.y = -4.99;
scene.add(contactShadowPlane);

// Helper: render contact shadow
function renderContactShadow() {
  // Build shadow scene: clone sphere positions into shadow scene with shadow material
  // Clear shadow scene first
  while (shadowScene.children.length > 0) {
    shadowScene.remove(shadowScene.children[0]);
  }
  
  // Add sphere proxies to shadow scene at their WORLD positions
  // (accounting for sphereGroup transform)
  sphereGroup.updateMatrixWorld(true);
  const tempPos = new THREE.Vector3();
  
  spheres.forEach(s => {
    // Get world position of this sphere
    tempPos.setFromMatrixPosition(s.mesh.matrixWorld);
    
    // Create a simple sphere in the shadow scene at this world position
    const proxyGeo = s.mesh.geometry;
    const proxy = new THREE.Mesh(proxyGeo, shadowDepthMaterial);
    proxy.position.copy(tempPos);
    shadowScene.add(proxy);
  });
  
  // Render shadow scene from top-down into RT_A
  const origClearColor = renderer.getClearColor(new THREE.Color());
  const origClearAlpha = renderer.getClearAlpha();
  
  renderer.setClearColor(0xffffff, 1.0);
  renderer.setRenderTarget(shadowRT_A);
  renderer.clear();
  renderer.render(shadowScene, shadowCamera);
  
  // Blur pass 1: A -> B (horizontal)
  blurHMaterial.uniforms.tDiffuse.value = shadowRT_A.texture;
  blurQuad.material = blurHMaterial;
  renderer.setRenderTarget(shadowRT_B);
  renderer.clear();
  renderer.render(blurScene, blurCamera);
  
  // Blur pass 1: B -> A (vertical)
  blurVMaterial.uniforms.tDiffuse.value = shadowRT_B.texture;
  blurQuad.material = blurVMaterial;
  renderer.setRenderTarget(shadowRT_A);
  renderer.clear();
  renderer.render(blurScene, blurCamera);
  
  // Blur pass 2: A -> B (horizontal)
  blurHMaterial.uniforms.tDiffuse.value = shadowRT_A.texture;
  blurQuad.material = blurHMaterial;
  renderer.setRenderTarget(shadowRT_B);
  renderer.clear();
  renderer.render(blurScene, blurCamera);
  
  // Blur pass 2: B -> A (vertical)
  blurVMaterial.uniforms.tDiffuse.value = shadowRT_B.texture;
  blurQuad.material = blurVMaterial;
  renderer.setRenderTarget(shadowRT_A);
  renderer.clear();
  renderer.render(blurScene, blurCamera);
  
  // Blur pass 3 for extra softness
  blurHMaterial.uniforms.tDiffuse.value = shadowRT_A.texture;
  blurQuad.material = blurHMaterial;
  renderer.setRenderTarget(shadowRT_B);
  renderer.clear();
  renderer.render(blurScene, blurCamera);
  
  blurVMaterial.uniforms.tDiffuse.value = shadowRT_B.texture;
  blurQuad.material = blurVMaterial;
  renderer.setRenderTarget(shadowRT_A);
  renderer.clear();
  renderer.render(blurScene, blurCamera);
  
  // Restore
  renderer.setRenderTarget(null);
  renderer.setClearColor(origClearColor, origClearAlpha);
  
  // Update shadow plane material
  contactShadowMaterial.map = shadowRT_A.texture;
}

// Fog
scene.fog = new THREE.Fog(0xf0eeeb, 18, 40);

// Animation & Physics
const clock = new THREE.Clock();
let frameCount = 0;
let lastFpsTime = 0;

function animate() {
  requestAnimationFrame(animate);
  const t = clock.getElapsedTime();
  
  // Compute momentum from all sphere velocities
  currentMomentum = 0;
  spheres.forEach(s => {
    currentMomentum += Math.sqrt(s.velocity.x * s.velocity.x + s.velocity.y * s.velocity.y + s.velocity.z * s.velocity.z) * s.mass;
  });
  smoothMomentum += (currentMomentum - smoothMomentum) * 0.08;
  
  // Update energy meter
  const energyPercent = Math.min(100, (smoothMomentum / 8) * 100);
  const energyFill = document.getElementById('energyFill');
  const energyValue = document.getElementById('energyValue');
  if (energyFill) {
    energyFill.style.width = energyPercent + '%';
    if (energyPercent > 60) {
      energyFill.classList.add('high');
    } else {
      energyFill.classList.remove('high');
    }
  }
  if (energyValue) {
    energyValue.textContent = Math.round(energyPercent);
    if (energyPercent > 60) {
      energyValue.classList.add('high');
    } else {
      energyValue.classList.remove('high');
    }
  }
  
    // Smooth mouse
  mouse.x += (mouseTarget.x - mouse.x) * 0.05;
  mouse.y += (mouseTarget.y - mouse.y) * 0.05;
  
  // Sphere group rotation: auto-rotate + mouse influence
  const autoRotateSpeed = 0.15;
  const autoRotAngle = autoRotateEnabled ? t * autoRotateSpeed + autoRotateOffset : cameraOrbit.targetTheta;
  cameraOrbit.targetTheta = autoRotAngle + mouse.x * 0.25;
  cameraOrbit.targetPhi = Math.PI / 2 - ((autoRotateEnabled ? Math.sin(t * 0.08) * 0.1 : 0) + mouse.y * 0.12);
  
  // Clamp phi to avoid flipping
  cameraOrbit.targetPhi = Math.max(0.3, Math.min(Math.PI - 0.3, cameraOrbit.targetPhi));
  
  // Smooth interpolation
  cameraOrbit.theta += (cameraOrbit.targetTheta - cameraOrbit.theta) * 0.03;
  cameraOrbit.phi += (cameraOrbit.targetPhi - cameraOrbit.phi) * 0.03;
  
  // Camera stays fixed
  camera.position.set(0, 0, cameraOrbit.radius);
  camera.lookAt(0, 0, 0);
  
  // Apply physics forces
  applyMouseForce();
  applySpringForces();
  
  // Gentle float animation + velocity integration
  spheres.forEach((s, i) => {
    const floatY = Math.sin(t * s.floatSpeed + s.phase) * s.floatAmp;
    const floatX = Math.cos(t * s.floatSpeed * 0.7 + s.phase) * s.floatAmp * 0.5;
    
    // Apply velocity
    s.velocity.x *= DAMPING;
    s.velocity.y *= DAMPING;
    s.velocity.z *= DAMPING;
    
    s.mesh.position.x += s.velocity.x + floatX * 0.05;
    s.mesh.position.y += s.velocity.y + floatY * 0.05;
    s.mesh.position.z += s.velocity.z;
    
    // Clamp to reasonable bounds
    const maxBound = 8;
    s.mesh.position.x = Math.max(-maxBound, Math.min(maxBound, s.mesh.position.x));
    s.mesh.position.z = Math.max(-maxBound, Math.min(maxBound, s.mesh.position.z));
    
    // Floor collision - floor is at y = -5, sphere bottom edge must not go below it
    const floorY = -5 + s.radius;
    if (s.mesh.position.y < floorY) {
      s.mesh.position.y = floorY;
      s.velocity.y = Math.abs(s.velocity.y) * 0.5; // bounce with energy loss
    }
    
    s.mesh.position.y = Math.max(-maxBound, Math.min(maxBound, s.mesh.position.y));
  });
  
  // Run collision resolution
  for (let pass = 0; pass < 3; pass++) {
    resolveSphereCollisions();
  }
  
  // Subtle whole-group breathing
  const breathe = 1 + Math.sin(t * 0.4) * 0.008;
  sphereGroup.scale.set(breathe, breathe, breathe);
  
  // 3D gradient: darken spheres closer to center of group
  const gradientRadius = gradientRadiusParam;
  const darknessFactor = 1.0 - gradientIntensity; // convert intensity to darkness factor
  spheres.forEach((s, i) => {
    const px = s.mesh.position.x;
    const py = s.mesh.position.y;
    const pz = s.mesh.position.z;
    const distFromCenter = Math.sqrt(px * px + py * py + pz * pz);
    const normalizedDist = Math.min(distFromCenter / gradientRadius, 1.0);
    // Ease: spheres at center are darkest, at edge are original color
    const brightness = darknessFactor + (1.0 - darknessFactor) * (normalizedDist * normalizedDist);
    
    const mat = s.mesh.material;
    const basePalette = palette[i % palette.length];
    const baseColor = new THREE.Color(basePalette.color);
    mat.color.copy(baseColor).multiplyScalar(brightness);
    if (mat.attenuationColor) {
      mat.attenuationColor.copy(baseColor).multiplyScalar(brightness);
    }
  });
  
  // Rotate sphere group based on orbit angles
  const groupRotY = cameraOrbit.theta;
  const groupRotX = -(cameraOrbit.phi - Math.PI / 2);
  sphereGroup.rotation.set(groupRotX, groupRotY, 0);
  currentGroupRotationY = groupRotY;
  
  // Counter-rotate env map so reflections stay world-stable
  sphereMaterials.forEach(m => {
    if (m.envMap) {
      m.envMap.offset = m.envMap.offset || new THREE.Vector2();
      m.envMap.offset.x = -groupRotY / (Math.PI * 2) * envRotSpeedMultiplier;
    }
  });
  if (goldMaterial.envMap) {
    goldMaterial.envMap.offset = goldMaterial.envMap.offset || new THREE.Vector2();
    goldMaterial.envMap.offset.x = -groupRotY / (Math.PI * 2) * envRotSpeedMultiplier;
  }
  

  
  // Render contact shadows (floor)
  renderContactShadow();
  
  // CPU-side: find close sphere pairs, project midpoints to screen, send to shader
  sphereGroup.updateMatrixWorld(true);
  const _tmpA = new THREE.Vector3();
  const _tmpB = new THREE.Vector3();
  const _tmpMid = new THREE.Vector3();
  let pairIdx = 0;

  for (let i = 0; i < spheres.length && pairIdx < MAX_SHADOW_PAIRS; i++) {
    _tmpA.setFromMatrixPosition(spheres[i].mesh.matrixWorld);
    for (let j = i + 1; j < spheres.length && pairIdx < MAX_SHADOW_PAIRS; j++) {
      _tmpB.setFromMatrixPosition(spheres[j].mesh.matrixWorld);
      const worldDist = _tmpA.distanceTo(_tmpB);
      const touchDist = (spheres[i].radius + spheres[j].radius) * 1.15;
      if (worldDist < touchDist && worldDist > 0.01) {
        const proximity = 1.0 - (worldDist / touchDist);

        // Project midpoint to screen UV
        _tmpMid.lerpVectors(_tmpA, _tmpB, 0.5);
        _tmpMid.project(camera);
        const sx = _tmpMid.x * 0.5 + 0.5;
        const sy = _tmpMid.y * 0.5 + 0.5;

        // Screen-space zone radius based on smaller sphere
        const smallR = Math.min(spheres[i].radius, spheres[j].radius);
        const viewZ = _tmpMid.clone().applyMatrix4(camera.matrixWorldInverse).z;
        const screenR = (smallR * camera.projectionMatrix.elements[0]) / (-viewZ) * 0.5 * 1.2;

        pairData[pairIdx].set(sx, sy, Math.max(screenR, 0.005), proximity * proximity * 0.35);
        pairIdx++;
      }
    }
  }
  sscsPairUniforms.pairCount.value = pairIdx;
  // Zero out unused pairs
  for (let i = pairIdx; i < MAX_SHADOW_PAIRS; i++) {
    pairData[i].set(0, 0, 0, 0);
  }
  sscsPairUniforms.aspect.value = window.innerWidth / window.innerHeight;
  
  // Render with composer (includes SSCS pass)
  composer.render();
}

animate();

// Resize
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  composer.setSize(window.innerWidth, window.innerHeight);
  sscsPairUniforms.resolution.value.set(window.innerWidth, window.innerHeight);
  sscsPairUniforms.aspect.value = window.innerWidth / window.innerHeight;
});