# Remix: Real-Time 3D Watch Website Experience

Created with [Omma](https://omma.build)

## Setup

Open `index.html` in your browser, or:

```bash
npx serve .
```
