# Remix: Flavora — Interactive Meal Builder Experience

Created with [Omma](https://omma.build)

## Setup

Open `index.html` in your browser, or:

```bash
npx serve .
```
