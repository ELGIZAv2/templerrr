import * as THREE from 'three/webgpu';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { uniform, vec2, vec3, vec4, float, hash, screenUV, time, clamp, pass, mrt, output, transformedNormalView, Fn, Loop, If } from 'three/tsl';
import { bloom } from 'three/examples/jsm/tsl/display/BloomNode.js';
import { ao } from 'three/examples/jsm/tsl/display/GTAONode.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { RGBELoader } from 'three/examples/jsm/loaders/RGBELoader.js';

// ─── Scene ───
const scene = new THREE.Scene();
scene.backgroundBlurriness = 0.3;
scene.backgroundIntensity = 0.6;
scene.environmentIntensity = 0.7;

const camera = new THREE.PerspectiveCamera(40, window.innerWidth / window.innerHeight, 0.1, 100);
camera.position.set(6, 5, 8);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGPURenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.8;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.VSMShadowMap;
const root = document.getElementById('root') ?? document.body;
root.appendChild(renderer.domElement);
await renderer.init();

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.enablePan = false;
controls.target.set(0, 0, 0);
controls.minDistance = 5;
controls.maxDistance = 20;

// ─── Procedural textures ───
function createCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return { canvas: c, ctx: c.getContext('2d') };
}

function hashSeed(s) {
  // MurmurHash3-style finalizer to spread sequential seeds far apart
  s = ((s >>> 16) ^ s) * 0x45d9f3b | 0;
  s = ((s >>> 16) ^ s) * 0x45d9f3b | 0;
  s = (s >>> 16) ^ s;
  return (s >>> 0) || 1; // ensure non-zero positive
}

function seededRandom(seed) {
  let s = hashSeed(seed);
  return function () {
    s = (s * 16807 + 0) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function generateNormalMap() {
  const size = 256;
  const { canvas, ctx } = createCanvas(size, size);
  const imageData = ctx.createImageData(size, size);
  const data = imageData.data;
  const rand = seededRandom(42);
  for (let i = 0; i < size * size; i++) {
    // Base micro-roughness
    let nx = 128 + (rand() - 0.5) * 24;
    let ny = 128 + (rand() - 0.5) * 24;
    // Occasional stronger bumps for plastic grain texture
    if (rand() > 0.92) {
      nx += (rand() - 0.5) * 40;
      ny += (rand() - 0.5) * 40;
    }
    data[i * 4] = Math.max(0, Math.min(255, nx));
    data[i * 4 + 1] = Math.max(0, Math.min(255, ny));
    data[i * 4 + 2] = 255;
    data[i * 4 + 3] = 255;
  }
  ctx.putImageData(imageData, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

function generateClearcoatNormalMap(scratchCount = 200, scratchStrength = 60, scratchWidth = 0.5, seed = 254) {
  const size = 256;
  const { canvas, ctx } = createCanvas(size, size);
  ctx.fillStyle = 'rgb(128,128,255)';
  ctx.fillRect(0, 0, size, size);
  const imageData = ctx.getImageData(0, 0, size, size);
  const data = imageData.data;
  const floatR = new Float32Array(size * size).fill(128);
  const floatG = new Float32Array(size * size).fill(128);
  const rand = seededRandom(seed);

  // Fine scratches — thin hairline scratches, longer strokes
  const halfW = Math.max(0.25, scratchWidth * 0.5);
  const intHalfW = Math.ceil(halfW);
  for (let s = 0; s < scratchCount; s++) {
    const startX = rand() * size, startY = rand() * size;
    const angle = rand() * Math.PI * 2;
    const len = 60 + rand() * 450;
    const curve = (rand() - 0.5) * 1.2;
    const steps = Math.ceil(len);
    for (let i = 0; i < steps; i++) {
      const t = i / steps;
      const curAngle = angle + curve * t;
      const px = startX + Math.cos(curAngle) * i;
      const py = startY + Math.sin(curAngle) * i;
      const perpX = -Math.sin(curAngle), perpY = Math.cos(curAngle);
      const endFade = Math.min(t * 6, 1.0) * Math.min((1 - t) * 6, 1.0);
      for (let tt = -intHalfW; tt <= intHalfW; tt++) {
        const dist = Math.abs(tt);
        if (dist > halfW) continue;
        const falloff = 1.0 - dist / (halfW + 0.001);
        const ox = ((Math.round(px + perpX * tt * 0.5) % size) + size) % size;
        const oy = ((Math.round(py + perpY * tt * 0.5) % size) + size) % size;
        const fi = oy * size + ox;
        const normalizedPos = halfW > 0 ? tt / halfW : 0;
        const side = normalizedPos < 0 ? -1 : normalizedPos > 0 ? 1 : 0;
        const strength = scratchStrength * normalizedPos * normalizedPos * endFade * falloff;
        floatR[fi] += perpX * side * strength;
        floatG[fi] += perpY * side * strength;
      }
    }
  }

  // Deep gouges — fewer but wider and stronger
  const gougeCount = Math.floor(scratchCount * 0.03);
  for (let s = 0; s < gougeCount; s++) {
    const startX = rand() * size, startY = rand() * size;
    const angle = rand() * Math.PI * 2;
    const len = 60 + rand() * 200;
    const curve = (rand() - 0.5) * 0.8;
    const gougeWidth = Math.max(1, Math.ceil(scratchWidth) + Math.floor(rand() * 1));
    const gougeStr = scratchStrength * 1.2;
    const steps = Math.ceil(len);
    for (let i = 0; i < steps; i++) {
      const t = i / steps;
      const curAngle = angle + curve * t;
      const px = startX + Math.cos(curAngle) * i;
      const py = startY + Math.sin(curAngle) * i;
      const perpX = -Math.sin(curAngle), perpY = Math.cos(curAngle);
      const endFade = Math.min(t * 4, 1.0) * Math.min((1 - t) * 4, 1.0);
      for (let tt = -gougeWidth; tt <= gougeWidth; tt++) {
        const ox = ((Math.round(px + perpX * tt * 0.5) % size) + size) % size;
        const oy = ((Math.round(py + perpY * tt * 0.5) % size) + size) % size;
        const fi = oy * size + ox;
        const normalizedPos = tt / gougeWidth;
        const side = normalizedPos < 0 ? -1 : normalizedPos > 0 ? 1 : 0;
        const strength = gougeStr * normalizedPos * normalizedPos * endFade;
        floatR[fi] += perpX * side * strength;
        floatG[fi] += perpY * side * strength;
      }
    }
  }

  // Micro-dents — small circular indentations
  const dentCount = Math.floor(scratchCount * 0.04);
  for (let d = 0; d < dentCount; d++) {
    const cx = rand() * size;
    const cy = rand() * size;
    const r = 1.5 + rand() * 4;
    const dentStr = 10 + rand() * 20;
    for (let dy = -Math.ceil(r); dy <= Math.ceil(r); dy++) {
      for (let dx = -Math.ceil(r); dx <= Math.ceil(r); dx++) {
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > r) continue;
        const ox = ((Math.round(cx + dx) % size) + size) % size;
        const oy = ((Math.round(cy + dy) % size) + size) % size;
        const fi = oy * size + ox;
        const falloff = 1.0 - (dist / r);
        // Normal points outward from center of dent
        const nx = dx / (dist + 0.01);
        const ny = dy / (dist + 0.01);
        floatR[fi] += nx * dentStr * falloff;
        floatG[fi] += ny * dentStr * falloff;
      }
    }
  }

  for (let i = 0; i < size * size; i++) {
    data[i * 4] = Math.max(0, Math.min(255, Math.round(floatR[i])));
    data[i * 4 + 1] = Math.max(0, Math.min(255, Math.round(floatG[i])));
  }
  ctx.putImageData(imageData, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

// ─── Environment ───
const rgbeLoader = new RGBELoader();
const pmremGenerator = new THREE.PMREMGenerator(renderer);
pmremGenerator.compileEquirectangularShader();

function generateFallbackEnvMap() {
  const size = 128;
  const { canvas, ctx } = createCanvas(size * 4, size * 2);
  const grad = ctx.createLinearGradient(0, 0, 0, size * 2);
  grad.addColorStop(0, '#87CEEB');
  grad.addColorStop(0.4, '#B0D4E8');
  grad.addColorStop(0.5, '#E8DCC8');
  grad.addColorStop(1, '#8B7355');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size * 4, size * 2);
  const tex = new THREE.CanvasTexture(canvas);
  tex.mapping = THREE.EquirectangularReflectionMapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

const fallbackEnv = generateFallbackEnvMap();
scene.environment = fallbackEnv;
scene.background = fallbackEnv;

const HDR_ENVIRONMENTS = [
  { name: 'Sunset Clouds',  url: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/kloppenheim_06_puresky_1k.hdr' },
  { name: 'Evening Clouds',  url: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/kloofendal_48d_partly_cloudy_puresky_1k.hdr' },
  { name: 'Wasteland Clouds', url: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/wasteland_clouds_puresky_1k.hdr' },
  { name: 'Industrial Sunset', url: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/industrial_sunset_puresky_1k.hdr' },
  { name: 'Venice Sunset',  url: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/venice_sunset_1k.hdr' },
  { name: 'Sky on Fire',    url: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/the_sky_is_on_fire_1k.hdr' },
  { name: 'Cape Hill',      url: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/cape_hill_1k.hdr' },
  { name: 'Studio',         url: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/studio_small_09_1k.hdr' },
  { name: 'Photo Studio',   url: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/photo_studio_01_1k.hdr' },
];

const hdrCache = {};
let currentHdrIndex = 0;

function loadHDR(index) {
  currentHdrIndex = index;
  const entry = HDR_ENVIRONMENTS[index];
  if (hdrCache[entry.url]) {
    scene.environment = hdrCache[entry.url];
    scene.background = hdrCache[entry.url];
    return;
  }
  rgbeLoader.load(entry.url, (hdr) => {
    const envMap = pmremGenerator.fromEquirectangular(hdr).texture;
    hdr.dispose();
    hdrCache[entry.url] = envMap;
    if (currentHdrIndex === index) {
      scene.environment = envMap;
      scene.background = envMap;
    }
  }, undefined, () => {});
}

loadHDR(0);

const normalMap = generateNormalMap();
// Separate clearcoat normal maps for frame vs sticker
const frameClearcoatNormalMap = generateClearcoatNormalMap(300, 60, 0.5, 254);

// Sticker-specific wear: fingerprints, smudges, oily residue (not scratches)
function generateStickerWearNormalMap(fingerprints = 12, smudges = 8, oiliness = 40, seed = 777) {
  const size = 256;
  const { canvas, ctx } = createCanvas(size, size);
  ctx.fillStyle = 'rgb(128,128,255)';
  ctx.fillRect(0, 0, size, size);
  const imageData = ctx.getImageData(0, 0, size, size);
  const data = imageData.data;
  const floatR = new Float32Array(size * size).fill(128);
  const floatG = new Float32Array(size * size).fill(128);
  const rand = seededRandom(seed);

  // Fingerprint whorls — elliptical concentric ridges
  for (let f = 0; f < fingerprints; f++) {
    const cx = rand() * size, cy = rand() * size;
    const rx = 12 + rand() * 30, ry = 15 + rand() * 35;
    const angle = rand() * Math.PI;
    const cosA = Math.cos(angle), sinA = Math.sin(angle);
    const ridgeCount = 5 + Math.floor(rand() * 6);
    const ridgeStr = oiliness * (0.4 + rand() * 0.6);
    for (let r = 0; r < ridgeCount; r++) {
      const t = (r + 1) / (ridgeCount + 1);
      const crx = rx * t, cry = ry * t;
      const steps = Math.ceil(Math.PI * 2 * Math.max(crx, cry));
      for (let s = 0; s < steps; s++) {
        const a = (s / steps) * Math.PI * 2;
        const lx = Math.cos(a) * crx, ly = Math.sin(a) * cry;
        const px = cx + lx * cosA - ly * sinA;
        const py = cy + lx * sinA + ly * cosA;
        const ix = ((Math.round(px) % size) + size) % size;
        const iy = ((Math.round(py) % size) + size) % size;
        const fi = iy * size + ix;
        // Ridge normal points outward from ellipse center
        const dx = px - cx, dy = py - cy;
        const dist = Math.sqrt(dx * dx + dy * dy) + 0.01;
        const ridgeFade = Math.sin(t * Math.PI);
        floatR[fi] += (dx / dist) * ridgeStr * ridgeFade * 0.5;
        floatG[fi] += (dy / dist) * ridgeStr * ridgeFade * 0.5;
      }
    }
  }

  // Oily smudges — broad soft warps
  for (let s = 0; s < smudges; s++) {
    const cx = rand() * size, cy = rand() * size;
    const r = 8 + rand() * 25;
    const smudgeStr = oiliness * (0.3 + rand() * 0.5);
    const dirX = (rand() - 0.5) * 2, dirY = (rand() - 0.5) * 2;
    const dirLen = Math.sqrt(dirX * dirX + dirY * dirY) + 0.01;
    const ndx = dirX / dirLen, ndy = dirY / dirLen;
    for (let dy = -Math.ceil(r); dy <= Math.ceil(r); dy++) {
      for (let dx = -Math.ceil(r); dx <= Math.ceil(r); dx++) {
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > r) continue;
        const ix = ((Math.round(cx + dx) % size) + size) % size;
        const iy = ((Math.round(cy + dy) % size) + size) % size;
        const fi = iy * size + ix;
        const falloff = (1.0 - dist / r) * (1.0 - dist / r);
        floatR[fi] += ndx * smudgeStr * falloff;
        floatG[fi] += ndy * smudgeStr * falloff;
      }
    }
  }

  // Palm drag streaks — long soft directional smears
  const streakCount = Math.floor(smudges * 0.3);
  for (let s = 0; s < streakCount; s++) {
    const sx = rand() * size, sy = rand() * size;
    const angle = rand() * Math.PI;
    const len = 40 + rand() * 120;
    const w = 4 + rand() * 10;
    const streakStr = oiliness * 0.3;
    const cosA = Math.cos(angle), sinA = Math.sin(angle);
    const steps = Math.ceil(len);
    for (let i = 0; i < steps; i++) {
      const t = i / steps;
      const px = sx + cosA * i;
      const py = sy + sinA * i;
      const fade = Math.sin(t * Math.PI);
      for (let ww = -Math.ceil(w); ww <= Math.ceil(w); ww++) {
        const ox = ((Math.round(px - sinA * ww) % size) + size) % size;
        const oy = ((Math.round(py + cosA * ww) % size) + size) % size;
        const fi = oy * size + ox;
        const wFade = 1.0 - Math.abs(ww) / w;
        floatR[fi] += cosA * streakStr * fade * wFade;
        floatG[fi] += sinA * streakStr * fade * wFade;
      }
    }
  }

  for (let i = 0; i < size * size; i++) {
    data[i * 4] = Math.max(0, Math.min(255, Math.round(floatR[i])));
    data[i * 4 + 1] = Math.max(0, Math.min(255, Math.round(floatG[i])));
  }
  ctx.putImageData(imageData, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

const stickerClearcoatNormalMap = generateStickerWearNormalMap(12, 8, 40, 777);

// ─── Sticker Wrinkle Normal Map ───
// Generates a tangent-space normal map from procedural wrinkle height data
// This is applied to clearcoatNormalMap so wrinkles are visible on the glossy coat
function generateStickerWrinkleNormalMap(seed = 1337, size = 512) {
  const { canvas, ctx } = createCanvas(size, size);
  const rand = seededRandom(seed);
  const heightField = new Float32Array(size * size).fill(0.5);

  // Per-sticker wrinkle personality
  const wkPersonality = rand(); // 0-1: wrinkle character
  const wkDominantAngle = rand() * Math.PI; // dominant crease direction
  const wkIntensity = 0.4 + rand() * 0.8; // overall wrinkle intensity
  // Wrinkle origin point (creases radiate outward from here)
  const wkOriginX = size * (0.15 + rand() * 0.7);
  const wkOriginY = size * (0.15 + rand() * 0.7);

  // 1) Large flowing creases — radiate from unique origin per sticker
  const creaseCount = wkPersonality < 0.25 ? (2 + Math.floor(rand() * 2)) :
                      wkPersonality > 0.75 ? (7 + Math.floor(rand() * 5)) : (4 + Math.floor(rand() * 4));
  for (let c = 0; c < creaseCount; c++) {
    // Creases originate from the sticker's unique wrinkle origin
    const fromOrigin = rand() < 0.6;
    let sx, sy;
    if (fromOrigin) {
      sx = wkOriginX + (rand() - 0.5) * size * 0.3;
      sy = wkOriginY + (rand() - 0.5) * size * 0.3;
    } else {
      const edgeSide = Math.floor(rand() * 4);
      if (edgeSide === 0) { sx = rand() * size; sy = 0; }
      else if (edgeSide === 1) { sx = size; sy = rand() * size; }
      else if (edgeSide === 2) { sx = rand() * size; sy = size; }
      else { sx = 0; sy = rand() * size; }
    }
    // Bias angle toward dominant direction
    const angle = wkDominantAngle + (rand() - 0.5) * 2.0;
    const len = size * (0.3 + rand() * 0.6) * wkIntensity;
    const curve = (rand() - 0.5) * 3.0;
    const width = (3 + rand() * 12) * wkIntensity;
    const ridgeHeight = (0.2 + rand() * 0.3) * wkIntensity;
    const steps = Math.ceil(len * 1.5);
    for (let i = 0; i < steps; i++) {
      const t = i / steps;
      const curAngle = angle + curve * t * t;
      const px = sx + Math.cos(curAngle) * (i * len / steps);
      const py = sy + Math.sin(curAngle) * (i * len / steps);
      const perpX = -Math.sin(curAngle);
      const perpY = Math.cos(curAngle);
      const endFade = Math.min(t * 4, 1.0) * Math.min((1 - t) * 4, 1.0);
      for (let w = -Math.ceil(width); w <= Math.ceil(width); w++) {
        const dist = Math.abs(w);
        if (dist > width) continue;
        const nx = px + perpX * w;
        const ny = py + perpY * w;
        const ix = ((Math.round(nx) % size) + size) % size;
        const iy = ((Math.round(ny) % size) + size) % size;
        const fi = iy * size + ix;
        const normalizedDist = dist / width;
        const profile = Math.exp(-normalizedDist * normalizedDist * 4.0);
        const edgeDip = normalizedDist > 0.6 ? -(1.0 - normalizedDist) / 0.4 * 0.5 : 0;
        heightField[fi] += (profile * ridgeHeight + edgeDip * ridgeHeight * 0.4) * endFade;
      }
    }
  }

  // 2) Secondary wrinkles — perpendicular to dominant direction for variety
  const secondaryCount = Math.round((5 + Math.floor(rand() * 10)) * wkIntensity);
  const secAngleBase = wkDominantAngle + Math.PI * 0.4 + rand() * 0.4;
  for (let c = 0; c < secondaryCount; c++) {
    const sx = rand() * size;
    const sy = rand() * size;
    const angle = secAngleBase + (rand() - 0.5) * 1.5;
    const len = size * (0.1 + rand() * 0.3);
    const curve = (rand() - 0.5) * 3.5;
    const width = 1.5 + rand() * 5;
    const ridgeHeight = (0.08 + rand() * 0.18) * wkIntensity;
    const steps = Math.ceil(len);
    for (let i = 0; i < steps; i++) {
      const t = i / steps;
      const curAngle = angle + curve * t;
      const px = sx + Math.cos(curAngle) * (i * len / steps);
      const py = sy + Math.sin(curAngle) * (i * len / steps);
      const perpX = -Math.sin(curAngle);
      const perpY = Math.cos(curAngle);
      const endFade = Math.min(t * 5, 1.0) * Math.min((1 - t) * 5, 1.0);
      for (let w = -Math.ceil(width); w <= Math.ceil(width); w++) {
        const dist = Math.abs(w);
        if (dist > width) continue;
        const nx = px + perpX * w;
        const ny = py + perpY * w;
        const ix = ((Math.round(nx) % size) + size) % size;
        const iy = ((Math.round(ny) % size) + size) % size;
        const fi = iy * size + ix;
        const normalizedDist = dist / width;
        const profile = Math.exp(-normalizedDist * normalizedDist * 4.0);
        heightField[fi] += profile * ridgeHeight * endFade;
      }
    }
  }

  // 3) Micro-ripples — cluster in unique regions per sticker
  const rippleCount = Math.round((12 + Math.floor(rand() * 20)) * wkIntensity);
  const rippleZoneX = rand() * size;
  const rippleZoneY = rand() * size;
  const rippleSpread = size * (0.3 + rand() * 0.5);
  for (let r = 0; r < rippleCount; r++) {
    // 60% cluster near the ripple zone, 40% scattered
    const clustered = rand() < 0.6;
    const sx = clustered ? (rippleZoneX + (rand() - 0.5) * rippleSpread) : (rand() * size);
    const sy = clustered ? (rippleZoneY + (rand() - 0.5) * rippleSpread) : (rand() * size);
    const angle = rand() * Math.PI * 2;
    const len = size * (0.04 + rand() * 0.16);
    const width = 0.8 + rand() * 2.5;
    const ridgeHeight = (0.03 + rand() * 0.07) * wkIntensity;
    const steps = Math.ceil(len);
    for (let i = 0; i < steps; i++) {
      const t = i / steps;
      const px = sx + Math.cos(angle) * (i * len / steps);
      const py = sy + Math.sin(angle) * (i * len / steps);
      const perpX = -Math.sin(angle);
      const perpY = Math.cos(angle);
      const endFade = Math.min(t * 6, 1.0) * Math.min((1 - t) * 6, 1.0);
      for (let w = -Math.ceil(width); w <= Math.ceil(width); w++) {
        const dist = Math.abs(w);
        if (dist > width) continue;
        const nx = px + perpX * w;
        const ny = py + perpY * w;
        const ix = ((Math.round(nx) % size) + size) % size;
        const iy = ((Math.round(ny) % size) + size) % size;
        const fi = iy * size + ix;
        const profile = Math.cos(dist / width * Math.PI * 0.5);
        heightField[fi] += profile * ridgeHeight * endFade;
      }
    }
  }

  // 4) Low-frequency undulation — unique wave directions per sticker
  const waveCount = 2 + Math.floor(rand() * 4);
  const waveAngleBase = rand() * Math.PI * 2;
  for (let w = 0; w < waveCount; w++) {
    const waveAngle = waveAngleBase + rand() * 1.5;
    const freq = (0.3 + rand() * 2.5) * Math.PI * 2 / size;
    const freqX = Math.cos(waveAngle) * freq;
    const freqY = Math.sin(waveAngle) * freq;
    const phase = rand() * Math.PI * 2;
    const amp = (0.03 + rand() * 0.07) * wkIntensity;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        heightField[y * size + x] += Math.sin(x * freqX + y * freqY + phase) * amp;
      }
    }
  }

  // Normalize height field to 0-1
  let hMin = Infinity, hMax = -Infinity;
  for (let i = 0; i < size * size; i++) {
    if (heightField[i] < hMin) hMin = heightField[i];
    if (heightField[i] > hMax) hMax = heightField[i];
  }
  const hRange = hMax - hMin || 1;
  for (let i = 0; i < size * size; i++) {
    heightField[i] = (heightField[i] - hMin) / hRange;
  }

  // Convert height field to tangent-space normal map using Sobel operator
  const imageData = ctx.createImageData(size, size);
  const data = imageData.data;
  const strength = 3.0; // Normal map strength multiplier
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const x0 = (x - 1 + size) % size;
      const x1 = (x + 1) % size;
      const y0 = (y - 1 + size) % size;
      const y1 = (y + 1) % size;
      // Sobel gradients
      const dX = (
        heightField[y0 * size + x1] + 2 * heightField[y * size + x1] + heightField[y1 * size + x1]
      ) - (
        heightField[y0 * size + x0] + 2 * heightField[y * size + x0] + heightField[y1 * size + x0]
      );
      const dY = (
        heightField[y1 * size + x0] + 2 * heightField[y1 * size + x] + heightField[y1 * size + x1]
      ) - (
        heightField[y0 * size + x0] + 2 * heightField[y0 * size + x] + heightField[y0 * size + x1]
      );
      // Tangent-space normal
      let nx = -dX * strength;
      let ny = -dY * strength;
      let nz = 1.0;
      const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
      nx /= len; ny /= len; nz /= len;
      const pi = (y * size + x) * 4;
      data[pi]     = Math.round((nx * 0.5 + 0.5) * 255);
      data[pi + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      data[pi + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      data[pi + 3] = 255;
    }
  }
  ctx.putImageData(imageData, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

// Generate unique wrinkle normal maps per sticker face
// Large prime step ensures seeds are well-separated even before hashing
let wrinkleSeedCounter = 100;
function generateUniqueWrinkleNormalMap() {
  wrinkleSeedCounter += 137; // prime step for extra seed dispersion
  return generateStickerWrinkleNormalMap(wrinkleSeedCounter, 512);
}

// ─── Lighting ───
const keyLight = new THREE.DirectionalLight(0xffeedd, 1.2);
keyLight.position.set(6, 10, 4);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(1024, 1024);
keyLight.shadow.camera.near = 0.5;
keyLight.shadow.camera.far = 30;
keyLight.shadow.camera.left = -10;
keyLight.shadow.camera.right = 10;
keyLight.shadow.camera.top = 10;
keyLight.shadow.camera.bottom = -10;
keyLight.shadow.bias = -0.0005;
keyLight.shadow.normalBias = 0.04;
keyLight.shadow.radius = 0;
keyLight.shadow.blurSamples = 1;
keyLight.name = 'keyLight';
scene.add(keyLight);

const fillLight = new THREE.HemisphereLight(0xffecd2, 0x3a2f1a, 0.3);
fillLight.name = 'fillLight';
scene.add(fillLight);

const rimLight = new THREE.SpotLight(0xffa94d, 0.8, 25, Math.PI / 6, 0.5, 1);
rimLight.position.set(-4, 6, -5);
rimLight.target.position.set(0, 0, 0);
rimLight.name = 'rimLight';
scene.add(rimLight);
scene.add(rimLight.target);

// ─── SSR Uniforms ───
const ssrEnabledU = uniform(1.0);
const ssrStrengthU = uniform(0.77);
const ssrThicknessU = uniform(0.07);
const ssrMaxDistU = uniform(2.63);
const ssrFresnelPowU = uniform(1.0);
const ssrFadeU = uniform(0.90);
const ssrReflDirThreshU = uniform(0.0);
const ssrReflDirAxisU = uniform(0); // 0=Y, 1=X, 2=Z
const ssrReflDirSignU = uniform(1.0); // 1.0 = positive only, -1.0 = negative only
const projMatU = uniform(camera.projectionMatrix);
const projInvMatU = uniform(camera.projectionMatrixInverse);

// ─── Post-processing ───
const postProcessing = new THREE.PostProcessing(renderer);
const grainEnabledU = uniform(0.0);
const grainIntensityU = uniform(0.08);
const highlightClampU = uniform(0.0);
const scenePass = pass(scene, camera);

scenePass.setMRT(mrt({
  output: output,
  normal: transformedNormalView,
}));

const aoEnabledU = uniform(1.0);
const scenePassColor = scenePass.getTextureNode('output');
const scenePassNormal = scenePass.getTextureNode('normal');
const scenePassDepth = scenePass.getTextureNode('depth');

const aoPass = ao(scenePassDepth, scenePassNormal, camera);
aoPass.distanceExponent.value = 1.03;
aoPass.distanceFallOff.value = 0.25;
aoPass.radius.value = 0.07;
aoPass.scale.value = 0.60;
aoPass.thickness.value = 0.71;
aoPass.samples.value = 2;

const aoTexture = aoPass.getTextureNode();
const aoFactor = vec3(aoTexture.x, aoTexture.x, aoTexture.x);
const aoMixed = aoFactor.mul(aoEnabledU).add(float(1.0).sub(aoEnabledU));
const aoBlended = scenePassColor.mul(aoMixed);

// ─── SSR Node ───
let currentSsrSteps = 64;

function buildSsrNode(steps) {
  return Fn(([colorTex, depthTex, normalTex]) => {
  const uv = screenUV;
  const rawDepth = depthTex.sample(uv).x;
  const isSky = rawDepth.greaterThanEqual(0.999);
  const A = projMatU.element(2).element(2);
  const B = projMatU.element(3).element(2);
  const ndcZ = rawDepth.mul(2.0).sub(1.0);
  const linZ = B.div(ndcZ.add(A));
  const clipX = uv.x.mul(2.0).sub(1.0);
  const clipY = float(1.0).sub(uv.y).mul(2.0).sub(1.0);
  const vx = clipX.mul(projInvMatU.element(0).element(0)).mul(linZ);
  const vy = clipY.mul(projInvMatU.element(1).element(1)).mul(linZ);
  const viewPos = vec3(vx, vy, linZ.negate());
  const normN = normalTex.sample(uv).xyz.normalize();
  const viewDir = viewPos.normalize();
  const reflDirNorm = viewDir.sub(normN.mul(viewDir.dot(normN).mul(2.0))).normalize();
  const NdotV = normN.dot(viewDir.negate()).clamp(0.0, 1.0);
  const fresnel = float(1.0).sub(NdotV).pow(ssrFresnelPowU).clamp(0.0, 1.0);
  const reflZ = reflDirNorm.z;
  const hitColor = vec3(0.0, 0.0, 0.0).toVar();
  const hitWeight = float(0.0).toVar();
  const hitT = float(0.0).toVar();
  const prevT = float(0.0).toVar();

  // Configurable reflection direction filter
  const chosenAxis = reflDirNorm.y.mul(ssrReflDirAxisU.equal(0).toFloat())
    .add(reflDirNorm.x.mul(ssrReflDirAxisU.equal(1).toFloat()))
    .add(reflDirNorm.z.mul(ssrReflDirAxisU.equal(2).toFloat()));
  const axisVal = chosenAxis.mul(ssrReflDirSignU);
  const passesFilter = axisVal.greaterThan(ssrReflDirThreshU);

  If(ssrEnabledU.greaterThan(0.5).and(reflZ.lessThan(0.1)).and(isSky.not()).and(passesFilter), () => {
    Loop(steps, ({ i }) => {
      const fi = float(i).add(1.0);
      const t = fi.div(float(steps)).mul(ssrMaxDistU);
      const samplePos = viewPos.add(reflDirNorm.mul(t));
      const negZ = samplePos.z.negate();
      const sClipX = samplePos.x.mul(projMatU.element(0).element(0)).div(negZ);
      const sClipY = samplePos.y.mul(projMatU.element(1).element(1)).div(negZ);
      const sUV = vec2(sClipX.mul(0.5).add(0.5), float(1.0).sub(sClipY.mul(0.5).add(0.5)));
      const inBounds = sUV.x.greaterThanEqual(0.0).and(sUV.x.lessThanEqual(1.0)).and(sUV.y.greaterThanEqual(0.0)).and(sUV.y.lessThanEqual(1.0));
      If(inBounds.and(hitWeight.lessThan(0.5)), () => {
        const sampledDepth = depthTex.sample(sUV).x;
        const sampledNdcZ = sampledDepth.mul(2.0).sub(1.0);
        const sampledLinZ = B.div(sampledNdcZ.add(A));
        const diff = negZ.sub(sampledLinZ);
        const isHit = diff.greaterThan(0.0).and(diff.lessThan(ssrThicknessU));
        const notSky = sampledDepth.lessThan(0.999);
        If(isHit.and(notSky), () => {
          hitT.assign(t);
          hitWeight.assign(1.0);
        });
      });
      If(hitWeight.lessThan(0.5), () => { prevT.assign(t); });
    });

    If(hitWeight.greaterThan(0.5), () => {
      const loT = prevT.toVar();
      const hiT = hitT.toVar();
      Loop(4, () => {
        const midT = loT.add(hiT).mul(0.5);
        const midPos = viewPos.add(reflDirNorm.mul(midT));
        const midNegZ = midPos.z.negate();
        const midClipX = midPos.x.mul(projMatU.element(0).element(0)).div(midNegZ);
        const midClipY = midPos.y.mul(projMatU.element(1).element(1)).div(midNegZ);
        const midUV = vec2(midClipX.mul(0.5).add(0.5), float(1.0).sub(midClipY.mul(0.5).add(0.5)));
        const midDepth = depthTex.sample(midUV).x;
        const midNdcZ = midDepth.mul(2.0).sub(1.0);
        const midLinZ = B.div(midNdcZ.add(A));
        const midDiff = midNegZ.sub(midLinZ);
        If(midDiff.greaterThan(0.0), () => { hiT.assign(midT); }).Else(() => { loT.assign(midT); });
      });
      const finalT = loT.add(hiT).mul(0.5);
      const finalPos = viewPos.add(reflDirNorm.mul(finalT));
      const finalNegZ = finalPos.z.negate();
      const finalClipX = finalPos.x.mul(projMatU.element(0).element(0)).div(finalNegZ);
      const finalClipY = finalPos.y.mul(projMatU.element(1).element(1)).div(finalNegZ);
      const finalUV = vec2(finalClipX.mul(0.5).add(0.5), float(1.0).sub(finalClipY.mul(0.5).add(0.5)));
      const edgeX = finalUV.x.mul(float(1.0).sub(finalUV.x)).mul(4.0).clamp(0.0, 1.0);
      const edgeY = finalUV.y.mul(float(1.0).sub(finalUV.y)).mul(4.0).clamp(0.0, 1.0);
      const edgeFade = edgeX.mul(edgeY);
      const distFade = float(1.0).sub(finalT.div(ssrMaxDistU)).clamp(0.0, 1.0);
      const sampledColor = colorTex.sample(finalUV).xyz;
      const finalWeight = edgeFade.mul(distFade);
      hitColor.assign(sampledColor.mul(finalWeight));
    });
  });

  const reflectionMix = hitWeight.mul(fresnel).mul(ssrStrengthU).mul(ssrFadeU);
  return vec4(hitColor, reflectionMix);
});
}

let ssrReflectionNode = buildSsrNode(64);

// ─── Bloom ───
const bloomEnabledU = uniform(1.0);
const bloomStrengthU = uniform(0.35);
const bloomRadiusU = uniform(0.4);
const bloomThresholdU = uniform(0.85);

function rebuildPostPipeline() {
  const ssrResult = ssrReflectionNode(scenePassColor, scenePassDepth, scenePassNormal);
  let source = aoBlended.add(vec4(ssrResult.xyz.mul(ssrResult.w), 0.0));

  const bloomOnly = bloom(source, bloomStrengthU, bloomRadiusU, bloomThresholdU);
  source = source.add(bloomOnly.mul(bloomEnabledU));

  const _uv = screenUV.mul(vec2(float(window.innerWidth), float(window.innerHeight)));
  const _seed = _uv.add(vec2(time.mul(7.23), time.mul(3.91)));
  const _noise = hash(_seed.dot(vec2(127.1, 311.7)));
  const _grainAmount = _noise.sub(0.5).mul(grainIntensityU).mul(grainEnabledU);
  const _withGrain = clamp(source.add(_grainAmount), 0.0, 1.0);

  // Soft highlight compression — pull down hot pixels toward 0.92 max
  const _lum = _withGrain.x.mul(0.2126).add(_withGrain.y.mul(0.7152)).add(_withGrain.z.mul(0.0722));
  const _highlightKnee = float(0.75);
  const _highlightCompress = float(1.0).sub(
    _lum.sub(_highlightKnee).max(0.0).mul(0.6).min(0.3)
  );
  const _compressed = _withGrain.mul(_highlightCompress);

  postProcessing.outputNode = _compressed;
  postProcessing.needsUpdate = true;
}

rebuildPostPipeline();

// ─── Rubik's Cube ───
const FACE_COLORS = {
  right:  new THREE.Color('#FF2D78'), // Hot pink
  left:   new THREE.Color('#FF8C00'), // Orange
  top:    new THREE.Color('#00D4FF'), // Cyan
  bottom: new THREE.Color('#FFD500'), // Yellow
  front:  new THREE.Color('#33E64D'), // Green
  back:   new THREE.Color('#C850FF'), // Purple
};

const CUBIE_SIZE = 0.62;
const GAP = 0.04;
const STEP = CUBIE_SIZE + GAP;
const INNER_COLOR = new THREE.Color('#1a1a1a');
const FRAME_COLOR = new THREE.Color('#111111');

// Generate a sticker texture: colored rounded rectangle with dark border
function createStickerTexture(color, size = 512, seed = 0) {
  const { canvas, ctx } = createCanvas(size, size);
  const rand = seededRandom(seed + 7919);

  // Sticker fills the entire texture (no dark frame margin — frame is the cubie itself)
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, size, size);

  // Use full size with tiny margin for edge effects
  const margin = size * 0.02;
  const radius = size * 0.06;
  const w = size - margin * 2;
  const h = size - margin * 2;

  // Read current wobble param
  const wobblePct = (typeof stickerParams !== 'undefined') ? stickerParams.wobble : 0.15;
  const wobbleAmt = size * 0.01 * wobblePct;
  const steps = 40;

  ctx.beginPath();
  function wobble() { return (rand() - 0.5) * wobbleAmt * 2; }

  // Top edge
  ctx.moveTo(margin + radius + wobble(), margin + wobble());
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const x = margin + radius + t * (w - radius * 2);
    ctx.lineTo(x + wobble(), margin + wobble());
  }
  ctx.quadraticCurveTo(margin + w + wobble(), margin + wobble(), margin + w + wobble(), margin + radius + wobble());
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const y = margin + radius + t * (h - radius * 2);
    ctx.lineTo(margin + w + wobble(), y + wobble());
  }
  ctx.quadraticCurveTo(margin + w + wobble(), margin + h + wobble(), margin + w - radius + wobble(), margin + h + wobble());
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const x = margin + w - radius - t * (w - radius * 2);
    ctx.lineTo(x + wobble(), margin + h + wobble());
  }
  ctx.quadraticCurveTo(margin + wobble(), margin + h + wobble(), margin + wobble(), margin + h - radius + wobble());
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const y = margin + h - radius - t * (h - radius * 2);
    ctx.lineTo(margin + wobble(), y + wobble());
  }
  ctx.quadraticCurveTo(margin + wobble(), margin + wobble(), margin + radius + wobble(), margin + wobble());
  ctx.closePath();

  // Clip to the sticker shape for imperfections
  ctx.save();
  ctx.clip();

  // Matte gradient — less glossy, more worn look
  const grad = ctx.createLinearGradient(margin, margin, margin, margin + h);
  grad.addColorStop(0, 'rgba(255,255,255,0.08)');
  grad.addColorStop(0.3, 'rgba(255,255,255,0.02)');
  grad.addColorStop(0.5, 'rgba(0,0,0,0.03)');
  grad.addColorStop(0.8, 'rgba(0,0,0,0.10)');
  grad.addColorStop(1, 'rgba(0,0,0,0.15)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  // ── Per-sticker personality profile ──
  // Each sticker gets a unique "character" that biases which imperfections dominate
  const rawPersonality = rand(); // 0-1 raw
  // Collapse personality toward 0.5 when variance is low — reduces pristine-vs-heavy contrast
  const personality = 0.5 + (rawPersonality - 0.5) * ((typeof stickerParams !== 'undefined' && stickerParams.wearVariance != null) ? stickerParams.wearVariance : 1.0);
  const fpScale = 0.3 + rand() * 1.4;     // fingerprint size multiplier
  const wearBias = rand() * Math.PI * 2;   // angular bias for wear concentration
  const wearQuadrant = Math.floor(rand() * 4); // which quadrant gets most wear
  // wearVariance controls how spread-out the age differences are across stickers
  // At 0 all stickers look equally worn (ageFactor=0.8), at 1 full range 0.4–1.2
  const wv = (typeof stickerParams !== 'undefined' && stickerParams.wearVariance != null) ? stickerParams.wearVariance : 1.0;
  const ageFactor = 0.8 + (rand() - 0.5) * 0.8 * wv;    // how "aged" this sticker looks

  // ── Fingerprints (oily smudge ellipses) ──
  const baseFpCount = (typeof stickerParams !== 'undefined') ? stickerParams.fingerprints : 5;
  // Vary count per sticker: some pristine (0-1), some heavily handled (up to 2x)
  const fingerprintCount = Math.max(0, Math.round(baseFpCount * (personality < 0.2 ? 0.2 : (personality > 0.8 ? 1.8 : 1.0))));
  for (let f = 0; f < fingerprintCount; f++) {
    // Cluster fingerprints in a unique region per sticker using wearQuadrant
    const qx = (wearQuadrant % 2 === 0) ? 0.15 + rand() * 0.4 : 0.45 + rand() * 0.4;
    const qy = (wearQuadrant < 2) ? 0.15 + rand() * 0.4 : 0.45 + rand() * 0.4;
    const cx = margin + w * (rand() < 0.6 ? qx : (0.1 + rand() * 0.8));
    const cy = margin + h * (rand() < 0.6 ? qy : (0.1 + rand() * 0.8));
    const rx = (10 + rand() * 40) * fpScale;
    const ry = (15 + rand() * 50) * fpScale;
    const angle = wearBias + rand() * Math.PI * 0.5;
    const rings = 4 + Math.floor(rand() * 12);
    for (let r = 0; r < rings; r++) {
      const t = r / rings;
      const ringRx = rx * (0.2 + t * 0.8);
      const ringRy = ry * (0.2 + t * 0.8);
      ctx.strokeStyle = `rgba(255,255,255,${0.01 + rand() * 0.03})`;
      ctx.lineWidth = 0.5 + rand() * 1.5;
      ctx.beginPath();
      ctx.ellipse(cx, cy, ringRx, ringRy, angle, rand() * 0.5, Math.PI * 2 - rand() * 0.8);
      ctx.stroke();
    }
    const smudgeGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(rx, ry));
    smudgeGrad.addColorStop(0, `rgba(255,255,255,${0.03 + rand() * 0.05})`);
    smudgeGrad.addColorStop(0.5 + rand() * 0.3, `rgba(255,255,255,${0.005 + rand() * 0.02})`);
    smudgeGrad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = smudgeGrad;
    ctx.beginPath();
    ctx.ellipse(cx, cy, rx * (1.0 + rand() * 0.4), ry * (1.0 + rand() * 0.4), angle, 0, Math.PI * 2);
    ctx.fill();
  }

  // ── Worn/torn holes (sticker peeled away revealing dark base) ──
  const baseHoleCount = (typeof stickerParams !== 'undefined') ? stickerParams.holes : 3;
  // Some stickers are nearly pristine, others heavily damaged
  const holeCount = Math.max(0, Math.round(baseHoleCount * ageFactor * (personality < 0.15 ? 0.0 : 1.0)));
  ctx.globalCompositeOperation = 'destination-out';
  // Pick 1-2 specific corners/edges this sticker's holes cluster around
  const holeClusterCorner = Math.floor(rand() * 4);
  const holeClusterEdge = Math.floor(rand() * 4);
  for (let h2 = 0; h2 < holeCount; h2++) {
    let hx, hy;
    const placement = rand();
    if (placement < 0.35) {
      // Near the sticker's unique cluster corner
      const cx2 = [margin + 10, margin + w - 10, margin + w - 10, margin + 10][holeClusterCorner];
      const cy2 = [margin + 10, margin + 10, margin + h - 10, margin + h - 10][holeClusterCorner];
      hx = cx2 + (rand() - 0.5) * 30;
      hy = cy2 + (rand() - 0.5) * 30;
    } else if (placement < 0.65) {
      // Near the sticker's unique cluster edge
      if (holeClusterEdge === 0) { hx = margin + rand() * w; hy = margin + rand() * 18; }
      else if (holeClusterEdge === 1) { hx = margin + rand() * w; hy = margin + h - rand() * 18; }
      else if (holeClusterEdge === 2) { hx = margin + rand() * 18; hy = margin + rand() * h; }
      else { hx = margin + w - rand() * 18; hy = margin + rand() * h; }
    } else {
      hx = margin + 10 + rand() * (w - 20);
      hy = margin + 10 + rand() * (h - 20);
    }
    // Vary hole size dramatically per sticker
    const holeR = (2 + rand() * 16) * ageFactor;
    const blobs = 2 + Math.floor(rand() * 6);
    for (let b = 0; b < blobs; b++) {
      const bx = hx + (rand() - 0.5) * holeR * 1.8;
      const by = hy + (rand() - 0.5) * holeR * 1.8;
      const br = holeR * (0.2 + rand() * 0.8);
      ctx.beginPath();
      ctx.arc(bx, by, br, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.globalCompositeOperation = 'source-over';

  // ── Draw dark base back under the holes (reveals frame beneath) ──
  ctx.globalCompositeOperation = 'destination-over';
  ctx.fillStyle = '#111111';
  ctx.fillRect(0, 0, size, size);
  ctx.globalCompositeOperation = 'source-over';

  // ── Edge wear — unique per-sticker chipping/peeling along edges ──
  const baseEdgeWear = (typeof stickerParams !== 'undefined') ? stickerParams.edgeWear : 8;
  // Dramatically vary wear amount: some stickers barely worn, others heavily
  const edgeWearCount = Math.round(baseEdgeWear * ageFactor * (0.5 + rand() * 1.0));
  ctx.globalCompositeOperation = 'source-atop';

  // Pick 1-2 dominant edges unique to this sticker (strongly biased)
  const dominantEdge = Math.floor(rand() * 4);
  const secondaryEdge = (dominantEdge + 1 + Math.floor(rand() * 2)) % 4;
  const wearIntensity = 0.3 + rand() * 0.7 * ageFactor;
  // Some stickers are chip-heavy, others scratch-heavy
  const chipBias = rand(); // >0.5 = more chips, <0.5 = more scratches

  for (let i = 0; i < edgeWearCount + 4; i++) {
    let cx, cy;
    const r2 = rand();
    const activeEdge = r2 < 0.45 ? dominantEdge : (r2 < 0.7 ? secondaryEdge : Math.floor(rand() * 4));
    // Place wear along the chosen edge with varied depth
    const edgeDepth = rand() * 16 * ageFactor;
    switch (activeEdge) {
      case 0: cx = margin + rand() * w; cy = margin + edgeDepth; break;
      case 1: cx = margin + w - edgeDepth; cy = margin + rand() * h; break;
      case 2: cx = margin + rand() * w; cy = margin + h - edgeDepth; break;
      case 3: cx = margin + edgeDepth; cy = margin + rand() * h; break;
    }
    const isChip = rand() > (1.0 - chipBias);
    if (isChip) {
      const cr = (1.5 + rand() * 8) * wearIntensity;
      const blobs = 1 + Math.floor(rand() * 4);
      for (let b = 0; b < blobs; b++) {
        ctx.fillStyle = `rgba(255,255,255,${0.04 + rand() * 0.1})`;
        ctx.beginPath();
        ctx.arc(cx + (rand()-0.5)*cr*1.5, cy + (rand()-0.5)*cr*1.5, cr*(0.3+rand()*0.7), 0, Math.PI*2);
        ctx.fill();
      }
    } else {
      const scratchLen = (4 + rand() * 22) * wearIntensity;
      const scratchAngle = wearBias + (rand() - 0.5) * 1.5;
      ctx.strokeStyle = `rgba(255,255,255,${0.04 + rand() * 0.09})`;
      ctx.lineWidth = 0.8 + rand() * 3;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(scratchAngle)*scratchLen, cy + Math.sin(scratchAngle)*scratchLen);
      ctx.stroke();
    }
  }

  // ── Corner wear — unique worn corners per sticker (0-3 corners affected) ──
  const numWornCorners = Math.floor(rand() * 4); // 0 to 3 corners
  const cornerOrder = [0, 1, 2, 3].sort(() => rand() - 0.5);
  const corners = [
    [margin + 8, margin + 8],
    [margin + w - 8, margin + 8],
    [margin + w - 8, margin + h - 8],
    [margin + 8, margin + h - 8],
  ];
  for (let ci = 0; ci < numWornCorners; ci++) {
    const [ccx, ccy] = corners[cornerOrder[ci]];
    const cornerIntensity = rand() * ageFactor;
    const chipCount = 1 + Math.floor(rand() * 5 * cornerIntensity);
    for (let c = 0; c < chipCount; c++) {
      const r = 1.5 + rand() * 6 * cornerIntensity;
      ctx.fillStyle = `rgba(255,255,255,${0.03 + rand() * 0.08})`;
      ctx.beginPath();
      ctx.arc(ccx + (rand()-0.5)*14, ccy + (rand()-0.5)*14, r, 0, Math.PI*2);
      ctx.fill();
    }
  }

  // ── Sticker wrinkles — subtle crease lines from peeling/reapplication ──
  ctx.globalCompositeOperation = 'source-atop';
  // Wrinkle style per sticker: some have many small wrinkles, others few large ones
  const wrinkleStyle = rand(); // <0.3: few big, 0.3-0.7: medium, >0.7: many small
  const wrinkleCount = wrinkleStyle < 0.3 ? (1 + Math.floor(rand() * 2)) : 
                       wrinkleStyle > 0.7 ? (4 + Math.floor(rand() * 5)) : (2 + Math.floor(rand() * 3));
  // Per-sticker dominant wrinkle direction
  const wrinkleDir = rand() * Math.PI;
  for (let i = 0; i < wrinkleCount; i++) {
    let sx, sy, ex, ey;
    // Use dominant direction with per-wrinkle variance
    const thisAngle = wrinkleDir + (rand() - 0.5) * 1.2;
    const crossLen = w * (wrinkleStyle < 0.3 ? (0.6 + rand() * 0.4) : (0.2 + rand() * 0.5));
    const centerX = margin + w * (0.2 + rand() * 0.6);
    const centerY = margin + h * (0.2 + rand() * 0.6);
    sx = centerX - Math.cos(thisAngle) * crossLen * 0.5;
    sy = centerY - Math.sin(thisAngle) * crossLen * 0.5;
    ex = centerX + Math.cos(thisAngle) * crossLen * 0.5;
    ey = centerY + Math.sin(thisAngle) * crossLen * 0.5;

    const mx = (sx + ex) / 2 + (rand() - 0.5) * w * 0.35;
    const my = (sy + ey) / 2 + (rand() - 0.5) * h * 0.35;
    const lw = wrinkleStyle < 0.3 ? (0.8 + rand() * 1.2) : (0.4 + rand() * 0.7);
    ctx.lineWidth = lw;
    ctx.lineCap = 'round';
    ctx.strokeStyle = `rgba(0,0,0,${0.03 + rand() * 0.06})`;
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.quadraticCurveTo(mx, my, ex, ey);
    ctx.stroke();
    ctx.strokeStyle = `rgba(255,255,255,${0.02 + rand() * 0.04})`;
    ctx.beginPath();
    ctx.moveTo(sx + 1, sy + 1);
    ctx.quadraticCurveTo(mx + 1, my + 1, ex + 1, ey + 1);
    ctx.stroke();
  }

  // ── Fine secondary wrinkles — vary count dramatically ──
  const fineWrinkles = Math.round((2 + Math.floor(rand() * 6)) * ageFactor);
  const fineDir = wrinkleDir + Math.PI * 0.3 + rand() * 0.4; // slightly offset from main
  for (let i = 0; i < fineWrinkles; i++) {
    const sx = margin + w * (0.05 + rand() * 0.9);
    const sy = margin + h * (0.05 + rand() * 0.9);
    const ang = fineDir + (rand() - 0.5) * 1.5;
    const len = 10 + rand() * 50;
    const bend = (rand() - 0.5) * 20;
    ctx.lineWidth = 0.3 + rand() * 0.6;
    ctx.strokeStyle = `rgba(0,0,0,${0.02 + rand() * 0.04})`;
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.quadraticCurveTo(
      sx + Math.cos(ang) * len * 0.5 + bend,
      sy + Math.sin(ang) * len * 0.5 + bend,
      sx + Math.cos(ang) * len,
      sy + Math.sin(ang) * len
    );
    ctx.stroke();
    ctx.strokeStyle = `rgba(255,255,255,${0.015 + rand() * 0.03})`;
    ctx.beginPath();
    ctx.moveTo(sx + 0.7, sy + 0.7);
    ctx.quadraticCurveTo(
      sx + Math.cos(ang) * len * 0.5 + bend + 0.7,
      sy + Math.sin(ang) * len * 0.5 + bend + 0.7,
      sx + Math.cos(ang) * len + 0.7,
      sy + Math.sin(ang) * len + 0.7
    );
    ctx.stroke();
  }

  // ── Broad scuff marks — unique direction and clustering per sticker ──
  const scuffCount = Math.round((1 + Math.floor(rand() * 5)) * ageFactor);
  const scuffBaseAngle = wearBias + rand() * 0.5;
  // Scuffs cluster in a specific region of this sticker
  const scuffCenterX = margin + w * (0.2 + rand() * 0.6);
  const scuffCenterY = margin + h * (0.2 + rand() * 0.6);
  ctx.globalCompositeOperation = 'source-atop';
  for (let i = 0; i < scuffCount; i++) {
    const sx = scuffCenterX + (rand() - 0.5) * w * 0.5;
    const sy = scuffCenterY + (rand() - 0.5) * h * 0.5;
    const angle = scuffBaseAngle + (rand() - 0.5) * 1.0;
    const len = 15 + rand() * 70;
    const wid = 1.5 + rand() * 7;
    ctx.strokeStyle = `rgba(0,0,0,${0.02 + rand() * 0.06})`;
    ctx.lineWidth = wid;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    const cpx = sx + Math.cos(angle) * len * 0.5 + (rand() - 0.5) * 30;
    const cpy = sy + Math.sin(angle) * len * 0.5 + (rand() - 0.5) * 30;
    ctx.quadraticCurveTo(cpx, cpy, sx + Math.cos(angle) * len, sy + Math.sin(angle) * len);
    ctx.stroke();
  }

  // ── Micro-scratches — unique dominant scratch direction per sticker ──
  const baseScratchCount = (typeof stickerParams !== 'undefined') ? stickerParams.microScratches : 6;
  const microScratchCount = Math.round(baseScratchCount * (0.3 + rand() * 1.4) * ageFactor);
  const scratchDominantAngle = rand() * Math.PI; // unique scratch direction
  ctx.globalCompositeOperation = 'source-atop';
  for (let i = 0; i < microScratchCount; i++) {
    const sx = margin + rand() * w;
    const sy = margin + rand() * h;
    // 70% follow dominant direction, 30% random
    const angle = rand() < 0.7 ? (scratchDominantAngle + (rand() - 0.5) * 0.6) : (rand() * Math.PI * 2);
    const len = 5 + rand() * 50;
    ctx.strokeStyle = `rgba(255,255,255,${0.03 + rand() * 0.08})`;
    ctx.lineWidth = 0.4 + rand() * 1.2;
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx + Math.cos(angle) * len, sy + Math.sin(angle) * len);
    ctx.stroke();
  }

  // ── Dust/dirt specks — cluster in unique zone per sticker ──
  const baseDustCount = (typeof stickerParams !== 'undefined') ? stickerParams.dustSpecks : 10;
  const dustSpeckCount = Math.round(baseDustCount * (0.3 + rand() * 1.4));
  const dustZoneX = margin + w * (0.1 + rand() * 0.8);
  const dustZoneY = margin + h * (0.1 + rand() * 0.8);
  const dustSpread = w * (0.3 + rand() * 0.7);
  ctx.globalCompositeOperation = 'source-atop';
  for (let i = 0; i < dustSpeckCount; i++) {
    const clustered = rand() < 0.5;
    const dx = clustered ? (dustZoneX + (rand() - 0.5) * dustSpread) : (margin + rand() * w);
    const dy = clustered ? (dustZoneY + (rand() - 0.5) * dustSpread) : (margin + rand() * h);
    const dr = 0.4 + rand() * 2.5;
    const isDark = rand() > 0.5;
    ctx.fillStyle = isDark
      ? `rgba(0,0,0,${0.04 + rand() * 0.09})`
      : `rgba(255,255,255,${0.02 + rand() * 0.06})`;
    ctx.beginPath();
    ctx.arc(dx, dy, dr, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();

  // ── Subtle edge darkening around sticker border ──
  ctx.globalCompositeOperation = 'source-over';
  const edgeGrad = ctx.createRadialGradient(size/2, size/2, size*0.35, size/2, size/2, size*0.52);
  edgeGrad.addColorStop(0, 'rgba(0,0,0,0)');
  edgeGrad.addColorStop(1, 'rgba(0,0,0,0.12)');
  ctx.fillStyle = edgeGrad;
  ctx.fillRect(0, 0, size, size);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// Cache sticker textures
// Each cubie face gets a unique sticker with its own imperfections
let stickerSeedCounter = 0;
function getStickerTexture(face) {
  // Generate a unique texture per cubie face for varied imperfections
  stickerSeedCounter += 97; // prime step for seed dispersion
  return createStickerTexture('#' + FACE_COLORS[face].getHexString(), 256, stickerSeedCounter);
}

// Inner face (dark plastic frame) texture
let innerTexture = null;
function getInnerTexture() {
  if (!innerTexture) {
    const { canvas, ctx } = createCanvas(64, 64);
    ctx.fillStyle = '#111111';
    ctx.fillRect(0, 0, 64, 64);
    innerTexture = new THREE.CanvasTexture(canvas);
    innerTexture.colorSpace = THREE.SRGBColorSpace;
  }
  return innerTexture;
}

// Shared frame material — one instance for all inner faces
const sharedFrameMaterial = new THREE.MeshPhysicalMaterial({
  color: FRAME_COLOR,
  roughness: 0.09,
  metalness: 0.00,
  clearcoat: 0.92,
  clearcoatRoughness: 0.29,
  clearcoatNormalMap: frameClearcoatNormalMap,
  clearcoatNormalScale: new THREE.Vector2(0.15, 0.15),
  normalMap: normalMap,
  normalScale: new THREE.Vector2(0.39, 0.39),
  envMapIntensity: 1.71,
  sheen: 0.70,
  sheenRoughness: 0.68,
  sheenColor: new THREE.Color(0x333333),
});

// Unique sticker material per individual sticker (not shared per face)
// This ensures each of the 9 stickers on a face has its own wear/wrinkle patterns
const allStickerMaterials = {}; // keyed by unique sticker id: "face_x_y_z"
const sharedStickerMaterials = {}; // legacy compat: maps face -> array of materials for that face

function createStickerMaterial(face) {
  const stickerTex = getStickerTexture(face);
  const hsl = { h: 0, s: 0, l: 0 };
  FACE_COLORS[face].getHSL(hsl);
  const sheenCol = new THREE.Color().setHSL(hsl.h, hsl.s * 0.3, Math.min(1, hsl.l + 0.35));
  const wrinkleNormal = generateUniqueWrinkleNormalMap();
  return new THREE.MeshPhysicalMaterial({
    map: stickerTex,
    color: 0xffffff,
    roughness: 0.00,
    metalness: 0.72,
    clearcoat: 0.85,
    clearcoatRoughness: 0.05,
    normalMap: normalMap,
    normalScale: new THREE.Vector2(0.18, 0.18),
    clearcoatNormalMap: wrinkleNormal,
    clearcoatNormalScale: new THREE.Vector2(0.35, 0.35),
    envMapIntensity: 1.19,
    sheen: 0.1,
    sheenRoughness: 0.47,
    sheenColor: sheenCol,
    iridescence: 0.8,
    iridescenceIOR: 1.35,
    iridescenceThicknessRange: [200, 600],
    transparent: false,
  });
}

function getUniqueStickerMaterial(face, x, y, z) {
  const key = `${face}_${x}_${y}_${z}`;
  if (!allStickerMaterials[key]) {
    allStickerMaterials[key] = createStickerMaterial(face);
    if (!sharedStickerMaterials[face]) sharedStickerMaterials[face] = [];
    sharedStickerMaterials[face].push(allStickerMaterials[key]);
  }
  return allStickerMaterials[key];
}

// Sticker overlay geometry — a very thin raised pad for each face direction
const STICKER_THICKNESS = 0.003;
const STICKER_INSET = CUBIE_SIZE * 0.82; // slightly smaller than the cubie face
// RoundedBoxGeometry clamps radius to half the smallest dimension (STICKER_THICKNESS/2),
// so we use an extruded 2D rounded-rect Shape instead for visible corner rounding.
const STICKER_RADIUS = 0.025;
const stickerShape = new THREE.Shape();
{
  const w = STICKER_INSET / 2;
  const h = STICKER_INSET / 2;
  const r = STICKER_RADIUS;
  stickerShape.moveTo(-w + r, -h);
  stickerShape.lineTo(w - r, -h);
  stickerShape.quadraticCurveTo(w, -h, w, -h + r);
  stickerShape.lineTo(w, h - r);
  stickerShape.quadraticCurveTo(w, h, w - r, h);
  stickerShape.lineTo(-w + r, h);
  stickerShape.quadraticCurveTo(-w, h, -w, h - r);
  stickerShape.lineTo(-w, -h + r);
  stickerShape.quadraticCurveTo(-w, -h, -w + r, -h);
}
const stickerGeo = new THREE.ExtrudeGeometry(stickerShape, {
  depth: STICKER_THICKNESS,
  bevelEnabled: true,
  bevelThickness: 0.0005,
  bevelSize: 0.0005,
  bevelSegments: 1,
  curveSegments: 8,
});
// Center the extrusion so the sticker is centered on its origin (extrude goes 0..depth in Z)
stickerGeo.translate(0, 0, -STICKER_THICKNESS / 2);
// Compute UVs: project XY onto [0,1] range for proper texture mapping
{
  const pos = stickerGeo.attributes.position;
  const uvArr = new Float32Array(pos.count * 2);
  const halfW = STICKER_INSET / 2;
  const halfH = STICKER_INSET / 2;
  for (let i = 0; i < pos.count; i++) {
    uvArr[i * 2]     = (pos.getX(i) + halfW) / STICKER_INSET;
    uvArr[i * 2 + 1] = (pos.getY(i) + halfH) / STICKER_INSET;
  }
  stickerGeo.setAttribute('uv', new THREE.BufferAttribute(uvArr, 2));
}

// Face direction normals and rotations for sticker placement
const FACE_DIRS = {
  right:  { axis: new THREE.Vector3(1, 0, 0),  rot: new THREE.Euler(0, Math.PI / 2, 0) },
  left:   { axis: new THREE.Vector3(-1, 0, 0), rot: new THREE.Euler(0, -Math.PI / 2, 0) },
  top:    { axis: new THREE.Vector3(0, 1, 0),  rot: new THREE.Euler(-Math.PI / 2, 0, 0) },
  bottom: { axis: new THREE.Vector3(0, -1, 0), rot: new THREE.Euler(Math.PI / 2, 0, 0) },
  front:  { axis: new THREE.Vector3(0, 0, 1),  rot: new THREE.Euler(0, 0, 0) },
  back:   { axis: new THREE.Vector3(0, 0, -1), rot: new THREE.Euler(0, Math.PI, 0) },
};

// Build cubie materials — ALL faces get the frame material now
function createCubieMaterials() {
  return [sharedFrameMaterial, sharedFrameMaterial, sharedFrameMaterial,
          sharedFrameMaterial, sharedFrameMaterial, sharedFrameMaterial];
}

// Add sticker overlay meshes as children of a cubie
function addStickerOverlays(cubieMesh, x, y, z) {
  const faces = ['right', 'left', 'top', 'bottom', 'front', 'back'];
  const conditions = [x === 1, x === -1, y === 1, y === -1, z === 1, z === -1];
  faces.forEach((face, i) => {
    if (!conditions[i]) return;
    const dir = FACE_DIRS[face];
    const stickerMesh = new THREE.Mesh(stickerGeo, getUniqueStickerMaterial(face, x, y, z));
    // Position the sticker flush on the cubie face
    const offset = dir.axis.clone().multiplyScalar(CUBIE_SIZE / 2 + STICKER_THICKNESS / 2 + 0.0005);
    stickerMesh.position.copy(offset);
    stickerMesh.rotation.copy(dir.rot);
    stickerMesh.castShadow = true;
    stickerMesh.receiveShadow = false;
    stickerMesh.name = `sticker_${face}_${x+1}_${y+1}_${z+1}`;
    stickerMesh.userData = { isSticker: true, face };
    cubieMesh.add(stickerMesh);
  });
}

const cubies = [];
const cubieGroup = new THREE.Group();
cubieGroup.name = 'rubiksCube';
scene.add(cubieGroup);

const cubieGeo = new RoundedBoxGeometry(CUBIE_SIZE, CUBIE_SIZE, CUBIE_SIZE, 4, 0.03);

for (let x = -1; x <= 1; x++) {
  for (let y = -1; y <= 1; y++) {
    for (let z = -1; z <= 1; z++) {
      const materials = createCubieMaterials();
      const mesh = new THREE.Mesh(cubieGeo, materials);
      mesh.position.set(x * STEP, y * STEP, z * STEP);
      // Only outer cubies cast shadows; center cubie (0,0,0) is invisible
      const isEdge = (x !== 0 || y !== 0 || z !== 0);
      mesh.castShadow = isEdge;
      mesh.receiveShadow = isEdge;
      mesh.name = `cubie_${x+1}_${y+1}_${z+1}`;
      mesh.userData = { gx: x, gy: y, gz: z };
      cubieGroup.add(mesh);
      cubies.push(mesh);
      // Add sticker overlays as child meshes on outer faces
      addStickerOverlays(mesh, x, y, z);
    }
  }
}

// ─── Lake Surface ───
const lakeSettings = {
  waveScale: 1.0,
  waveStrength: 5,
  waveDetail: 0.08,
  driftSpeed: 0.0003,
  color: '#1a4a6b',
  opacity: 0.75,
  transmission: 0,
  ior: 1.33,
  normalStrength: 0.5,
};

function generateWaterNormalMap(detail, strength) {
  const size = 256;
  const { canvas, ctx } = createCanvas(size, size);
  const imageData = ctx.createImageData(size, size);
  const data = imageData.data;
  const d = detail || lakeSettings.waveDetail;
  const str = strength || lakeSettings.waveStrength;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      // Multiple octaves of smooth sine waves — no harsh edges
      const s1 = Math.sin(x * d * 0.6 + 0.3) * Math.cos(y * d * 0.8 + 0.5);
      const s2 = Math.sin(x * d * 1.4 + 2.1) * Math.cos(y * d * 1.1 + 1.3) * 0.5;
      const s3 = Math.sin((x + y) * d * 0.4 + 0.7) * 0.3;
      const s4 = Math.sin(x * d * 2.3 - y * d * 0.9 + 3.1) * 0.2;
      const nx = 128 + (s1 + s2 + s3) * str;
      const ny = 128 + (s2 + s3 + s4) * str;
      data[i]     = Math.max(0, Math.min(255, Math.round(nx)));
      data[i + 1] = Math.max(0, Math.min(255, Math.round(ny)));
      data[i + 2] = 255;
      data[i + 3] = 255;
    }
  }
  ctx.putImageData(imageData, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

let waterNormalMap = generateWaterNormalMap();

// Large lake with alpha fade at edges for endless look
const lakeRadius = 40;
const lakeSegments = 64;
const lakeGeo = new THREE.CircleGeometry(lakeRadius, lakeSegments);
lakeGeo.rotateX(-Math.PI / 2);

// Add vertex colors for edge fade
const lakePos = lakeGeo.attributes.position;
const lakeColors = new Float32Array(lakePos.count * 4);
for (let i = 0; i < lakePos.count; i++) {
  const x = lakePos.getX(i);
  const z = lakePos.getZ(i);
  const dist = Math.sqrt(x * x + z * z) / lakeRadius;
  const alpha = 1.0 - Math.pow(Math.max(0, (dist - 0.3) / 0.7), 1.5);
  lakeColors[i * 4]     = 1;
  lakeColors[i * 4 + 1] = 1;
  lakeColors[i * 4 + 2] = 1;
  lakeColors[i * 4 + 3] = Math.max(0, Math.min(1, alpha));
}
lakeGeo.setAttribute('color', new THREE.BufferAttribute(lakeColors, 4));

const lakeMat = new THREE.MeshPhysicalMaterial({
  color: new THREE.Color(lakeSettings.color),
  roughness: 0.05,
  metalness: 0.0,
  transmission: lakeSettings.transmission,
  thickness: 0,
  ior: lakeSettings.ior,
  clearcoat: 1.0,
  clearcoatRoughness: 0.02,
  normalMap: waterNormalMap,
  normalScale: new THREE.Vector2(lakeSettings.normalStrength, lakeSettings.normalStrength),
  envMapIntensity: 1.2,
  transparent: true,
  opacity: lakeSettings.opacity,
  vertexColors: true,
  side: THREE.FrontSide,
});
const ground = new THREE.Mesh(lakeGeo, lakeMat);
ground.receiveShadow = true;
ground.position.y = -1.35;
ground.name = 'ground';
scene.add(ground);

// Fog to blend lake into horizon
scene.fog = new THREE.FogExp2(0x4a6a8a, 0.025);

// Animate water ripple drift
const waterClock = { offset: 0 };

// ─── Rotation logic ───
const AXES = {
  R: { axis: 'x', layer: 1, dir: -1 },
  L: { axis: 'x', layer: -1, dir: 1 },
  U: { axis: 'y', layer: 1, dir: -1 },
  D: { axis: 'y', layer: -1, dir: 1 },
  F: { axis: 'z', layer: 1, dir: -1 },
  B: { axis: 'z', layer: -1, dir: 1 },
  M: { axis: 'x', layer: 0, dir: 1 },  // Middle layer (between R and L, same dir as L)
  E: { axis: 'y', layer: 0, dir: 1 },  // Equatorial layer (between U and D, same dir as D)
  S: { axis: 'z', layer: 0, dir: -1 }, // Standing layer (between F and B, same dir as F)
};

// Only allow keyboard moves for the standard 6 face moves
const KEYBOARD_MOVES = ['R', 'L', 'U', 'D', 'F', 'B'];

let isAnimating = false;
let animQueue = [];
const animGroup = new THREE.Group();
animGroup.name = 'animGroup';
scene.add(animGroup);

function getCubiesOnLayer(axis, layer) {
  const prop = 'g' + axis;
  return cubies.filter(c => Math.round(c.userData[prop]) === layer);
}

function roundVec(v) {
  v.x = Math.round(v.x * 100) / 100;
  v.y = Math.round(v.y * 100) / 100;
  v.z = Math.round(v.z * 100) / 100;
}

function animateMove(moveName, reverse = false, speed = 1.0) {
  return new Promise(resolve => {
    const move = AXES[moveName];
    if (!move) { resolve(); return; }
    const { axis, layer, dir } = move;
    const angle = (Math.PI / 2) * dir * (reverse ? -1 : 1);

    const layerCubies = getCubiesOnLayer(axis, layer);

    // Parent cubies to animation group
    animGroup.rotation.set(0, 0, 0);
    animGroup.updateMatrixWorld(true);

    layerCubies.forEach(c => {
      cubieGroup.updateMatrixWorld(true);
      const worldPos = new THREE.Vector3();
      c.getWorldPosition(worldPos);
      const worldQuat = new THREE.Quaternion();
      c.getWorldQuaternion(worldQuat);

      animGroup.add(c);
      c.position.copy(animGroup.worldToLocal(worldPos));
      c.quaternion.copy(worldQuat);
    });

    const duration = 280 / speed;
    const start = performance.now();

    function tick() {
      const t = Math.min((performance.now() - start) / duration, 1);
      const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

      if (axis === 'x') animGroup.rotation.x = angle * ease;
      if (axis === 'y') animGroup.rotation.y = angle * ease;
      if (axis === 'z') animGroup.rotation.z = angle * ease;

      if (t < 1) {
        requestAnimationFrame(tick);
      } else {
        // Finalize
        if (axis === 'x') animGroup.rotation.x = angle;
        if (axis === 'y') animGroup.rotation.y = angle;
        if (axis === 'z') animGroup.rotation.z = angle;
        animGroup.updateMatrixWorld(true);

        layerCubies.forEach(c => {
          const wp = new THREE.Vector3();
          c.getWorldPosition(wp);
          const wq = new THREE.Quaternion();
          c.getWorldQuaternion(wq);

          cubieGroup.add(c);
          cubieGroup.updateMatrixWorld(true);
          c.position.copy(cubieGroup.worldToLocal(wp));
          c.quaternion.copy(wq);

          // Snap position
          roundVec(c.position);
          c.userData.gx = Math.round(c.position.x / STEP);
          c.userData.gy = Math.round(c.position.y / STEP);
          c.userData.gz = Math.round(c.position.z / STEP);
        });

        animGroup.rotation.set(0, 0, 0);
        resolve();
      }
    }
    requestAnimationFrame(tick);
  });
}

async function processQueue() {
  if (isAnimating || animQueue.length === 0) return;
  isAnimating = true;
  while (animQueue.length > 0) {
    const { move, reverse, speed } = animQueue.shift();
    await animateMove(move, reverse, speed);
  }
  isAnimating = false;
  updateMoveCount();
  checkSolved();
}

function queueMove(move, reverse = false, speed = 1.0) {
  animQueue.push({ move, reverse, speed });
  processQueue();
}

// ─── Scramble ───
let moveHistory = [];
let moveCount = 0;
let timerStart = null;
let timerInterval = null;
let isSolved = true;
let isScrambling = false;

function scramble(n = 20) {
  if (isAnimating && !isScrambling) return;
  isScrambling = true;
  moveHistory = [];
  moveCount = 0;
  isSolved = false;
  updateMoveCount();

  // Reset timer
  clearInterval(timerInterval);
  timerStart = null;
  updateTimer();

  const moveNames = KEYBOARD_MOVES;
  let last = '';
  const moves = [];
  for (let i = 0; i < n; i++) {
    let m;
    do { m = moveNames[Math.floor(Math.random() * moveNames.length)]; } while (m === last);
    last = m;
    const rev = Math.random() > 0.5;
    moves.push({ move: m, reverse: rev });
  }

  moves.forEach(({ move, reverse }) => {
    animQueue.push({ move, reverse, speed: 4.0 });
  });

  const origProcess = processQueue;
  isAnimating = false;
  processQueue().then(() => {
    isScrambling = false;
    // Start timer on first user move
  });
}

// ─── Solve check ───
function checkSolved() {
  if (isScrambling) return;
  for (const face of Object.keys(FACE_COLORS)) {
    const { axis, val } = faceMapping[face];
    const prop = 'g' + axis;
    const faceCubies = cubies.filter(c => c.userData[prop] === val);
    // Collect sticker colors from overlay meshes on this face
    const colors = [];
    for (const cubie of faceCubies) {
      const sticker = cubie.children.find(ch => ch.userData.isSticker && ch.userData.face === face);
      if (!sticker) return; // missing sticker means not solved
      colors.push(sticker.material.color.getHexString());
    }
    // All 9 stickers on this face must share the same color
    for (let i = 1; i < colors.length; i++) {
      if (colors[i] !== colors[0]) return;
    }
  }
  isSolved = true;
  clearInterval(timerInterval);

  // Calculate final time
  const finalTime = timerStart ? ((performance.now() - timerStart) / 1000).toFixed(2) : '0.00';

  // Show solved message with time
  const msg = document.getElementById('solvedMsg');
  const sub = document.getElementById('solvedSub');
  if (sub) {
    sub.textContent = `${finalTime}s · ${moveCount} moves`;
  }
  if (msg) {
    msg.classList.add('show');
    setTimeout(() => msg.classList.remove('show'), 4000);
  }
}

const faceMapping = {
  right:  { axis: 'x', val: 1, matIndex: 0 },
  left:   { axis: 'x', val: -1, matIndex: 1 },
  top:    { axis: 'y', val: 1, matIndex: 2 },
  bottom: { axis: 'y', val: -1, matIndex: 3 },
  front:  { axis: 'z', val: 1, matIndex: 4 },
  back:   { axis: 'z', val: -1, matIndex: 5 },
};

// ─── Mouse / touch face-turn interaction ───
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
let dragStart = null;
let dragCubie = null;
let dragFaceNormal = null;
let isDragging = false;
let dragHitPoint = null;

// Live-rotation drag state
let liveDragActive = false;       // true once we've determined the move and are visually rotating
let liveDragMove = null;          // { moveName, axis, layer, dir }
let liveDragAngle = 0;            // current rotation angle in radians
let liveDragCubies = [];          // cubies in the rotating layer
let liveDragPlane = null;         // THREE.Plane for raycasting
let liveDragStartPoint = null;    // initial hit on that plane
let liveDragRotAxis = null;       // 'x', 'y', or 'z'
let liveDragSign = 1;             // direction multiplier

const SNAP_THRESHOLD = Math.PI / 4; // 45° — must exceed this to commit the turn

function getFaceNormal(face, object) {
  const normal = face.normal.clone();
  const worldQuat = new THREE.Quaternion();
  object.getWorldQuaternion(worldQuat);
  normal.applyQuaternion(worldQuat);
  const axes = [
    new THREE.Vector3(1, 0, 0), new THREE.Vector3(-1, 0, 0),
    new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, -1, 0),
    new THREE.Vector3(0, 0, 1), new THREE.Vector3(0, 0, -1),
  ];
  let best = axes[0], bestDot = -Infinity;
  for (const a of axes) {
    const d = normal.dot(a);
    if (d > bestDot) { bestDot = d; best = a; }
  }
  return best.clone();
}

function findMoveForAxis(cubie, moveAxis) {
  const layerVal = cubie.userData['g' + moveAxis];
  for (const [name, def] of Object.entries(AXES)) {
    if (def.axis === moveAxis && def.layer === layerVal) {
      return { moveName: name, axis: def.axis, layer: def.layer, dir: def.dir };
    }
  }
  return null;
}

// Get the two possible rotation axes for a given face (perpendicular to face normal)
function getCandidateAxes(faceNormal) {
  const axes = ['x', 'y', 'z'];
  const fn = { x: Math.abs(faceNormal.x), y: Math.abs(faceNormal.y), z: Math.abs(faceNormal.z) };
  // The two axes perpendicular to the face normal
  return axes.filter(a => fn[a] < 0.5);
}

// Compute a tangent vector for a given rotation axis and face normal
function computeTangent(faceNormal, rotAxis) {
  const rotAxisVec = new THREE.Vector3(
    rotAxis === 'x' ? 1 : 0,
    rotAxis === 'y' ? 1 : 0,
    rotAxis === 'z' ? 1 : 0
  );
  const tangent = new THREE.Vector3().crossVectors(faceNormal, rotAxisVec).normalize();
  if (tangent.lengthSq() < 0.001) {
    tangent.crossVectors(faceNormal, new THREE.Vector3(1, 0, 0)).normalize();
    if (tangent.lengthSq() < 0.001) tangent.crossVectors(faceNormal, new THREE.Vector3(0, 1, 0)).normalize();
  }
  return tangent;
}

// Begin live-dragging: parent cubies to animGroup and start tracking angle
function beginLiveDrag(moveResult, signMultiplier) {
  const { axis, layer } = moveResult;
  liveDragCubies = getCubiesOnLayer(axis, layer);
  liveDragRotAxis = axis;
  liveDragSign = signMultiplier;

  animGroup.rotation.set(0, 0, 0);
  animGroup.updateMatrixWorld(true);

  liveDragCubies.forEach(c => {
    cubieGroup.updateMatrixWorld(true);
    const wp = new THREE.Vector3();
    c.getWorldPosition(wp);
    const wq = new THREE.Quaternion();
    c.getWorldQuaternion(wq);
    animGroup.add(c);
    c.position.copy(animGroup.worldToLocal(wp));
    c.quaternion.copy(wq);
  });

  liveDragAngle = 0;
  liveDragActive = true;
}

// Update the visual rotation of the layer during drag
function updateLiveDragAngle(angle) {
  liveDragAngle = angle;
  // Clamp to ±90°
  const clamped = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, angle));
  if (liveDragRotAxis === 'x') animGroup.rotation.set(clamped, 0, 0);
  else if (liveDragRotAxis === 'y') animGroup.rotation.set(0, clamped, 0);
  else animGroup.rotation.set(0, 0, clamped);
}

// Finish live drag: either commit (animate to 90°) or snap back (animate to 0°)
function finishLiveDrag() {
  if (!liveDragActive) return;
  liveDragActive = false;

  const currentAngle = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, liveDragAngle));
  const shouldCommit = Math.abs(currentAngle) > SNAP_THRESHOLD;
  const targetAngle = shouldCommit ? Math.sign(currentAngle) * (Math.PI / 2) : 0;

  const startAngle = currentAngle;
  const startTime = performance.now();
  const duration = 180; // ms

  isAnimating = true;

  function snapTick() {
    const t = Math.min((performance.now() - startTime) / duration, 1);
    const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    const angle = startAngle + (targetAngle - startAngle) * ease;

    if (liveDragRotAxis === 'x') animGroup.rotation.set(angle, 0, 0);
    else if (liveDragRotAxis === 'y') animGroup.rotation.set(0, angle, 0);
    else animGroup.rotation.set(0, 0, angle);

    if (t < 1) {
      requestAnimationFrame(snapTick);
    } else {
      // Set final rotation
      if (liveDragRotAxis === 'x') animGroup.rotation.set(targetAngle, 0, 0);
      else if (liveDragRotAxis === 'y') animGroup.rotation.set(0, targetAngle, 0);
      else animGroup.rotation.set(0, 0, targetAngle);
      animGroup.updateMatrixWorld(true);

      // Reparent cubies back to cubieGroup
      liveDragCubies.forEach(c => {
        const wp = new THREE.Vector3();
        c.getWorldPosition(wp);
        const wq = new THREE.Quaternion();
        c.getWorldQuaternion(wq);
        cubieGroup.add(c);
        cubieGroup.updateMatrixWorld(true);
        c.position.copy(cubieGroup.worldToLocal(wp));
        c.quaternion.copy(wq);
        roundVec(c.position);
        c.userData.gx = Math.round(c.position.x / STEP);
        c.userData.gy = Math.round(c.position.y / STEP);
        c.userData.gz = Math.round(c.position.z / STEP);
      });

      animGroup.rotation.set(0, 0, 0);
      liveDragCubies = [];
      isAnimating = false;

      if (shouldCommit) {
        // Determine the actual reverse for undo purposes.
        // animateMove applies: angle = dir * (reverse ? -1 : 1) * PI/2
        // So: reverse = ((targetAngle > 0) === (dir < 0))
        // i.e. positive rotation with negative dir = normal (reverse=false? no...)
        // Solve: dir * (reverse ? -1 : 1) = sign(targetAngle)
        //   (reverse ? -1 : 1) = sign(targetAngle) / dir = sign(targetAngle) * dir (since dir is ±1)
        //   if sign(targetAngle)*dir = 1 → reverse=false; if -1 → reverse=true
        const actualReverse = (Math.sign(targetAngle) * liveDragMove.dir) < 0;
        moveCount++;
        moveHistory.push({ move: liveDragMove.moveName, reverse: actualReverse });
        updateMoveCount();
        checkSolved();
      }

      // Process any queued keyboard moves
      processQueue();
    }
  }

  requestAnimationFrame(snapTick);
}

renderer.domElement.addEventListener('pointerdown', (e) => {
  if (e.button !== 0) return;
  if (liveDragActive) return;

  mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;

  raycaster.setFromCamera(mouse, camera);
  const hits = raycaster.intersectObjects(cubies, true);

  if (hits.length > 0 && !isAnimating && !isScrambling) {
    const hit = hits[0];
    // If we hit a sticker overlay, use its parent cubie
    dragCubie = hit.object.userData.isSticker ? hit.object.parent : hit.object;
    dragFaceNormal = getFaceNormal(hit.face, hit.object);
    dragHitPoint = hit.point.clone();
    dragStart = new THREE.Vector2(e.clientX, e.clientY);
    isDragging = false;
    controls.enabled = false;

    if (!timerStart) {
      isSolved = false;
      timerStart = performance.now();
      timerInterval = setInterval(updateTimer, 50);
    }
  }
});

// Store the tangent used during live drag so angle computation is consistent
let liveDragTangent = null;

window.addEventListener('pointermove', (e) => {
  if (liveDragActive && liveDragPlane && liveDragStartPoint) {
    // Update live rotation angle from pointer
    const currNdc = new THREE.Vector2(
      (e.clientX / window.innerWidth) * 2 - 1,
      -(e.clientY / window.innerHeight) * 2 + 1
    );
    raycaster.setFromCamera(currNdc, camera);
    const currPoint = new THREE.Vector3();
    raycaster.ray.intersectPlane(liveDragPlane, currPoint);
    if (currPoint) {
      const delta = currPoint.clone().sub(liveDragStartPoint);
      const projected = delta.dot(liveDragTangent);
      const angle = (projected / (STEP * 1.5)) * (Math.PI / 2) * liveDragSign;
      updateLiveDragAngle(angle);
    }
    return;
  }

  if (!dragStart) return;
  if (isDragging) return;
  if (isAnimating) {
    dragStart = null;
    dragCubie = null;
    dragFaceNormal = null;
    dragHitPoint = null;
    isDragging = false;
    controls.enabled = true;
    return;
  }

  const dx = e.clientX - dragStart.x;
  const dy = e.clientY - dragStart.y;
  const dist = Math.sqrt(dx * dx + dy * dy);

  if (dist > 10) {
    isDragging = true;

    // Raycast current pointer onto the face plane
    const currNdc = new THREE.Vector2(
      (e.clientX / window.innerWidth) * 2 - 1,
      -(e.clientY / window.innerHeight) * 2 + 1
    );
    raycaster.setFromCamera(currNdc, camera);
    const plane = new THREE.Plane().setFromNormalAndCoplanarPoint(dragFaceNormal, dragHitPoint);
    const currPoint = new THREE.Vector3();
    raycaster.ray.intersectPlane(plane, currPoint);

    if (currPoint) {
      const dragDelta = currPoint.clone().sub(dragHitPoint);

      // Get the two candidate rotation axes for this face
      const candidates = getCandidateAxes(dragFaceNormal);

      // Project the drag delta onto each candidate's tangent to find which axis
      // the user is dragging along most strongly
      let bestAxis = null;
      let bestProjection = 0;
      let bestTangent = null;

      for (const axis of candidates) {
        const tangent = computeTangent(dragFaceNormal, axis);
        const proj = Math.abs(dragDelta.dot(tangent));
        if (proj > bestProjection) {
          bestProjection = proj;
          bestAxis = axis;
          bestTangent = tangent;
        }
      }

      if (bestAxis) {
        const moveResult = findMoveForAxis(dragCubie, bestAxis);
        if (moveResult) {
          // Compute the sign mapping: how does dragging along this tangent
          // relate to the rotation direction?
          // We use the cross product: tangent × faceNormal gives the rotation direction
          // when dragging in the positive tangent direction
          const rotAxisVec = new THREE.Vector3(
            bestAxis === 'x' ? 1 : 0,
            bestAxis === 'y' ? 1 : 0,
            bestAxis === 'z' ? 1 : 0
          );
          // The cross product of (faceNormal × rotAxisVec) = tangent direction
          // We need: when the user drags along +tangent, which way should the layer rotate?
          // Use the right-hand rule: cross(tangent, faceNormal) should align with rotAxis
          const crossCheck = new THREE.Vector3().crossVectors(bestTangent, dragFaceNormal);
          const signMultiplier = -Math.sign(crossCheck.dot(rotAxisVec));

          liveDragMove = moveResult;
          liveDragPlane = plane;
          liveDragStartPoint = dragHitPoint.clone();
          liveDragTangent = bestTangent;
          beginLiveDrag(moveResult, signMultiplier);

          // Immediately compute initial angle from current pointer
          const projected = dragDelta.dot(bestTangent);
          const angle = (projected / (STEP * 1.5)) * (Math.PI / 2) * signMultiplier;
          updateLiveDragAngle(angle);
        }
      }
    }

    dragStart = null;
    dragCubie = null;
  }
});

window.addEventListener('pointerup', () => {
  if (liveDragActive) {
    finishLiveDrag();
    dragFaceNormal = null;
    dragHitPoint = null;
    isDragging = false;
    controls.enabled = true;
    return;
  }

  if (dragStart || isDragging) {
    dragStart = null;
    dragCubie = null;
    dragFaceNormal = null;
    dragHitPoint = null;
    isDragging = false;
  }
  controls.enabled = true;
});

// ─── Keyboard controls ───
window.addEventListener('keydown', (e) => {
  if (isAnimating && !isScrambling) return;
  if (isScrambling) return;

  const key = e.key.toUpperCase();
  const reverse = e.shiftKey;

  if (KEYBOARD_MOVES.includes(key)) {
    if (!timerStart) {
      isSolved = false;
      timerStart = performance.now();
      timerInterval = setInterval(updateTimer, 50);
    }
    moveCount++;
    moveHistory.push({ move: key, reverse });
    queueMove(key, reverse);
  }
});

// ─── HUD ───
function updateMoveCount() {
  const el = document.getElementById('moveCount');
  if (el) el.textContent = moveCount;
}

function updateTimer() {
  const el = document.getElementById('timer');
  if (!timerStart) {
    if (el) el.textContent = '0.00';
    return;
  }
  const elapsed = (performance.now() - timerStart) / 1000;
  const formatted = elapsed.toFixed(2);
  if (el) el.textContent = formatted;
}

// ─── UI Creation ───
// ─── Top Timer overlay ───
// ─── FPS Counter ───
const fpsCounter = document.createElement('div');
fpsCounter.id = 'fpsCounter';
fpsCounter.innerHTML = `
  <span class="fps-label">FPS</span>
  <span id="fpsValue">--</span>
`;
root.appendChild(fpsCounter);

let fpsFrames = 0;
let fpsLastTime = performance.now();

function updateFPS() {
  fpsFrames++;
  const now = performance.now();
  if (now - fpsLastTime >= 500) {
    const fps = Math.round((fpsFrames * 1000) / (now - fpsLastTime));
    const el = document.getElementById('fpsValue');
    if (el) el.textContent = fps;
    fpsFrames = 0;
    fpsLastTime = now;
  }
}



const hud = document.createElement('div');
hud.id = 'hud';
hud.innerHTML = `
  <div class="hud-stats">
    <div class="hud-stat">
      <span class="hud-stat-label">Moves</span>
      <span class="hud-stat-value" id="moveCount">0</span>
    </div>
    <div class="hud-stat">
      <span class="hud-stat-label">Time</span>
      <span class="hud-stat-value" id="timer">0.00</span>
    </div>
  </div>
  <div class="hud-actions">
    <button class="hud-btn" id="btnScramble">Scramble</button>
    <button class="hud-btn hud-btn-secondary" id="btnUndo">Undo</button>
    <button class="hud-btn hud-btn-secondary" id="btnReset">Reset</button>
  </div>

`;
root.appendChild(hud);

const solvedMsg = document.createElement('div');
solvedMsg.id = 'solvedMsg';
solvedMsg.innerHTML = `
  <div class="solved-icon">🎉</div>
  <div class="solved-title">Solved!</div>
  <div class="solved-sub" id="solvedSub"></div>
`;
root.appendChild(solvedMsg);

// Button handlers
document.getElementById('btnScramble').addEventListener('click', () => {
  scramble(20);
});

document.getElementById('btnUndo').addEventListener('click', () => {
  if (isAnimating || moveHistory.length === 0 || isScrambling) return;
  const last = moveHistory.pop();
  moveCount = Math.max(0, moveCount - 1);
  updateMoveCount();
  queueMove(last.move, !last.reverse);
});

document.getElementById('btnReset').addEventListener('click', () => {
  if (isScrambling) return;
  animQueue = [];
  isAnimating = false;
  moveHistory = [];
  moveCount = 0;
  isSolved = true;
  clearInterval(timerInterval);
  timerStart = null;
  updateMoveCount();
  updateTimer();

  // Reset all cubies to their original positions
  cubies.forEach(c => {
    // Move back to cubieGroup if in animGroup
    if (c.parent !== cubieGroup) cubieGroup.add(c);
    const name = c.name; // cubie_X_Y_Z
    const parts = name.split('_');
    const ox = parseInt(parts[1]) - 1;
    const oy = parseInt(parts[2]) - 1;
    const oz = parseInt(parts[3]) - 1;
    c.position.set(ox * STEP, oy * STEP, oz * STEP);
    c.quaternion.identity();
    c.userData.gx = ox;
    c.userData.gy = oy;
    c.userData.gz = oz;

    // Reassign shared frame materials (no need to recreate)
    c.material = createCubieMaterials();
  });
});

// Prevent orbit when clicking HUD
hud.addEventListener('pointerdown', e => e.stopPropagation());
hud.addEventListener('pointermove', e => e.stopPropagation());

// ─── Settings Panel ───
const helpToggle = document.createElement('div');
helpToggle.id = 'helpToggle';
helpToggle.innerHTML = `?`;
const helpTooltip = document.createElement('div');
helpTooltip.id = 'helpTooltip';
helpTooltip.innerHTML = `
  <div class="help-row"><span class="help-keys">R L U D F B</span></div>
  <div class="help-row"><span class="help-desc">Hold <b>Shift</b> = reverse</span></div>
  <div class="help-row"><span class="help-desc">Or drag faces to turn</span></div>
`;
helpToggle.appendChild(helpTooltip);
root.appendChild(helpToggle);

const settingsToggle = document.createElement('button');
settingsToggle.id = 'settingsToggle';
settingsToggle.textContent = '⚙';
root.appendChild(settingsToggle);

const settingsPanel = document.createElement('div');
settingsPanel.id = 'settingsPanel';
settingsPanel.innerHTML = `
  <div class="settings-section">
    <div class="settings-section-title">Environment</div>
    <div class="setting-row">
      <span class="setting-label">HDR</span>
      <select id="sHdr">
        ${HDR_ENVIRONMENTS.map((e, i) => `<option value="${i}"${i === 0 ? ' selected' : ''}>${e.name}</option>`).join('')}
      </select>
    </div>
    <div class="setting-row">
      <span class="setting-label">Exposure</span>
      <input type="range" id="sExposure" min="0.1" max="2.0" step="0.01" value="0.8">
      <span class="setting-value" id="sExposureVal">0.8</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">BG Blur</span>
      <input type="range" id="sBgBlur" min="0" max="1" step="0.01" value="0.3">
      <span class="setting-value" id="sBgBlurVal">0.30</span>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">SSR</div>
    <div class="setting-row">
      <span class="setting-label">Enabled</span>
      <button class="setting-toggle on" id="sSsrEnabled"></button>
    </div>
    <div class="setting-row">
      <span class="setting-label">Steps</span>
      <input type="range" id="sSsrSteps" min="4" max="128" step="4" value="64">
      <span class="setting-value" id="sSsrStepsVal">64</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Strength</span>
      <input type="range" id="sSsrStrength" min="0" max="1" step="0.01" value="0.77">
      <span class="setting-value" id="sSsrStrengthVal">0.77</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Distance</span>
      <input type="range" id="sSsrDist" min="0.1" max="5" step="0.01" value="2.63">
      <span class="setting-value" id="sSsrDistVal">2.63</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Thickness</span>
      <input type="range" id="sSsrThick" min="0.01" max="1" step="0.01" value="0.07">
      <span class="setting-value" id="sSsrThickVal">0.07</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Fresnel</span>
      <input type="range" id="sSsrFresnel" min="0.1" max="5" step="0.1" value="1.0">
      <span class="setting-value" id="sSsrFresnelVal">1.0</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Fade</span>
      <input type="range" id="sSsrFade" min="0" max="1" step="0.01" value="0.90">
      <span class="setting-value" id="sSsrFadeVal">0.90</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Dir Filter Axis</span>
      <select id="sSsrDirAxis">
        <option value="0" selected>Y (up/down)</option>
        <option value="1">X (left/right)</option>
        <option value="2">Z (fwd/back)</option>
      </select>
    </div>
    <div class="setting-row">
      <span class="setting-label">Dir Sign</span>
      <select id="sSsrDirSign">
        <option value="1" selected>Positive</option>
        <option value="-1">Negative</option>
        <option value="0">Both (no filter)</option>
      </select>
    </div>
    <div class="setting-row">
      <span class="setting-label">Dir Threshold</span>
      <input type="range" id="sSsrDirThresh" min="-1" max="1" step="0.01" value="0.00">
      <span class="setting-value" id="sSsrDirThreshVal">0.00</span>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">Bloom</div>
    <div class="setting-row">
      <span class="setting-label">Enabled</span>
      <button class="setting-toggle on" id="sBloomEnabled"></button>
    </div>
    <div class="setting-row">
      <span class="setting-label">Strength</span>
      <input type="range" id="sBloomStr" min="0" max="2" step="0.01" value="0.35">
      <span class="setting-value" id="sBloomStrVal">0.35</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Radius</span>
      <input type="range" id="sBloomRad" min="0" max="1" step="0.01" value="0.40">
      <span class="setting-value" id="sBloomRadVal">0.40</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Threshold</span>
      <input type="range" id="sBloomThr" min="0" max="2" step="0.01" value="0.85">
      <span class="setting-value" id="sBloomThrVal">0.85</span>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">Ambient Occlusion</div>
    <div class="setting-row">
      <span class="setting-label">Enabled</span>
      <button class="setting-toggle on" id="sAoEnabled"></button>
    </div>
    <div class="setting-row">
      <span class="setting-label">Radius</span>
      <input type="range" id="sAoRadius" min="0.01" max="0.2" step="0.001" value="0.07">
      <span class="setting-value" id="sAoRadiusVal">0.07</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Scale</span>
      <input type="range" id="sAoScale" min="0.1" max="2" step="0.01" value="0.60">
      <span class="setting-value" id="sAoScaleVal">0.60</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Thickness</span>
      <input type="range" id="sAoThick" min="0.01" max="2" step="0.01" value="0.71">
      <span class="setting-value" id="sAoThickVal">0.71</span>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">Film Grain</div>
    <div class="setting-row">
      <span class="setting-label">Enabled</span>
      <button class="setting-toggle" id="sGrainEnabled"></button>
    </div>
    <div class="setting-row">
      <span class="setting-label">Intensity</span>
      <input type="range" id="sGrainInt" min="0" max="0.3" step="0.001" value="0.08">
      <span class="setting-value" id="sGrainIntVal">0.08</span>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">Frame Scratches</div>
    <div class="setting-row">
      <span class="setting-label">Scratch Strength</span>
      <input type="range" id="sScratchStr" min="0" max="0.3" step="0.001" value="0.200">
      <span class="setting-value" id="sScratchStrVal">0.20</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Scratch Count</span>
      <input type="range" id="sScratchCount" min="0" max="500" step="10" value="300">
      <span class="setting-value" id="sScratchCountVal">300</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Scratch Depth</span>
      <input type="range" id="sScratchDepth" min="10" max="200" step="5" value="60">
      <span class="setting-value" id="sScratchDepthVal">60</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Scratch Width</span>
      <input type="range" id="sScratchWidth" min="0.2" max="4" step="0.1" value="0.5">
      <span class="setting-value" id="sScratchWidthVal">0.5</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Regen Scratches</span>
      <button class="hud-btn hud-btn-secondary" id="btnRegenFrameScratches" style="font-size:10px;padding:4px 12px;">Apply</button>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">Sticker Wear</div>
    <div class="setting-row">
      <span class="setting-label">Wear Strength</span>
      <input type="range" id="sWearStr" min="0" max="0.3" step="0.001" value="0.120">
      <span class="setting-value" id="sWearStrVal">0.12</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Fingerprints</span>
      <input type="range" id="sWearFingerprints" min="0" max="30" step="1" value="12">
      <span class="setting-value" id="sWearFingerprintsVal">12</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Smudges</span>
      <input type="range" id="sWearSmudges" min="0" max="20" step="1" value="8">
      <span class="setting-value" id="sWearSmudgesVal">8</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Oiliness</span>
      <input type="range" id="sWearOiliness" min="5" max="120" step="5" value="40">
      <span class="setting-value" id="sWearOilinessVal">40</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Sticker Wobble</span>
      <input type="range" id="sStickerWobble" min="0" max="3" step="0.01" value="0.15">
      <span class="setting-value" id="sStickerWobbleVal">0.15</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Edge Wear</span>
      <input type="range" id="sEdgeWear" min="0" max="60" step="1" value="8">
      <span class="setting-value" id="sEdgeWearVal">8</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Micro Scratches</span>
      <input type="range" id="sMicroScratches" min="0" max="30" step="1" value="6">
      <span class="setting-value" id="sMicroScratchesVal">6</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Dust Specks</span>
      <input type="range" id="sDustSpecks" min="0" max="50" step="1" value="10">
      <span class="setting-value" id="sDustSpecksVal">10</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Sticker Fingerprints</span>
      <input type="range" id="sFingerprints" min="0" max="15" step="0.5" value="10">
      <span class="setting-value" id="sFingerprintsVal">10</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Holes / Tears</span>
      <input type="range" id="sHoles" min="0" max="10" step="1" value="3">
      <span class="setting-value" id="sHolesVal">3</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Wear Variance</span>
      <input type="range" id="sWearVariance" min="0" max="1" step="0.01" value="1.00">
      <span class="setting-value" id="sWearVarianceVal">1.00</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Regen Sticker Wear</span>
      <button class="hud-btn hud-btn-secondary" id="btnRegenTextures" style="font-size:10px;padding:4px 12px;">Apply</button>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">Sticker Material (PBR)</div>
    <div class="setting-row">
      <span class="setting-label">Roughness</span>
      <input type="range" id="sStkRough" min="0" max="1" step="0.01" value="0.00">
      <span class="setting-value" id="sStkRoughVal">0.00</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Metalness</span>
      <input type="range" id="sStkMetal" min="0" max="1" step="0.01" value="0.72">
      <span class="setting-value" id="sStkMetalVal">0.72</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Clearcoat</span>
      <input type="range" id="sStkClear" min="0" max="1" step="0.01" value="0.26">
      <span class="setting-value" id="sStkClearVal">0.26</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">CC Roughness</span>
      <input type="range" id="sStkCcRough" min="0" max="1" step="0.01" value="0.10">
      <span class="setting-value" id="sStkCcRoughVal">0.10</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Sheen</span>
      <input type="range" id="sStkSheen" min="0" max="1" step="0.01" value="0.10">
      <span class="setting-value" id="sStkSheenVal">0.10</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Sheen Roughness</span>
      <input type="range" id="sStkSheenRough" min="0" max="1" step="0.01" value="0.47">
      <span class="setting-value" id="sStkSheenRoughVal">0.47</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Env Intensity</span>
      <input type="range" id="sStkEnv" min="0" max="3" step="0.01" value="1.19">
      <span class="setting-value" id="sStkEnvVal">1.19</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Normal Scale</span>
      <input type="range" id="sStkNormal" min="0" max="1" step="0.01" value="0.18">
      <span class="setting-value" id="sStkNormalVal">0.18</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Wrinkle Intensity</span>
      <input type="range" id="sStkWrinkle" min="0" max="2.0" step="0.01" value="0.35">
      <span class="setting-value" id="sStkWrinkleVal">0.35</span>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">Frame Material (PBR)</div>
    <div class="setting-row">
      <span class="setting-label">Color</span>
      <input type="color" id="sFrameColor" value="#111111">
    </div>
    <div class="setting-row">
      <span class="setting-label">Roughness</span>
      <input type="range" id="sFrameRough" min="0" max="1" step="0.01" value="0.09">
      <span class="setting-value" id="sFrameRoughVal">0.09</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Metalness</span>
      <input type="range" id="sFrameMetal" min="0" max="1" step="0.01" value="0.00">
      <span class="setting-value" id="sFrameMetalVal">0.00</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Clearcoat</span>
      <input type="range" id="sFrameClear" min="0" max="1" step="0.01" value="0.92">
      <span class="setting-value" id="sFrameClearVal">0.92</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">CC Roughness</span>
      <input type="range" id="sFrameCcRough" min="0" max="1" step="0.01" value="0.29">
      <span class="setting-value" id="sFrameCcRoughVal">0.29</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Sheen</span>
      <input type="range" id="sFrameSheen" min="0" max="1" step="0.01" value="0.70">
      <span class="setting-value" id="sFrameSheenVal">0.70</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Sheen Roughness</span>
      <input type="range" id="sFrameSheenRough" min="0" max="1" step="0.01" value="0.68">
      <span class="setting-value" id="sFrameSheenRoughVal">0.68</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Env Intensity</span>
      <input type="range" id="sFrameEnv" min="0" max="3" step="0.01" value="1.71">
      <span class="setting-value" id="sFrameEnvVal">1.71</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Normal Scale</span>
      <input type="range" id="sFrameNormal" min="0" max="1" step="0.01" value="0.39">
      <span class="setting-value" id="sFrameNormalVal">0.39</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">CC Normal Scale</span>
      <input type="range" id="sFrameCcNormal" min="0" max="0.3" step="0.001" value="0.150">
      <span class="setting-value" id="sFrameCcNormalVal">0.15</span>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">Lake</div>
    <div class="setting-row">
      <span class="setting-label">Wave Scale</span>
      <input type="range" id="sWaveScale" min="1" max="20" step="0.1" value="1.0">
      <span class="setting-value" id="sWaveScaleVal">1.00</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Wave Strength</span>
      <input type="range" id="sWaveStr" min="5" max="80" step="1" value="5">
      <span class="setting-value" id="sWaveStrVal">5</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Drift Speed</span>
      <input type="range" id="sWaveDrift" min="0" max="0.003" step="0.0001" value="0.0003">
      <span class="setting-value" id="sWaveDriftVal">0.00</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Normal</span>
      <input type="range" id="sWaveNormal" min="0" max="2" step="0.01" value="0.50">
      <span class="setting-value" id="sWaveNormalVal">0.50</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Opacity</span>
      <input type="range" id="sLakeOpacity" min="0" max="1" step="0.01" value="0.75">
      <span class="setting-value" id="sLakeOpacityVal">0.75</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Roughness</span>
      <input type="range" id="sLakeRough" min="0" max="1" step="0.01" value="0.05">
      <span class="setting-value" id="sLakeRoughVal">0.05</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Metalness</span>
      <input type="range" id="sLakeMetal" min="0" max="1" step="0.01" value="0.00">
      <span class="setting-value" id="sLakeMetalVal">0.00</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Transmission</span>
      <input type="range" id="sLakeTrans" min="0" max="1" step="0.01" value="0.00">
      <span class="setting-value" id="sLakeTransVal">0.00</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">IOR</span>
      <input type="range" id="sLakeIor" min="1.0" max="2.5" step="0.01" value="1.33">
      <span class="setting-value" id="sLakeIorVal">1.33</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Thickness</span>
      <input type="range" id="sLakeThick" min="0" max="10" step="0.1" value="0.0">
      <span class="setting-value" id="sLakeThickVal">0.00</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Clearcoat</span>
      <input type="range" id="sLakeClearcoat" min="0" max="1" step="0.01" value="1.00">
      <span class="setting-value" id="sLakeClearcoatVal">1.00</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">CC Roughness</span>
      <input type="range" id="sLakeCcRough" min="0" max="1" step="0.01" value="0.02">
      <span class="setting-value" id="sLakeCcRoughVal">0.02</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Env Intensity</span>
      <input type="range" id="sLakeEnv" min="0" max="3" step="0.01" value="1.20">
      <span class="setting-value" id="sLakeEnvVal">1.20</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Color</span>
      <input type="color" id="sLakeColor" value="#1a4a6b">
    </div>
    <div class="setting-row">
      <span class="setting-label">Fog Density</span>
      <input type="range" id="sFogDensity" min="0" max="0.1" step="0.001" value="0.025">
      <span class="setting-value" id="sFogDensityVal">0.03</span>
    </div>
  </div>

  <div class="settings-section">
    <div class="settings-section-title">Lighting</div>
    <div class="setting-row">
      <span class="setting-label">Key Light</span>
      <input type="range" id="sKeyLight" min="0" max="10" step="0.1" value="1.2">
      <span class="setting-value" id="sKeyLightVal">1.2</span>
    </div>
    <div class="setting-row">
      <span class="setting-label">Rim Light</span>
      <input type="range" id="sRimLight" min="0" max="10" step="0.1" value="0.8">
      <span class="setting-value" id="sRimLightVal">0.8</span>
    </div>
  </div>
`;
root.appendChild(settingsPanel);

// Prevent orbit controls when interacting with settings
settingsPanel.addEventListener('pointerdown', e => e.stopPropagation());
settingsPanel.addEventListener('pointermove', e => e.stopPropagation());

// Toggle panel open/close
settingsToggle.addEventListener('click', () => {
  settingsPanel.classList.toggle('open');
});

// Helper to wire slider
function wireSlider(id, valId, callback, isInt) {
  const slider = document.getElementById(id);
  const valEl = document.getElementById(valId);
  slider.addEventListener('input', () => {
    const v = parseFloat(slider.value);
    valEl.textContent = isInt ? Math.round(v).toString() : v.toFixed(2);
    callback(v);
  });
}

// Helper to wire toggle
function wireToggle(id, initial, callback) {
  const btn = document.getElementById(id);
  let state = initial;
  if (state) btn.classList.add('on'); else btn.classList.remove('on');
  btn.addEventListener('click', () => {
    state = !state;
    btn.classList.toggle('on', state);
    callback(state);
  });
}

// Environment
document.getElementById('sHdr').addEventListener('change', (e) => {
  loadHDR(parseInt(e.target.value));
});
wireSlider('sExposure', 'sExposureVal', v => { renderer.toneMappingExposure = v; });
wireSlider('sBgBlur', 'sBgBlurVal', v => { scene.backgroundBlurriness = v; });

// SSR
wireToggle('sSsrEnabled', true, on => { ssrEnabledU.value = on ? 1.0 : 0.0; });
wireSlider('sSsrSteps', 'sSsrStepsVal', v => {
  const steps = Math.round(v);
  if (steps !== currentSsrSteps) {
    currentSsrSteps = steps;
    ssrReflectionNode = buildSsrNode(steps);
    rebuildPostPipeline();
  }
}, true);
wireSlider('sSsrStrength', 'sSsrStrengthVal', v => { ssrStrengthU.value = v; });
wireSlider('sSsrDist', 'sSsrDistVal', v => { ssrMaxDistU.value = v; });
wireSlider('sSsrThick', 'sSsrThickVal', v => { ssrThicknessU.value = v; });
wireSlider('sSsrFresnel', 'sSsrFresnelVal', v => { ssrFresnelPowU.value = v; });
wireSlider('sSsrFade', 'sSsrFadeVal', v => { ssrFadeU.value = v; });

// SSR direction filter
document.getElementById('sSsrDirAxis').addEventListener('change', (e) => {
  ssrReflDirAxisU.value = parseInt(e.target.value);
  rebuildPostPipeline();
});
document.getElementById('sSsrDirSign').addEventListener('change', (e) => {
  const v = parseFloat(e.target.value);
  ssrReflDirSignU.value = v;
  rebuildPostPipeline();
});
wireSlider('sSsrDirThresh', 'sSsrDirThreshVal', v => {
  ssrReflDirThreshU.value = v;
  rebuildPostPipeline();
});

// Bloom
wireToggle('sBloomEnabled', true, on => { bloomEnabledU.value = on ? 1.0 : 0.0; });
wireSlider('sBloomStr', 'sBloomStrVal', v => { bloomStrengthU.value = v; rebuildPostPipeline(); });
wireSlider('sBloomRad', 'sBloomRadVal', v => { bloomRadiusU.value = v; rebuildPostPipeline(); });
wireSlider('sBloomThr', 'sBloomThrVal', v => { bloomThresholdU.value = v; rebuildPostPipeline(); });

// AO
wireToggle('sAoEnabled', true, on => { aoEnabledU.value = on ? 1.0 : 0.0; });
wireSlider('sAoRadius', 'sAoRadiusVal', v => { aoPass.radius.value = v; });
wireSlider('sAoScale', 'sAoScaleVal', v => { aoPass.scale.value = v; });
wireSlider('sAoThick', 'sAoThickVal', v => { aoPass.thickness.value = v; });

// Film Grain
wireToggle('sGrainEnabled', false, on => { grainEnabledU.value = on ? 1.0 : 0.0; });
wireSlider('sGrainInt', 'sGrainIntVal', v => { grainIntensityU.value = v; });

// Helper to check if a material index is an outer (sticker) face for a cubie
function isOuterFace(cubie, matIndex) {
  const { gx, gy, gz } = cubie.userData;
  return [gx === 1, gx === -1, gy === 1, gy === -1, gz === 1, gz === -1][matIndex];
}

// Update sticker (outer) material property — all unique sticker materials
function updateStickerMaterials(prop, value) {
  Object.values(allStickerMaterials).forEach(mat => {
    if (prop === 'normalScale' || prop === 'clearcoatNormalScale') {
      mat[prop].set(value, value);
    } else {
      mat[prop] = value;
    }
    mat.needsUpdate = true;
  });
}

// Update frame (inner) material property — single shared material
function updateFrameMaterials(prop, value) {
  const mat = sharedFrameMaterial;
  if (prop === 'normalScale' || prop === 'clearcoatNormalScale') {
    mat[prop].set(value, value);
  } else if (prop === 'color') {
    mat.color.set(value);
  } else {
    mat[prop] = value;
  }
  mat.needsUpdate = true;
}

// Frame Scratches controls
wireSlider('sScratchStr', 'sScratchStrVal', v => { updateFrameMaterials('clearcoatNormalScale', v); });
wireSlider('sScratchCount', 'sScratchCountVal', () => {});
wireSlider('sScratchDepth', 'sScratchDepthVal', () => {});
wireSlider('sScratchWidth', 'sScratchWidthVal', () => {});

document.getElementById('btnRegenFrameScratches').addEventListener('click', () => {
  const scratchCount = parseInt(document.getElementById('sScratchCount').value);
  const scratchDepth = parseInt(document.getElementById('sScratchDepth').value);
  const scratchWidth = parseFloat(document.getElementById('sScratchWidth').value);
  const newCCMap = generateClearcoatNormalMap(scratchCount, scratchDepth, scratchWidth, 254);
  frameClearcoatNormalMap.image = newCCMap.image;
  frameClearcoatNormalMap.needsUpdate = true;
  sharedFrameMaterial.needsUpdate = true;
});

// Sticker Wear controls
wireSlider('sWearStr', 'sWearStrVal', v => { updateStickerMaterials('clearcoatNormalScale', v); });
wireSlider('sWearFingerprints', 'sWearFingerprintsVal', () => {});
wireSlider('sWearSmudges', 'sWearSmudgesVal', () => {});
wireSlider('sWearOiliness', 'sWearOilinessVal', () => {});
wireSlider('sStickerWobble', 'sStickerWobbleVal', v => { stickerParams.wobble = v; });
wireSlider('sEdgeWear', 'sEdgeWearVal', v => { stickerParams.edgeWear = Math.round(v); });
wireSlider('sMicroScratches', 'sMicroScratchesVal', v => { stickerParams.microScratches = Math.round(v); });
wireSlider('sDustSpecks', 'sDustSpecksVal', v => { stickerParams.dustSpecks = Math.round(v); });
wireSlider('sFingerprints', 'sFingerprintsVal', v => { stickerParams.fingerprints = Math.round(v); });
wireSlider('sHoles', 'sHolesVal', v => { stickerParams.holes = Math.round(v); });
wireSlider('sWearVariance', 'sWearVarianceVal', v => { stickerParams.wearVariance = v; });

// Sticker imperfection params — kept in an object so regen can read them
const stickerParams = {
  wobble: 0.15,
  edgeWear: 8,
  microScratches: 6,
  dustSpecks: 10,
  fingerprints: 10,
  holes: 3,
  wearVariance: 1.0,
};

document.getElementById('btnRegenTextures').addEventListener('click', () => {
  stickerParams.wobble = parseFloat(document.getElementById('sStickerWobble').value);
  stickerParams.edgeWear = parseInt(document.getElementById('sEdgeWear').value);
  stickerParams.microScratches = parseInt(document.getElementById('sMicroScratches').value);
  stickerParams.dustSpecks = parseInt(document.getElementById('sDustSpecks').value);
  stickerParams.fingerprints = parseInt(document.getElementById('sFingerprints').value);
  stickerParams.holes = parseInt(document.getElementById('sHoles').value);
  stickerParams.wearVariance = parseFloat(document.getElementById('sWearVariance').value);

  // Regenerate sticker textures and wrinkle normal maps on ALL unique sticker materials
  stickerSeedCounter = 0;
  wrinkleSeedCounter = 100;
  const wrinkleScale = parseFloat(document.getElementById('sStkWrinkle').value);
  Object.entries(allStickerMaterials).forEach(([key, mat]) => {
    // Extract face name from key "face_x_y_z"
    const face = key.split('_')[0];
    const newTex = getStickerTexture(face);
    if (mat.map) mat.map.dispose();
    mat.map = newTex;
    // Regenerate unique wrinkle normal map per sticker (applied to clearcoat)
    if (mat.clearcoatNormalMap) mat.clearcoatNormalMap.dispose();
    mat.clearcoatNormalMap = generateUniqueWrinkleNormalMap();
    mat.clearcoatNormalScale.set(wrinkleScale, wrinkleScale);
    mat.needsUpdate = true;
  });
});

// Sticker Material PBR controls
wireSlider('sStkRough', 'sStkRoughVal', v => { updateStickerMaterials('roughness', v); });
wireSlider('sStkMetal', 'sStkMetalVal', v => { updateStickerMaterials('metalness', v); });
wireSlider('sStkClear', 'sStkClearVal', v => { updateStickerMaterials('clearcoat', v); });
wireSlider('sStkCcRough', 'sStkCcRoughVal', v => { updateStickerMaterials('clearcoatRoughness', v); });
wireSlider('sStkSheen', 'sStkSheenVal', v => { updateStickerMaterials('sheen', v); });
wireSlider('sStkSheenRough', 'sStkSheenRoughVal', v => { updateStickerMaterials('sheenRoughness', v); });
wireSlider('sStkEnv', 'sStkEnvVal', v => { updateStickerMaterials('envMapIntensity', v); });
wireSlider('sStkNormal', 'sStkNormalVal', v => { updateStickerMaterials('normalScale', v); });
wireSlider('sStkWrinkle', 'sStkWrinkleVal', v => {
  Object.values(allStickerMaterials).forEach(mat => {
    mat.clearcoatNormalScale.set(v, v);
    mat.needsUpdate = true;
  });
});

// Frame Material PBR controls
document.getElementById('sFrameColor').addEventListener('input', (e) => { updateFrameMaterials('color', e.target.value); });
wireSlider('sFrameRough', 'sFrameRoughVal', v => { updateFrameMaterials('roughness', v); });
wireSlider('sFrameMetal', 'sFrameMetalVal', v => { updateFrameMaterials('metalness', v); });
wireSlider('sFrameClear', 'sFrameClearVal', v => { updateFrameMaterials('clearcoat', v); });
wireSlider('sFrameCcRough', 'sFrameCcRoughVal', v => { updateFrameMaterials('clearcoatRoughness', v); });
wireSlider('sFrameSheen', 'sFrameSheenVal', v => { updateFrameMaterials('sheen', v); });
wireSlider('sFrameSheenRough', 'sFrameSheenRoughVal', v => { updateFrameMaterials('sheenRoughness', v); });
wireSlider('sFrameEnv', 'sFrameEnvVal', v => { updateFrameMaterials('envMapIntensity', v); });
wireSlider('sFrameNormal', 'sFrameNormalVal', v => { updateFrameMaterials('normalScale', v); });
wireSlider('sFrameCcNormal', 'sFrameCcNormalVal', v => { updateFrameMaterials('clearcoatNormalScale', v); });

// Lake
wireSlider('sWaveScale', 'sWaveScaleVal', v => {
  lakeSettings.waveScale = v;
  waterNormalMap.repeat.set(v, v);
});
wireSlider('sWaveStr', 'sWaveStrVal', v => {
  lakeSettings.waveStrength = v;
  const newMap = generateWaterNormalMap(lakeSettings.waveDetail, v);
  newMap.wrapS = newMap.wrapT = THREE.RepeatWrapping;
  newMap.repeat.set(lakeSettings.waveScale, lakeSettings.waveScale);
  newMap.offset.copy(waterNormalMap.offset);
  lakeMat.normalMap = newMap;
  lakeMat.needsUpdate = true;
  waterNormalMap.dispose();
  waterNormalMap = newMap;
});
wireSlider('sWaveDrift', 'sWaveDriftVal', v => { lakeSettings.driftSpeed = v; });
wireSlider('sWaveNormal', 'sWaveNormalVal', v => {
  lakeSettings.normalStrength = v;
  lakeMat.normalScale.set(v, v);
});
wireSlider('sLakeOpacity', 'sLakeOpacityVal', v => {
  lakeSettings.opacity = v;
  lakeMat.opacity = v;
});
wireSlider('sLakeRough', 'sLakeRoughVal', v => { lakeMat.roughness = v; });
wireSlider('sLakeMetal', 'sLakeMetalVal', v => { lakeMat.metalness = v; });
wireSlider('sLakeTrans', 'sLakeTransVal', v => { lakeMat.transmission = v; });
wireSlider('sLakeIor', 'sLakeIorVal', v => { lakeMat.ior = v; });
wireSlider('sLakeThick', 'sLakeThickVal', v => { lakeMat.thickness = v; });
wireSlider('sLakeClearcoat', 'sLakeClearcoatVal', v => { lakeMat.clearcoat = v; });
wireSlider('sLakeCcRough', 'sLakeCcRoughVal', v => { lakeMat.clearcoatRoughness = v; });
wireSlider('sLakeEnv', 'sLakeEnvVal', v => { lakeMat.envMapIntensity = v; });
document.getElementById('sLakeColor').addEventListener('input', (e) => {
  lakeMat.color.set(e.target.value);
});
wireSlider('sFogDensity', 'sFogDensityVal', v => {
  scene.fog.density = v;
});

// Lighting
wireSlider('sKeyLight', 'sKeyLightVal', v => { keyLight.intensity = v; });
wireSlider('sRimLight', 'sRimLightVal', v => { rimLight.intensity = v; });

// ─── Animation loop ───
function animate() {
  updateFPS();
  controls.update();

  // Drift water normal map for gentle ripple animation
  waterClock.offset += lakeSettings.driftSpeed;
  waterNormalMap.offset.set(waterClock.offset, waterClock.offset * 0.7);
  projMatU.value.copy(camera.projectionMatrix);
  projInvMatU.value.copy(camera.projectionMatrixInverse);
  postProcessing.render();
}

renderer.setAnimationLoop(animate);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});