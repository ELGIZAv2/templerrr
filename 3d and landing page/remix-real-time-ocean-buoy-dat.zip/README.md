# Remix: Real-time Ocean Buoy Data Visualizer & Simulator

Created with [Omma](https://omma.build)

## Setup

Open `index.html` in your browser, or:

```bash
npx serve .
```
