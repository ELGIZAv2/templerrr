import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";
import img930 from "@/assets/megsy-930.jpg";
import imgGT from "@/assets/megsy-gt.jpg";
import imgRS from "@/assets/megsy-rs.jpg";
import imgVision from "@/assets/megsy-vision.jpg";

const data: Record<string, { name: string; year: string; power: string; torque: string; topSpeed: string; weight: string; desc: string; img: string }> = {
  "megsy-930": { name: "Megsy 930", year: "1975", power: "260 HP", torque: "343 Nm", topSpeed: "260 km/h", weight: "1140 kg", desc: "The car that defined a generation. A 3.0L flat-six with a single KKK turbocharger, raw and uncompromising.", img: img930 },
  "megsy-gt": { name: "Megsy GT", year: "1982", power: "315 HP", torque: "412 Nm", topSpeed: "285 km/h", weight: "1280 kg", desc: "Continent-crossing comfort meets motorsport DNA. Hand-stitched leather, hydraulic everything.", img: imgGT },
  "megsy-rs": { name: "Megsy RS", year: "1991", power: "381 HP", torque: "490 Nm", topSpeed: "310 km/h", weight: "1210 kg", desc: "Stripped, caged, focused. A Nürburgring weapon homologated for the road.", img: imgRS },
  "megsy-vision": { name: "Megsy Vision", year: "2026", power: "850 HP", torque: "1100 Nm", topSpeed: "330 km/h", weight: "1690 kg", desc: "Three motors. Carbon monocoque. Zero apologies. The future, hand-built.", img: imgVision },
};

export const Route = createFileRoute("/models/$slug")({
  head: ({ params }) => {
    const m = data[params.slug];
    return {
      meta: [
        { title: m ? `${m.name} — Megsy Archive` : "Model — Megsy" },
        { name: "description", content: m?.desc ?? "Megsy model details." },
      ],
    };
  },
  loader: ({ params }) => {
    if (!data[params.slug]) throw notFound();
    return { model: data[params.slug] };
  },
  errorComponent: ({ error }) => (
    <MegsyLayout><h1 className="megsy-h1">Error</h1><p>{error.message}</p></MegsyLayout>
  ),
  notFoundComponent: () => (
    <MegsyLayout>
      <div className="megsy-eyebrow">404</div>
      <h1 className="megsy-h1">Model not found</h1>
      <Link to="/models" className="megsy-btn" style={{ marginTop: 32 }}>Back to Models</Link>
    </MegsyLayout>
  ),
  component: ModelDetailPage,
});

function ModelDetailPage() {
  const { model: m } = Route.useLoaderData();
  const specs = [
    ["Power", m.power], ["Torque", m.torque], ["Top Speed", m.topSpeed], ["Weight", m.weight], ["Year", m.year],
  ];
  return (
    <MegsyLayout>
      <div className="megsy-eyebrow">{m.year} · The Archive</div>
      <h1 className="megsy-h1">{m.name}</h1>
      <p className="megsy-lead">{m.desc}</p>

      <div style={{ aspectRatio: "21/9", margin: "64px 0", overflow: "hidden", background: "#0a0a0a" }}>
        <img src={m.img} alt={m.name} width={1280} height={800} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
      </div>

      <h2 className="megsy-h2">Specifications</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 0, borderTop: "1px solid rgba(240,237,232,0.08)" }}>
        {specs.map(([k, v]) => (
          <div key={k} style={{ borderBottom: "1px solid rgba(240,237,232,0.08)", borderRight: "1px solid rgba(240,237,232,0.08)", padding: "24px 20px" }}>
            <div style={{ fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "#888", marginBottom: 8 }}>{k}</div>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 28, color: "#c8a96e" }}>{v}</div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 64, display: "flex", gap: 16, flexWrap: "wrap" }}>
        <Link to="/book" className="megsy-btn">Book a Test Drive</Link>
        <Link to="/models" className="megsy-btn megsy-btn-outline">All Models</Link>
      </div>
    </MegsyLayout>
  );
}
