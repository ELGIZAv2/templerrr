import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";
import { useState } from "react";

export const Route = createFileRoute("/book")({
  head: () => ({
    meta: [
      { title: "Book a Test Drive — Megsy Archive" },
      { name: "description", content: "Reserve a private test drive at our Stuttgart workshop." },
    ],
  }),
  component: BookPage,
});

const models = ["Megsy 930", "Megsy GT", "Megsy RS", "Megsy Vision"];

function BookPage() {
  const [model, setModel] = useState(models[0]);
  const [done, setDone] = useState(false);

  if (done) {
    return (
      <MegsyLayout>
        <div style={{ maxWidth: 560, margin: "64px auto", textAlign: "center" }}>
          <div className="megsy-eyebrow">Reservation Received</div>
          <h1 className="megsy-h1">See you soon.</h1>
          <p className="megsy-lead" style={{ margin: "0 auto" }}>Our concierge will confirm your appointment within 24 hours.</p>
        </div>
      </MegsyLayout>
    );
  }

  return (
    <MegsyLayout>
      <div className="megsy-eyebrow">Private Appointment</div>
      <h1 className="megsy-h1">Book a<br/>Test Drive.</h1>
      <p className="megsy-lead">A two-hour private session on the roads around our Stuttgart workshop. Coffee, espresso, and one of the cars in our archive — your choice.</p>

      <form onSubmit={(e) => { e.preventDefault(); setDone(true); }} style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginTop: 64, maxWidth: 720 }} className="megsy-grid-2">
        <div style={{ gridColumn: "1 / -1" }}>
          <label className="megsy-label">Model</label>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 12 }}>
            {models.map((m) => (
              <button type="button" key={m} onClick={() => setModel(m)}
                style={{
                  padding: "10px 18px",
                  background: model === m ? "#c8a96e" : "transparent",
                  color: model === m ? "#0a0a0a" : "#f0ede8",
                  border: "1px solid " + (model === m ? "#c8a96e" : "rgba(240,237,232,0.2)"),
                  fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700,
                  fontSize: 12, letterSpacing: "0.2em", textTransform: "uppercase",
                  cursor: "pointer",
                }}>{m}</button>
            ))}
          </div>
        </div>
        <div><label className="megsy-label">Full Name</label><input className="megsy-input" required /></div>
        <div><label className="megsy-label">Email</label><input className="megsy-input" type="email" required /></div>
        <div><label className="megsy-label">Phone</label><input className="megsy-input" required /></div>
        <div><label className="megsy-label">Preferred Date</label><input className="megsy-input" type="date" required /></div>
        <div style={{ gridColumn: "1 / -1" }}>
          <label className="megsy-label">Notes</label>
          <textarea className="megsy-textarea" placeholder="Anything we should know?" />
        </div>
        <button type="submit" className="megsy-btn" style={{ gridColumn: "1 / -1", justifySelf: "start" }}>
          Reserve Appointment
        </button>
      </form>
      <style>{`@media (max-width: 700px) { .megsy-grid-2 { grid-template-columns: 1fr !important; } }`}</style>
    </MegsyLayout>
  );
}
