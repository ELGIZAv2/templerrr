import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Megsy Archive" },
      { name: "description", content: "The story of Megsy: half a century of automotive obsession." },
      { property: "og:title", content: "About — Megsy Archive" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const stats = [["50+", "Years of Heritage"], ["12", "Iconic Models"], ["2,400", "Cars in Archive"], ["38", "Countries Served"]];
  const team = [
    { name: "Hans Reuter", role: "Founder & Chief Engineer" },
    { name: "Aiko Tanaka", role: "Head of Design" },
    { name: "Marco Bellini", role: "Master Coachbuilder" },
    { name: "Elena Voss", role: "Heritage Curator" },
  ];
  return (
    <MegsyLayout>
      <div className="megsy-eyebrow">Since 1975</div>
      <h1 className="megsy-h1">A Legend,<br/>Hand-Built.</h1>
      <p className="megsy-lead">Megsy began in a single garage in Stuttgart with one rule: no shortcuts, ever. Five decades later, every car still leaves our workshop the same way it always has — by hand, signed by the engineer who built it.</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 0, marginTop: 96, borderTop: "1px solid rgba(240,237,232,0.08)" }}>
        {stats.map(([n, l]) => (
          <div key={l} style={{ borderBottom: "1px solid rgba(240,237,232,0.08)", borderRight: "1px solid rgba(240,237,232,0.08)", padding: "32px 24px" }}>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: 56, color: "#c8a96e", letterSpacing: "-0.02em" }}>{n}</div>
            <div style={{ fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "#888", marginTop: 4 }}>{l}</div>
          </div>
        ))}
      </div>

      <h2 className="megsy-h2" style={{ marginTop: 96 }}>Our Philosophy</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 32 }}>
        {[
          ["Heritage", "Every car carries the DNA of the original 930 — uncompromising, mechanical, alive."],
          ["Craft", "1,400 hours per chassis. Every weld, stitch and bolt placed by a single human."],
          ["Future", "Electrons or octane — what matters is the conversation between driver and machine."],
        ].map(([t, d]) => (
          <div key={t} className="megsy-card">
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 28, textTransform: "uppercase", color: "#c8a96e", marginBottom: 12 }}>{t}</div>
            <p style={{ color: "rgba(240,237,232,0.7)", lineHeight: 1.7 }}>{d}</p>
          </div>
        ))}
      </div>

      <h2 className="megsy-h2" style={{ marginTop: 96 }}>The People</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 24 }}>
        {team.map((p) => (
          <div key={p.name} className="megsy-card">
            <div style={{ aspectRatio: "1/1", background: "linear-gradient(135deg, #1a1a1a, #0a0a0a)", marginBottom: 20, display: "flex", alignItems: "center", justifyContent: "center", color: "#c8a96e", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: 64 }}>
              {p.name.split(" ").map(n => n[0]).join("")}
            </div>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 22, textTransform: "uppercase" }}>{p.name}</div>
            <div style={{ fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "#c8a96e", marginTop: 6 }}>{p.role}</div>
          </div>
        ))}
      </div>
    </MegsyLayout>
  );
}
