import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MEGSY — 1975 Legend" },
      { name: "description", content: "MEGSY — A scroll-driven 3D automotive experience." },
      { property: "og:title", content: "MEGSY — 1975 Legend" },
      { property: "og:description", content: "MEGSY — A scroll-driven 3D automotive experience." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <iframe
      src="/megsy.html"
      title="MEGSY"
      style={{
        position: "fixed",
        inset: 0,
        width: "100vw",
        height: "100vh",
        border: "none",
      }}
    />
  );
}
