import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";
import { useState } from "react";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Login — Megsy Archive" },
      { name: "description", content: "Sign in to the Megsy member archive." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  return (
    <MegsyLayout>
      <div style={{ maxWidth: 460, margin: "32px auto" }}>
        <div className="megsy-eyebrow">Member Archive</div>
        <h1 className="megsy-h1" style={{ fontSize: "clamp(40px,6vw,72px)" }}>
          {mode === "login" ? "Sign In" : "Join"}
        </h1>
        <p className="megsy-lead" style={{ marginBottom: 48 }}>
          {mode === "login" ? "Welcome back to the archive." : "Reserve your name in the Megsy registry."}
        </p>

        <form onSubmit={(e) => e.preventDefault()} style={{ display: "flex", flexDirection: "column", gap: 28 }}>
          {mode === "signup" && (
            <div>
              <label className="megsy-label">Full Name</label>
              <input className="megsy-input" required />
            </div>
          )}
          <div>
            <label className="megsy-label">Email</label>
            <input className="megsy-input" type="email" required />
          </div>
          <div>
            <label className="megsy-label">Password</label>
            <input className="megsy-input" type="password" required />
          </div>
          <button type="submit" className="megsy-btn" style={{ marginTop: 12 }}>
            {mode === "login" ? "Sign In" : "Create Account"}
          </button>
        </form>

        <div style={{ marginTop: 32, fontSize: 13, color: "rgba(240,237,232,0.6)" }}>
          {mode === "login" ? (
            <>New to Megsy? <button onClick={() => setMode("signup")} style={{ background: "none", border: "none", color: "#c8a96e", cursor: "pointer", letterSpacing: "0.1em", textTransform: "uppercase", fontSize: 11 }}>Create Account</button></>
          ) : (
            <>Already a member? <button onClick={() => setMode("login")} style={{ background: "none", border: "none", color: "#c8a96e", cursor: "pointer", letterSpacing: "0.1em", textTransform: "uppercase", fontSize: 11 }}>Sign In</button></>
          )}
        </div>
        <div style={{ marginTop: 12, fontSize: 12 }}>
          <Link to="/" style={{ color: "#888", letterSpacing: "0.15em", textTransform: "uppercase", fontSize: 11 }}>← Back home</Link>
        </div>
      </div>
    </MegsyLayout>
  );
}
