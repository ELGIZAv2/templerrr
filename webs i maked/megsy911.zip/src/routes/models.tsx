import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";
import img930 from "@/assets/megsy-930.jpg";
import imgGT from "@/assets/megsy-gt.jpg";
import imgRS from "@/assets/megsy-rs.jpg";
import imgVision from "@/assets/megsy-vision.jpg";

export const Route = createFileRoute("/models")({
  head: () => ({
    meta: [
      { title: "Models — Megsy Archive" },
      { name: "description", content: "Discover the Megsy collection of legendary cars." },
      { property: "og:title", content: "Models — Megsy Archive" },
    ],
  }),
  component: ModelsPage,
});

const models = [
  { slug: "megsy-930", name: "Megsy 930", year: "1975", power: "260 HP", desc: "The original turbocharged legend.", img: img930 },
  { slug: "megsy-gt", name: "Megsy GT", year: "1982", power: "315 HP", desc: "A grand tourer refined to perfection.", img: imgGT },
  { slug: "megsy-rs", name: "Megsy RS", year: "1991", power: "381 HP", desc: "Track-bred. Road-legal. Untamed.", img: imgRS },
  { slug: "megsy-vision", name: "Megsy Vision", year: "2026", power: "850 HP", desc: "Electric future. Analog soul.", img: imgVision },
];

function ModelsPage() {
  return (
    <MegsyLayout>
      <div className="megsy-eyebrow">The Collection</div>
      <h1 className="megsy-h1">Models</h1>
      <p className="megsy-lead">Four decades of obsession. Each Megsy is hand-built, numbered and archived for the next generation of believers.</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(360px, 1fr))", gap: 32, marginTop: 64 }}>
        {models.map((m) => (
          <Link key={m.slug} to="/models/$slug" params={{ slug: m.slug }} className="megsy-card" style={{ display: "block", padding: 0, overflow: "hidden" }}>
            <div style={{ aspectRatio: "16/10", overflow: "hidden", background: "#0a0a0a" }}>
              <img src={m.img} alt={m.name} loading="lazy" width={1280} height={800} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block", transition: "transform .6s ease" }} />
            </div>
            <div style={{ padding: 28 }}>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 32, textTransform: "uppercase", letterSpacing: "-0.01em" }}>{m.name}</div>
              <div style={{ fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "#c8a96e", marginTop: 6 }}>{m.power} · {m.year}</div>
              <p style={{ marginTop: 16, color: "rgba(240,237,232,0.6)", fontSize: 14, lineHeight: 1.6 }}>{m.desc}</p>
              <div style={{ marginTop: 24, fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "#c8a96e" }}>View Details →</div>
            </div>
          </Link>
        ))}
      </div>
    </MegsyLayout>
  );
}
