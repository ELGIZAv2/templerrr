import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";
import { useState } from "react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Megsy Archive" },
      { name: "description", content: "Get in touch with the Megsy team." },
      { property: "og:title", content: "Contact — Megsy Archive" },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);
  return (
    <MegsyLayout>
      <div className="megsy-eyebrow">Get in Touch</div>
      <h1 className="megsy-h1">Contact</h1>
      <p className="megsy-lead">Inquiries, commissions, restorations or just a conversation — we read every message ourselves.</p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 64, marginTop: 64 }} className="megsy-grid-2">
        <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: "flex", flexDirection: "column", gap: 28 }}>
          <div>
            <label className="megsy-label">Name</label>
            <input className="megsy-input" required />
          </div>
          <div>
            <label className="megsy-label">Email</label>
            <input className="megsy-input" type="email" required />
          </div>
          <div>
            <label className="megsy-label">Subject</label>
            <input className="megsy-input" required />
          </div>
          <div>
            <label className="megsy-label">Message</label>
            <textarea className="megsy-textarea" required />
          </div>
          <button type="submit" className="megsy-btn" style={{ alignSelf: "flex-start" }}>
            {sent ? "Message Sent ✓" : "Send Message"}
          </button>
        </form>

        <div>
          {[
            ["Workshop", "Schwabstraße 14\n70197 Stuttgart, Germany"],
            ["Email", "archive@megsy.example"],
            ["Phone", "+49 711 555 0930"],
            ["Hours", "Mon–Fri  09:00 — 18:00\nSat  by appointment"],
          ].map(([t, v]) => (
            <div key={t} style={{ borderTop: "1px solid rgba(240,237,232,0.08)", padding: "24px 0" }}>
              <div style={{ fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "#c8a96e", marginBottom: 8 }}>{t}</div>
              <div style={{ whiteSpace: "pre-line", fontSize: 16, lineHeight: 1.7, color: "rgba(240,237,232,0.8)" }}>{v}</div>
            </div>
          ))}
        </div>
      </div>
      <style>{`@media (max-width: 768px) { .megsy-grid-2 { grid-template-columns: 1fr !important; gap: 48px !important; } }`}</style>
    </MegsyLayout>
  );
}
