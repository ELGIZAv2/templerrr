import { Link, useLocation } from "@tanstack/react-router";
import { ReactNode } from "react";

const navItems = [
  { to: "/", label: "Home" },
  { to: "/models", label: "Models" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
  { to: "/login", label: "Login" },
];

export function MegsyLayout({ children }: { children: ReactNode }) {
  const location = useLocation();
  return (
    <div className="megsy-root">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Barlow+Condensed:wght@600;700;800;900&display=swap');
        .megsy-root {
          --black: #0a0a0a;
          --white: #f0ede8;
          --accent: #c8a96e;
          --gray: #888;
          --light-gray: #1a1a1a;
          background: var(--black);
          color: var(--white);
          font-family: 'Inter', sans-serif;
          min-height: 100vh;
          overflow-x: hidden;
        }
        .megsy-root *, .megsy-root *::before, .megsy-root *::after { box-sizing: border-box; }
        .megsy-root a { color: inherit; text-decoration: none; }
        .megsy-nav {
          position: fixed; top: 0; left: 0; right: 0; z-index: 100;
          display: flex; justify-content: space-between; align-items: center;
          padding: 24px 48px;
          background: linear-gradient(to bottom, rgba(10,10,10,0.95), rgba(10,10,10,0.7) 70%, transparent);
        }
        .megsy-logo {
          font-family: 'Barlow Condensed', sans-serif;
          font-weight: 900; font-size: 13px; letter-spacing: 0.2em;
          text-transform: uppercase;
        }
        .megsy-nav-right { display: flex; gap: 32px; align-items: center; }
        .megsy-nav-right a {
          font-size: 11px; letter-spacing: 0.15em; text-transform: uppercase;
          opacity: 0.6; transition: opacity .3s, color .3s;
        }
        .megsy-nav-right a:hover, .megsy-nav-right a.active { opacity: 1; color: var(--accent); }
        .megsy-cta {
          padding: 10px 18px; border: 1px solid var(--accent); color: var(--accent) !important;
          opacity: 1 !important;
        }
        .megsy-cta:hover { background: var(--accent); color: var(--black) !important; }
        .megsy-main { padding: 140px 48px 96px; max-width: 1280px; margin: 0 auto; }
        .megsy-eyebrow {
          font-family: 'Barlow Condensed', sans-serif;
          font-size: 12px; letter-spacing: 0.3em; text-transform: uppercase;
          color: var(--accent); margin-bottom: 16px;
        }
        .megsy-h1 {
          font-family: 'Barlow Condensed', sans-serif;
          font-weight: 800; font-size: clamp(48px, 8vw, 120px);
          line-height: 0.92; letter-spacing: -0.02em; text-transform: uppercase;
          margin-bottom: 32px;
        }
        .megsy-h2 {
          font-family: 'Barlow Condensed', sans-serif;
          font-weight: 700; font-size: clamp(32px, 4vw, 56px);
          letter-spacing: -0.01em; text-transform: uppercase; margin-bottom: 24px;
        }
        .megsy-lead { font-size: 18px; line-height: 1.7; color: rgba(240,237,232,0.7); max-width: 640px; }
        .megsy-footer {
          border-top: 1px solid rgba(240,237,232,0.08);
          padding: 48px; text-align: center; font-size: 11px;
          letter-spacing: 0.2em; text-transform: uppercase; color: var(--gray);
        }
        .megsy-card {
          border: 1px solid rgba(240,237,232,0.08);
          background: rgba(255,255,255,0.02);
          padding: 32px; transition: border-color .3s, transform .3s;
        }
        .megsy-card:hover { border-color: var(--accent); transform: translateY(-4px); }
        .megsy-input, .megsy-textarea {
          width: 100%; background: transparent; border: none;
          border-bottom: 1px solid rgba(240,237,232,0.2);
          color: var(--white); padding: 14px 0; font-family: 'Inter', sans-serif;
          font-size: 15px; outline: none; transition: border-color .3s;
        }
        .megsy-input:focus, .megsy-textarea:focus { border-bottom-color: var(--accent); }
        .megsy-textarea { resize: vertical; min-height: 120px; }
        .megsy-label {
          display: block; font-size: 11px; letter-spacing: 0.2em;
          text-transform: uppercase; color: var(--gray); margin-bottom: 8px;
        }
        .megsy-btn {
          display: inline-block; padding: 16px 36px;
          background: var(--accent); color: var(--black); border: none;
          font-family: 'Barlow Condensed', sans-serif; font-weight: 700;
          font-size: 14px; letter-spacing: 0.2em; text-transform: uppercase;
          cursor: pointer; transition: background .3s; text-align: center;
        }
        .megsy-btn:hover { background: var(--white); }
        .megsy-btn-outline {
          background: transparent; border: 1px solid var(--accent); color: var(--accent);
        }
        .megsy-btn-outline:hover { background: var(--accent); color: var(--black); }
        @keyframes megsyPageIn {
          from { opacity: 0; transform: translateY(12px); filter: blur(4px); }
          to   { opacity: 1; transform: translateY(0);    filter: blur(0); }
        }
        .megsy-page {
          animation: megsyPageIn 520ms cubic-bezier(.22,.8,.36,1) both;
          will-change: opacity, transform, filter;
        }
        @media (max-width: 768px) {
          .megsy-nav { padding: 18px 24px; }
          .megsy-nav-right { gap: 18px; overflow-x: auto; }
          .megsy-main { padding: 120px 24px 64px; }
        }
      `}</style>
      <nav className="megsy-nav">
        <Link to="/" className="megsy-logo">Megsy / Archive</Link>
        <div className="megsy-nav-right">
          {navItems.map((it) => (
            <Link
              key={it.to}
              to={it.to}
              activeOptions={{ exact: it.to === "/" }}
              activeProps={{ className: "active" }}
            >
              {it.label}
            </Link>
          ))}
          <Link to="/book" className="megsy-cta">Book Test Drive</Link>
        </div>
      </nav>
      <main className="megsy-main">
        <div key={location.pathname} className="megsy-page">{children}</div>
      </main>
      <footer className="megsy-footer">© Megsy Archive — Crafted in 1975, preserved for eternity.</footer>
    </div>
  );
}
