import { expect, test } from "@playwright/test";

test.describe("home page navigation", () => {
  test("header links navigate from the 3D home iframe", async ({ page }) => {
    await page.goto("/");

    const home = page.frameLocator('iframe[title="MEGSY"]');

    await home.getByRole("link", { name: "Models" }).click();
    await expect(page).toHaveURL(/\/models$/);

    await page.goto("/");
    await home.getByRole("link", { name: "About" }).click();
    await expect(page).toHaveURL(/\/about$/);

    await page.goto("/");
    await home.getByRole("link", { name: "Contact" }).click();
    await expect(page).toHaveURL(/\/contact$/);

    await page.goto("/");
    await home.getByRole("link", { name: "Login" }).click();
    await expect(page).toHaveURL(/\/login$/);

    await page.goto("/");
    await home.getByRole("link", { name: "Book Test Drive" }).click();
    await expect(page).toHaveURL(/\/book$/);
  });

  test("final CTA navigates to booking", async ({ page }) => {
    await page.goto("/");

    const home = page.frameLocator('iframe[title="MEGSY"]');
    const cta = home.getByRole("link", { name: "Begin Enquiry" });
    await cta.scrollIntoViewIfNeeded();
    await cta.click();

    await expect(page).toHaveURL(/\/book$/);
  });
});