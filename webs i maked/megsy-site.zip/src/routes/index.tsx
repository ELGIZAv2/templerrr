import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Megsy — Sound, Reflected." },
      { name: "description", content: "Megsy is an independent music & creative studio. Explore curated frequencies, featured artists and custom pressings." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  useEffect(() => {
    let cleanup: (() => void) | undefined;
    let cancelled = false;
    import("@/lib/vinyl-scene").then((m) => {
      if (cancelled) return;
      try { cleanup = m.initVinylScene(); } catch (e) { console.error(e); }
    });
    return () => {
      cancelled = true;
      try { cleanup?.(); } catch {}
    };
  }, []);

  return (
    <>
      <SiteNav />

      {/* Section jump dots */}
      <div className="section-dots">
        <div className="section-dot active" data-section="section-hero"><span className="dot-label">Home</span></div>
        <div className="section-dot" data-section="section-artists"><span className="dot-label">Artists</span></div>
        <div className="section-dot" data-section="section-contact"><span className="dot-label">Contact</span></div>
      </div>

      <div id="three-canvas"></div>

      {/* Section 1: Hero */}
      <section id="section-hero" className="page-section section-hero">
        <div className="section-inner">
          <div className="hero-content">
            <div className="hero-text">
              <div className="hero-tag">Independent Music & Creative Studio — Est. 2024</div>
              <h1 className="hero-title">
                Sound
                <span className="outline-word">Reflected.</span>
              </h1>
              <p className="hero-desc">
                Megsy crafts records that mirror your world. Every groove captures the frequency of now —
                raw, real, reflective.
              </p>
              <div className="hero-actions">
                <Link to="/catalog" className="btn-primary">Explore Catalog →</Link>
                <Link to="/contact" className="btn-secondary get-in-touch-btn">Get in Touch</Link>
              </div>
            </div>
            <div className="hero-vinyl-space"></div>
          </div>
        </div>
        <div className="stats-bar" id="stats-bar">
          <div className="stat-item"><div className="stat-number">127</div><div className="stat-label">Releases</div></div>
          <div className="stat-item"><div className="stat-number">48</div><div className="stat-label">Artists</div></div>
          <div className="stat-item"><div className="stat-number">12K</div><div className="stat-label">Pressed</div></div>
        </div>
      </section>

      <div className="scroll-hint" id="scroll-hint">
        <span>Scroll</span>
        <div className="scroll-line"></div>
      </div>

      {/* Section 2: Artists */}
      <section id="section-artists" className="page-section section-artists">
        <div className="section-inner">
          <div className="artists-text">
            <div className="section-tag">Featured Artists</div>
            <h2>Curated<br />Frequencies</h2>
            <p>Every artist on the Megsy roster brings a unique sonic fingerprint. We don't just press records — we preserve moments in wax.</p>
            <ul className="artist-list">
              <li><span className="artist-num">01</span> Mira Solstice — Ambient Electronica</li>
              <li><span className="artist-num">02</span> The Grain — Post-Rock</li>
              <li><span className="artist-num">03</span> Kasra — Experimental Jazz</li>
              <li><span className="artist-num">04</span> Hollow Sun — Shoegaze</li>
            </ul>
            <div style={{ marginTop: 28 }}>
              <Link to="/artists" className="btn-secondary">View All Artists →</Link>
            </div>
          </div>
          <div className="artists-vinyl-space"></div>
        </div>
      </section>

      {/* Section 3: Contact */}
      <section id="section-contact" className="page-section section-contact">
        <div className="section-inner">
          <div className="contact-tag">Get in Touch</div>
          <h2 className="contact-title">
            Let's Press
            <span className="outline-word" style={{ color: "#ffffff", WebkitTextStroke: "1.5px #0a0a0a" }}>Together.</span>
          </h2>
          <p className="contact-desc">
            Whether you're an artist looking to press your first record or a collector hunting rarities — we'd love to hear from you.
          </p>
          <div className="contact-actions">
            <Link to="/contact" className="btn-primary">Start a Project →</Link>
            <Link to="/catalog" className="btn-secondary get-in-touch-btn">View Pressings</Link>
          </div>
        </div>
      </section>


      <SiteFooter />
    </>
  );
}
