import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/artists")({
  head: () => ({
    meta: [
      { title: "Artists — Megsy" },
      { name: "description", content: "Six independent artists shaping the Megsy roster — ambient, post-rock, jazz, shoegaze, modern classical and dub techno." },
      { property: "og:title", content: "Artists — Megsy" },
      { property: "og:description", content: "Meet the Megsy roster." },
    ],
  }),
  component: ArtistsPage,
});

const artists = [
  { name: "Mira Solstice", genre: "Ambient Electronica", from: "Reykjavík, IS", since: 2024, releases: 3,
    bio: "Field recordings reshaped into slow, glowing dreamscapes. Mira's records sound like rooms you've never been in but can almost remember." },
  { name: "The Grain", genre: "Post-Rock", from: "Glasgow, UK", since: 2024, releases: 2,
    bio: "Walls of distortion, quiet centers. A four-piece built for big rooms and headphones, equally at home with both." },
  { name: "Kasra", genre: "Experimental Jazz", from: "Berlin, DE", since: 2025, releases: 2,
    bio: "Brass, breath and code in conversation. Kasra's sets are unpredictable, deliberate and never the same twice." },
  { name: "Hollow Sun", genre: "Shoegaze", from: "Lisbon, PT", since: 2025, releases: 2,
    bio: "Reverb-soaked guitars layered over patient rhythms. Records you put on at midnight and finish at three." },
  { name: "Aster Vale", genre: "Modern Classical", from: "Oslo, NO", since: 2025, releases: 1,
    bio: "Piano cycles informed by minimalism and modular synthesis. A composer for film as much as for headphones." },
  { name: "Ortega Loop", genre: "Dub Techno", from: "Mexico City, MX", since: 2026, releases: 1,
    bio: "Underwater rhythms for late-night listening. Hardware-only sets, recorded straight to tape." },
];

function ArtistsPage() {
  return (
    <PageShell>
      <div className="inner-page">
        <div className="inner-wrap">
          <div className="eyebrow">Megsy Roster</div>
          <h1 className="page-title">
            Six Voices,
            <span className="outline-word">One Studio.</span>
          </h1>
          <p className="page-lede">
            We sign small. Six artists, three continents, one shared philosophy: press the work that wouldn't
            survive a streaming-first world. Want to join? <Link to="/contact" style={{ color: "#0a0a0a", textDecoration: "underline" }}>Send us your demo.</Link>
          </p>

          <div className="grid-cards">
            {artists.map((a, i) => (
              <article key={a.name} className="card">
                <div className={`card-cover tone-${(i % 5) + 1}`}></div>
                <div className="card-meta">{a.genre} · {a.from}</div>
                <div className="card-title">{a.name}</div>
                <div className="card-sub">{a.bio}</div>
                <div className="card-foot">
                  <span>Since {a.since} · {a.releases} {a.releases === 1 ? "release" : "releases"}</span>
                  <Link to="/catalog">Music →</Link>
                </div>
              </article>
            ))}
          </div>

          <div className="section-block">
            <h2>Demo submissions</h2>
            <p className="lede">
              We listen to everything sent to demos@megsy.studio. Send links, not files — Bandcamp, SoundCloud
              and private streams welcome. Reply within four weeks if it's a fit; longer if we're on the road.
            </p>
            <div className="feature-grid">
              <div className="feature">
                <div className="num">01</div>
                <h3>What we sign</h3>
                <p>Long-form work. Albums and EPs we can press, sleeve and stand behind for years.</p>
              </div>
              <div className="feature">
                <div className="num">02</div>
                <h3>What we offer</h3>
                <p>Mastering, vinyl pressing, sleeve design, distribution and a small but loyal audience.</p>
              </div>
              <div className="feature">
                <div className="num">03</div>
                <h3>What we ask</h3>
                <p>That you stay on the roster. We don't sign one-record deals.</p>
              </div>
            </div>
            <div style={{ marginTop: 28 }}>
              <Link to="/contact" className="btn-primary">Submit a demo →</Link>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
