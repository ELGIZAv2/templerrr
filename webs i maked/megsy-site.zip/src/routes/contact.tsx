import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Megsy" },
      { name: "description", content: "Get in touch with Megsy Studio: demo submissions, custom pressings, press inquiries and partnerships." },
      { property: "og:title", content: "Contact — Megsy" },
      { property: "og:description", content: "Get in touch with Megsy Studio." },
    ],
  }),
  component: ContactPage,
});

const faqs = [
  { q: "Do you accept demo submissions?", a: "Yes — send links (Bandcamp, SoundCloud, private streams) to demos@megsy.studio. We listen to everything and reply within four weeks if it's a fit." },
  { q: "What's the minimum run for custom pressings?", a: "We press from 100 copies up. For the best per-unit pricing we recommend 300+." },
  { q: "Can you master a record we'll press elsewhere?", a: "Yes. We offer mastering as a standalone service for vinyl, digital and tape." },
  { q: "Do you ship worldwide?", a: "We ship from Amsterdam to over 60 countries. Free EU shipping over €80, free worldwide over €120." },
  { q: "Can I visit the studio?", a: "By appointment. Email hello@megsy.studio with a few date options and we'll find a time." },
];

function ContactPage() {
  const [sent, setSent] = useState(false);
  const [open, setOpen] = useState<number | null>(0);

  return (
    <PageShell>
      <div className="inner-page">
        <div className="inner-wrap">
          <div className="eyebrow">Get in Touch</div>
          <h1 className="page-title">
            Let's Press
            <span className="outline-word">Together.</span>
          </h1>
          <p className="page-lede">
            Demos, custom pressings, partnerships and questions — we read every message.
            We usually reply within two working days.
          </p>

          <div className="contact-grid">
            <form
              className="contact-form"
              onSubmit={(e) => { e.preventDefault(); setSent(true); }}
            >
              <div className="form-row">
                <div>
                  <label htmlFor="name">Name</label>
                  <input id="name" name="name" required placeholder="Your name" />
                </div>
                <div>
                  <label htmlFor="email">Email</label>
                  <input id="email" name="email" type="email" required placeholder="you@studio.com" />
                </div>
              </div>
              <div className="form-row">
                <div>
                  <label htmlFor="org">Studio / Label (optional)</label>
                  <input id="org" name="org" placeholder="Where you're writing from" />
                </div>
                <div>
                  <label htmlFor="subject">Subject</label>
                  <select id="subject" name="subject" defaultValue="demo">
                    <option value="demo">Demo submission</option>
                    <option value="press">Custom pressing</option>
                    <option value="master">Mastering only</option>
                    <option value="press-kit">Press / interview</option>
                    <option value="visit">Studio visit</option>
                    <option value="other">Something else</option>
                  </select>
                </div>
              </div>
              <div>
                <label htmlFor="message">Message</label>
                <textarea id="message" name="message" required placeholder="Tell us about the project, links to listen, run size, timing — whatever's helpful." />
              </div>
              <div>
                <button type="submit" className="btn-primary" style={{ width: "100%", justifyContent: "center" }}>
                  {sent ? "✓ Thanks — we'll be in touch" : "Send message →"}
                </button>
              </div>
            </form>

            <aside className="contact-info-card">
              <div className="label">Studio</div>
              <div className="value">Megsy Studio<br />Ringgade 14<br />1095 AB Amsterdam, NL</div>

              <div className="label">General</div>
              <div className="value">hello@megsy.studio</div>

              <div className="label">Demos</div>
              <div className="value">demos@megsy.studio</div>

              <div className="label">Custom Pressings</div>
              <div className="value">press@megsy.studio</div>

              <div className="label">Hours</div>
              <div className="value">Mon–Fri · 10:00–18:00 CET</div>
            </aside>
          </div>

          <div className="section-block">
            <h2>Frequently asked</h2>
            <p className="lede">If your question isn't here, the form above is the fastest route.</p>
            <div className="faq-list">
              {faqs.map((f, i) => (
                <div key={f.q} className={`faq-item ${open === i ? "faq-open" : ""}`}>
                  <button className="faq-q" onClick={() => setOpen(open === i ? null : i)}>
                    <span>{f.q}</span>
                    <span className="faq-icon">{open === i ? "−" : "+"}</span>
                  </button>
                  {open === i && <div className="faq-a">{f.a}</div>}
                </div>
              ))}
            </div>
          </div>

          <div className="section-block" style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <Link to="/about" className="btn-secondary">More about Megsy</Link>
            <Link to="/artists" className="btn-secondary">View the roster</Link>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
