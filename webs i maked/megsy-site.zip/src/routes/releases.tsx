import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/releases")({
  head: () => ({
    meta: [
      { title: "Releases — Megsy" },
      { name: "description", content: "Upcoming and recent releases from Megsy Studio. Pre-order new pressings or revisit the back catalog." },
      { property: "og:title", content: "Releases — Megsy" },
      { property: "og:description", content: "Upcoming and recent releases." },
    ],
  }),
  component: ReleasesPage,
});

const upcoming = [
  { id: "MGS-009", title: "Tidal Drift", artist: "Mira Solstice", date: "Mar 2026", status: "Pre-order", tracks: 8, runtime: "42:18" },
  { id: "MGS-010", title: "Concrete Grain", artist: "The Grain", date: "Apr 2026", status: "Coming soon", tracks: 6, runtime: "38:54" },
  { id: "MGS-013", title: "Brass Method", artist: "Kasra", date: "Jun 2026", status: "Announced", tracks: 9, runtime: "51:02" },
];

const recent = [
  { id: "MGS-008", title: "Inner Bloom", artist: "Hollow Sun", date: "Nov 2025", status: "Out now", tracks: 7, runtime: "39:11" },
  { id: "MGS-007", title: "Field Notes", artist: "Kasra", date: "Sep 2025", status: "Out now", tracks: 8, runtime: "44:30" },
  { id: "MGS-006", title: "Slow Decay", artist: "The Grain", date: "Jun 2025", status: "Out now", tracks: 6, runtime: "37:22" },
  { id: "MGS-005", title: "Northbound Static", artist: "Mira Solstice", date: "Mar 2025", status: "Sold out", tracks: 4, runtime: "22:14" },
  { id: "MGS-012", title: "Underwater Mass", artist: "Ortega Loop", date: "Feb 2025", status: "Out now", tracks: 8, runtime: "46:08" },
  { id: "MGS-011", title: "Cycles in Glass", artist: "Aster Vale", date: "Nov 2024", status: "Out now", tracks: 9, runtime: "48:55" },
];

const featured = recent[0];

type Item = typeof recent[number];

function Row({ r, n }: { r: Item; n: number }) {
  return (
    <div className="list-row">
      <span className="num">{String(n).padStart(2, "0")}</span>
      <div className="info">
        <div className="t">{r.title}</div>
        <div className="s">{r.artist} · {r.id} · {r.tracks} tracks · {r.runtime}</div>
      </div>
      <span className={`pill pill-${r.status.replace(/\s/g, "").toLowerCase()}`}>{r.status}</span>
      <span className="dur">{r.date}</span>
    </div>
  );
}

function ReleasesPage() {
  return (
    <PageShell>
      <div className="inner-page">
        <div className="inner-wrap">
          <div className="eyebrow">Catalog Releases</div>
          <h1 className="page-title">
            What's Next,
            <span className="outline-word">What's Now.</span>
          </h1>
          <p className="page-lede">
            Three upcoming pressings, six recent drops and a back catalog that grows by roughly one record a month.
            Pre-orders ship in the order received.
          </p>

          <article className="featured-release">
            <div className="card-cover tone-2" style={{ borderRadius: 18 }}></div>
            <div>
              <div className="eyebrow" style={{ marginBottom: 12 }}>Featured Release</div>
              <h2 style={{ fontFamily: "Syne, sans-serif", fontSize: "clamp(28px, 4vw, 48px)", fontWeight: 800, letterSpacing: "-0.02em", marginBottom: 12 }}>
                {featured.title}
              </h2>
              <p style={{ color: "#666", fontSize: 15, marginBottom: 6 }}>{featured.artist}</p>
              <p style={{ color: "#999", fontSize: 13, marginBottom: 24 }}>{featured.id} · {featured.date} · {featured.runtime}</p>
              <p style={{ color: "#555", lineHeight: 1.7, marginBottom: 24 }}>
                Hollow Sun's most patient record yet — seven tracks of slow shoegaze built around layered guitars,
                analog tape and the kind of room reverb you can only get from a real space. Mastered for vinyl by
                the studio team and pressed at half speed on 180g black wax.
              </p>
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                <Link to="/shop" className="btn-primary">Buy on vinyl →</Link>
                <Link to="/artists" className="btn-secondary">More from Hollow Sun</Link>
              </div>
            </div>
          </article>

          <div className="section-block">
            <h2>Upcoming</h2>
            <p className="lede">Reserve a copy before the stamper hits the press. We email you when your record ships.</p>
            <div className="list-rows">
              {upcoming.map((r, i) => <Row key={r.id} r={r} n={i + 1} />)}
            </div>
          </div>

          <div className="section-block">
            <h2>Recently released</h2>
            <p className="lede">The most recent six pressings from the studio.</p>
            <div className="list-rows">
              {recent.map((r, i) => <Row key={r.id} r={r} n={i + 1} />)}
            </div>
          </div>

          <div className="section-block" style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <Link to="/catalog" className="btn-primary">See full catalog →</Link>
            <Link to="/shop" className="btn-secondary">Visit the shop</Link>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
