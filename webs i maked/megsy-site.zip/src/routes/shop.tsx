import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "Shop — Megsy" },
      { name: "description", content: "Buy vinyl, merch and limited bundles direct from Megsy Studio. Worldwide shipping." },
      { property: "og:title", content: "Shop — Megsy" },
      { property: "og:description", content: "Vinyl, merch and limited bundles." },
    ],
  }),
  component: ShopPage,
});

const products = [
  { id: "v-001", title: "Reflections in Wax", sub: "Mira Solstice — 12\" 180g", price: 32, kind: "vinyl" },
  { id: "v-002", title: "Quiet Architecture", sub: "The Grain — 12\" 180g", price: 34, kind: "vinyl" },
  { id: "v-003", title: "Ash & Brass", sub: "Kasra — 2x12\" 180g", price: 48, kind: "vinyl" },
  { id: "v-004", title: "Hollow Light", sub: "Hollow Sun — 12\" Color", price: 36, kind: "vinyl" },
  { id: "v-005", title: "Cycles in Glass", sub: "Aster Vale — 12\" 180g", price: 30, kind: "vinyl" },
  { id: "v-006", title: "Underwater Mass", sub: "Ortega Loop — 12\" Color", price: 36, kind: "vinyl" },
  { id: "m-001", title: "Megsy Studio Tee", sub: "Heavyweight cotton, screen-printed", price: 28, kind: "merch" },
  { id: "m-002", title: "Logo Tote", sub: "Natural canvas, reinforced strap", price: 18, kind: "merch" },
  { id: "m-003", title: "Engineer's Cap", sub: "Six-panel, embroidered logo", price: 24, kind: "merch" },
  { id: "m-004", title: "Sleeve Print Set", sub: "Three A3 prints, signed and numbered", price: 36, kind: "merch" },
  { id: "b-001", title: "Roster Bundle", sub: "Four LPs + tee + tote", price: 120, kind: "bundle" },
  { id: "b-002", title: "Ambient Bundle", sub: "Mira Solstice — full discography", price: 78, kind: "bundle" },
];

function ShopPage() {
  const [filter, setFilter] = useState<"all" | "vinyl" | "merch" | "bundle">("all");
  const [cart, setCart] = useState<Record<string, number>>({});
  const [open, setOpen] = useState(false);

  const add = (id: string) => { setCart((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 })); setOpen(true); };
  const remove = (id: string) => setCart((c) => {
    const n = { ...c };
    if ((n[id] ?? 0) <= 1) delete n[id]; else n[id] -= 1;
    return n;
  });
  const list = filter === "all" ? products : products.filter((p) => p.kind === filter);
  const total = Object.entries(cart).reduce((sum, [id, q]) => sum + (products.find((p) => p.id === id)?.price ?? 0) * q, 0);
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const shipping = total > 0 ? (total >= 80 ? 0 : 8) : 0;

  return (
    <PageShell>
      <div className="inner-page">
        <div className="inner-wrap">
          <div className="eyebrow">Megsy Shop</div>
          <h1 className="page-title">
            Take it
            <span className="outline-word">Home.</span>
          </h1>
          <p className="page-lede">
            Vinyl, merch and limited bundles — pressed, printed and shipped from the studio in Amsterdam.
            Free shipping on orders over €80. This is a frontend demo; complete checkout opens via{" "}
            <Link to="/contact" style={{ color: "#0a0a0a", textDecoration: "underline" }}>contact</Link>.
          </p>

          <div className="shop-grid">
            <div>
              <div className="toolbar">
                <div className="chip-group">
                  {(["all", "vinyl", "merch", "bundle"] as const).map((k) => (
                    <button key={k} onClick={() => setFilter(k)} className={`chip ${filter === k ? "chip-on" : ""}`} style={{ textTransform: "capitalize" }}>
                      {k}
                    </button>
                  ))}
                </div>
                <button onClick={() => setOpen(true)} className="btn-secondary" style={{ marginLeft: "auto" }}>
                  Cart ({count}) · €{total}
                </button>
              </div>

              <div className="grid-cards">
                {list.map((p, i) => (
                  <article key={p.id} className="card">
                    <div className={`card-cover tone-${(i % 5) + 1}`}></div>
                    <div className="card-meta">{p.kind}</div>
                    <div className="card-title">{p.title}</div>
                    <div className="card-sub">{p.sub}</div>
                    <div className="card-foot">
                      <span className="price">€{p.price}</span>
                      <button onClick={() => add(p.id)} className="btn-primary" style={{ padding: "8px 18px", fontSize: 12 }}>
                        Add to cart
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            </div>

            <aside className={`cart-drawer ${open ? "cart-open" : ""}`}>
              <div className="cart-head">
                <h3>Your cart</h3>
                <button onClick={() => setOpen(false)} aria-label="Close" className="cart-close">×</button>
              </div>
              {count === 0 ? (
                <p className="cart-empty">Your cart is empty. Add a record to get started.</p>
              ) : (
                <>
                  <ul className="cart-list">
                    {Object.entries(cart).map(([id, q]) => {
                      const p = products.find((x) => x.id === id)!;
                      return (
                        <li key={id} className="cart-item">
                          <div>
                            <div style={{ fontWeight: 600, color: "#0a0a0a" }}>{p.title}</div>
                            <div style={{ fontSize: 12, color: "#888" }}>{p.sub}</div>
                          </div>
                          <div className="qty">
                            <button onClick={() => remove(id)}>−</button>
                            <span>{q}</span>
                            <button onClick={() => add(id)}>+</button>
                          </div>
                          <div className="price" style={{ minWidth: 60, textAlign: "right" }}>€{p.price * q}</div>
                        </li>
                      );
                    })}
                  </ul>
                  <div className="cart-totals">
                    <div><span>Subtotal</span><span>€{total}</span></div>
                    <div><span>Shipping</span><span>{shipping === 0 ? "Free" : `€${shipping}`}</span></div>
                    <div className="cart-grand"><span>Total</span><span>€{total + shipping}</span></div>
                  </div>
                  <Link to="/contact" className="btn-primary" style={{ width: "100%", justifyContent: "center" }}>
                    Continue to checkout →
                  </Link>
                </>
              )}
            </aside>
          </div>

          <div className="section-block">
            <h2>Shipping & returns</h2>
            <div className="feature-grid">
              <div className="feature"><div className="num">01</div><h3>Worldwide shipping</h3><p>We ship from Amsterdam to over 60 countries. Tracked, insured, and packed flat.</p></div>
              <div className="feature"><div className="num">02</div><h3>Free over €80</h3><p>Orders over €80 ship free within the EU. €120 elsewhere.</p></div>
              <div className="feature"><div className="num">03</div><h3>30-day returns</h3><p>Defective records replaced free. Unopened sealed copies refundable within 30 days.</p></div>
              <div className="feature"><div className="num">04</div><h3>Direct from studio</h3><p>No middleman. Each record is pulled, sleeved and signed off by the studio team.</p></div>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
