import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/catalog")({
  head: () => ({
    meta: [
      { title: "Catalog — Megsy" },
      { name: "description", content: "Browse the full Megsy catalog: 24 curated pressings across ambient, post-rock, jazz, shoegaze, modern classical and dub techno." },
      { property: "og:title", content: "Catalog — Megsy" },
      { property: "og:description", content: "Curated frequencies and limited-press records." },
    ],
  }),
  component: CatalogPage,
});

const records = [
  { id: "MGS-001", title: "Reflections in Wax", artist: "Mira Solstice", year: 2024, format: "12\" 180g", genre: "Ambient", price: 32, stock: "In stock" },
  { id: "MGS-002", title: "Quiet Architecture", artist: "The Grain", year: 2024, format: "12\" 180g", genre: "Post-Rock", price: 34, stock: "In stock" },
  { id: "MGS-003", title: "Ash & Brass", artist: "Kasra", year: 2024, format: "2x12\" 180g", genre: "Jazz", price: 48, stock: "Limited" },
  { id: "MGS-004", title: "Hollow Light", artist: "Hollow Sun", year: 2024, format: "12\" Color", genre: "Shoegaze", price: 36, stock: "In stock" },
  { id: "MGS-005", title: "Northbound Static", artist: "Mira Solstice", year: 2023, format: "10\" EP", genre: "Ambient", price: 24, stock: "Sold out" },
  { id: "MGS-006", title: "Slow Decay", artist: "The Grain", year: 2023, format: "12\" 180g", genre: "Post-Rock", price: 32, stock: "In stock" },
  { id: "MGS-007", title: "Field Notes", artist: "Kasra", year: 2023, format: "12\" Limited", genre: "Jazz", price: 42, stock: "Limited" },
  { id: "MGS-008", title: "Inner Bloom", artist: "Hollow Sun", year: 2023, format: "12\" 180g", genre: "Shoegaze", price: 32, stock: "In stock" },
  { id: "MGS-009", title: "Tidal Drift", artist: "Mira Solstice", year: 2026, format: "12\" 180g", genre: "Ambient", price: 34, stock: "Pre-order" },
  { id: "MGS-010", title: "Concrete Grain", artist: "The Grain", year: 2026, format: "12\" 180g", genre: "Post-Rock", price: 34, stock: "Pre-order" },
  { id: "MGS-011", title: "Cycles in Glass", artist: "Aster Vale", year: 2025, format: "12\" 180g", genre: "Modern Classical", price: 30, stock: "In stock" },
  { id: "MGS-012", title: "Underwater Mass", artist: "Ortega Loop", year: 2025, format: "12\" Color", genre: "Dub Techno", price: 36, stock: "In stock" },
];

const genres = ["All", "Ambient", "Post-Rock", "Jazz", "Shoegaze", "Modern Classical", "Dub Techno"] as const;
const sorts = ["Newest", "Oldest", "Price ↑", "Price ↓"] as const;

function CatalogPage() {
  const [genre, setGenre] = useState<typeof genres[number]>("All");
  const [sort, setSort] = useState<typeof sorts[number]>("Newest");
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    let l = records.filter((r) =>
      (genre === "All" || r.genre === genre) &&
      (q === "" || (r.title + r.artist + r.id).toLowerCase().includes(q.toLowerCase()))
    );
    if (sort === "Newest") l = [...l].sort((a, b) => b.year - a.year);
    if (sort === "Oldest") l = [...l].sort((a, b) => a.year - b.year);
    if (sort === "Price ↑") l = [...l].sort((a, b) => a.price - b.price);
    if (sort === "Price ↓") l = [...l].sort((a, b) => b.price - a.price);
    return l;
  }, [genre, sort, q]);

  return (
    <PageShell>
      <div className="inner-page">
        <div className="inner-wrap">
          <div className="eyebrow">The Megsy Catalog</div>
          <h1 className="page-title">
            Pressed
            <span className="outline-word">Frequencies.</span>
          </h1>
          <p className="page-lede">
            Twelve releases. Six artists. One philosophy: press only the records we'd want to own ourselves.
            Everything below is mastered, sleeved and shipped from the studio in Amsterdam.
          </p>

          <div className="toolbar">
            <input
              className="toolbar-search"
              placeholder="Search by title, artist or ID…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <div className="chip-group">
              {genres.map((g) => (
                <button key={g} onClick={() => setGenre(g)} className={`chip ${genre === g ? "chip-on" : ""}`}>{g}</button>
              ))}
            </div>
            <select className="select-min" value={sort} onChange={(e) => setSort(e.target.value as typeof sorts[number])}>
              {sorts.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>

          <div className="result-count">{filtered.length} release{filtered.length === 1 ? "" : "s"}</div>

          <div className="grid-cards">
            {filtered.map((r, i) => (
              <article key={r.id} className="card">
                <div className={`card-cover tone-${(i % 5) + 1}`}></div>
                <div className="card-meta">{r.id} · {r.year} · {r.format}</div>
                <div className="card-title">{r.title}</div>
                <div className="card-sub">{r.artist} · {r.genre}</div>
                <div className="card-foot">
                  <span className="price">€{r.price}</span>
                  <span className={`stock-tag stock-${r.stock.replace(/\s|-/g, "").toLowerCase()}`}>{r.stock}</span>
                </div>
              </article>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="empty-state">No releases match those filters. Try a different genre or clear the search.</div>
          )}

          <div className="section-block">
            <h2>Looking for something specific?</h2>
            <p className="lede">
              We keep a small back-catalog at the studio. If a release shows as sold out, get in touch — we sometimes
              hold a few copies for label friends and serious collectors.
            </p>
            <Link to="/contact" className="btn-primary">Ask about a record →</Link>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
