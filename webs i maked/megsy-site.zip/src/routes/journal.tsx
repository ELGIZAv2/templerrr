import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/journal")({
  head: () => ({
    meta: [
      { title: "Journal — Megsy" },
      { name: "description", content: "Notes from the Megsy studio: mastering, pressings, artists and the slow craft of independent music." },
      { property: "og:title", content: "Journal — Megsy" },
      { property: "og:description", content: "Notes from the studio." },
    ],
  }),
  component: JournalPage,
});

const posts = [
  { id: 1, date: "07 May 2026", title: "Why we still cut at half speed", category: "Craft", read: "6 min", excerpt: "Half-speed cutting takes twice as long, costs twice as much, and produces a noticeably quieter pressing. Here's why we still do it for almost everything we release." },
  { id: 2, date: "22 Apr 2026", title: "A short history of the Megsy roster", category: "Studio", read: "8 min", excerpt: "From two artists in a converted warehouse to six across three continents — what changed, what didn't, and what we listen for next." },
  { id: 3, date: "11 Mar 2026", title: "Field notes from a remote masters session", category: "Craft", read: "5 min", excerpt: "Working across time zones with Aster Vale meant rethinking how we mark up a master. A short note on async listening." },
  { id: 4, date: "02 Feb 2026", title: "Sleeve as instrument", category: "Design", read: "7 min", excerpt: "Why the artwork is part of the master, not an accessory — and how we brief our designers." },
  { id: 5, date: "18 Jan 2026", title: "On running an independent label in 2026", category: "Studio", read: "10 min", excerpt: "What's working, what isn't, and the bets we're making for the next two years of Megsy." },
  { id: 6, date: "04 Dec 2025", title: "Inside Hollow Sun's Inner Bloom", category: "Artists", read: "6 min", excerpt: "How seven slow shoegaze tracks became one of our favorite records of the year — track-by-track with the band." },
  { id: 7, date: "20 Nov 2025", title: "The case against streaming-first records", category: "Craft", read: "8 min", excerpt: "We don't think every record needs to live on streaming. Here's how that shapes what we sign." },
  { id: 8, date: "01 Oct 2025", title: "Welcome, Ortega Loop", category: "Studio", read: "3 min", excerpt: "A short introduction to our newest artist, joining the roster from Mexico City with one record already in the pipeline." },
];

const categories = ["All", "Craft", "Studio", "Design", "Artists"] as const;

function JournalPage() {
  const [cat, setCat] = useState<typeof categories[number]>("All");
  const list = cat === "All" ? posts : posts.filter((p) => p.category === cat);

  return (
    <PageShell>
      <div className="inner-page">
        <div className="inner-wrap">
          <div className="eyebrow">The Megsy Journal</div>
          <h1 className="page-title">
            Notes from the
            <span className="outline-word">Studio.</span>
          </h1>
          <p className="page-lede">
            Slow writing about craft, mastering, the music we love and the records we're working on.
            Roughly one essay a month — never more than two.
          </p>

          <div className="toolbar">
            <div className="chip-group">
              {categories.map((c) => (
                <button key={c} onClick={() => setCat(c)} className={`chip ${cat === c ? "chip-on" : ""}`}>{c}</button>
              ))}
            </div>
          </div>

          <div className="journal-list">
            {list.map((p) => (
              <article key={p.id} className="journal-item">
                <span className="date">{p.date} · {p.read}</span>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "#999", marginBottom: 6 }}>
                    {p.category}
                  </div>
                  <h3>{p.title}</h3>
                  <p>{p.excerpt}</p>
                </div>
                <span className="arrow">→</span>
              </article>
            ))}
          </div>

          <div className="section-block">
            <h2>Get new essays in your inbox</h2>
            <p className="lede">One email when something new goes up. No marketing, no tracking, no pixels.</p>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", maxWidth: 480 }}>
              <input className="select-min" style={{ flex: 1, minWidth: 220 }} placeholder="you@studio.com" />
              <Link to="/contact" className="btn-primary">Subscribe →</Link>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
