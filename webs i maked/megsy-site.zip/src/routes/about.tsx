import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Megsy" },
      { name: "description", content: "Megsy is an independent music & creative studio based in Amsterdam. Six artists, in-house mastering, custom pressings." },
      { property: "og:title", content: "About — Megsy" },
      { property: "og:description", content: "About Megsy Studio." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <PageShell>
      <div className="inner-page">
        <div className="inner-wrap">
          <div className="eyebrow">About Megsy</div>
          <h1 className="page-title">
            Small studio,
            <span className="outline-word">Big rooms.</span>
          </h1>
          <p className="page-lede">
            Megsy is an independent music & creative studio. We sign a small roster, press records we believe in,
            and work slowly enough to still hear the details. Based in Amsterdam, shipping worldwide.
          </p>

          <div className="stat-strip">
            <div><div className="big">2024</div><div className="lbl">Founded</div></div>
            <div><div className="big">6</div><div className="lbl">Artists</div></div>
            <div><div className="big">12</div><div className="lbl">Releases</div></div>
            <div><div className="big">12K+</div><div className="lbl">Records pressed</div></div>
          </div>

          <div className="about-split">
            <div>
              <h2 style={{ fontFamily: "Syne, sans-serif", fontSize: "clamp(28px, 3.5vw, 44px)", fontWeight: 800, letterSpacing: "-0.02em", marginBottom: 18 }}>
                The story
              </h2>
              <p>
                We started Megsy in 2024 around a single idea: that recorded music still deserves an object
                worth holding. A sleeve you read. A pressing you can play in twenty years. A roster you trust.
              </p>
              <p>
                Today we're six artists, two engineers and one cutting lathe in a converted warehouse near
                the IJ. We master in-house, sleeve in-house, and ship from the studio. Nothing leaves the
                building until someone on the team has played it end to end.
              </p>
              <p>
                We're small on purpose. A small roster means we can fully back every release — physical
                production, design, distribution, press, and the long-term work of building an audience that
                stays.
              </p>
              <p>
                If you're an artist looking for a long-term home, or a label hunting for a manufacturing partner,
                we'd love to talk.
              </p>
              <div style={{ marginTop: 24, display: "flex", gap: 12, flexWrap: "wrap" }}>
                <Link to="/contact" className="btn-primary">Get in touch →</Link>
                <Link to="/artists" className="btn-secondary">Meet the roster</Link>
              </div>
            </div>

            <div className="timeline">
              <div className="tl-item">
                <span className="yr">2024</span>
                <div>
                  <h4>Founded</h4>
                  <p>Megsy opens with two artists, one engineer and a cutting lathe in a converted warehouse.</p>
                </div>
              </div>
              <div className="tl-item">
                <span className="yr">2024</span>
                <div>
                  <h4>First press</h4>
                  <p>"Reflections in Wax" by Mira Solstice — 500 copies, sold out in three weeks.</p>
                </div>
              </div>
              <div className="tl-item">
                <span className="yr">2025</span>
                <div>
                  <h4>Roster expands</h4>
                  <p>Hollow Sun, Kasra and Aster Vale join the studio family. Six releases pressed across the year.</p>
                </div>
              </div>
              <div className="tl-item">
                <span className="yr">2026</span>
                <div>
                  <h4>Custom pressings</h4>
                  <p>We open the studio to outside artists and labels for short runs and bespoke records.</p>
                </div>
              </div>
              <div className="tl-item">
                <span className="yr">2026</span>
                <div>
                  <h4>Ortega Loop joins</h4>
                  <p>Our first artist outside Europe brings dub techno to the Megsy roster from Mexico City.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="section-block">
            <h2>What we do</h2>
            <p className="lede">Four services, one studio, all under one roof.</p>
            <div className="feature-grid">
              <div className="feature"><div className="num">01</div><h3>A&R</h3><p>Long-term signings and project deals with independent artists. We don't sign one-record deals.</p></div>
              <div className="feature"><div className="num">02</div><h3>Mastering</h3><p>In-house mastering for vinyl, digital and tape. Half-speed cutting on most releases.</p></div>
              <div className="feature"><div className="num">03</div><h3>Custom Pressing</h3><p>Short-run vinyl pressings with full sleeve and label production. From 100 copies up.</p></div>
              <div className="feature"><div className="num">04</div><h3>Distribution</h3><p>Direct-to-fan shipping and curated indie record store distribution across Europe.</p></div>
            </div>
          </div>

          <div className="section-block">
            <h2>The team</h2>
            <p className="lede">Three people on payroll. Two cats on the studio floor.</p>
            <div className="grid-cards">
              <article className="card">
                <div className="card-cover tone-1"></div>
                <div className="card-meta">Founder · A&R</div>
                <div className="card-title">Megsy Lange</div>
                <div className="card-sub">Started the studio in 2024 after ten years running a record store. Signs every artist personally.</div>
              </article>
              <article className="card">
                <div className="card-cover tone-2"></div>
                <div className="card-meta">Mastering Engineer</div>
                <div className="card-title">Janneke de Vries</div>
                <div className="card-sub">Cuts every Megsy release. Background in classical mastering, brought to vinyl in 2022.</div>
              </article>
              <article className="card">
                <div className="card-cover tone-3"></div>
                <div className="card-meta">Studio & Production</div>
                <div className="card-title">Théo Marchand</div>
                <div className="card-sub">Runs the day-to-day: pressings, sleeves, shipping, the website you're reading.</div>
              </article>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
