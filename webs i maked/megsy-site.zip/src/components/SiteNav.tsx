import { Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";

const links = [
  { to: "/", label: "Home" },
  { to: "/catalog", label: "Catalog" },
  { to: "/releases", label: "Releases" },
  { to: "/artists", label: "Artists" },
  { to: "/shop", label: "Shop" },
  { to: "/journal", label: "Journal" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteNav() {
  const [open, setOpen] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const unsub = router.subscribe("onResolved", () => setOpen(false));
    return unsub;
  }, [router]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  return (
    <>
      <nav className="nav" aria-label="Main navigation" style={{ opacity: 1, animation: "none" }}>
        <Link to="/" className="nav-logo" style={{ textDecoration: "none" }}>
          MEGSY<span>studio</span>
        </Link>
        <button
          className={`hamburger ${open ? "open" : ""}`}
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span className="hamburger-line"></span>
          <span className="hamburger-line"></span>
          <span className="hamburger-line"></span>
        </button>
        <ul className={`nav-links ${open ? "open" : ""}`}>
          {links.map((l) => (
            <li key={l.to}>
              <Link to={l.to} activeOptions={{ exact: l.to === "/" }} activeProps={{ style: { color: "#0a0a0a" } }}>
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      <div
        className={`mobile-menu-overlay ${open ? "active" : ""}`}
        onClick={() => setOpen(false)}
      ></div>
    </>
  );
}
