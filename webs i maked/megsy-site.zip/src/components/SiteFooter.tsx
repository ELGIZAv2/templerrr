import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <div className="footer-top">
          <div className="footer-brand">
            <div className="footer-logo">
              MEGSY<span>studio</span>
            </div>
            <p className="footer-desc">
              An independent music & creative studio. We craft sound that mirrors your world — every track captures the frequency of now.
            </p>
          </div>
          <div className="footer-cols">
            <div className="footer-col">
              <div className="footer-col-title">Studio</div>
              <Link to="/">Home</Link>
              <Link to="/about">About</Link>
              <Link to="/artists">Artists</Link>
              <Link to="/journal">Journal</Link>
            </div>
            <div className="footer-col">
              <div className="footer-col-title">Music</div>
              <Link to="/catalog">Catalog</Link>
              <Link to="/releases">Releases</Link>
              <Link to="/shop">Shop</Link>
              <Link to="/contact">Custom Press</Link>
            </div>
            <div className="footer-col">
              <div className="footer-col-title">Connect</div>
              <a href="#" target="_blank" rel="noopener noreferrer">Instagram</a>
              <a href="#" target="_blank" rel="noopener noreferrer">Twitter / X</a>
              <a href="#" target="_blank" rel="noopener noreferrer">Bandcamp</a>
              <a href="#" target="_blank" rel="noopener noreferrer">SoundCloud</a>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Megsy Studio. All rights reserved.</span>
          <span className="footer-credits">Sound, Reflected.</span>
        </div>
      </div>
    </footer>
  );
}
