import { Link } from "@tanstack/react-router";

const navItems = [
  { to: "/", label: "Globe" },
  { to: "/cities", label: "Cities" },
  { to: "/favorites", label: "Favorites" },
  { to: "/compare", label: "Compare" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
  { to: "/settings", label: "Settings" },
] as const;

export function Navbar({ transparent = false }: { transparent?: boolean }) {
  return (
    <header
      className="fixed top-4 left-1/2 -translate-x-1/2 z-[1100] w-[min(960px,calc(100vw-24px))]"
      style={{
        fontFamily:
          "-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Inter', system-ui, sans-serif",
      }}
    >
      <div
        className="flex items-center justify-between gap-4 px-3 py-2 rounded-2xl border border-white/10 text-white"
        style={{
          background: transparent ? "rgba(10,10,16,0.45)" : "rgba(10,10,16,0.65)",
          backdropFilter: "saturate(180%) blur(24px)",
          WebkitBackdropFilter: "saturate(180%) blur(24px)",
          boxShadow:
            "0 1px 0 rgba(255,255,255,0.08) inset, 0 10px 30px -10px rgba(0,0,0,0.6)",
        }}
      >
        <Link to="/" className="flex items-center gap-2 pl-2">
          <span
            className="inline-block h-2 w-2 rounded-full"
            style={{
              background:
                "radial-gradient(circle at 30% 30%, #67e8f9, #0891b2 60%, #0e1230)",
              boxShadow: "0 0 12px rgba(34,211,238,0.6)",
            }}
          />
          <span className="text-sm font-semibold tracking-[0.28em]">MEGSY</span>
        </Link>
        <nav className="flex items-center gap-0.5 text-[12px]">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="px-3 py-1.5 rounded-xl text-white/65 hover:text-white hover:bg-white/10 transition"
              activeProps={{
                className:
                  "px-3 py-1.5 rounded-xl bg-white/15 text-white shadow-[0_1px_0_rgba(255,255,255,0.12)_inset]",
              }}
              activeOptions={{ exact: item.to === "/" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
