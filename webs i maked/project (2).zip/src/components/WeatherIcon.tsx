import {
  Sun,
  CloudSun,
  Cloud,
  Cloudy,
  CloudFog,
  CloudDrizzle,
  CloudRain,
  CloudHail,
  CloudSnow,
  Snowflake,
  CloudLightning,
  HelpCircle,
  type LucideIcon,
} from "lucide-react";

const map: Record<number, { icon: LucideIcon; label: string; color: string }> = {
  0: { icon: Sun, label: "Clear", color: "#ffd166" },
  1: { icon: CloudSun, label: "Mainly clear", color: "#ffd9a0" },
  2: { icon: CloudSun, label: "Partly cloudy", color: "#cdd6e0" },
  3: { icon: Cloudy, label: "Overcast", color: "#9aa4b2" },
  45: { icon: CloudFog, label: "Fog", color: "#a7b3c2" },
  48: { icon: CloudFog, label: "Rime fog", color: "#a7b3c2" },
  51: { icon: CloudDrizzle, label: "Light drizzle", color: "#7ec8ff" },
  53: { icon: CloudDrizzle, label: "Drizzle", color: "#7ec8ff" },
  55: { icon: CloudDrizzle, label: "Heavy drizzle", color: "#5fb3ff" },
  61: { icon: CloudRain, label: "Light rain", color: "#5fb3ff" },
  63: { icon: CloudRain, label: "Rain", color: "#3da0ff" },
  65: { icon: CloudHail, label: "Heavy rain", color: "#1e88ff" },
  71: { icon: CloudSnow, label: "Light snow", color: "#dceeff" },
  73: { icon: CloudSnow, label: "Snow", color: "#cfe6ff" },
  75: { icon: Snowflake, label: "Heavy snow", color: "#bcdcff" },
  77: { icon: CloudSnow, label: "Snow grains", color: "#cfe6ff" },
  80: { icon: CloudRain, label: "Showers", color: "#5fb3ff" },
  81: { icon: CloudRain, label: "Heavy showers", color: "#3da0ff" },
  82: { icon: CloudHail, label: "Violent showers", color: "#1e88ff" },
  85: { icon: CloudSnow, label: "Snow showers", color: "#cfe6ff" },
  86: { icon: Snowflake, label: "Heavy snow showers", color: "#bcdcff" },
  95: { icon: CloudLightning, label: "Thunderstorm", color: "#c4b5fd" },
  96: { icon: CloudLightning, label: "Thunderstorm + hail", color: "#a78bfa" },
  99: { icon: CloudLightning, label: "Severe thunderstorm", color: "#8b5cf6" },
};

export function getWeather(code: number | null | undefined) {
  if (code == null) return { icon: HelpCircle, label: "Unknown", color: "#9aa4b2" };
  return map[code] ?? { icon: HelpCircle, label: "Unknown", color: "#9aa4b2" };
}

export function WeatherIcon({
  code,
  className = "h-6 w-6",
  strokeWidth = 1.5,
}: {
  code: number | null | undefined;
  className?: string;
  strokeWidth?: number;
}) {
  const { icon: Icon, color } = getWeather(code);
  return <Icon className={className} style={{ color }} strokeWidth={strokeWidth} />;
}
