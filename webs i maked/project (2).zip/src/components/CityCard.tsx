import { Link } from "@tanstack/react-router";
import { Star, GitCompare } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { type City, citySlug } from "@/lib/cities";
import { fetchCurrent, tempColor, convertTemp } from "@/lib/weather";
import { favorites, compare, unit, useStorageValue } from "@/lib/preferences";
import { WeatherIcon, getWeather } from "./WeatherIcon";

export function CityCard({ city }: { city: City }) {
  const slug = citySlug(city);
  const u = useStorageValue(() => unit.get());
  const isFav = useStorageValue(() => favorites.has(slug));
  const inCompare = useStorageValue(() => compare.has(slug));

  const { data, isLoading } = useQuery({
    queryKey: ["weather", "current", city.lat, city.lon],
    queryFn: () => fetchCurrent(city.lat, city.lon),
    staleTime: 10 * 60 * 1000,
  });

  const w = getWeather(data?.weatherCode);
  const color = tempColor(data?.temp ?? null);

  return (
    <div
      className="group relative rounded-3xl border border-white/10 p-5 transition hover:-translate-y-0.5 hover:border-white/20"
      style={{
        background:
          "linear-gradient(180deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 100%)",
        backdropFilter: "blur(24px) saturate(160%)",
        WebkitBackdropFilter: "blur(24px) saturate(160%)",
        boxShadow:
          "0 1px 0 rgba(255,255,255,0.08) inset, 0 20px 40px -24px rgba(0,0,0,0.7)",
      }}
    >
      <Link to="/city/$slug" params={{ slug }} className="block">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="font-semibold text-[15px] tracking-tight">{city.name}</div>
            <div className="text-[11px] text-white/40 mt-0.5">{city.country}</div>
          </div>
          {city.isUS && (
            <span className="text-[9px] px-2 py-0.5 rounded-full bg-orange-400/15 text-orange-300 border border-orange-300/20">
              US
            </span>
          )}
        </div>
        <div className="flex items-end justify-between">
          <div>
            <div className="text-[34px] font-semibold tracking-tight leading-none" style={{ color }}>
              {isLoading ? "—" : convertTemp(data?.temp ?? null, u)}
            </div>
            <div className="text-[11px] text-white/45 mt-2">{w.label}</div>
          </div>
          <WeatherIcon code={data?.weatherCode} className="h-10 w-10" strokeWidth={1.4} />
        </div>
      </Link>
      <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition">
        <button
          aria-label="Toggle favorite"
          onClick={(e) => {
            e.preventDefault();
            favorites.toggle(slug);
          }}
          className="p-1.5 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur"
        >
          <Star
            className={"h-3.5 w-3.5 " + (isFav ? "fill-yellow-300 text-yellow-300" : "text-white/70")}
          />
        </button>
        <button
          aria-label="Toggle compare"
          onClick={(e) => {
            e.preventDefault();
            compare.toggle(slug);
          }}
          className="p-1.5 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur"
        >
          <GitCompare
            className={"h-3.5 w-3.5 " + (inCompare ? "text-cyan-300" : "text-white/70")}
          />
        </button>
      </div>
    </div>
  );
}
