import type { ReactNode } from "react";
import { Reveal } from "./Reveal";

export function PageShell({
  title,
  subtitle,
  eyebrow,
  children,
  hero,
}: {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  hero?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div
      className="relative min-h-screen text-white pt-28 pb-24 px-6 overflow-x-hidden"
      style={{
        fontFamily:
          "-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Inter', system-ui, sans-serif",
        background:
          "radial-gradient(1200px 600px at 10% -10%, rgba(56,189,248,0.18), transparent 60%), radial-gradient(900px 500px at 100% 10%, rgba(168,85,247,0.18), transparent 60%), #050508",
      }}
    >
      {/* Subtle grain */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 opacity-[0.04] mix-blend-overlay"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)' opacity='0.6'/></svg>\")",
        }}
      />

      <div className="relative max-w-6xl mx-auto">
        <Reveal>
          <header className="mb-12">
            {eyebrow && (
              <div className="text-[11px] uppercase tracking-[0.3em] text-cyan-300/80 mb-3">
                {eyebrow}
              </div>
            )}
            <h1 className="text-4xl md:text-6xl font-semibold tracking-tight bg-gradient-to-b from-white to-white/60 bg-clip-text text-transparent">
              {title}
            </h1>
            {subtitle && (
              <p className="mt-4 text-base md:text-lg text-white/55 max-w-2xl">{subtitle}</p>
            )}
            {hero}
          </header>
        </Reveal>
        {children}
      </div>
    </div>
  );
}
