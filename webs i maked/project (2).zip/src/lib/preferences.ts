const FAV_KEY = "megsy:favorites";
const UNIT_KEY = "megsy:unit";
const COMPARE_KEY = "megsy:compare";

function read(key: string): string[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(key) ?? "[]");
  } catch {
    return [];
  }
}
function write(key: string, val: string[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(val));
  window.dispatchEvent(new CustomEvent("megsy:storage", { detail: key }));
}

export const favorites = {
  get: () => read(FAV_KEY),
  has: (slug: string) => read(FAV_KEY).includes(slug),
  toggle: (slug: string) => {
    const cur = read(FAV_KEY);
    write(FAV_KEY, cur.includes(slug) ? cur.filter((s) => s !== slug) : [...cur, slug]);
  },
  clear: () => write(FAV_KEY, []),
};

export const compare = {
  get: () => read(COMPARE_KEY),
  has: (slug: string) => read(COMPARE_KEY).includes(slug),
  toggle: (slug: string) => {
    const cur = read(COMPARE_KEY);
    if (cur.includes(slug)) {
      write(COMPARE_KEY, cur.filter((s) => s !== slug));
    } else if (cur.length < 4) {
      write(COMPARE_KEY, [...cur, slug]);
    }
  },
  clear: () => write(COMPARE_KEY, []),
};

export type Unit = "C" | "F";
export const unit = {
  get: (): Unit => {
    if (typeof window === "undefined") return "C";
    return (localStorage.getItem(UNIT_KEY) as Unit) ?? "C";
  },
  set: (u: Unit) => {
    if (typeof window === "undefined") return;
    localStorage.setItem(UNIT_KEY, u);
    window.dispatchEvent(new CustomEvent("megsy:storage", { detail: UNIT_KEY }));
  },
};

import { useSyncExternalStore } from "react";

export function useStorageValue<T>(getter: () => T): T {
  return useSyncExternalStore(
    (notify) => {
      const handler = () => notify();
      window.addEventListener("megsy:storage", handler);
      window.addEventListener("storage", handler);
      return () => {
        window.removeEventListener("megsy:storage", handler);
        window.removeEventListener("storage", handler);
      };
    },
    getter,
    getter,
  );
}
