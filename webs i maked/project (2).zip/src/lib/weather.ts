export type CurrentWeather = {
  temp: number | null;
  humidity: number | null;
  windSpeed: number | null;
  weatherCode: number | null;
};

export type DailyForecast = {
  date: string;
  tMax: number;
  tMin: number;
  code: number;
  precipitation: number;
  windMax: number;
};

export type FullWeather = {
  current: CurrentWeather;
  daily: DailyForecast[];
  hourly: { time: string; temp: number; code: number }[];
  updatedAt: string;
};

export async function fetchCurrent(lat: number, lon: number): Promise<CurrentWeather> {
  const res = await fetch(
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&timezone=auto`,
  );
  if (!res.ok) throw new Error("Weather fetch failed");
  const data = await res.json();
  return {
    temp: data.current?.temperature_2m ?? null,
    humidity: data.current?.relative_humidity_2m ?? null,
    windSpeed: data.current?.wind_speed_10m ?? null,
    weatherCode: data.current?.weather_code ?? null,
  };
}

export async function fetchFull(lat: number, lon: number): Promise<FullWeather> {
  const res = await fetch(
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
      `&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code` +
      `&hourly=temperature_2m,weather_code` +
      `&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_sum,wind_speed_10m_max` +
      `&forecast_days=7&timezone=auto`,
  );
  if (!res.ok) throw new Error("Weather fetch failed");
  const d = await res.json();
  const daily: DailyForecast[] = (d.daily?.time ?? []).map((t: string, i: number) => ({
    date: t,
    tMax: d.daily.temperature_2m_max[i],
    tMin: d.daily.temperature_2m_min[i],
    code: d.daily.weather_code[i],
    precipitation: d.daily.precipitation_sum[i],
    windMax: d.daily.wind_speed_10m_max[i],
  }));
  const hourly = (d.hourly?.time ?? []).slice(0, 24).map((t: string, i: number) => ({
    time: t,
    temp: d.hourly.temperature_2m[i],
    code: d.hourly.weather_code[i],
  }));
  return {
    current: {
      temp: d.current?.temperature_2m ?? null,
      humidity: d.current?.relative_humidity_2m ?? null,
      windSpeed: d.current?.wind_speed_10m ?? null,
      weatherCode: d.current?.weather_code ?? null,
    },
    daily,
    hourly,
    updatedAt: new Date().toISOString(),
  };
}

export function weatherDescription(code: number | null): { text: string; icon: string } {
  const labels: Record<number, string> = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Rime fog", 51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle",
    61: "Light rain", 63: "Rain", 65: "Heavy rain",
    71: "Light snow", 73: "Snow", 75: "Heavy snow", 77: "Snow grains",
    80: "Rain showers", 81: "Heavy showers", 82: "Violent showers",
    85: "Snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Thunderstorm + hail", 99: "Severe thunderstorm",
  };
  if (code == null) return { text: "Unknown", icon: "" };
  return { text: labels[code] ?? "Unknown", icon: "" };
}

export function tempColor(temp: number | null): string {
  if (temp === null) return "#666";
  if (temp <= -10) return "#0066ff";
  if (temp <= 0) return "#00aaff";
  if (temp <= 10) return "#00ddff";
  if (temp <= 15) return "#00ffaa";
  if (temp <= 20) return "#88ff00";
  if (temp <= 25) return "#ffee00";
  if (temp <= 30) return "#ff8800";
  if (temp <= 35) return "#ff4400";
  return "#ff0000";
}

export function convertTemp(c: number | null, unit: "C" | "F"): string {
  if (c === null) return "—";
  return unit === "F" ? `${Math.round((c * 9) / 5 + 32)}°F` : `${Math.round(c)}°C`;
}
