import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { Navbar } from "@/components/Navbar";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Megsy — 3D Globe Weather" },
      { name: "description", content: "Live global weather on an interactive 3D Earth, by Megsy." },
      { property: "og:title", content: "Megsy — 3D Globe Weather" },
      { property: "og:description", content: "Live global weather on an interactive 3D Earth, by Megsy." },
    ],
  }),
  component: Index,
});

function loadScript(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[data-megsy-src="${src}"]`)) return resolve();
    const s = document.createElement("script");
    s.src = src;
    s.dataset.megsySrc = src;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.body.appendChild(s);
  });
}

function Index() {
  useEffect(() => {
    const prevBg = document.body.style.background;
    const prevOverflow = document.body.style.overflow;
    document.body.style.background = "#050508";
    document.body.style.overflow = "hidden";

    let cancelled = false;
    (async () => {
      await loadScript("https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js");
      await loadScript(
        "https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js",
      );
      if (cancelled) return;
      const s = document.createElement("script");
      s.src = "/megsy-globe.js?v=" + Date.now();
      s.dataset.megsyGlobe = "1";
      document.body.appendChild(s);
    })();
    return () => {
      cancelled = true;
      try {
        (window as unknown as { __megsyCleanup?: () => void }).__megsyCleanup?.();
      } catch {
        // ignore
      }
      document.querySelectorAll("script[data-megsy-globe]").forEach((el) => el.remove());
      document.body.style.background = prevBg;
      document.body.style.overflow = prevOverflow;
    };
  }, []);

  return (
    <>
      <style>{`
        body.megsy-globe-active canvas { position: fixed !important; inset: 0; z-index: 0; pointer-events: auto; }
        body.megsy-globe-active > div:first-of-type { position: relative; z-index: 1200; pointer-events: none; }
        body.megsy-globe-active > div:first-of-type header { pointer-events: auto; }
      `}</style>
      <BodyClassToggle />
      <Navbar transparent />
    </>
  );
}

function BodyClassToggle() {
  useEffect(() => {
    document.body.classList.add("megsy-globe-active");
    return () => document.body.classList.remove("megsy-globe-active");
  }, []);
  return null;
}
