import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { PageShell } from "@/components/PageShell";
import { Reveal } from "@/components/Reveal";
import { unit, useStorageValue, favorites, compare } from "@/lib/preferences";

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings — Megsy" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const u = useStorageValue(() => unit.get());
  const favs = useStorageValue(() => favorites.get());
  const cmp = useStorageValue(() => compare.get());

  return (
    <>
      <Navbar />
      <PageShell
        eyebrow="Preferences"
        title="Settings."
        subtitle="Everything is stored locally on your device. Nothing leaves your browser."
      >
        <div className="grid gap-4 max-w-2xl">
          <Reveal>
            <Card title="Temperature unit" hint="Used across all city pages and the globe.">
              <div className="flex gap-1 p-1 rounded-2xl bg-black/40 border border-white/10">
                {(["C", "F"] as const).map((v) => (
                  <button
                    key={v}
                    onClick={() => unit.set(v)}
                    className={
                      "px-5 py-2 rounded-xl text-sm font-medium transition " +
                      (u === v ? "bg-white text-black" : "text-white/60 hover:text-white")
                    }
                  >
                    {v === "C" ? "Celsius" : "Fahrenheit"}
                  </button>
                ))}
              </div>
            </Card>
          </Reveal>

          <Reveal delay={0.05}>
            <Card title="Saved data" hint="Cleared instantly. This cannot be undone.">
              <div className="flex flex-wrap gap-2">
                <Pill label={`${favs.length} favorites`} onClick={() => favorites.clear()} action="Clear" />
                <Pill label={`${cmp.length} in compare`} onClick={() => compare.clear()} action="Clear" />
              </div>
            </Card>
          </Reveal>

          <Reveal delay={0.1}>
            <Card title="About" hint="">
              <div className="text-sm text-white/60 leading-relaxed">
                Megsy v1.0 — built with TanStack Start, Three.js, and the
                Open-Meteo API.
              </div>
            </Card>
          </Reveal>
        </div>
      </PageShell>
    </>
  );
}

function Card({
  title,
  hint,
  children,
}: {
  title: string;
  hint: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className="rounded-3xl border border-white/10 p-6"
      style={{
        background: "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
        backdropFilter: "blur(20px) saturate(160%)",
      }}
    >
      <div className="flex items-start justify-between gap-6 flex-wrap">
        <div>
          <div className="font-semibold tracking-tight">{title}</div>
          {hint && <div className="text-xs text-white/45 mt-1">{hint}</div>}
        </div>
        <div>{children}</div>
      </div>
    </div>
  );
}

function Pill({ label, action, onClick }: { label: string; action: string; onClick: () => void }) {
  return (
    <div className="flex items-center gap-2 pl-4 pr-1 py-1 rounded-full border border-white/10 bg-black/30 text-xs">
      <span className="text-white/70">{label}</span>
      <button
        onClick={onClick}
        className="px-3 py-1 rounded-full bg-white/10 hover:bg-white/15 text-white/80"
      >
        {action}
      </button>
    </div>
  );
}
