import { createFileRoute, Link } from "@tanstack/react-router";
import { useQueries } from "@tanstack/react-query";
import { X, GitCompare } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { PageShell } from "@/components/PageShell";
import { Stagger, StaggerItem, Reveal } from "@/components/Reveal";
import { WeatherIcon, getWeather } from "@/components/WeatherIcon";
import { findCityBySlug, citySlug } from "@/lib/cities";
import { compare, unit, useStorageValue } from "@/lib/preferences";
import { fetchCurrent, tempColor, convertTemp } from "@/lib/weather";

export const Route = createFileRoute("/compare")({
  head: () => ({ meta: [{ title: "Compare Cities — Megsy" }] }),
  component: ComparePage,
});

function ComparePage() {
  const slugs = useStorageValue(() => compare.get());
  const u = useStorageValue(() => unit.get());
  const cities = slugs.map(findCityBySlug).filter((c): c is NonNullable<typeof c> => !!c);

  const queries = useQueries({
    queries: cities.map((c) => ({
      queryKey: ["weather", "current", c.lat, c.lon],
      queryFn: () => fetchCurrent(c.lat, c.lon),
      staleTime: 10 * 60 * 1000,
    })),
  });

  return (
    <>
      <Navbar />
      <PageShell
        eyebrow="Side by side"
        title="Compare."
        subtitle={`${cities.length} of 4 cities. Add from any city page or the cities list.`}
      >
        {cities.length === 0 ? (
          <Reveal>
            <div
              className="rounded-3xl border border-white/10 p-12 text-center max-w-xl mx-auto"
              style={{
                background: "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
                backdropFilter: "blur(20px) saturate(160%)",
              }}
            >
              <GitCompare className="h-8 w-8 text-cyan-300 mx-auto mb-4" strokeWidth={1.4} />
              <p className="text-white/70 mb-6">Pick up to four cities to compare.</p>
              <Link
                to="/cities"
                className="inline-flex items-center px-5 py-2.5 rounded-full bg-white text-black text-sm font-medium hover:bg-white/90 transition"
              >
                Browse cities
              </Link>
            </div>
          </Reveal>
        ) : (
          <>
            <div className="flex justify-end mb-4">
              <button
                onClick={() => compare.clear()}
                className="text-xs text-white/55 hover:text-white px-3 py-1.5 rounded-full border border-white/10 hover:border-white/20 transition"
              >
                Clear all
              </button>
            </div>
            <Stagger
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
              gap={0.06}
            >
              {cities.map((c, i) => {
                const q = queries[i];
                const w = getWeather(q.data?.weatherCode);
                return (
                  <StaggerItem key={c.name + c.country}>
                    <div
                      className="relative rounded-3xl border border-white/10 p-6 h-full"
                      style={{
                        background:
                          "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
                        backdropFilter: "blur(20px) saturate(160%)",
                      }}
                    >
                      <button
                        onClick={() => compare.toggle(citySlug(c))}
                        className="absolute top-3 right-3 p-1.5 rounded-full hover:bg-white/10 transition"
                        aria-label="Remove"
                      >
                        <X className="h-3.5 w-3.5 text-white/50" />
                      </button>
                      <div className="font-semibold tracking-tight">{c.name}</div>
                      <div className="text-[11px] text-white/40 mb-5">{c.country}</div>
                      <WeatherIcon
                        code={q.data?.weatherCode}
                        className="h-12 w-12 mb-3"
                        strokeWidth={1.3}
                      />
                      <div
                        className="text-4xl font-semibold tracking-tight"
                        style={{ color: tempColor(q.data?.temp ?? null) }}
                      >
                        {q.isLoading ? "—" : convertTemp(q.data?.temp ?? null, u)}
                      </div>
                      <div className="text-xs text-white/55 mb-5">{w.label}</div>
                      <div className="space-y-1.5 text-xs text-white/60 pt-4 border-t border-white/10">
                        <Row label="Humidity" value={q.data?.humidity != null ? `${q.data.humidity}%` : "—"} />
                        <Row
                          label="Wind"
                          value={
                            q.data?.windSpeed != null ? `${Math.round(q.data.windSpeed)} km/h` : "—"
                          }
                        />
                      </div>
                    </div>
                  </StaggerItem>
                );
              })}
            </Stagger>
          </>
        )}
      </PageShell>
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-white/45">{label}</span>
      <span className="text-white/85">{value}</span>
    </div>
  );
}
