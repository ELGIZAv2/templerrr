import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { PageShell } from "@/components/PageShell";
import { Reveal, Stagger, StaggerItem } from "@/components/Reveal";
import { Globe2, Zap, Layers, Heart, ShieldCheck, Sparkles } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Megsy" },
      { name: "description", content: "Megsy is a real-time 3D weather globe and city explorer." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const features = [
    { icon: Globe2, title: "Interactive 3D Earth", text: "Drag, zoom and orbit a cinematic globe with live temperature markers." },
    { icon: Zap, title: "Real-time data", text: "Powered by Open-Meteo. Refreshed every few minutes, cached at the edge." },
    { icon: Layers, title: "Detailed forecasts", text: "Hourly temperature charts and a clean seven-day outlook for any city." },
    { icon: Heart, title: "Favorites & Compare", text: "Save cities you care about and view them side by side in one glance." },
    { icon: ShieldCheck, title: "Private by design", text: "No accounts, no tracking. Preferences stay on your device." },
    { icon: Sparkles, title: "Built with care", text: "TanStack Start, Three.js and a dash of motion to make it feel alive." },
  ];
  return (
    <>
      <Navbar />
      <PageShell
        eyebrow="About"
        title="A living atlas of weather."
        subtitle="Megsy turns global conditions into something you can feel — quiet motion, generous space, and crystal-clear typography."
      >
        <Reveal delay={0.1}>
          <div
            className="rounded-3xl border border-white/10 p-8 md:p-12 mb-12"
            style={{
              background:
                "linear-gradient(180deg, rgba(34,211,238,0.08), rgba(168,85,247,0.06))",
              backdropFilter: "blur(20px) saturate(160%)",
            }}
          >
            <p className="text-lg md:text-xl text-white/80 leading-relaxed max-w-3xl">
              We built Megsy to make weather feel like a place, not a number. A
              dark, cinematic globe sprinkled with hundreds of live readings — and
              underneath it, a focused dashboard for every city you care about.
            </p>
          </div>
        </Reveal>

        <Stagger className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f) => (
            <StaggerItem key={f.title}>
              <div
                className="h-full rounded-3xl border border-white/10 p-6 transition hover:-translate-y-0.5 hover:border-white/20"
                style={{
                  background:
                    "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
                  backdropFilter: "blur(20px) saturate(160%)",
                }}
              >
                <div
                  className="inline-flex h-10 w-10 items-center justify-center rounded-2xl mb-4"
                  style={{
                    background: "rgba(34,211,238,0.12)",
                    border: "1px solid rgba(34,211,238,0.25)",
                  }}
                >
                  <f.icon className="h-5 w-5 text-cyan-300" strokeWidth={1.6} />
                </div>
                <div className="font-semibold tracking-tight mb-1.5">{f.title}</div>
                <div className="text-sm text-white/60 leading-relaxed">{f.text}</div>
              </div>
            </StaggerItem>
          ))}
        </Stagger>
      </PageShell>
    </>
  );
}
