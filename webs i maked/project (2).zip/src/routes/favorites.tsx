import { createFileRoute, Link } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { PageShell } from "@/components/PageShell";
import { CityCard } from "@/components/CityCard";
import { Stagger, StaggerItem, Reveal } from "@/components/Reveal";
import { findCityBySlug } from "@/lib/cities";
import { favorites, useStorageValue } from "@/lib/preferences";
import { Star } from "lucide-react";

export const Route = createFileRoute("/favorites")({
  head: () => ({ meta: [{ title: "Favorites — Megsy" }] }),
  component: FavoritesPage,
});

function FavoritesPage() {
  const favs = useStorageValue(() => favorites.get());
  const cities = favs.map(findCityBySlug).filter((c): c is NonNullable<typeof c> => !!c);

  return (
    <>
      <Navbar />
      <PageShell
        eyebrow="Saved"
        title="Favorites."
        subtitle={
          cities.length === 0
            ? "Star any city and it will show up here."
            : `${cities.length} ${cities.length === 1 ? "city" : "cities"} you keep an eye on.`
        }
      >
        {cities.length === 0 ? (
          <Reveal>
            <div
              className="rounded-3xl border border-white/10 p-12 text-center max-w-xl mx-auto"
              style={{
                background: "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
                backdropFilter: "blur(20px) saturate(160%)",
              }}
            >
              <Star className="h-8 w-8 text-yellow-300/80 mx-auto mb-4" strokeWidth={1.4} />
              <p className="text-white/70 mb-6">No favorites yet.</p>
              <Link
                to="/cities"
                className="inline-flex items-center px-5 py-2.5 rounded-full bg-white text-black text-sm font-medium hover:bg-white/90 transition"
              >
                Browse cities
              </Link>
            </div>
          </Reveal>
        ) : (
          <Stagger
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3"
            gap={0.04}
          >
            {cities.map((c) => (
              <StaggerItem key={c.name + c.country}>
                <CityCard city={c} />
              </StaggerItem>
            ))}
          </Stagger>
        )}
      </PageShell>
    </>
  );
}
