import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { PageShell } from "@/components/PageShell";
import { CityCard } from "@/components/CityCard";
import { Stagger, StaggerItem } from "@/components/Reveal";
import { allCities } from "@/lib/cities";

export const Route = createFileRoute("/cities")({
  head: () => ({
    meta: [
      { title: "All Cities — Megsy" },
      { name: "description", content: "Browse live weather across world capitals and US cities." },
    ],
  }),
  component: CitiesPage,
});

function CitiesPage() {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"all" | "world" | "us">("all");
  const [visible, setVisible] = useState(48);
  const list = useMemo(() => {
    return allCities.filter((c) => {
      if (filter === "world" && c.isUS) return false;
      if (filter === "us" && !c.isUS) return false;
      if (!q) return true;
      const s = q.toLowerCase();
      return c.name.toLowerCase().includes(s) || c.country.toLowerCase().includes(s);
    });
  }, [q, filter]);

  useEffect(() => setVisible(48), [q, filter]);

  return (
    <>
      <Navbar />
      <PageShell
        eyebrow="Explore"
        title="Cities"
        subtitle={`Live conditions across ${allCities.length} locations. Refined for clarity.`}
      >
        <div
          className="flex flex-col md:flex-row gap-3 mb-8 p-2 rounded-2xl border border-white/10"
          style={{
            background: "rgba(255,255,255,0.04)",
            backdropFilter: "blur(20px) saturate(160%)",
          }}
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search city or country"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/30 border border-white/10 text-sm placeholder:text-white/30 focus:outline-none focus:border-cyan-300/50"
            />
          </div>
          <div className="flex gap-1 p-1 rounded-xl bg-black/30 border border-white/10">
            {(["all", "world", "us"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={
                  "px-4 py-1.5 rounded-lg text-xs font-medium transition " +
                  (filter === f ? "bg-white/15 text-white" : "text-white/55 hover:text-white")
                }
              >
                {f === "all" ? "All" : f === "world" ? "World" : "US"}
              </button>
            ))}
          </div>
        </div>

        <div className="text-xs text-white/40 mb-4">
          {list.length.toLocaleString()} matching {list.length === 1 ? "city" : "cities"}
        </div>

        <Stagger
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3"
          gap={0.03}
        >
          {list.slice(0, visible).map((c) => (
            <StaggerItem key={c.name + c.country}>
              <CityCard city={c} />
            </StaggerItem>
          ))}
        </Stagger>

        {visible < list.length && (
          <div className="flex justify-center mt-10">
            <button
              onClick={() => setVisible((v) => v + 48)}
              className="px-6 py-3 rounded-full bg-white/10 hover:bg-white/15 border border-white/15 text-sm font-medium transition backdrop-blur"
            >
              Load {Math.min(48, list.length - visible)} more
            </button>
          </div>
        )}
      </PageShell>
    </>
  );
}
