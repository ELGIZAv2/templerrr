import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { PageShell } from "@/components/PageShell";
import { Reveal } from "@/components/Reveal";
import { Mail, Github, Twitter, Send, Check } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [{ title: "Contact — Megsy" }] }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);
  return (
    <>
      <Navbar />
      <PageShell
        eyebrow="Contact"
        title="Get in touch."
        subtitle="Questions, ideas, or partnerships — we read every message."
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-4xl">
          <Reveal>
            <div
              className="h-full rounded-3xl border border-white/10 p-7"
              style={{
                background: "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
                backdropFilter: "blur(20px) saturate(160%)",
              }}
            >
              <h2 className="font-semibold tracking-tight text-lg mb-5">Reach us</h2>
              <ul className="space-y-4 text-sm text-white/75">
                <Row icon={Mail} label="hello@megsy.app" />
                <Row icon={Github} label="github.com/megsy" />
                <Row icon={Twitter} label="@megsy" />
              </ul>
              <div className="mt-8 pt-6 border-t border-white/10 text-xs text-white/45 leading-relaxed">
                Replies usually within one business day. For urgent issues with
                the live globe, please mention the city you were viewing.
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSent(true);
              }}
              className="rounded-3xl border border-white/10 p-7 space-y-3"
              style={{
                background: "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
                backdropFilter: "blur(20px) saturate(160%)",
              }}
            >
              <Field placeholder="Your name" />
              <Field placeholder="Your email" type="email" />
              <textarea
                required
                rows={5}
                placeholder="Your message"
                className="w-full px-4 py-3 rounded-2xl bg-black/30 border border-white/10 text-sm placeholder:text-white/30 focus:outline-none focus:border-cyan-300/50 resize-none"
              />
              <button
                type="submit"
                disabled={sent}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-white text-black text-sm font-semibold transition hover:bg-white/90 disabled:opacity-80"
              >
                {sent ? (
                  <>
                    <Check className="h-4 w-4" /> Thanks — we'll be in touch
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" /> Send message
                  </>
                )}
              </button>
            </form>
          </Reveal>
        </div>
      </PageShell>
    </>
  );
}

function Row({ icon: Icon, label }: { icon: typeof Mail; label: string }) {
  return (
    <li className="flex items-center gap-3">
      <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-cyan-300/10 border border-cyan-300/20">
        <Icon className="h-4 w-4 text-cyan-300" strokeWidth={1.6} />
      </span>
      <span>{label}</span>
    </li>
  );
}

function Field({ placeholder, type = "text" }: { placeholder: string; type?: string }) {
  return (
    <input
      required
      type={type}
      placeholder={placeholder}
      className="w-full px-4 py-3 rounded-2xl bg-black/30 border border-white/10 text-sm placeholder:text-white/30 focus:outline-none focus:border-cyan-300/50"
    />
  );
}
