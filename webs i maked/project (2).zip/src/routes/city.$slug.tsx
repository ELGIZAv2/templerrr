import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Star, GitCompare, Droplets, Wind, Clock, MapPin } from "lucide-react";
import {
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Area,
  AreaChart,
} from "recharts";
import { Navbar } from "@/components/Navbar";
import { Reveal, Stagger, StaggerItem } from "@/components/Reveal";
import { WeatherIcon, getWeather } from "@/components/WeatherIcon";
import { findCityBySlug, citySlug } from "@/lib/cities";
import { fetchFull, tempColor, convertTemp } from "@/lib/weather";
import { favorites, compare, unit, useStorageValue } from "@/lib/preferences";

export const Route = createFileRoute("/city/$slug")({
  loader: ({ params }) => {
    const city = findCityBySlug(params.slug);
    if (!city) throw notFound();
    return { city };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.city.name} Weather — Megsy` },
      {
        name: "description",
        content: `Live weather, hourly trend and 7-day forecast for ${loaderData?.city.name}, ${loaderData?.city.country}.`,
      },
    ],
  }),
  component: CityDetailPage,
  notFoundComponent: () => (
    <>
      <Navbar />
      <div className="min-h-screen bg-[#050508] text-white pt-32 text-center">
        <h1 className="text-2xl font-bold">City not found</h1>
        <Link to="/cities" className="text-cyan-300 underline mt-4 inline-block">
          Back to Cities
        </Link>
      </div>
    </>
  ),
});

function CityDetailPage() {
  const { city } = Route.useLoaderData();
  const slug = citySlug(city);
  const u = useStorageValue(() => unit.get());
  const isFav = useStorageValue(() => favorites.has(slug));
  const inCompare = useStorageValue(() => compare.has(slug));

  const { data, isLoading, error } = useQuery({
    queryKey: ["weather", "full", city.lat, city.lon],
    queryFn: () => fetchFull(city.lat, city.lon),
    staleTime: 10 * 60 * 1000,
  });

  const w = getWeather(data?.current.weatherCode);
  const color = tempColor(data?.current.temp ?? null);

  const hourly = (data?.hourly ?? []).map((h) => ({
    time: new Date(h.time).getHours().toString().padStart(2, "0"),
    temp: u === "F" ? Math.round((h.temp * 9) / 5 + 32) : Math.round(h.temp),
  }));

  return (
    <>
      <Navbar />
      <div
        className="relative min-h-screen text-white pt-28 pb-24 px-6"
        style={{
          fontFamily:
            "-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Inter', system-ui, sans-serif",
          background:
            "radial-gradient(1200px 600px at 10% -10%, rgba(56,189,248,0.18), transparent 60%), radial-gradient(900px 500px at 100% 10%, rgba(168,85,247,0.18), transparent 60%), #050508",
        }}
      >
        <div className="max-w-5xl mx-auto">
          <Reveal>
            <Link
              to="/cities"
              className="inline-flex items-center gap-1.5 text-xs text-white/55 hover:text-white mb-8 transition"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> All cities
            </Link>
          </Reveal>

          <Reveal delay={0.05}>
            <div className="flex flex-wrap items-end justify-between gap-6 mb-10">
              <div>
                <div className="text-[11px] uppercase tracking-[0.3em] text-cyan-300/80 mb-3">
                  Now
                </div>
                <h1 className="text-5xl md:text-6xl font-semibold tracking-tight bg-gradient-to-b from-white to-white/60 bg-clip-text text-transparent">
                  {city.name}
                </h1>
                <p className="text-white/55 mt-2">{city.country}</p>
                <p className="text-xs text-white/35 mt-2 flex items-center gap-1.5">
                  <MapPin className="h-3 w-3" />
                  {Math.abs(city.lat).toFixed(2)}°{city.lat >= 0 ? "N" : "S"} ·{" "}
                  {Math.abs(city.lon).toFixed(2)}°{city.lon >= 0 ? "E" : "W"}
                </p>
              </div>
              <div className="flex gap-2">
                <ActionBtn active={isFav} onClick={() => favorites.toggle(slug)}>
                  <Star
                    className={"h-4 w-4 " + (isFav ? "fill-yellow-300 text-yellow-300" : "")}
                    strokeWidth={1.6}
                  />
                  {isFav ? "Favorited" : "Favorite"}
                </ActionBtn>
                <ActionBtn active={inCompare} onClick={() => compare.toggle(slug)}>
                  <GitCompare
                    className={"h-4 w-4 " + (inCompare ? "text-cyan-300" : "")}
                    strokeWidth={1.6}
                  />
                  {inCompare ? "In Compare" : "Compare"}
                </ActionBtn>
              </div>
            </div>
          </Reveal>

          {error && (
            <div className="rounded-2xl border border-red-400/30 bg-red-500/10 p-4 text-sm text-red-200">
              Failed to load weather. Please retry.
            </div>
          )}

          {isLoading && <div className="text-white/50">Loading…</div>}

          {data && (
            <>
              <Reveal delay={0.1}>
                <div
                  className="rounded-[28px] border border-white/10 p-8 md:p-10 mb-8"
                  style={{
                    background:
                      "linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0.02))",
                    backdropFilter: "blur(24px) saturate(180%)",
                    boxShadow: "0 1px 0 rgba(255,255,255,0.1) inset, 0 30px 60px -30px rgba(0,0,0,0.7)",
                  }}
                >
                  <div className="flex items-center gap-8 flex-wrap">
                    <WeatherIcon
                      code={data.current.weatherCode}
                      className="h-24 w-24"
                      strokeWidth={1.2}
                    />
                    <div>
                      <div
                        className="text-7xl md:text-8xl font-semibold tracking-tight leading-none"
                        style={{ color }}
                      >
                        {convertTemp(data.current.temp, u)}
                      </div>
                      <div className="text-white/65 mt-3 text-lg">{w.label}</div>
                    </div>
                  </div>
                  <Stagger
                    className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-8"
                    gap={0.05}
                  >
                    <StaggerItem>
                      <Stat
                        icon={<Droplets className="h-4 w-4" strokeWidth={1.6} />}
                        label="Humidity"
                        value={data.current.humidity != null ? `${data.current.humidity}%` : "—"}
                      />
                    </StaggerItem>
                    <StaggerItem>
                      <Stat
                        icon={<Wind className="h-4 w-4" strokeWidth={1.6} />}
                        label="Wind"
                        value={
                          data.current.windSpeed != null
                            ? `${Math.round(data.current.windSpeed)} km/h`
                            : "—"
                        }
                      />
                    </StaggerItem>
                    <StaggerItem>
                      <Stat
                        icon={<Clock className="h-4 w-4" strokeWidth={1.6} />}
                        label="Updated"
                        value={new Date(data.updatedAt).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      />
                    </StaggerItem>
                  </Stagger>
                </div>
              </Reveal>

              <Reveal delay={0.15}>
                <section className="mb-10">
                  <h2 className="text-[11px] font-semibold uppercase tracking-[0.3em] text-white/50 mb-4">
                    Next 24 hours
                  </h2>
                  <div
                    className="rounded-[24px] border border-white/10 p-5 h-72"
                    style={{
                      background:
                        "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
                      backdropFilter: "blur(20px) saturate(160%)",
                    }}
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={hourly} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                        <defs>
                          <linearGradient id="cyanFill" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#22d3ee" stopOpacity={0.45} />
                            <stop offset="100%" stopColor="#22d3ee" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis dataKey="time" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} axisLine={false} />
                        <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} axisLine={false} width={36} />
                        <Tooltip
                          contentStyle={{
                            background: "rgba(10,10,16,0.9)",
                            border: "1px solid rgba(255,255,255,0.1)",
                            borderRadius: 12,
                            fontSize: 12,
                            backdropFilter: "blur(12px)",
                          }}
                        />
                        <Area
                          type="monotone"
                          dataKey="temp"
                          stroke="#22d3ee"
                          strokeWidth={2.5}
                          fill="url(#cyanFill)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </section>
              </Reveal>

              <Reveal delay={0.2}>
                <section>
                  <h2 className="text-[11px] font-semibold uppercase tracking-[0.3em] text-white/50 mb-4">
                    Seven-day forecast
                  </h2>
                  <Stagger
                    className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2"
                    gap={0.04}
                  >
                    {data.daily.map((d) => (
                      <StaggerItem key={d.date}>
                        <div
                          className="rounded-2xl border border-white/10 p-4 text-center h-full"
                          style={{
                            background:
                              "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
                            backdropFilter: "blur(20px) saturate(160%)",
                          }}
                        >
                          <div className="text-[10px] uppercase tracking-wider text-white/40 mb-2">
                            {new Date(d.date).toLocaleDateString(undefined, { weekday: "short" })}
                          </div>
                          <div className="flex justify-center mb-3">
                            <WeatherIcon code={d.code} className="h-6 w-6" strokeWidth={1.4} />
                          </div>
                          <div className="text-base font-semibold" style={{ color: tempColor(d.tMax) }}>
                            {convertTemp(d.tMax, u)}
                          </div>
                          <div className="text-[11px] text-white/40 mt-0.5">
                            {convertTemp(d.tMin, u)}
                          </div>
                        </div>
                      </StaggerItem>
                    ))}
                  </Stagger>
                </section>
              </Reveal>
            </>
          )}
        </div>
      </div>
    </>
  );
}

function ActionBtn({
  children,
  onClick,
  active,
}: {
  children: React.ReactNode;
  onClick: () => void;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={
        "px-4 py-2 rounded-full border text-xs font-medium flex items-center gap-2 transition backdrop-blur " +
        (active
          ? "bg-white/15 border-white/25 text-white"
          : "bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20")
      }
    >
      {children}
    </button>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-black/30 border border-white/10 p-4">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-white/45 mb-2">
        {icon} {label}
      </div>
      <div className="text-base font-semibold tracking-tight">{value}</div>
    </div>
  );
}
