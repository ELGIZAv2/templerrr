// Frontend-only store using localStorage
export type User = { email: string; name: string; role: "user" | "admin" };
export type MenuItem = { id: string; name: string; price: number; category: string; description?: string };
export type CartItem = { id: string; name: string; price: number; qty: number };
export type Order = { id: string; userEmail: string; items: CartItem[]; total: number; status: string; createdAt: string };

const K = {
  users: "megsy_users",
  current: "megsy_current_user",
  menu: "megsy_menu",
  cart: "megsy_cart",
  orders: "megsy_orders",
};

function read<T>(k: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try { return JSON.parse(localStorage.getItem(k) || "null") ?? fallback; } catch { return fallback; }
}
function write(k: string, v: unknown) {
  if (typeof window === "undefined") return;
  localStorage.setItem(k, JSON.stringify(v));
}

const seedMenu: MenuItem[] = [
  { id: "1", name: "Signature Bowl", price: 14, category: "Bowls", description: "House grain bowl with seasonal toppings." },
  { id: "2", name: "Smoked Brisket", price: 22, category: "Mains", description: "12-hour smoked, served with slaw." },
  { id: "3", name: "Garden Salad", price: 11, category: "Starters", description: "Fresh greens, citrus dressing." },
  { id: "4", name: "Chef's Pasta", price: 17, category: "Mains", description: "Hand-rolled pasta in tomato basil." },
];

export function getMenu(): MenuItem[] {
  const m = read<MenuItem[]>(K.menu, []);
  if (m.length === 0) { write(K.menu, seedMenu); return seedMenu; }
  return m;
}
export function setMenu(items: MenuItem[]) { write(K.menu, items); }

export function getUsers(): (User & { password: string })[] { return read(K.users, []); }
export function getCurrentUser(): User | null { return read<User | null>(K.current, null); }
export function setCurrentUser(u: User | null) { write(K.current, u); }

export function signup(email: string, password: string, name: string): User {
  const users = getUsers();
  if (users.find((u) => u.email === email)) throw new Error("Email already registered");
  const role: "user" | "admin" = email === "admin@megsy.com" ? "admin" : "user";
  const user: User & { password: string } = { email, password, name, role };
  users.push(user);
  write(K.users, users);
  const { password: _p, ...pub } = user;
  setCurrentUser(pub);
  return pub;
}
export function login(email: string, password: string): User {
  const u = getUsers().find((x) => x.email === email && x.password === password);
  if (!u) throw new Error("Invalid email or password");
  const { password: _p, ...pub } = u;
  setCurrentUser(pub);
  return pub;
}
export function logout() { setCurrentUser(null); }

export function getCart(): CartItem[] { return read<CartItem[]>(K.cart, []); }
export function setCart(items: CartItem[]) { write(K.cart, items); window.dispatchEvent(new Event("cart-updated")); }
export function addToCart(item: MenuItem) {
  const cart = getCart();
  const existing = cart.find((c) => c.id === item.id);
  if (existing) existing.qty += 1;
  else cart.push({ id: item.id, name: item.name, price: item.price, qty: 1 });
  setCart(cart);
}

export function getOrders(): Order[] { return read<Order[]>(K.orders, []); }
export function placeOrder(userEmail: string): Order {
  const cart = getCart();
  if (cart.length === 0) throw new Error("Cart is empty");
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const order: Order = {
    id: Math.random().toString(36).slice(2, 10),
    userEmail, items: cart, total, status: "Confirmed",
    createdAt: new Date().toISOString(),
  };
  const orders = getOrders();
  orders.unshift(order);
  write(K.orders, orders);
  setCart([]);
  return order;
}
