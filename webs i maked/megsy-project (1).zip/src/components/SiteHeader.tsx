import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getCart, getCurrentUser, logout } from "@/lib/store";

export function SiteHeader() {
  const navigate = useNavigate();
  const [user, setUser] = useState(getCurrentUser());
  const [cartCount, setCartCount] = useState(0);
  const { location } = useRouterState();

  useEffect(() => {
    const refresh = () => {
      setUser(getCurrentUser());
      setCartCount(getCart().reduce((s, i) => s + i.qty, 0));
    };
    refresh();
    window.addEventListener("cart-updated", refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("cart-updated", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, [location.pathname]);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#0e0e0e]/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link to="/" className="font-serif text-xl font-bold tracking-wide text-[#f0ece4]">
          megsy
        </Link>
        <nav className="hidden gap-7 text-xs font-medium uppercase tracking-wider text-[#a8a29e] md:flex">
          <Link to="/" className="hover:text-[#d4a373]">Home</Link>
          <Link to="/menu" className="hover:text-[#d4a373]">Menu</Link>
          <Link to="/cart" className="hover:text-[#d4a373]">Cart {cartCount > 0 && `(${cartCount})`}</Link>
          {user && <Link to="/orders" className="hover:text-[#d4a373]">Orders</Link>}
          {user?.role === "admin" && <Link to="/admin" className="hover:text-[#d4a373]">Admin</Link>}
        </nav>
        <div className="flex items-center gap-3">
          {user ? (
            <>
              <span className="hidden text-xs text-[#a8a29e] md:inline">{user.name}</span>
              <button
                onClick={() => { logout(); setUser(null); navigate({ to: "/" }); }}
                className="rounded-full border border-white/10 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#a8a29e] transition hover:border-[#d4a373] hover:text-[#d4a373]"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="rounded-full border border-white/10 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#a8a29e] hover:border-[#d4a373] hover:text-[#d4a373]">Login</Link>
              <Link to="/signup" className="rounded-full bg-[#d4a373] px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#0e0e0e] hover:bg-[#e8c9a0]">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
