import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { getCart, setCart, getCurrentUser, placeOrder } from "@/lib/store";

export const Route = createFileRoute("/_app/cart")({
  component: CartPage,
  head: () => ({ meta: [{ title: "Cart — megsy" }] }),
});

function CartPage() {
  const navigate = useNavigate();
  const [items, setItems] = useState(() => getCart());
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);

  const updateQty = (id: string, delta: number) => {
    const next = items
      .map((i) => (i.id === id ? { ...i, qty: Math.max(0, i.qty + delta) } : i))
      .filter((i) => i.qty > 0);
    setItems(next);
    setCart(next);
  };

  const checkout = () => {
    const u = getCurrentUser();
    if (!u) { navigate({ to: "/login" }); return; }
    const order = placeOrder(u.email);
    setItems([]);
    navigate({ to: "/orders" });
    void order;
  };

  return (
    <div>
      <h1 className="mb-8 font-serif text-4xl">Your Cart</h1>
      {items.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-[#161616] p-10 text-center">
          <p className="text-[#a8a29e]">Your cart is empty.</p>
          <Link to="/menu" className="mt-6 inline-block rounded-full bg-[#d4a373] px-6 py-3 text-xs font-semibold uppercase tracking-wider text-[#0e0e0e]">Browse menu</Link>
        </div>
      ) : (
        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <div className="space-y-3">
            {items.map((i) => (
              <div key={i.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-[#161616] p-5">
                <div>
                  <div className="font-serif text-xl">{i.name}</div>
                  <div className="text-sm text-[#a8a29e]">${i.price} each</div>
                </div>
                <div className="flex items-center gap-3">
                  <button onClick={() => updateQty(i.id, -1)} className="h-8 w-8 rounded-full border border-white/10 hover:border-[#d4a373]">−</button>
                  <span className="w-6 text-center">{i.qty}</span>
                  <button onClick={() => updateQty(i.id, 1)} className="h-8 w-8 rounded-full border border-white/10 hover:border-[#d4a373]">+</button>
                </div>
              </div>
            ))}
          </div>
          <aside className="h-fit rounded-2xl border border-white/10 bg-[#161616] p-6">
            <div className="flex justify-between text-[#a8a29e]"><span>Subtotal</span><span>${total.toFixed(2)}</span></div>
            <div className="mt-2 flex justify-between text-[#a8a29e]"><span>Service</span><span>Free</span></div>
            <div className="my-4 border-t border-white/10" />
            <div className="flex justify-between font-serif text-2xl"><span>Total</span><span className="text-[#d4a373]">${total.toFixed(2)}</span></div>
            <button onClick={checkout} className="mt-6 w-full rounded-full bg-[#d4a373] py-3 text-xs font-semibold uppercase tracking-wider text-[#0e0e0e] hover:bg-[#e8c9a0]">
              Checkout
            </button>
          </aside>
        </div>
      )}
    </div>
  );
}
