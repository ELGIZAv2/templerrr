import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { addToCart, getMenu } from "@/lib/store";

export const Route = createFileRoute("/_app/menu")({
  component: MenuPage,
  head: () => ({ meta: [{ title: "Menu — megsy" }] }),
});

function MenuPage() {
  const [items] = useState(() => getMenu());
  const [added, setAdded] = useState<string | null>(null);
  return (
    <div>
      <h1 className="mb-2 font-serif text-4xl">Our Menu</h1>
      <p className="mb-10 text-[#a8a29e]">Crafted dishes, available to order now.</p>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((it) => (
          <div key={it.id} className="rounded-2xl border border-white/10 bg-[#161616] p-6 transition hover:border-[#d4a373]/40">
            <div className="text-xs uppercase tracking-widest text-[#d4a373]">{it.category}</div>
            <h3 className="mt-2 font-serif text-2xl">{it.name}</h3>
            <p className="mt-2 text-sm text-[#a8a29e]">{it.description}</p>
            <div className="mt-6 flex items-center justify-between">
              <span className="font-serif text-2xl text-[#d4a373]">${it.price}</span>
              <button
                onClick={() => { addToCart(it); setAdded(it.id); setTimeout(() => setAdded(null), 1200); }}
                className="rounded-full bg-[#d4a373] px-5 py-2 text-xs font-semibold uppercase tracking-wider text-[#0e0e0e] hover:bg-[#e8c9a0]"
              >
                {added === it.id ? "Added" : "Add to cart"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
