import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getCurrentUser, getMenu, setMenu, getOrders, type MenuItem, type Order } from "@/lib/store";

export const Route = createFileRoute("/_app/admin")({
  component: AdminPage,
  head: () => ({ meta: [{ title: "Admin — megsy" }] }),
});

function AdminPage() {
  const navigate = useNavigate();
  const [items, setItems] = useState<MenuItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [form, setForm] = useState({ name: "", price: "", category: "", description: "" });

  useEffect(() => {
    const u = getCurrentUser();
    if (!u || u.role !== "admin") { navigate({ to: "/login" }); return; }
    setItems(getMenu());
    setOrders(getOrders());
  }, [navigate]);

  const save = (next: MenuItem[]) => { setItems(next); setMenu(next); };
  const add = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.price) return;
    save([...items, { id: Math.random().toString(36).slice(2, 8), name: form.name, price: parseFloat(form.price), category: form.category || "Other", description: form.description }]);
    setForm({ name: "", price: "", category: "", description: "" });
  };
  const remove = (id: string) => save(items.filter((i) => i.id !== id));

  return (
    <div className="space-y-12">
      <div>
        <h1 className="mb-2 font-serif text-4xl">Admin Dashboard</h1>
        <p className="text-[#a8a29e]">Manage menu and view orders.</p>
        <p className="mt-2 text-xs text-[#78716c]">Tip: Sign up with email <code className="text-[#d4a373]">admin@megsy.com</code> to get admin access.</p>
      </div>

      <section>
        <h2 className="mb-4 font-serif text-2xl">Add menu item</h2>
        <form onSubmit={add} className="grid gap-3 rounded-2xl border border-white/10 bg-[#161616] p-6 sm:grid-cols-2">
          <input className="rounded-md border border-white/10 bg-[#0e0e0e] px-4 py-2 text-sm" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className="rounded-md border border-white/10 bg-[#0e0e0e] px-4 py-2 text-sm" placeholder="Price" type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
          <input className="rounded-md border border-white/10 bg-[#0e0e0e] px-4 py-2 text-sm" placeholder="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
          <input className="rounded-md border border-white/10 bg-[#0e0e0e] px-4 py-2 text-sm" placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <button className="rounded-full bg-[#d4a373] px-6 py-2 text-xs font-semibold uppercase tracking-wider text-[#0e0e0e] hover:bg-[#e8c9a0] sm:col-span-2">Add item</button>
        </form>
      </section>

      <section>
        <h2 className="mb-4 font-serif text-2xl">Menu ({items.length})</h2>
        <div className="space-y-2">
          {items.map((i) => (
            <div key={i.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-[#161616] p-4">
              <div>
                <div className="font-medium">{i.name} <span className="text-xs text-[#a8a29e]">· {i.category}</span></div>
                <div className="text-sm text-[#d4a373]">${i.price}</div>
              </div>
              <button onClick={() => remove(i.id)} className="rounded-full border border-white/10 px-4 py-2 text-xs uppercase tracking-wider text-[#a8a29e] hover:border-red-500/50 hover:text-red-300">Delete</button>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="mb-4 font-serif text-2xl">All orders ({orders.length})</h2>
        <div className="space-y-2">
          {orders.map((o) => (
            <div key={o.id} className="rounded-xl border border-white/10 bg-[#161616] p-4 text-sm">
              <div className="flex justify-between text-[#a8a29e]">
                <span>#{o.id} · {o.userEmail}</span>
                <span className="text-[#d4a373]">${o.total.toFixed(2)}</span>
              </div>
              <div className="mt-1 text-xs text-[#78716c]">{new Date(o.createdAt).toLocaleString()} · {o.items.length} items</div>
            </div>
          ))}
          {orders.length === 0 && <p className="text-sm text-[#a8a29e]">No orders yet.</p>}
        </div>
      </section>
    </div>
  );
}
