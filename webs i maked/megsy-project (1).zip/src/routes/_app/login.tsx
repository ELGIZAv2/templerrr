import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { login } from "@/lib/store";

export const Route = createFileRoute("/_app/login")({
  component: LoginPage,
  head: () => ({ meta: [{ title: "Login — megsy" }] }),
});

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");

  return (
    <div className="mx-auto max-w-md">
      <h1 className="mb-2 font-serif text-4xl">Welcome back</h1>
      <p className="mb-8 text-[#a8a29e]">Sign in to continue.</p>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          try { login(email, password); navigate({ to: "/menu" }); }
          catch (e2) { setErr((e2 as Error).message); }
        }}
        className="space-y-4 rounded-2xl border border-white/10 bg-[#161616] p-8"
      >
        {err && <div className="rounded-md border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">{err}</div>}
        <input className="w-full rounded-md border border-white/10 bg-[#0e0e0e] px-4 py-3 text-sm" placeholder="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input className="w-full rounded-md border border-white/10 bg-[#0e0e0e] px-4 py-3 text-sm" placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button className="w-full rounded-full bg-[#d4a373] py-3 text-xs font-semibold uppercase tracking-wider text-[#0e0e0e] hover:bg-[#e8c9a0]">Sign in</button>
        <p className="text-center text-sm text-[#a8a29e]">No account? <Link to="/signup" className="text-[#d4a373]">Sign up</Link></p>
      </form>
    </div>
  );
}
