import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getCurrentUser, getOrders, type Order } from "@/lib/store";

export const Route = createFileRoute("/_app/orders")({
  component: OrdersPage,
  head: () => ({ meta: [{ title: "Orders — megsy" }] }),
});

function OrdersPage() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    const u = getCurrentUser();
    if (!u) { navigate({ to: "/login" }); return; }
    setOrders(getOrders().filter((o) => o.userEmail === u.email));
  }, [navigate]);

  return (
    <div>
      <h1 className="mb-8 font-serif text-4xl">Your Orders</h1>
      {orders.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-[#161616] p-10 text-center">
          <p className="text-[#a8a29e]">No orders yet.</p>
          <Link to="/menu" className="mt-6 inline-block rounded-full bg-[#d4a373] px-6 py-3 text-xs font-semibold uppercase tracking-wider text-[#0e0e0e]">Order now</Link>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((o) => (
            <div key={o.id} className="rounded-2xl border border-white/10 bg-[#161616] p-6">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <div className="font-mono text-xs text-[#a8a29e]">#{o.id}</div>
                  <div className="text-xs text-[#78716c]">{new Date(o.createdAt).toLocaleString()}</div>
                </div>
                <span className="rounded-full bg-[#d4a373]/10 px-3 py-1 text-xs uppercase tracking-wider text-[#d4a373]">{o.status}</span>
              </div>
              <div className="space-y-1 text-sm text-[#a8a29e]">
                {o.items.map((i) => (
                  <div key={i.id} className="flex justify-between">
                    <span>{i.qty}× {i.name}</span>
                    <span>${(i.price * i.qty).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex justify-between border-t border-white/10 pt-4 font-serif text-xl">
                <span>Total</span>
                <span className="text-[#d4a373]">${o.total.toFixed(2)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
