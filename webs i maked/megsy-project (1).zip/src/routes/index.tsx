import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [{ title: "megsy — Build Your Meal" }],
  }),
});

function Index() {
  return (
    <iframe
      src="/app.html"
      title="megsy"
      style={{ border: 0, width: "100vw", height: "100vh", display: "block" }}
    />
  );
}
