import { createFileRoute, Outlet } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";

export const Route = createFileRoute("/_app")({
  component: () => (
    <div className="min-h-screen bg-[#0e0e0e] text-[#f0ece4]">
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-6 py-12">
        <Outlet />
      </main>
    </div>
  ),
});
