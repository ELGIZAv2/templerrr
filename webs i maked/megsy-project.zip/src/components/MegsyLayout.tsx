import { Link, useLocation } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useState } from "react";

const PRIMARY = [
  { to: "/mission", label: "Mission" },
  { to: "/pillars", label: "Pillars" },
  { to: "/impact", label: "Impact" },
  { to: "/community", label: "Community" },
  { to: "/blog", label: "Blog" },
  { to: "/about", label: "About" },
  { to: "/pricing", label: "Pricing" },
  { to: "/contact", label: "Contact" },
] as const;

export function MegsyLayout({ children }: { children: ReactNode }) {
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <div className="megsy">
      <div className="m-bg-scene" aria-hidden="true">
        <div className="m-bg-glow m-bg-glow-1" />
        <div className="m-bg-glow m-bg-glow-2" />
        <div className="m-bg-glow m-bg-glow-3" />
        <div className="m-bg-grain" />
      </div>
      <nav className="m-nav">
        <Link to="/" className="m-nav-logo" onClick={() => setOpen(false)}>
          Megsy
        </Link>
        <div className="m-nav-links">
          {PRIMARY.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className={pathname === n.to ? "is-active" : ""}
            >
              {n.label}
            </Link>
          ))}
        </div>
        <button
          type="button"
          className="m-burger"
          aria-label="Menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span />
          <span />
          <span />
        </button>
      </nav>

      {open && (
        <div className="m-mobile-menu" onClick={() => setOpen(false)}>
          {PRIMARY.map((n) => (
            <Link key={n.to} to={n.to}>
              {n.label}
            </Link>
          ))}
          <Link to="/faq">FAQ</Link>
          <Link to="/team">Team</Link>
        </div>
      )}

      <main className="m-page">{children}</main>

      <footer className="m-site-foot">
        <div className="m-foot-grid">
          <div>
            <div className="m-foot-logo">Megsy</div>
            <p className="m-foot-desc">
              A quiet corner of the web for slow craft, open tools, and the
              people who still care how things are made.
            </p>
          </div>
          <div>
            <div className="m-foot-title">The Field</div>
            <Link to="/mission">Our Idea</Link>
            <Link to="/pillars">What We Stand For</Link>
            <Link to="/impact">In Numbers</Link>
            <Link to="/community">Community</Link>
          </div>
          <div>
            <div className="m-foot-title">Workshop</div>
            <Link to="/documentation">Handbook</Link>
            <Link to="/open-source">Open Source</Link>
            <Link to="/research">Notes & Research</Link>
            <Link to="/blog">Journal</Link>
            <Link to="/press">Press</Link>
          </div>
          <div>
            <div className="m-foot-title">Studio</div>
            <Link to="/about">About</Link>
            <Link to="/team">Team</Link>
            <Link to="/careers">Work With Us</Link>
            <Link to="/pricing">Membership</Link>
            <Link to="/faq">FAQ</Link>
          </div>
          <div>
            <div className="m-foot-title">Say Hello</div>
            <Link to="/contact">Contact</Link>
            <Link to="/newsletter">Letters from Megsy</Link>
            <Link to="/partnerships">Partnerships</Link>
            <Link to="/privacy">Privacy</Link>
            <Link to="/terms">Terms</Link>
          </div>
        </div>
        <div className="m-foot-bottom">
          <span>© 2026 Megsy. Built slowly, on purpose.</span>
          <span className="m-foot-socials">
            <a href="https://twitter.com" target="_blank" rel="noopener">
              Twitter
            </a>
            <a href="https://github.com" target="_blank" rel="noopener">
              GitHub
            </a>
            <a href="https://discord.com" target="_blank" rel="noopener">
              Discord
            </a>
          </span>
        </div>
      </footer>
    </div>
  );
}
