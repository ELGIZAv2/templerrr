import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/mission")({
  head: () => ({
    meta: [
      { title: "Our Idea — Megsy" },
      { name: "description", content: "What Megsy is, and what it isn't. Slow craft, open tools, and a quieter web." },
      { property: "og:title", content: "Our Idea — Megsy" },
      { property: "og:description", content: "What Megsy is, and what it isn't." },
    ],
  }),
  component: MissionPage,
});

function MissionPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">The Megsy Idea</p>
      <h1 className="m-h1">A practice, not a <em>platform</em>.</h1>
      <p className="m-lede">
        Megsy isn't a product launch or a pitch deck. It's a way of making things
        on the web — closer to a workshop than a factory, closer to a garden than
        a growth chart.
      </p>

      <section className="m-section">
        <h2>What Megsy <em>is</em></h2>
        <p>
          A small studio, a public handbook, and a community of people who still
          care how the internet feels. We write software, we publish notes, and
          we host a few quiet projects that anyone can fork.
        </p>
        <p>
          Everything we make is in the open. The code, the decisions, the things
          we got wrong — all on the table.
        </p>
      </section>

      <section className="m-section">
        <h2>What Megsy <em>isn't</em></h2>
        <ul className="m-list">
          <li><strong>Not a startup</strong>No funding round, no board meetings, no exit.</li>
          <li><strong>Not a feed</strong>Nothing to scroll, no algorithm tuning your day.</li>
          <li><strong>Not in a hurry</strong>Things ship when they're good, not when the sprint ends.</li>
        </ul>
      </section>

      <div className="m-section">
        <Link to="/pillars" className="m-btn">What we stand for →</Link>
      </div>
    </MegsyLayout>
  );
}
