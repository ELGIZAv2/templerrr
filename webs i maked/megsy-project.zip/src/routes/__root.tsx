import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="megsy">
      <main className="m-page" style={{ textAlign: "center" }}>
        <p className="m-eyebrow">404 · Wrong turn</p>
        <h1 className="m-h1">This page <em>isn't here</em>.</h1>
        <p className="m-lede" style={{ margin: "0 auto" }}>
          The link you followed doesn't lead anywhere — maybe it moved, maybe it
          never existed. Head back to the front and try a different door.
        </p>
        <div className="m-section">
          <Link to="/" className="m-btn">← Back to Megsy</Link>
        </div>
      </main>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();

  return (
    <div className="megsy">
      <main className="m-page" style={{ textAlign: "center" }}>
        <p className="m-eyebrow">Something went wrong</p>
        <h1 className="m-h1">A <em>small glitch</em>.</h1>
        <p className="m-lede" style={{ margin: "0 auto" }}>
          {error.message || "Something went wrong on our end."}
        </p>
        <div className="m-section" style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <button
            type="button"
            className="m-btn"
            onClick={() => {
              router.invalidate();
              reset();
            }}
          >
            Try again
          </button>
          <Link to="/" className="m-btn">Go home</Link>
        </div>
      </main>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Megsy — A quieter corner of the web" },
      { name: "description", content: "Megsy is a quiet corner of the internet for slow craft, open tools, and the people behind the screen." },
      { name: "author", content: "Megsy" },
      { property: "og:title", content: "Megsy — A quieter corner of the web" },
      { property: "og:description", content: "Slow craft, open tools, and a community that takes its time." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:site", content: "@Megsy" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
    </QueryClientProvider>
  );
}
