import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms — Megsy" },
      { name: "description", content: "The rules of the road for using Megsy services." },
    ],
  }),
  component: Terms,
});

function Terms() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Terms of Service</p>
      <h1 className="m-h1">The rules of the <em>road</em>.</h1>
      <p className="m-lede">
        Last updated April 2026. By using Megsy you agree to a small number of
        sensible things, listed below in plain language.
      </p>

      <section className="m-section">
        <h2>The <em>short version</em></h2>
        <ul className="m-list">
          <li><strong>Be kind</strong>Treat other members with respect. Harassment ends your membership.</li>
          <li><strong>Be honest</strong>Don't impersonate others. Don't claim our research as your own.</li>
          <li><strong>Be careful</strong>Our software is provided as-is. Test before relying on it in production.</li>
          <li><strong>Be legal</strong>Don't use Megsy services to do illegal things, or to harm the natural world.</li>
        </ul>
      </section>

      <section className="m-section">
        <h2>If something <em>goes wrong</em></h2>
        <p>
          We aim to give 90 days' notice before changing these terms in any
          meaningful way. Disputes are governed by Portuguese law. If you have a
          concern, please reach out before lawyering up — we usually fix things
          on the spot.
        </p>
      </section>
    </MegsyLayout>
  );
}
