import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Megsy — A quieter corner of the web" },
      {
        name: "description",
        content:
          "Megsy is a quiet corner of the internet for slow craft, open tools, and the people behind the screen.",
      },
      { property: "og:title", content: "Megsy — A quieter corner of the web" },
      {
        property: "og:description",
        content: "Slow craft, open tools, and a community that takes its time. Welcome to Megsy.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/home-3d.html"
      title="Megsy — Digital Oasis"
      style={{
        position: "fixed",
        inset: 0,
        width: "100vw",
        height: "100vh",
        border: 0,
        background: "#000",
      }}
    />
  );
}
