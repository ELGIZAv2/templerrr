import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/partnerships")({
  head: () => ({
    meta: [
      { title: "Partnerships — Megsy" },
      { name: "description", content: "Partner with the Megsy collective." },
    ],
  }),
  component: PartnersPage,
});

function PartnersPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Partnerships</p>
      <h1 className="m-h1">Quiet, <em>long collaborations</em>.</h1>
      <p className="m-lede">
        We work with a handful of studios, publishers, and small companies on
        projects we genuinely care about. We say no to most introductions, and
        we try to say it kindly.
      </p>

      <section className="m-section">
        <h2>What we look for</h2>
        <ul className="m-list">
          <li><strong>Real projects</strong>Something concrete to build, write, or design — not a sponsorship slot.</li>
          <li><strong>Open by default</strong>If we make it together, we'd both like to be able to share it.</li>
          <li><strong>Time to do it well</strong>Reasonable timelines, reasonable scope, reasonable people.</li>
        </ul>
      </section>

      <div className="m-section">
        <Link to="/contact" className="m-btn">Start a conversation →</Link>
      </div>
    </MegsyLayout>
  );
}
