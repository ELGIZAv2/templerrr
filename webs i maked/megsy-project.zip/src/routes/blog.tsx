import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [
      { title: "Journal — Megsy" },
      { name: "description", content: "The Megsy journal — short essays, working notes, and the occasional rant." },
      { property: "og:title", content: "Journal — Megsy" },
      { property: "og:description", content: "Short essays and working notes from the Megsy team." },
    ],
  }),
  component: BlogPage,
});

const POSTS = [
  {
    slug: "small-on-purpose",
    date: "April 12, 2026",
    title: "Small on purpose",
    excerpt:
      "Why we capped the team at nine, turned down the funding round, and built Megsy to stay this size for as long as it makes sense.",
  },
  {
    slug: "the-quiet-stack",
    date: "March 02, 2026",
    title: "The quiet stack",
    excerpt:
      "Three tools we removed from our setup this quarter, and why their absence made the work — and the days — noticeably better.",
  },
  {
    slug: "writing-the-handbook",
    date: "January 21, 2026",
    title: "Writing the handbook",
    excerpt:
      "Notes on building Megsy's open handbook in public: what we shared, what we didn't, and what we changed our mind about.",
  },
];

function BlogPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">The Journal</p>
      <h1 className="m-h1">Short essays, <em>slow takes</em>.</h1>
      <p className="m-lede">
        Notes from the studio, working journals, and the occasional longer
        piece. Posts go up when they're ready — no schedule, no algorithm.
      </p>

      <div className="m-grid">
        {POSTS.map((p) => (
          <Link key={p.slug} to="/blog/$slug" params={{ slug: p.slug }} className="m-card">
            <div className="m-card-num">{p.date}</div>
            <h3>{p.title}</h3>
            <p>{p.excerpt}</p>
          </Link>
        ))}
      </div>
    </MegsyLayout>
  );
}
