import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/press")({
  head: () => ({
    meta: [
      { title: "Press — Megsy" },
      { name: "description", content: "Press kit, brand assets, and contact for journalists." },
      { property: "og:title", content: "Press — Megsy" },
      { property: "og:description", content: "Press kit and media contact for Megsy." },
    ],
  }),
  component: Press,
});

const COVERAGE = [
  { src: "WIRED", title: "The studio that doesn't want to scale", year: "2026" },
  { src: "MIT Tech Review", title: "Inside Megsy's mycelial routing experiment", year: "2025" },
  { src: "It's Nice That", title: "Aki Tanaka on quiet interfaces", year: "2025" },
  { src: "Resilience.org", title: "Cooperatives are the new startups", year: "2024" },
];

function Press() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Press &amp; Media</p>
      <h1 className="m-h1">For <em>journalists</em>.</h1>
      <p className="m-lede">
        Need a quote, a logo, a high-res photograph, or a cup of tea? Email{" "}
        <a style={{ color: "var(--m-accent)" }} href="mailto:press@megsy.example">
          press@megsy.example
        </a>{" "}
        and we'll reply within two business days.
      </p>

      <section className="m-section">
        <h2>Brand <em>assets</em></h2>
        <ul className="m-list">
          <li><strong>Logo pack</strong>SVG + PNG, light and dark variants. <a style={{ color: "var(--m-accent)" }} href="#">Download</a></li>
          <li><strong>Brand guidelines</strong>Type, color, voice, and a few rules. <a style={{ color: "var(--m-accent)" }} href="#">Download (PDF)</a></li>
          <li><strong>Founder portraits</strong>Press-quality photographs of Lena and the team. <a style={{ color: "var(--m-accent)" }} href="#">Download</a></li>
        </ul>
      </section>

      <section className="m-section">
        <h2>Recent <em>coverage</em></h2>
        <div className="m-grid">
          {COVERAGE.map((c) => (
            <div className="m-card" key={c.title}>
              <div className="m-card-num">{c.year}</div>
              <h3>{c.title}</h3>
              <p>{c.src}</p>
            </div>
          ))}
        </div>
      </section>
    </MegsyLayout>
  );
}
