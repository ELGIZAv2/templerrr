import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy — Megsy" },
      { name: "description", content: "How Megsy handles your data: as little as possible, as transparently as possible." },
    ],
  }),
  component: Privacy,
});

function Privacy() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Privacy</p>
      <h1 className="m-h1">As little as <em>possible</em>.</h1>
      <p className="m-lede">
        Last updated April 2026. The short version: we don't sell your data,
        we don't run third-party trackers, and we forget you when you ask us to.
      </p>

      <section className="m-section">
        <h2>What we <em>collect</em></h2>
        <ul className="m-list">
          <li><strong>Account data</strong>Email, display name, and (optionally) a city — only if you create an account.</li>
          <li><strong>Newsletter email</strong>Stored separately, used only to send the quarterly dispatch. Unsubscribe with a single click.</li>
          <li><strong>Server logs</strong>Anonymised IPs and request paths, kept for 14 days, used only to debug outages.</li>
        </ul>
      </section>

      <section className="m-section">
        <h2>What we <em>don't</em> do</h2>
        <p>No advertising trackers, no third-party analytics, no fingerprinting, no cross-site cookies. We use a single first-party session cookie when you sign in, and that's it.</p>
      </section>

      <section className="m-section">
        <h2>Your <em>rights</em></h2>
        <p>You can request a full export, a correction, or full deletion of your data at any time by emailing <a style={{ color: "var(--m-accent)" }} href="mailto:privacy@megsy.example">privacy@megsy.example</a>. We respond within 30 days.</p>
      </section>
    </MegsyLayout>
  );
}
