import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/careers")({
  head: () => ({
    meta: [
      { title: "Careers — Megsy" },
      { name: "description", content: "Join the Megsy team." },
    ],
  }),
  component: CareersPage,
});

const ROLES = [
  { title: "Product Engineer", loc: "Remote · Europe", type: "Full-time" },
  { title: "Designer (Brand & Web)", loc: "Remote · Anywhere", type: "Full-time" },
  { title: "Writer / Editor", loc: "Remote · Anywhere", type: "Part-time" },
  { title: "Community Lead", loc: "Remote · Europe", type: "Full-time" },
];

function CareersPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Work With Us</p>
      <h1 className="m-h1">A small team, <em>kept that way</em>.</h1>
      <p className="m-lede">
        We hire slowly and rarely. Fair pay, four-day weeks, real holidays, and
        the time to do good work without anyone breathing down your neck.
      </p>

      <div className="m-grid">
        {ROLES.map((r) => (
          <div key={r.title} className="m-card">
            <div className="m-card-num">{r.type}</div>
            <h3>{r.title}</h3>
            <p>{r.loc}</p>
          </div>
        ))}
      </div>
    </MegsyLayout>
  );
}
