import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

const POSTS: Record<string, { title: string; date: string; body: string[] }> = {
  "small-on-purpose": {
    title: "Small on purpose",
    date: "April 12, 2026",
    body: [
      "We get the question a lot: when are you going to grow? When are you going to hire? When are you going to take the round? The answer keeps being the same — probably never, and definitely not yet.",
      "Megsy works because it's small. Nine people can read every email, ship every change, and remember every conversation. Once you're past about a dozen, that breaks, and the company you built quietly turns into something else.",
      "We'd rather stay this size and do the work well than grow into something we no longer recognise.",
    ],
  },
  "the-quiet-stack": {
    title: "The quiet stack",
    date: "March 02, 2026",
    body: [
      "We removed three tools from our setup this quarter. The first was analytics. The second was a chat product I'd rather not name. The third was a build system that promised 'zero config' and delivered, instead, six.",
      "Each removal made the work better. Quieter. Slower in the right places, faster in the right places. Less to think about when we open the laptop in the morning.",
      "Subtraction is a feature. Most days it's the most important one.",
    ],
  },
  "writing-the-handbook": {
    title: "Writing the handbook",
    date: "January 21, 2026",
    body: [
      "We've been writing Megsy's handbook in public for a year. Salaries, decisions, retros, the things we got wrong — all of it lives on the open web for anyone to read.",
      "The surprising part isn't how much we shared. It's how much sharper our thinking got once we knew we'd have to explain it. A handbook written for strangers is a much better handbook than one written for yourself.",
    ],
  },
};

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const post = POSTS[params.slug];
    if (!post) throw notFound();
    return { post };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.post.title} — Megsy` },
          { name: "description", content: loaderData.post.body[0].slice(0, 150) },
          { property: "og:title", content: `${loaderData.post.title} — Megsy` },
          { property: "og:description", content: loaderData.post.body[0].slice(0, 150) },
        ]
      : [{ title: "Megsy" }],
  }),
  component: PostPage,
  notFoundComponent: () => (
    <MegsyLayout>
      <h1 className="m-h1">Not found</h1>
      <p className="m-lede">This post isn't here — maybe it was unpublished, or the link drifted.</p>
      <div className="m-section">
        <Link to="/blog" className="m-btn">Back to the journal →</Link>
      </div>
    </MegsyLayout>
  ),
  errorComponent: () => (
    <MegsyLayout>
      <h1 className="m-h1">Something broke</h1>
      <p className="m-lede">The page failed to load. Try again in a moment.</p>
    </MegsyLayout>
  ),
});

function PostPage() {
  const { post } = Route.useLoaderData();
  return (
    <MegsyLayout>
      <p className="m-eyebrow">{post.date}</p>
      <h1 className="m-h1">{post.title}</h1>
      <div className="m-section">
        {post.body.map((p: string, i: number) => (
          <p key={i}>{p}</p>
        ))}
      </div>
      <div className="m-section">
        <Link to="/blog" className="m-btn">← All posts</Link>
      </div>
    </MegsyLayout>
  );
}
