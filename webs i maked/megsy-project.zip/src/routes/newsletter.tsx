import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/newsletter")({
  head: () => ({
    meta: [
      { title: "Letters from Megsy" },
      { name: "description", content: "An occasional, well-written email from Megsy. No tracking, no spam." },
    ],
  }),
  component: NewsletterPage,
});

const schema = z.object({
  email: z.string().trim().email("Please enter a valid email").max(255),
});

function NewsletterPage() {
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <MegsyLayout>
      <p className="m-eyebrow">Letters from Megsy</p>
      <h1 className="m-h1">An email, <em>now and then</em>.</h1>
      <p className="m-lede">
        No tracking pixels, no "exclusive offers", no daily push. Just a short,
        well-edited email when there's something worth sharing — usually a few
        times a season.
      </p>

      {done ? (
        <div className="m-section">
          <div className="m-success">
            <h2 style={{ marginBottom: 8 }}>You're <em>on the list</em>.</h2>
            <p>We'll be in touch when the next letter goes out.</p>
          </div>
        </div>
      ) : (
        <form
          className="m-section"
          style={{ maxWidth: 480 }}
          onSubmit={(e) => {
            e.preventDefault();
            const email = (e.currentTarget.elements.namedItem("email") as HTMLInputElement).value;
            const r = schema.safeParse({ email });
            if (!r.success) {
              setError(r.error.issues[0]?.message ?? "Invalid email");
              return;
            }
            setError(null);
            setDone(true);
          }}
          noValidate
        >
          <div className="m-form-row">
            <label htmlFor="email">Email</label>
            <input className="m-input" id="email" name="email" type="email" maxLength={255} />
            {error && <div className="m-error">{error}</div>}
          </div>
          <button className="m-btn" type="submit">Subscribe →</button>
        </form>
      )}
    </MegsyLayout>
  );
}
