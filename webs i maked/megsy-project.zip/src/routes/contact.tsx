import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Megsy" },
      { name: "description", content: "Write to the Megsy collective." },
      { property: "og:title", content: "Contact — Megsy" },
      { property: "og:description", content: "Write to the Megsy collective." },
    ],
  }),
  component: ContactPage,
});

const schema = z.object({
  name: z.string().trim().min(1, "Name cannot be empty").max(100),
  email: z.string().trim().email("Please enter a valid email").max(255),
  message: z
    .string()
    .trim()
    .min(10, "A few more words, please")
    .max(2000, "Message must be under 2000 characters"),
});

function ContactPage() {
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  return (
    <MegsyLayout>
      <p className="m-eyebrow">Say Hello</p>
      <h1 className="m-h1">A <em>real</em> human will reply.</h1>
      <p className="m-lede">
        We read everything that comes in and answer within a few days. No
        ticketing system, no auto-responder, no "your call is important to us".
        Just a small inbox handled by an actual person.
      </p>

      {sent ? (
        <div className="m-section">
          <div className="m-success">
            <h2 style={{ marginBottom: 8 }}>Got it. <em>Thanks.</em></h2>
            <p>Your message is in. We'll write back as soon as we can.</p>
          </div>
        </div>
      ) : (
        <form
          className="m-section"
          style={{ maxWidth: 560 }}
          onSubmit={(e) => {
            e.preventDefault();
            const f = e.currentTarget;
            const data = {
              name: (f.elements.namedItem("name") as HTMLInputElement).value,
              email: (f.elements.namedItem("email") as HTMLInputElement).value,
              message: (f.elements.namedItem("message") as HTMLTextAreaElement).value,
            };
            const result = schema.safeParse(data);
            if (!result.success) {
              const errs: Record<string, string> = {};
              result.error.issues.forEach((i) => {
                if (i.path[0]) errs[String(i.path[0])] = i.message;
              });
              setErrors(errs);
              return;
            }
            setErrors({});
            setSent(true);
          }}
          noValidate
        >
          <div className="m-form-row">
            <label htmlFor="name">Your name</label>
            <input className="m-input" id="name" name="name" maxLength={100} />
            {errors.name && <div className="m-error">{errors.name}</div>}
          </div>
          <div className="m-form-row">
            <label htmlFor="email">Email</label>
            <input className="m-input" id="email" type="email" name="email" maxLength={255} />
            {errors.email && <div className="m-error">{errors.email}</div>}
          </div>
          <div className="m-form-row">
            <label htmlFor="message">Message</label>
            <textarea className="m-textarea" id="message" name="message" maxLength={2000} />
            {errors.message && <div className="m-error">{errors.message}</div>}
          </div>
          <button className="m-btn" type="submit">Send message →</button>
        </form>
      )}
    </MegsyLayout>
  );
}
