import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { MegsyLayout } from "@/components/MegsyLayout";

const emailSchema = z.string().trim().email("Please enter a valid email").max(255);

export const Route = createFileRoute("/community")({
  head: () => ({
    meta: [
      { title: "Community — Megsy" },
      { name: "description", content: "Join Megsy — a small, slow community of people who care how the web is made." },
      { property: "og:title", content: "Community — Megsy" },
      { property: "og:description", content: "A small, slow community. No funnel. Just a door." },
    ],
  }),
  component: CommunityPage,
});

function CommunityPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Find Your Place</p>
      <h1 className="m-h1">A <em>community</em>, not an audience.</h1>
      <p className="m-lede">
        Megsy is small on purpose. There's no follower count to chase and no
        algorithm rewarding the loudest voice. Just a few hundred people doing
        good work and talking about it like adults.
      </p>

      <section className="m-section">
        <h2>What you <em>get</em></h2>
        <ul className="m-list">
          <li><strong>Members' workshop</strong>An invite-only space for working sessions, peer reviews and quiet feedback.</li>
          <li><strong>Letters from Megsy</strong>A short, well-written email when there's actually something to share.</li>
          <li><strong>Open handbook</strong>Full access to how we work, what we're building, and what we got wrong.</li>
        </ul>
      </section>

      <section className="m-section">
        <h2>Drop us a <em>line</em></h2>
        <p>Leave your email and we'll write when the next round of invites opens.</p>
        <CommunityForm />
      </section>

      <div className="m-section">
        <Link to="/contact" className="m-btn">Or just say hello →</Link>
      </div>
    </MegsyLayout>
  );
}

function CommunityForm() {
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  if (done)
    return (
      <div className="m-success" style={{ marginTop: 20, maxWidth: 480 }}>
        Thanks — we'll write when the next round of invites opens.
      </div>
    );
  return (
    <form
      style={{ marginTop: 24, maxWidth: 480 }}
      noValidate
      onSubmit={(e) => {
        e.preventDefault();
        const email = (e.currentTarget.elements.namedItem("email") as HTMLInputElement).value;
        const r = emailSchema.safeParse(email);
        if (!r.success) {
          setError(r.error.issues[0]?.message ?? "Invalid email");
          return;
        }
        setError(null);
        setDone(true);
      }}
    >
      <div className="m-form-row">
        <label htmlFor="email">Email</label>
        <input
          className="m-input"
          id="email"
          name="email"
          type="email"
          maxLength={255}
          placeholder="you@somewhere.net"
        />
        {error && <div className="m-error">{error}</div>}
      </div>
      <button className="m-btn" type="submit">Request invite →</button>
    </form>
  );
}
