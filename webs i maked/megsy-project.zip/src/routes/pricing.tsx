import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Membership — Megsy" },
      { name: "description", content: "Three honest tiers. Pay what makes sense. Cancel any time." },
      { property: "og:title", content: "Membership — Megsy" },
      { property: "og:description", content: "Three honest tiers for joining the Megsy collective." },
    ],
  }),
  component: Pricing,
});

const TIERS = [
  {
    name: "Reader",
    price: "Free",
    suffix: "",
    feature: false,
    perks: [
      "Full access to the journal & handbook",
      "Letters from Megsy in your inbox",
      "All open-source projects, forever",
    ],
    cta: "Start here",
    href: "/community",
  },
  {
    name: "Member",
    price: "€7",
    suffix: "/ month",
    feature: true,
    perks: [
      "Everything in Reader",
      "Members-only workshop & forum",
      "Two community calls a month",
      "Early access to new projects",
    ],
    cta: "Become a Member",
    href: "/community",
  },
  {
    name: "Supporter",
    price: "€29",
    suffix: "/ month",
    feature: false,
    perks: [
      "Everything in Member",
      "Direct line to the studio",
      "Name credited on what we ship",
      "Helps us stay independent",
    ],
    cta: "Support Megsy",
    href: "/community",
  },
];

function Pricing() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Membership</p>
      <h1 className="m-h1">Three honest <em>tiers</em>.</h1>
      <p className="m-lede">
        No trials, no A/B tests, no limited offers. Pick the tier that feels
        right, change it whenever, cancel whenever. The public work stays
        public either way.
      </p>

      <div className="m-grid" style={{ marginTop: 56 }}>
        {TIERS.map((t) => (
          <div key={t.name} className={`m-tier${t.feature ? " is-feature" : ""}`}>
            <div className="m-tier-name">{t.name}</div>
            <div className="m-tier-price">
              {t.price}
              {t.suffix && <small>{t.suffix}</small>}
            </div>
            <ul>
              {t.perks.map((p) => (
                <li key={p}>{p}</li>
              ))}
            </ul>
            <div style={{ marginTop: "auto", paddingTop: 12 }}>
              <Link to={t.href} className="m-btn">
                {t.cta} →
              </Link>
            </div>
          </div>
        ))}
      </div>

      <section className="m-section">
        <h2>Pay what <em>makes sense</em></h2>
        <p>
          If a paid tier isn't realistic where you live or what you do, just{" "}
          <Link to="/contact" style={{ color: "var(--m-accent)" }}>email us</Link>{" "}
          and we'll send a free code. No questions, no forms.
        </p>
      </section>
    </MegsyLayout>
  );
}
