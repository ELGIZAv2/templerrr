import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/open-source")({
  head: () => ({
    meta: [
      { title: "Open Source — Megsy" },
      { name: "description", content: "Megsy ships everything in the open." },
    ],
  }),
  component: OpenSource,
});

const REPOS = [
  { name: "megsy/handbook", body: "Our public handbook — how we run the studio, written in markdown for anyone to read or fork." },
  { name: "megsy/quiet-ui", body: "A small set of accessible React components we use across our own projects." },
  { name: "megsy/letters", body: "The static-site generator that powers Letters from Megsy. Tiny, plain, and easy to host." },
  { name: "megsy/notes", body: "A lightweight notes app we built for ourselves and ended up liking enough to share." },
];

function OpenSource() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">In the Open</p>
      <h1 className="m-h1">Free to read, <em>free to fork</em>.</h1>
      <p className="m-lede">
        Most of what we make at Megsy lives on a public repo. Permissive
        licenses, plain code, no surprise telemetry. Take what's useful.
      </p>

      <div className="m-grid">
        {REPOS.map((r) => (
          <div key={r.name} className="m-card">
            <div className="m-card-num">repo</div>
            <h3>{r.name}</h3>
            <p>{r.body}</p>
          </div>
        ))}
      </div>

      <div className="m-section">
        <Link to="/documentation" className="m-btn">Read the handbook →</Link>
      </div>
    </MegsyLayout>
  );
}
