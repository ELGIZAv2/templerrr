import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/documentation")({
  head: () => ({
    meta: [
      { title: "Handbook — Megsy" },
      { name: "description", content: "The Megsy handbook — how we work, what we use, and how to get started." },
    ],
  }),
  component: DocsPage,
});

const SECTIONS = [
  { num: "01", title: "Getting started", body: "A short tour of Megsy, what's here, and where to begin." },
  { num: "02", title: "How we work", body: "Our weekly rhythm, decision-making, and the rules we keep coming back to." },
  { num: "03", title: "Open projects", body: "How to follow along, file an issue, or contribute a small fix." },
  { num: "04", title: "Writing for Megsy", body: "Tone, structure, and the editorial choices behind the journal." },
  { num: "05", title: "Design tokens", body: "Colors, type, spacing, and the small details that make Megsy feel like Megsy." },
  { num: "06", title: "API reference", body: "Endpoints for the few public tools we maintain, with example calls." },
];

function DocsPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">The Handbook</p>
      <h1 className="m-h1">How Megsy <em>actually works</em>.</h1>
      <p className="m-lede">
        The handbook is everything we'd tell a new teammate on day one. If
        anything here is wrong or unclear, please{" "}
        <a href="/contact" style={{ color: "var(--m-accent)" }}>tell us</a>.
      </p>

      <div className="m-grid">
        {SECTIONS.map((s) => (
          <div className="m-card" key={s.num}>
            <div className="m-card-num">{s.num}</div>
            <h3>{s.title}</h3>
            <p>{s.body}</p>
          </div>
        ))}
      </div>
    </MegsyLayout>
  );
}
