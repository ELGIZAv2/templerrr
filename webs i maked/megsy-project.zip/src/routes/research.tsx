import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/research")({
  head: () => ({
    meta: [
      { title: "Research — Megsy" },
      { name: "description", content: "Open research from the Megsy collective." },
    ],
  }),
  component: ResearchPage,
});

const PAPERS = [
  {
    n: "2026.01",
    title: "Designing for boredom",
    body:
      "Notes from a year of building an interface that doesn't try to keep you. Why disengagement turned out to be the better metric.",
  },
  {
    n: "2025.04",
    title: "What people actually pay for",
    body:
      "A small survey of Megsy members on which paid features they value, which they don't, and which they'd rather not exist at all.",
  },
  {
    n: "2025.02",
    title: "Slow software, measured",
    body:
      "An honest attempt at a metric for software that rewards longevity, repairability and quiet over engagement and activity.",
  },
];

function ResearchPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Notes & Research</p>
      <h1 className="m-h1">Things we've <em>looked into</em>.</h1>
      <p className="m-lede">
        Short reports and longer essays from the studio. Everything is published
        under a permissive license, with notes, data, and the things we got wrong.
      </p>

      <div className="m-grid">
        {PAPERS.map((p) => (
          <div className="m-card" key={p.n}>
            <div className="m-card-num">{p.n}</div>
            <h3>{p.title}</h3>
            <p>{p.body}</p>
          </div>
        ))}
      </div>
    </MegsyLayout>
  );
}
