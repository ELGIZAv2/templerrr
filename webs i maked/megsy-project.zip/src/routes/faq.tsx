import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Megsy" },
      { name: "description", content: "Answers to common questions about the Megsy collective." },
      { property: "og:title", content: "FAQ — Megsy" },
      { property: "og:description", content: "Common questions about Megsy." },
    ],
  }),
  component: Faq,
});

const QA = [
  {
    q: "What does Megsy actually build?",
    a: "Open-source tools for measuring, routing and reducing the environmental cost of software — plus the field hardware that feeds them.",
  },
  {
    q: "Is Megsy a company, a charity, or a co-op?",
    a: "We are a worker-owned cooperative registered in Portugal. Roughly 70% of our funding comes from member contributions and consulting, 30% from research grants.",
  },
  {
    q: "Can I use your code in a commercial product?",
    a: "Yes. Most of our repositories are MIT or Apache 2.0. A small number of datasets are CC-BY-SA. Each repo states its license clearly.",
  },
  {
    q: "How do I join the collective?",
    a: "Members join in cohorts of 50, twice a year. Reserve a place from the Community page — we'll write to you when applications open.",
  },
  {
    q: "Do you take investment?",
    a: "No. We are deliberately uninvestable: the cooperative bylaws prevent equity dilution and external ownership.",
  },
  {
    q: "Are you hiring?",
    a: "We hire one or two people each year, very slowly, mostly from inside the collective. Open roles are posted on the Careers page.",
  },
  {
    q: "Where are you based?",
    a: "Lisbon, with field labs in the Galician coast, Patagonia and Nairobi. We host visitors at the Lisbon studio by appointment.",
  },
];

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Common Questions</p>
      <h1 className="m-h1">If you were <em>wondering</em>…</h1>
      <p className="m-lede">
        The questions we hear most often, answered as honestly as we can. Missing
        something? <a style={{ color: "var(--m-accent)" }} href="/contact">Write to us</a>.
      </p>

      <div className="m-section" style={{ maxWidth: 760 }}>
        {QA.map((item, i) => {
          const isOpen = open === i;
          return (
            <div className="m-faq-item" key={item.q}>
              <button
                type="button"
                className="m-faq-q"
                aria-expanded={isOpen}
                onClick={() => setOpen(isOpen ? null : i)}
              >
                <span>{item.q}</span>
                <span aria-hidden>+</span>
              </button>
              {isOpen && <div className="m-faq-a">{item.a}</div>}
            </div>
          );
        })}
      </div>
    </MegsyLayout>
  );
}
