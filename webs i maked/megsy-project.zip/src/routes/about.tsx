import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Megsy" },
      { name: "description", content: "The story behind Megsy: a small studio building software the slow way." },
      { property: "og:title", content: "About — Megsy" },
      { property: "og:description", content: "A small studio building software the slow way." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">The Story</p>
      <h1 className="m-h1">Started small. <em>Stayed small</em>.</h1>
      <p className="m-lede">
        Megsy started in 2023 as a side project between three friends who were
        tired of how the web had started to feel. Three years on, we're still
        small, still independent, and still here — which feels like the win.
      </p>

      <section className="m-section">
        <h2>The <em>shape</em> of it</h2>
        <p>
          Megsy is a studio of nine people. We work remotely across four
          timezones, meet in person twice a year, and ship things at the pace
          of human thought rather than human anxiety.
        </p>
        <p>
          We don't have investors, ad partners, or a growth team. We pay
          ourselves a steady salary, take real holidays, and try to leave the
          internet a little better than we found it.
        </p>
      </section>

      <section className="m-section">
        <h2>What we <em>refuse</em></h2>
        <ul className="m-list">
          <li><strong>No surveillance</strong>We don't sell, share, or rent your data.</li>
          <li><strong>No dark patterns</strong>If a flow needs a trick to work, we don't ship it.</li>
          <li><strong>No endless growth</strong>We cap our headcount and our revenue, on purpose.</li>
        </ul>
      </section>

      <div className="m-section">
        <Link to="/team" className="m-btn">Meet the team →</Link>
      </div>
    </MegsyLayout>
  );
}
