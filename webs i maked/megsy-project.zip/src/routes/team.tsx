import { createFileRoute } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/team")({
  head: () => ({
    meta: [
      { title: "Team — Megsy" },
      { name: "description", content: "The nine people behind Megsy." },
      { property: "og:title", content: "Team — Megsy" },
      { property: "og:description", content: "The nine people behind Megsy." },
    ],
  }),
  component: TeamPage,
});

const PEOPLE = [
  { name: "Lena Ashford", role: "Founder · Direction", bio: "Wrote the original Megsy notes. Still mostly answers the email." },
  { name: "Idris Okafor", role: "Engineering", bio: "Quiet systems, sturdy code, and very strong opinions about sleep." },
  { name: "Sofía Marín", role: "Research", bio: "Reads more papers than is reasonable. Writes the ones we publish." },
  { name: "Aki Tanaka", role: "Design", bio: "Type, motion, and small details. Keeper of the Megsy color palette." },
  { name: "Beatriz Costa", role: "Operations", bio: "Runs the studio. Runs the office cat. Runs marathons on weekends." },
  { name: "Yusuf Al-Rashid", role: "Community", bio: "Hosts our open calls and somehow remembers everyone's name." },
  { name: "Mira Holm", role: "Open Source", bio: "Reviews every pull request with kindness and a green pen." },
  { name: "Joaquim Vidal", role: "Editorial", bio: "Edits the journal, the handbook, and most of our worst sentences." },
  { name: "Sana Patel", role: "Support", bio: "First to reply, last to lose patience. Loves a clear bug report." },
];

function TeamPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">The People</p>
      <h1 className="m-h1">Nine humans, <em>one studio</em>.</h1>
      <p className="m-lede">
        We work remotely across four timezones, meet in person twice a year,
        and trust each other to do good work the rest of the time.
      </p>

      <div className="m-grid">
        {PEOPLE.map((p) => (
          <div key={p.name} className="m-card">
            <div className="m-card-num">{p.role}</div>
            <h3>{p.name}</h3>
            <p>{p.bio}</p>
          </div>
        ))}
      </div>
    </MegsyLayout>
  );
}
