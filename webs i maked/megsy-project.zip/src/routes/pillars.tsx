import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/pillars")({
  head: () => ({
    meta: [
      { title: "What We Stand For — Megsy" },
      { name: "description", content: "The three things Megsy is built on: Slow Craft, Open Heart, Living Systems." },
      { property: "og:title", content: "What We Stand For — Megsy" },
      { property: "og:description", content: "Slow Craft. Open Heart. Living Systems." },
    ],
  }),
  component: PillarsPage,
});

const PILLARS = [
  {
    n: "01",
    title: "Slow Craft",
    body:
      "We ship when it's ready. Every detail at Megsy is handled with the patience of someone who plans to stay around long enough to live with it.",
  },
  {
    n: "02",
    title: "Open Heart",
    body:
      "No dark patterns, no manufactured urgency, no growth at all costs. Megsy treats your attention like the rare and finite thing it actually is.",
  },
  {
    n: "03",
    title: "Living Systems",
    body:
      "Tools that grow with you instead of locking you in. Everything we make is built to be remixed, extended, and shaped by the people using it.",
  },
];

function PillarsPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">Three Things</p>
      <h1 className="m-h1">What Megsy <em>stands for</em>.</h1>
      <p className="m-lede">
        Three small commitments that hold the whole thing up. Every project,
        every page, every decision passes through these.
      </p>

      <div className="m-grid">
        {PILLARS.map((p) => (
          <div key={p.n} className="m-card">
            <div className="m-card-num">{p.n}</div>
            <h3>{p.title}</h3>
            <p>{p.body}</p>
          </div>
        ))}
      </div>

      <div className="m-section">
        <Link to="/impact" className="m-btn">See it in numbers →</Link>
      </div>
    </MegsyLayout>
  );
}
