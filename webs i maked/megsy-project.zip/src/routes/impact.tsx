import { createFileRoute, Link } from "@tanstack/react-router";
import { MegsyLayout } from "@/components/MegsyLayout";

export const Route = createFileRoute("/impact")({
  head: () => ({
    meta: [
      { title: "By the Numbers — Megsy" },
      { name: "description", content: "Members, projects, countries, and the things we don't do. Megsy in numbers." },
      { property: "og:title", content: "By the Numbers — Megsy" },
      { property: "og:description", content: "Megsy in numbers." },
    ],
  }),
  component: ImpactPage,
});

const STATS = [
  { num: "12k", unit: "Quiet Members" },
  { num: "320", unit: "Open Projects" },
  { num: "47", unit: "Countries" },
  { num: "0", unit: "Ads, Ever" },
];

function ImpactPage() {
  return (
    <MegsyLayout>
      <p className="m-eyebrow">The Field, in Numbers</p>
      <h1 className="m-h1">Receipts, not <em>hype</em>.</h1>
      <p className="m-lede">
        Numbers don't tell the whole story — but they keep us honest. Updated
        every season, public always, no vanity metrics.
      </p>

      <div className="m-stat-row">
        {STATS.map((s) => (
          <div key={s.unit}>
            <div className="m-stat-num">{s.num}</div>
            <div className="m-stat-unit">{s.unit}</div>
          </div>
        ))}
      </div>

      <section className="m-section">
        <h2>What we <em>count</em></h2>
        <p>
          We track the things that matter to us: people who actually show up,
          projects that are still alive a year later, contributors from outside
          our small circle. We don't track engagement, time-on-site, or any of
          the metrics that quietly make the web worse.
        </p>
        <p>
          The full breakdown lives in our handbook — including the projects we
          shelved and the ideas that didn't work.
        </p>
      </section>

      <div className="m-section">
        <Link to="/research" className="m-btn">Read the notes →</Link>
      </div>
    </MegsyLayout>
  );
}
