export type Product = {
  id: string;
  name: string;
  tagline: string;
  price: number;
  description: string;
  features: string[];
  image: string;
  category: string;
};

export const products: Product[] = [
  {
    id: "ergonomic-sofa",
    name: "megsy Ergonomic Sofa",
    tagline: "Sit Smarter. Work Better. Live Deeper.",
    price: 2499,
    description:
      "An ergonomic seating system that flows with your body. One fluid motion. Infinite positions between 90° and 160°.",
    features: [
      "Infinite recline 90°–160°",
      "Memory-shape foam core",
      "Italian leather finish",
      "10-year frame warranty",
    ],
    image: "/assets/pasted-image-2026-03-30T06-04-35.png",
    category: "Sofas",
  },
  {
    id: "lounge-chair",
    name: "megsy Lounge Chair",
    tagline: "Where focus meets repose.",
    price: 1299,
    description:
      "A sculptural lounge chair built around the natural curve of the spine. Designed for hours, made for years.",
    features: ["Solid oak frame", "Adjustable headrest", "Hand-stitched upholstery"],
    image: "/assets/pasted-image-2026-03-30T06-04-35.png",
    category: "Chairs",
  },
  {
    id: "work-desk",
    name: "megsy Work Desk",
    tagline: "A surface for deep work.",
    price: 1799,
    description:
      "Height-adjustable desk crafted from solid walnut. Cable management built in. Whisper-quiet motor.",
    features: ["Electric height adjust", "Solid walnut top", "Integrated cable tray"],
    image: "/assets/pasted-image-2026-03-30T06-04-35.png",
    category: "Desks",
  },
  {
    id: "task-light",
    name: "megsy Task Light",
    tagline: "Light that thinks with you.",
    price: 349,
    description:
      "Tunable warm-to-cool LED with a sensor that adapts to ambient light through the day.",
    features: ["2700K–6500K tunable", "Ambient light sensor", "Touch dimming"],
    image: "/assets/pasted-image-2026-03-30T06-04-35.png",
    category: "Lighting",
  },
  {
    id: "side-table",
    name: "megsy Side Table",
    tagline: "Quiet companion.",
    price: 549,
    description: "A minimalist side table with a soft-touch ceramic top.",
    features: ["Ceramic top", "Powder-coated steel base", "Anti-slip feet"],
    image: "/assets/pasted-image-2026-03-30T06-04-35.png",
    category: "Tables",
  },
  {
    id: "bookshelf",
    name: "megsy Modular Shelf",
    tagline: "Build your own gravity.",
    price: 999,
    description: "Modular oak shelving — configure, expand, rebuild.",
    features: ["Tool-free assembly", "Solid oak", "Wall-anchor included"],
    image: "/assets/pasted-image-2026-03-30T06-04-35.png",
    category: "Storage",
  },
];

export const getProduct = (id: string) => products.find((p) => p.id === id);