import { createFileRoute, Link } from "@tanstack/react-router";
import { ShopLayout } from "@/components/layout/shop-layout";
import { products } from "@/data/products";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "Products — megsy" },
      { name: "description", content: "Shop the full megsy collection of ergonomic furniture." },
    ],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  return (
    <ShopLayout>
      <div className="mb-12">
        <p className="text-xs uppercase tracking-[0.3em] text-primary">Collection</p>
        <h1 className="mt-3 font-serif text-5xl italic md:text-6xl">All Products</h1>
        <p className="mt-4 max-w-xl text-muted-foreground">
          Furniture engineered for the way you actually live. Sit smarter. Work better.
        </p>
      </div>
      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((p) => (
          <Link
            key={p.id}
            to="/products/$id"
            params={{ id: p.id }}
            className="group overflow-hidden rounded-lg border border-border/60 bg-card transition-colors hover:border-primary/60"
          >
            <div className="aspect-square overflow-hidden bg-secondary">
              <img
                src={p.image}
                alt={p.name}
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
            </div>
            <div className="p-5">
              <p className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
                {p.category}
              </p>
              <h3 className="mt-2 text-lg">{p.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{p.tagline}</p>
              <p className="mt-3 text-sm text-primary">${p.price.toLocaleString()}</p>
            </div>
          </Link>
        ))}
      </div>
    </ShopLayout>
  );
}