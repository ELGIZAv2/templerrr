import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ShopLayout } from "@/components/layout/shop-layout";
import { useCart } from "@/context/cart-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "Checkout — megsy" }] }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const { items, subtotal, clear } = useCart();
  const navigate = useNavigate();
  const [done, setDone] = useState(false);

  if (items.length === 0 && !done) {
    return (
      <ShopLayout>
        <h1 className="font-serif text-4xl italic">Checkout</h1>
        <p className="mt-4 text-muted-foreground">Your cart is empty.</p>
        <Link to="/products" className="mt-6 inline-block text-primary">Browse products →</Link>
      </ShopLayout>
    );
  }

  if (done) {
    return (
      <ShopLayout>
        <div className="py-16 text-center">
          <h1 className="font-serif text-5xl italic">Thank you</h1>
          <p className="mt-4 text-muted-foreground">Your order has been placed.</p>
          <Button className="mt-8" onClick={() => navigate({ to: "/" })}>Back home</Button>
        </div>
      </ShopLayout>
    );
  }

  return (
    <ShopLayout>
      <h1 className="mb-10 font-serif text-5xl italic">Checkout</h1>
      <div className="grid gap-12 lg:grid-cols-[1fr_360px]">
        <form
          onSubmit={(e) => { e.preventDefault(); clear(); setDone(true); }}
          className="space-y-6"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2"><Label htmlFor="fn">First name</Label><Input id="fn" required /></div>
            <div className="space-y-2"><Label htmlFor="ln">Last name</Label><Input id="ln" required /></div>
          </div>
          <div className="space-y-2"><Label htmlFor="em">Email</Label><Input id="em" type="email" required /></div>
          <div className="space-y-2"><Label htmlFor="ad">Address</Label><Input id="ad" required /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2"><Label htmlFor="ct">City</Label><Input id="ct" required /></div>
            <div className="space-y-2"><Label htmlFor="zp">Postal code</Label><Input id="zp" required /></div>
          </div>
          <div className="space-y-2"><Label htmlFor="cc">Card number</Label><Input id="cc" placeholder="4242 4242 4242 4242" required /></div>
          <Button type="submit" size="lg" className="w-full">Place order — ${subtotal.toLocaleString()}</Button>
        </form>
        <aside className="h-fit rounded-lg border border-border/60 bg-card p-6">
          <h2 className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Order</h2>
          <ul className="mt-4 space-y-3 text-sm">
            {items.map((i) => (
              <li key={i.id} className="flex justify-between">
                <span>{i.name} × {i.qty}</span>
                <span>${(i.price * i.qty).toLocaleString()}</span>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex justify-between border-t border-border/60 pt-4">
            <span>Total</span><span className="text-primary">${subtotal.toLocaleString()}</span>
          </div>
        </aside>
      </div>
    </ShopLayout>
  );
}
