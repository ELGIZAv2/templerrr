import { createFileRoute, Link } from "@tanstack/react-router";
import { ShopLayout } from "@/components/layout/shop-layout";
import { useCart } from "@/context/cart-context";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Cart — megsy" }] }),
  component: CartPage,
});

function CartPage() {
  const { items, setQty, remove, subtotal } = useCart();
  return (
    <ShopLayout>
      <h1 className="mb-10 font-serif text-5xl italic">Your Cart</h1>
      {items.length === 0 ? (
        <div className="rounded-lg border border-border/60 bg-card p-12 text-center">
          <p className="text-muted-foreground">Your cart is empty.</p>
          <Link to="/products" className="mt-4 inline-block text-primary">Browse products →</Link>
        </div>
      ) : (
        <div className="grid gap-12 lg:grid-cols-[1fr_360px]">
          <ul className="divide-y divide-border/60">
            {items.map((i) => (
              <li key={i.id} className="flex gap-4 py-6">
                <img src={i.image} alt={i.name} className="h-24 w-24 rounded-md object-cover" />
                <div className="flex flex-1 flex-col">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3>{i.name}</h3>
                      <p className="mt-1 text-sm text-muted-foreground">${i.price.toLocaleString()}</p>
                    </div>
                    <button onClick={() => remove(i.id)} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
                  </div>
                  <div className="mt-auto flex items-center gap-2">
                    <button onClick={() => setQty(i.id, i.qty - 1)} className="h-8 w-8 rounded border border-border text-muted-foreground hover:text-foreground">−</button>
                    <span className="w-8 text-center text-sm">{i.qty}</span>
                    <button onClick={() => setQty(i.id, i.qty + 1)} className="h-8 w-8 rounded border border-border text-muted-foreground hover:text-foreground">+</button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
          <aside className="h-fit rounded-lg border border-border/60 bg-card p-6">
            <h2 className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Summary</h2>
            <div className="mt-4 flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>${subtotal.toLocaleString()}</span></div>
            <div className="mt-2 flex justify-between text-sm"><span className="text-muted-foreground">Shipping</span><span>Free</span></div>
            <div className="mt-4 flex justify-between border-t border-border/60 pt-4"><span>Total</span><span className="text-primary">${subtotal.toLocaleString()}</span></div>
            <Link to="/checkout" className="mt-6 block"><Button size="lg" className="w-full">Checkout</Button></Link>
          </aside>
        </div>
      )}
    </ShopLayout>
  );
}