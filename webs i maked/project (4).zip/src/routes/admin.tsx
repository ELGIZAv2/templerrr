import { createFileRoute } from "@tanstack/react-router";
import { ShopLayout } from "@/components/layout/shop-layout";
import { products } from "@/data/products";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin — megsy" }] }),
  component: AdminPage,
});

function AdminPage() {
  const totalValue = products.reduce((s, p) => s + p.price, 0);
  return (
    <ShopLayout>
      <p className="text-xs uppercase tracking-[0.3em] text-primary">Dashboard</p>
      <h1 className="mt-3 font-serif text-5xl italic md:text-6xl">Admin</h1>

      <div className="mt-10 grid gap-6 sm:grid-cols-3">
        <Stat label="Products" value={products.length.toString()} />
        <Stat label="Catalog value" value={`$${totalValue.toLocaleString()}`} />
        <Stat label="Orders" value="0" />
      </div>

      <h2 className="mt-16 text-xs uppercase tracking-[0.25em] text-muted-foreground">Catalog</h2>
      <div className="mt-4 overflow-hidden rounded-lg border border-border/60">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-left text-xs uppercase tracking-[0.2em] text-muted-foreground">
            <tr><th className="px-4 py-3">Product</th><th className="px-4 py-3">Category</th><th className="px-4 py-3 text-right">Price</th></tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-t border-border/60">
                <td className="px-4 py-3">{p.name}</td>
                <td className="px-4 py-3 text-muted-foreground">{p.category}</td>
                <td className="px-4 py-3 text-right text-primary">${p.price.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </ShopLayout>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border/60 bg-card p-6">
      <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">{label}</div>
      <div className="mt-2 text-3xl font-serif italic">{value}</div>
    </div>
  );
}
