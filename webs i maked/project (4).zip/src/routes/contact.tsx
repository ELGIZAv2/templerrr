import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ShopLayout } from "@/components/layout/shop-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [{ title: "Contact — megsy" }] }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);
  return (
    <ShopLayout>
      <p className="text-xs uppercase tracking-[0.3em] text-primary">Get in touch</p>
      <h1 className="mt-3 font-serif text-5xl italic md:text-6xl">Contact</h1>
      <div className="mt-12 grid gap-12 lg:grid-cols-2">
        <div className="space-y-6 text-sm text-muted-foreground">
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-foreground">Email</div>
            <p className="mt-2">hello@megsy.com</p>
          </div>
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-foreground">Studio</div>
            <p className="mt-2">Cairo, Egypt</p>
          </div>
        </div>
        <form
          onSubmit={(e) => { e.preventDefault(); setSent(true); }}
          className="space-y-4 rounded-lg border border-border/60 bg-card p-6"
        >
          <div className="space-y-2"><Label htmlFor="name">Name</Label><Input id="name" required /></div>
          <div className="space-y-2"><Label htmlFor="email">Email</Label><Input id="email" type="email" required /></div>
          <div className="space-y-2"><Label htmlFor="msg">Message</Label><Textarea id="msg" rows={5} required /></div>
          <Button type="submit" size="lg" className="w-full">Send message</Button>
          {sent && <p className="text-sm text-primary">Thanks! We'll be in touch.</p>}
        </form>
      </div>
    </ShopLayout>
  );
}
