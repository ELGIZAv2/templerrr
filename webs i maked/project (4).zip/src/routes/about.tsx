import { createFileRoute } from "@tanstack/react-router";
import { ShopLayout } from "@/components/layout/shop-layout";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [{ title: "About — megsy" }] }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <ShopLayout>
      <p className="text-xs uppercase tracking-[0.3em] text-primary">Our Story</p>
      <h1 className="mt-3 font-serif text-5xl italic md:text-6xl">About megsy</h1>
      <div className="mt-10 max-w-3xl space-y-6 text-foreground/80 leading-relaxed">
        <p>
          megsy was born from a simple belief: the way you sit shapes the way you live.
          We design ergonomic furniture for people who spend most of their day at a desk,
          on a call, or deep in focus.
        </p>
        <p>
          Every piece is engineered around the human body — from cervical alignment to lumbar
          support — using premium materials built to last a decade and beyond.
        </p>
        <p>Sit Smarter. Work Better. Live Deeper.</p>
      </div>
    </ShopLayout>
  );
}
