import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ShopLayout } from "@/components/layout/shop-layout";
import { getProduct } from "@/data/products";
import { useCart } from "@/context/cart-context";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/products/$id")({
  component: ProductDetail,
});

function ProductDetail() {
  const { id } = Route.useParams();
  const product = getProduct(id);
  const { add } = useCart();
  const navigate = useNavigate();
  const [qty, setQty] = useState(1);

  if (!product) {
    return (
      <ShopLayout>
        <div className="py-24 text-center">
          <h1 className="text-3xl">Product not found</h1>
          <Link to="/products" className="mt-6 inline-block text-primary">← Back to products</Link>
        </div>
      </ShopLayout>
    );
  }

  return (
    <ShopLayout>
      <Link to="/products" className="text-xs uppercase tracking-[0.25em] text-muted-foreground hover:text-foreground">← Back</Link>
      <div className="mt-8 grid gap-12 lg:grid-cols-2">
        <div className="aspect-square overflow-hidden rounded-lg bg-secondary">
          <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-primary">{product.category}</p>
          <h1 className="mt-3 font-serif text-4xl italic md:text-5xl">{product.name}</h1>
          <p className="mt-3 text-muted-foreground">{product.tagline}</p>
          <p className="mt-6 text-3xl text-primary">${product.price.toLocaleString()}</p>
          <p className="mt-6 leading-relaxed text-foreground/80">{product.description}</p>
          <ul className="mt-6 space-y-2">
            {product.features.map((f) => (<li key={f} className="text-sm text-muted-foreground">— {f}</li>))}
          </ul>
          <div className="mt-8 flex items-center gap-4">
            <div className="flex items-center rounded-md border border-border">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-3 py-2 text-muted-foreground hover:text-foreground">−</button>
              <span className="w-10 text-center">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} className="px-3 py-2 text-muted-foreground hover:text-foreground">+</button>
            </div>
            <Button size="lg" onClick={() => { add({ id: product.id, name: product.name, price: product.price, image: product.image }, qty); navigate({ to: "/cart" }); }}>Add to Cart</Button>
          </div>
        </div>
      </div>
    </ShopLayout>
  );
}